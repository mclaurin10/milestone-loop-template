import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
const git=(args)=>execFileSync('git',args,{windowsHide:true});
const text=(args)=>git(args).toString('utf8').trim();
const directory='artifacts/orch-auth-01-c2/setup';await mkdir(directory,{recursive:true});
const files=['tools/qualification-vm-lifecycle.mjs','tools/qualification-vm-lifecycle.test.mjs','tools/milestone-orchestrator/config/test-ownership.json','docs/runtime-qualification/ORCH-AUTH-01-C2/prepare-inputs.py','docs/runtime-qualification/ORCH-AUTH-01-C2/freeze-inputs.mjs','docs/runtime-qualification/ORCH-AUTH-01-C2/linux-boundaries.mjs','docs/runtime-qualification/ORCH-AUTH-01-C2/run-lifecycle.ts','docs/runtime-qualification/ORCH-AUTH-01-C2/run-focused.ts'];
const source={head:text(['rev-parse','HEAD']),candidateTree:text(['write-tree']),sourceMode:'frozen-index',files:[]};
for(const path of files){const bytes=await readFile(path);source.files.push({path,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),gitBlob:text(['rev-parse',`:${path}`])});}
await writeFile(directory+'/source.patch',git(['diff','--cached','--binary']));await writeFile(directory+'/source.json',JSON.stringify(source,null,2)+'\n');process.stdout.write(JSON.stringify({head:source.head,tree:source.candidateTree,files:source.files.length})+'\n');
