import fs from 'node:fs/promises';
const inputs=JSON.parse(Buffer.from(process.argv[1],'base64url'));
const results=[];
for(const item of inputs){let processAbsent=false;try{process.kill(item.pid,0);}catch(e){if(e.code!=='ESRCH')throw e;processAbsent=true;}let directoryAbsent=false;try{await fs.lstat(item.directory);}catch(e){if(e.code!=='ENOENT')throw e;directoryAbsent=true;}results.push({...item,processAbsent,directoryAbsent});}
process.stdout.write(JSON.stringify({at:new Date().toISOString(),platform:process.platform,nodeVersion:process.version,uid:process.getuid(),results})+'\n');
