set -euo pipefail
mirror=/mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/orch-auth-01-b
task_dir=$(cat "$mirror/linux-task-path.txt")
cd "$task_dir/src"
cat artifacts/ob1/runtime.stdout.log
cat artifacts/ob1/runtime.stderr.log
cat artifacts/ob1/outer-audit/runtime-report.json
tar -czf "$mirror/linux-run-1.tar.gz" artifacts/ob1
