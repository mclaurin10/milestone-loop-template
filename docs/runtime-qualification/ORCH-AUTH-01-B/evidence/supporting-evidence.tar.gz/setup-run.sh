set -euo pipefail
export PATH=/home/duncan/oa1-CKn8x9/bin:/home/duncan/oa1-CKn8x9/node-v24.18.0-linux-x64/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export CI=true
mirror=/mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/orch-auth-01-b
task_dir=$(mktemp -d /home/duncan/ob1-XXXXXX)
printf '%s\n' "$task_dir" > "$mirror/linux-task-path.txt"
git clone --quiet --no-local --no-hardlinks /mnt/c/Dev/loop-extraction/milestone-loop-template "$task_dir/src"
cd "$task_dir/src"
test "$(git rev-parse HEAD)" = e01298be5cc76ad33f66a73870e5b6e9d1f661ef
git remote remove origin
git apply --index "$mirror/source.patch"
git -c user.name='Qualification fixture' -c user.email='qualification@example.invalid' commit --quiet -m 'qualification: freeze ORCH-AUTH-01-B source for contained planning'
test -z "$(git status --porcelain)"
mkdir -p artifacts/ob1/setup
cp "$mirror/source.patch" artifacts/ob1/setup/source.patch
git show --format=fuller --no-patch > artifacts/ob1/setup/source-commit.txt
git rev-parse HEAD HEAD^{tree} > artifacts/ob1/setup/source-identity.txt
pnpm install --offline --frozen-lockfile --package-import-method=copy > artifacts/ob1/setup/install.log 2>&1
pnpm exec tsx docs/runtime-qualification/ORCH-AUTH-01-B/run-runtime.ts artifacts/ob1 sha256:e405e2790e743243dd669f8e58eeaff6c585df3cbc77e9a4316a7f07b4e2eaad > artifacts/ob1/runtime.stdout.log 2> artifacts/ob1/runtime.stderr.log
