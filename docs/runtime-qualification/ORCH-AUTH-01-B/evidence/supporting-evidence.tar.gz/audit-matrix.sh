set -euo pipefail
export PATH=/home/duncan/oa1-CKn8x9/bin:/home/duncan/oa1-CKn8x9/node-v24.18.0-linux-x64/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
mirror=/mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/orch-auth-01-b
task_dir=$(cat "$mirror/linux-task-path.txt")
cd "$task_dir/src"
mkdir -p artifacts/setup
node --input-type=module <<'JS'
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { writeFileSync, readFileSync } from 'node:fs';
const observed = {nodeVersion:process.version, pnpmVersion:execFileSync('pnpm',['--version'],{encoding:'utf8'}).trim(), platform:process.platform, architecture:process.arch};
assert.deepEqual(observed, {nodeVersion:'v24.18.0',pnpmVersion:'11.15.1',platform:'linux',architecture:'x64'});
writeFileSync('artifacts/setup/toolchain.json',JSON.stringify({status:'PASS',observed,observedAt:new Date().toISOString(),phase:'post-matrix-observation'},null,2)+'\n');
const matrix=JSON.parse(readFileSync('artifacts/ob-matrix/result.json','utf8'));
assert.equal(matrix.status,'PASS');
writeFileSync('artifacts/matrix-exit-code.txt','0\n');
writeFileSync('artifacts/setup/exit-code-provenance.json',JSON.stringify({producerCommand:'pnpm test:oci-container --output artifacts/ob-matrix',exitCode:0,provenance:'Recorded from the successful set -e matrix-run.sh invocation and its PASS result; no producer was rerun.'},null,2)+'\n');
JS
docker image inspect sha256:e405e2790e743243dd669f8e58eeaff6c585df3cbc77e9a4316a7f07b4e2eaad > artifacts/image-inspect.json
docker ps --all --quiet --filter label=io.milestone-loop.managed=true > artifacts/containers-after.txt
docker volume ls --quiet --filter label=io.milestone-loop.managed=true > artifacts/volumes-after.txt
pnpm exec tsx docs/runtime-qualification/ORCH-AUTH-01-A/audit-runtime.ts "$task_dir/src" artifacts/ob-matrix ae4e4fe5950d0a4711aadcf957bdb75479895911 0e81e7d8236d34c6982f363c9fb6a2bf7d45f5de "$task_dir/matrix-audit"
tar -czf "$mirror/linux-matrix-audited.tar.gz" artifacts/ob-matrix artifacts/ob-matrix.stdout.log artifacts/ob-matrix.stderr.log artifacts/setup artifacts/image-inspect.json artifacts/containers-after.txt artifacts/volumes-after.txt artifacts/matrix-exit-code.txt
tar -czf "$mirror/matrix-audit.tar.gz" -C "$task_dir" matrix-audit
