set -euo pipefail
export PATH=/home/duncan/oa1-CKn8x9/bin:/home/duncan/oa1-CKn8x9/node-v24.18.0-linux-x64/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
mirror=/mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/orch-auth-01-b
task_dir=$(cat "$mirror/linux-task-path.txt")
cd "$task_dir/src"
cat artifacts/ob1/runtime.stdout.log
cat artifacts/ob1/runtime.stderr.log
git bundle create artifacts/ob1/setup/source.bundle e01298be5cc76ad33f66a73870e5b6e9d1f661ef..HEAD
tar -czf "$mirror/linux-run-2.tar.gz" artifacts/ob1
pnpm test:oci-container --output artifacts/ob-matrix > artifacts/ob-matrix.stdout.log 2> artifacts/ob-matrix.stderr.log
tar -czf "$mirror/linux-matrix.tar.gz" artifacts/ob-matrix artifacts/ob-matrix.stdout.log artifacts/ob-matrix.stderr.log
