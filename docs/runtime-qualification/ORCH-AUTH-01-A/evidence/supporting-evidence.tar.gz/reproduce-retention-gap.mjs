import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
const base = resolve('artifacts/orch-auth-01-a/entry-run/artifacts/oa1/matrix/cases/normal');
const aggregate = JSON.parse(await readFile(resolve(base, 'evidence/aggregate-proof.json'), 'utf8'));
const observations = [];
for (const artifact of aggregate.artifacts) {
  const path = resolve(base, 'workspace-artifacts', artifact.path.slice('artifacts/'.length));
  try {
    const bytes = await readFile(path);
    assert.equal(bytes.length, artifact.bytes);
    assert.equal(createHash('sha256').update(bytes).digest('hex'), artifact.sha256);
    observations.push({ artifact, retainedPath: path, status: 'PASS' });
  } catch (error) {
    observations.push({ artifact, retainedPath: path, status: 'FAIL', error: String(error) });
  }
}
const failed = observations.some(entry => entry.status !== 'PASS');
await writeFile('artifacts/orch-auth-01-a/retention-gap.json', JSON.stringify({ status: failed ? 'FAIL' : 'PASS', observations, completionEligible: false }, null, 2) + '\n');
console.log(JSON.stringify({ status: failed ? 'FAIL' : 'PASS', missingOrInvalid: observations.filter(entry => entry.status === 'FAIL').length }));
if (failed) process.exitCode = 1;
