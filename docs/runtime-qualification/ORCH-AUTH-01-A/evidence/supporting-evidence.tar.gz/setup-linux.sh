#!/usr/bin/env bash
set -euo pipefail
umask 022
task_root=$(mktemp -d /tmp/oa1-XXXXXX)
printf '%s\n' "$task_root" > /mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/orch-auth-01-a/linux-root.txt
exec > >(tee "$task_root/setup.log") 2>&1
printf 'Task root: %s\n' "$task_root"
date --iso-8601=seconds
mkdir "$task_root/downloads" "$task_root/bin"
cd "$task_root/downloads"
curl --fail --location --retry 2 --connect-timeout 20 --max-time 300 --output node-v24.18.0-linux-x64.tar.xz https://nodejs.org/dist/v24.18.0/node-v24.18.0-linux-x64.tar.xz
curl --fail --location --retry 2 --connect-timeout 20 --max-time 120 --output SHASUMS256.txt https://nodejs.org/dist/v24.18.0/SHASUMS256.txt
awk '$2 == "node-v24.18.0-linux-x64.tar.xz" { print }' SHASUMS256.txt > selected-sha256.txt
test "$(wc -l < selected-sha256.txt)" -eq 1
sha256sum --check selected-sha256.txt
tar -xJf node-v24.18.0-linux-x64.tar.xz -C "$task_root"
export PATH="$task_root/bin:$task_root/node-v24.18.0-linux-x64/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
node --version
npm install --prefix "$task_root/pnpm" --ignore-scripts --no-audit --no-fund --package-lock-only=false pnpm@11.15.1
ln -s "$task_root/pnpm/node_modules/pnpm/bin/pnpm.cjs" "$task_root/bin/pnpm"
test "$(node --version)" = v24.18.0
test "$(pnpm --version)" = 11.15.1
git clone --no-local --no-hardlinks --no-checkout /mnt/c/Dev/loop-extraction/milestone-loop-template "$task_root/src"
git -C "$task_root/src" remote remove origin
git -C "$task_root/src" config core.autocrlf false
git -C "$task_root/src" checkout -b codex/orch-auth-01-a-runtime 2ec1d253ffe26b6051c68abb545a8cddef417984
cd "$task_root/src"
test "$(git rev-parse HEAD)" = 2ec1d253ffe26b6051c68abb545a8cddef417984
test "$(git rev-parse 'HEAD^{tree}')" = 7ae1542586eeea382c46b5a38064f56f632d3e11
test -z "$(git status --porcelain=v1 --untracked-files=all)"
test ! -e .git/objects/info/alternates
test -z "$(git remote)"
test -z "$(git for-each-ref --format='%(refname)' refs/milestone-loop/)"
mkdir -p artifacts/oa1/setup
node tools/milestone-orchestrator/ci/assert-exact-toolchain.mjs --output artifacts/oa1/setup/toolchain.json
git rev-parse HEAD 'HEAD^{tree}' > artifacts/oa1/setup/source-identity.txt
git status --porcelain=v1 --untracked-files=all > artifacts/oa1/setup/source-status-before.txt
id > artifacts/oa1/setup/user.txt
uname -a > artifacts/oa1/setup/kernel.txt
cat /etc/os-release > artifacts/oa1/setup/os-release.txt
stat -c '%U:%G %a' /var/run/docker.sock > artifacts/oa1/setup/socket.txt
docker version > artifacts/oa1/setup/docker-version.txt
docker info > artifacts/oa1/setup/docker-info.txt
docker context show > artifacts/oa1/setup/docker-context.txt
docker ps --all --quiet --filter label=io.milestone-loop.managed=true > artifacts/oa1/setup/containers-before.txt
docker volume ls --quiet --filter label=io.milestone-loop.managed=true > artifacts/oa1/setup/volumes-before.txt
test ! -s artifacts/oa1/setup/containers-before.txt
test ! -s artifacts/oa1/setup/volumes-before.txt
pnpm install --frozen-lockfile --package-import-method=copy
fixture_fetch_dir=$(mktemp -d "$task_root/fetch-XXXXXX")
git archive HEAD:fixtures/oci-candidate | tar -x -C "$fixture_fetch_dir"
pnpm --dir "$fixture_fetch_dir" --ignore-workspace fetch --frozen-lockfile
pnpm store path > artifacts/oa1/setup/pnpm-store-path.txt
git status --porcelain=v1 --untracked-files=all > artifacts/oa1/setup/source-status-after.txt
test ! -s artifacts/oa1/setup/source-status-after.txt
sha256sum pnpm-lock.yaml fixtures/oci-candidate/pnpm-lock.yaml tools/milestone-orchestrator/container/Dockerfile > artifacts/oa1/setup/inputs-sha256.txt
date --iso-8601=seconds
printf 'Setup complete: %s\n' "$task_root/src"
