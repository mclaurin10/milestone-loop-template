#!/usr/bin/env bash
set -euo pipefail
task_root=/home/duncan/oa1-CKn8x9
export PATH="$task_root/bin:$task_root/node-v24.18.0-linux-x64/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
cd "$task_root/src"
test -z "$(git status --porcelain=v1 --untracked-files=all)"
git apply --index /mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/orch-auth-01-a/runtime-fix.patch
git diff --cached --check
test "$(git rev-parse HEAD)" = 2ec1d253ffe26b6051c68abb545a8cddef417984
test "$(git write-tree)" = 73050cad83ec0f312498792c47bd55bff5bea060
test -z "$(git diff --name-only)"
test ! -e artifacts/oa2
mkdir -p artifacts/oa2/setup
node tools/milestone-orchestrator/ci/assert-exact-toolchain.mjs --output artifacts/oa2/setup/toolchain.json
git rev-parse HEAD 'HEAD^{tree}' > artifacts/oa2/setup/source-head.txt
git write-tree > artifacts/oa2/setup/source-tree.txt
git status --porcelain=v1 --untracked-files=all > artifacts/oa2/setup/source-status-before.txt
git diff --cached --binary > artifacts/oa2/setup/source.patch
docker version > artifacts/oa2/setup/docker-version.txt
docker info > artifacts/oa2/setup/docker-info.txt
id > artifacts/oa2/setup/user.txt
uname -a > artifacts/oa2/setup/kernel.txt
stat -c '%U:%G %a' /var/run/docker.sock > artifacts/oa2/setup/socket.txt
pnpm store path > artifacts/oa2/setup/pnpm-store-path.txt
sha256sum pnpm-lock.yaml fixtures/oci-candidate/pnpm-lock.yaml tools/milestone-orchestrator/container/Dockerfile > artifacts/oa2/setup/inputs-sha256.txt
date --iso-8601=seconds > artifacts/oa2/matrix-started.txt
set +e
pnpm test:oci-container --output artifacts/oa2/matrix > artifacts/oa2/matrix.log 2>&1
matrix_exit=$?
set -e
printf '%s\n' "$matrix_exit" > artifacts/oa2/matrix-exit-code.txt
date --iso-8601=seconds > artifacts/oa2/matrix-finished.txt
cat artifacts/oa2/matrix.log
git status --porcelain=v1 --untracked-files=all > artifacts/oa2/source-status-after-matrix.txt
cmp artifacts/oa2/setup/source-status-before.txt artifacts/oa2/source-status-after-matrix.txt
test "$(git write-tree)" = 73050cad83ec0f312498792c47bd55bff5bea060
test -z "$(git diff --name-only)"
docker ps --all --quiet --filter label=io.milestone-loop.managed=true > artifacts/oa2/containers-after.txt
docker volume ls --quiet --filter label=io.milestone-loop.managed=true > artifacts/oa2/volumes-after.txt
image_id=$(node --input-type=module -e 'import fs from "node:fs"; const value=JSON.parse(fs.readFileSync("artifacts/oa2/matrix/result.json", "utf8")); console.log(value.image?.imageId ?? "")')
if test -n "$image_id"; then
  docker image inspect "$image_id" > artifacts/oa2/image-inspect.json
fi
cp /mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/orch-auth-01-a/run-retained-matrix.sh artifacts/oa2/setup/run-retained-matrix.sh
tar -czf /mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/orch-auth-01-a/linux-retained-evidence.tar.gz -C "$task_root/src" artifacts/oa2
sha256sum /mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/orch-auth-01-a/linux-retained-evidence.tar.gz
exit "$matrix_exit"
