#!/usr/bin/env bash
set -euo pipefail
task_root=/home/duncan/oa1-CKn8x9
export PATH="$task_root/bin:$task_root/node-v24.18.0-linux-x64/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
cd "$task_root/src"
test "$(git rev-parse HEAD)" = 2ec1d253ffe26b6051c68abb545a8cddef417984
test -z "$(git status --porcelain=v1 --untracked-files=all)"
test "$(node --version)" = v24.18.0
test "$(pnpm --version)" = 11.15.1
test ! -e artifacts/oa1/matrix
date --iso-8601=seconds > artifacts/oa1/matrix-started.txt
set +e
pnpm test:oci-container --output artifacts/oa1/matrix > artifacts/oa1/matrix.log 2>&1
matrix_exit=$?
set -e
printf '%s\n' "$matrix_exit" > artifacts/oa1/matrix-exit-code.txt
date --iso-8601=seconds > artifacts/oa1/matrix-finished.txt
cat artifacts/oa1/matrix.log
git status --porcelain=v1 --untracked-files=all > artifacts/oa1/source-status-after-matrix.txt
git rev-parse HEAD 'HEAD^{tree}' > artifacts/oa1/source-identity-after-matrix.txt
docker ps --all --quiet --filter label=io.milestone-loop.managed=true > artifacts/oa1/containers-after.txt
docker volume ls --quiet --filter label=io.milestone-loop.managed=true > artifacts/oa1/volumes-after.txt
image_id=$(node --input-type=module -e 'import fs from "node:fs"; const value=JSON.parse(fs.readFileSync("artifacts/oa1/matrix/result.json", "utf8")); console.log(value.image?.imageId ?? "")')
if test -n "$image_id"; then
  docker image inspect "$image_id" > artifacts/oa1/image-inspect.json
fi
cp "$task_root/setup.log" artifacts/oa1/setup/setup.log
cp "$task_root/downloads/selected-sha256.txt" artifacts/oa1/setup/node-sha256.txt
cp "$task_root/pnpm/package-lock.json" artifacts/oa1/setup/pnpm-installer-lock.json
cp /mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/orch-auth-01-a/run-matrix.sh artifacts/oa1/setup/run-matrix.sh
cp /mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/orch-auth-01-a/setup-linux-persistent.sh artifacts/oa1/setup/setup-linux-persistent.sh
tar -czf /mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/orch-auth-01-a/linux-evidence.tar.gz -C "$task_root/src" artifacts/oa1
sha256sum /mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/orch-auth-01-a/linux-evidence.tar.gz
exit "$matrix_exit"
