$ErrorActionPreference='Stop'
$taskRoot='C:\Dev\loop-extraction\milestone-loop-template'
$taskOutput=Join-Path $taskRoot 'artifacts/wp6e-source-publication-20260906/unborn-publication-focused-2/termination'
if(Test-Path -LiteralPath $taskOutput){throw 'Termination evidence must be fresh'}
$taskProcesses=@(Get-CimInstance Win32_Process)
$taskTarget=@($taskProcesses | Where-Object ProcessId -eq 12336)
if($taskTarget.Count -ne 1 -or $taskTarget[0].ParentProcessId -ne 16664 -or $taskTarget[0].Name -ne 'node.exe'){throw 'Owned Vitest supervisor identity changed'}
$taskTarget=$taskTarget[0]
if($taskTarget.CommandLine -notlike '*pnpm.js exec vitest run*' -or $taskTarget.CommandLine -notlike '*\.tools\wp6e-c6e-unborn-precommit-20260907\artifacts\c6e-native-retry-1\vitest-report.json'){throw 'Owned Vitest output binding changed'}
$taskParent=@($taskProcesses | Where-Object ProcessId -eq 16664)
if($taskParent.Count -ne 1 -or $taskParent[0].CommandLine -notlike '*artifacts/c6e-native-retry-tools/runtime/run-focused.ts*'){throw 'Owned receipt writer identity changed'}
$taskIds=@([uint32]$taskTarget.ProcessId)
do {
  $taskChildren=@($taskProcesses | Where-Object {$_.ParentProcessId -in $taskIds -and $_.ProcessId -notin $taskIds})
  $taskIds+=@($taskChildren.ProcessId)
} while($taskChildren.Count -gt 0)
$taskBefore=@($taskProcesses | Where-Object {$_.ProcessId -in $taskIds} | Select-Object ProcessId,ParentProcessId,Name,CreationDate,CommandLine)
$taskKiller=Join-Path $env:SystemRoot 'System32/taskkill.exe'
$taskLauncher=Get-Item -LiteralPath $taskKiller
New-Item -ItemType Directory -Path $taskOutput | Out-Null
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $taskOutput 'executed-stop.ps1')
[ordered]@{observedAt=[DateTime]::UtcNow.ToString('o');reason='Stop an invalid observation harness: inherited LOOP_VERIFY_STAGE_ID/COMMAND_ID changed nested receipt owners. Preserve partial failure evidence; no complete-suite or product-regression claim.';target=$taskTarget.ProcessId;parent=$taskParent[0].ProcessId;before=$taskBefore;launcher=[ordered]@{path=$taskLauncher.FullName;bytes=$taskLauncher.Length;sha256=(Get-FileHash -LiteralPath $taskKiller -Algorithm SHA256).Hash.ToLowerInvariant()};completionEligible=$false} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $taskOutput 'start.json')
& $taskKiller /PID $taskTarget.ProcessId /T /F 1> (Join-Path $taskOutput 'stdout.log') 2> (Join-Path $taskOutput 'stderr.log')
$taskExit=$LASTEXITCODE
$taskAfter=@(Get-CimInstance Win32_Process | Where-Object {$_.ProcessId -in $taskIds} | Select-Object ProcessId,ParentProcessId,Name,CreationDate,CommandLine)
[ordered]@{observedAt=[DateTime]::UtcNow.ToString('o');argv=@($taskKiller,'/PID',[string]$taskTarget.ProcessId,'/T','/F');exitCode=$taskExit;remaining=$taskAfter;completionEligible=$false} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $taskOutput 'result.json')
if($taskExit -ne 0){throw 'Owned task termination failed'}
[ordered]@{target=$taskTarget.ProcessId;exitCode=$taskExit;remaining=$taskAfter.Count;evidence=$taskOutput}|ConvertTo-Json -Compress
