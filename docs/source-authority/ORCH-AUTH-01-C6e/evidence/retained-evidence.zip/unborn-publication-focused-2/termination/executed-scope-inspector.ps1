$ErrorActionPreference='Stop'
$taskRoot=(Resolve-Path -LiteralPath 'C:\Dev\loop-extraction\milestone-loop-template').Path
$taskStop=Join-Path $taskRoot 'artifacts/wp6e-source-publication-20260906/unborn-publication-focused-2/termination'
$taskPrivate=Join-Path $taskRoot 'artifacts/wp6e-source-publication-20260906/retention-draft/overbroad-stop-inventory'
if(Test-Path -LiteralPath $taskPrivate){throw 'Private inventory destination must be fresh'}
$taskBefore=Get-Content -LiteralPath (Join-Path $taskStop 'start.json') -Raw | ConvertFrom-Json
$taskAfter=Get-Content -LiteralPath (Join-Path $taskStop 'result.json') -Raw | ConvertFrom-Json
if($taskBefore.target -ne 12336 -or $taskAfter.argv[2] -ne '12336' -or $taskAfter.exitCode -ne 0){throw 'Unexpected actual stop target'}
$taskOutput=Get-Content -LiteralPath (Join-Path $taskStop 'stdout.log') -Raw
$taskEdges=@([regex]::Matches($taskOutput,'SUCCESS: The process with PID (\d+) \(child process of PID (\d+)\) has been terminated\.') | ForEach-Object {[pscustomobject]@{pid=[int]$_.Groups[1].Value;parent=[int]$_.Groups[2].Value}})
if($taskEdges.Count -ne 8){throw 'Unexpected taskkill acknowledgement count'}
foreach($taskEdge in $taskEdges){
  $taskCurrent=[int]$taskEdge.pid
  $taskSeen=[Collections.Generic.HashSet[int]]::new()
  while($taskCurrent -ne 12336){
    if(-not $taskSeen.Add($taskCurrent)){throw 'Cycle in actual taskkill acknowledgement'}
    $taskMatch=@($taskEdges | Where-Object pid -eq $taskCurrent)
    if($taskMatch.Count -ne 1){throw 'Acknowledged process is not rooted at the declared target'}
    $taskCurrent=[int]$taskMatch[0].parent
  }
}
$taskIds=[Collections.Generic.HashSet[int]]::new()
foreach($taskEdge in $taskEdges){[void]$taskIds.Add([int]$taskEdge.pid)}
$taskRemaining=@(Get-CimInstance Win32_Process | Where-Object {$taskIds.Contains([int]$_.ProcessId)} | Select-Object ProcessId,ParentProcessId,Name,CreationDate)
if($taskRemaining.Count -ne 0){throw 'An acknowledged owned process is still present'}
New-Item -ItemType Directory -Path $taskPrivate | Out-Null
$taskExcluded=@()
foreach($taskName in @('start.json','result.json')){
  $taskFrom=(Resolve-Path -LiteralPath (Join-Path $taskStop $taskName)).Path
  $taskTo=[IO.Path]::GetFullPath((Join-Path $taskPrivate $taskName))
  if(-not $taskFrom.StartsWith($taskRoot+'\',[StringComparison]::OrdinalIgnoreCase) -or -not $taskTo.StartsWith($taskRoot+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Inventory move escaped workspace'}
  $taskInfo=Get-Item -LiteralPath $taskFrom
  $taskExcluded+=,[ordered]@{originalName=$taskName;bytes=$taskInfo.Length;sha256=(Get-FileHash -LiteralPath $taskFrom -Algorithm SHA256).Hash.ToLowerInvariant();preservedAt=$taskTo}
  Move-Item -LiteralPath $taskFrom -Destination $taskTo
}
[ordered]@{schemaVersion='owned-native-stop-observation.v1';observedAt=[DateTime]::UtcNow.ToString('o');target=12336;argv=$taskAfter.argv;exitCode=$taskAfter.exitCode;acknowledged=$taskEdges;remaining=$taskRemaining;source='Actual taskkill stdout and fresh numeric HashSet PID observation';collectorDefect=[ordered]@{beforeCount=$taskBefore.before.Count;afterCount=$taskAfter.remaining.Count;interpretation='The original PowerShell process inventory over-included unrelated records. These are not owned-process counts. Only the explicit PID 12336 tree was passed to taskkill. The overbroad raw snapshots remain private outside curation.'};excludedRawInventory=$taskExcluded;verificationClaim=$false;completionEligible=$false}|ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $taskStop 'scope-observation.json')
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $taskStop 'executed-scope-inspector.ps1')
[ordered]@{target=12336;acknowledged=$taskEdges.Count;remaining=$taskRemaining.Count;rawInventoryPreservedPrivately=$true}|ConvertTo-Json -Compress
