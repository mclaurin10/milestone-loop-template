import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {existsSync} from 'node:fs';
import {mkdir,readFile,realpath,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
const repository=await realpath(resolve(import.meta.dirname,'../../..'));
const clone=await realpath(resolve(repository,'.tools/wp6e-c6e-unborn-precommit-20260907'));
const target=resolve(clone,'artifacts/c6e-native-retry-tools/runtime');
assert(!existsSync(target));
const metadataBytes=await readFile(resolve(repository,'artifacts/wp6e-source-publication-20260906/precommit-unborn-source-input-1/source.json'));
const metadata=JSON.parse(metadataBytes.toString());
const git=(...args)=>{const r=spawnSync('git',['--no-optional-locks','-C',clone,...args],{encoding:'utf8',windowsHide:true,timeout:30000});assert(!r.error&&r.status===0&&r.signal===null,r.stderr);return r.stdout.trimEnd();};
assert.equal(git('rev-parse','HEAD'),metadata.source.commit);assert.equal(git('status','--porcelain'),'');
let runner=await readFile(resolve(repository,'docs/source-authority/ORCH-AUTH-01-C6b/run-focused.ts'),'utf8');
let reporter=await readFile(resolve(repository,'docs/source-authority/ORCH-AUTH-01-C6a/progress-reporter.mjs'),'utf8');
const hash=data=>createHash('sha256').update(data).digest('hex');
const originals={runner:hash(runner),reporter:hash(reporter)};
function replace(text,before,after){assert(text.includes(before),before);return text.replace(before,after);}
runner='import { createHash } from "node:crypto";\n'+runner;
runner=replace(runner,'const files = process.argv.slice(2).map((name) => name);',`const expectedSource = JSON.parse(await readFile(resolve(import.meta.dirname, "source-input.json"), "utf8"));
const files = process.argv.slice(2).map((name) => name);`);
runner=replace(runner,'try {\n  const identity',`async function observeInput(phase: string) {
  const identity = await commandIdentity(context.repositoryRoot);
  assert.equal(identity.gitCommit, expectedSource.source.commit);
  assert.equal(identity.gitTree, expectedSource.source.tree);
  assert.equal(identity.gitStatus, "");
  const pins = [];
  for (const pin of expectedSource.pins) {
    const bytes = await readFile(resolve(context.repositoryRoot, pin.path));
    const actual = {path: pin.path, bytes: bytes.length, sha256: createHash("sha256").update(bytes).digest("hex")};
    assert.deepEqual(actual, pin);
    pins.push(actual);
  }
  assert.equal(pins.length, 331);
  await writeFile(resolve(context.artifactDirectory, "input-" + phase + ".json"), JSON.stringify({observedAt:new Date().toISOString(),identity,pins,completionEligible:false},null,2)+"\\n",{flag:"wx"});
}
try {
  await observeInput("before");
  for (const [from,to] of [[import.meta.filename,"executed-runner.ts"],[resolve(import.meta.dirname,"progress-reporter.mjs"),"executed-reporter.mjs"],[resolve(import.meta.dirname,"source-input.json"),"expected-source.json"]]) await writeFile(resolve(context.artifactDirectory,to),await readFile(from),{flag:"wx"});
  const identity`);
runner=replace(runner,'--reporter=./docs/source-authority/ORCH-AUTH-01-C6a/progress-reporter.mjs','--reporter=./artifacts/c6e-native-retry-tools/runtime/progress-reporter.mjs');
runner=replace(runner,'  const artifacts = [','  const artifacts = [\n    ...["input-before.json","input-after.json","executed-runner.ts","executed-reporter.mjs","expected-source.json"].map(path => ({path,kind:"source-native-retry-input"})),');
runner=replace(runner,'  assertCommandPassed(result, "Source scope regressions");','  await observeInput("after");\n  assertCommandPassed(result, "Source scope regressions");');
reporter=replace(reporter,'      state: test.result().state,','      state: test.result().state,\n      errors: (test.result().errors ?? []).map(error => ({ name: error.name, message: error.message, stack: error.stack })),');
await mkdir(target,{recursive:true});
await writeFile(resolve(target,'run-focused.ts'),runner,{flag:'wx'});
await writeFile(resolve(target,'progress-reporter.mjs'),reporter,{flag:'wx'});
await writeFile(resolve(target,'source-input.json'),metadataBytes,{flag:'wx'});
await writeFile(resolve(target,'preparation.json'),JSON.stringify({preparedAt:new Date().toISOString(),source:metadata.source,originals,runnerSha256:hash(runner),reporterSha256:hash(reporter),sourceChecksExecuted:false,completionEligible:false},null,2)+'\n',{flag:'wx'});
assert.equal(git('status','--porcelain'),'');
console.log(JSON.stringify({target,source:metadata.source,sourceChecksExecuted:false}));
