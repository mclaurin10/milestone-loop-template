import { createHash } from "node:crypto";
import assert from "node:assert/strict";
import { readFile, writeFile } from "node:fs/promises";
import { relative, resolve } from "node:path";
import {
  evidenceContext,
  commandIdentity,
  runPnpm,
  assertCommandPassed,
  writeReceipt,
  writeManualEvidenceFailure,
  FULL_SUITE_EVIDENCE_TIMEOUT_MS,
} from "../../../tools/evidence.mjs";
import {
  beginTestRunMeasurement,
  describeVitestReport,
} from "../../../tools/milestone-orchestrator/src/test-run-summary.js";
import { validateCommandReceiptDirectory } from "../../../tools/milestone-orchestrator/src/verifier.js";

const expectedSource = JSON.parse(await readFile(resolve(import.meta.dirname, "source-input.json"), "utf8"));
const files = process.argv.slice(2).map((name) => name);
assert(files.length > 0);
const context = await evidenceContext(
  "orch-auth-01-c6b",
  "source-scope-focused",
);
async function observeInput(phase: string) {
  const identity = await commandIdentity(context.repositoryRoot);
  assert.equal(identity.gitCommit, expectedSource.source.commit);
  assert.equal(identity.gitTree, expectedSource.source.tree);
  assert.equal(identity.gitStatus, "");
  const pins = [];
  for (const pin of expectedSource.pins) {
    const bytes = await readFile(resolve(context.repositoryRoot, pin.path));
    const actual = {path: pin.path, bytes: bytes.length, sha256: createHash("sha256").update(bytes).digest("hex")};
    assert.deepEqual(actual, pin);
    pins.push(actual);
  }
  assert.equal(pins.length, 331);
  await writeFile(resolve(context.artifactDirectory, "input-" + phase + ".json"), JSON.stringify({observedAt:new Date().toISOString(),identity,pins,completionEligible:false},null,2)+"\n",{flag:"wx"});
}
try {
  await observeInput("before");
  for (const [from,to] of [[import.meta.filename,"executed-runner.ts"],[resolve(import.meta.dirname,"progress-reporter.mjs"),"executed-reporter.mjs"],[resolve(import.meta.dirname,"source-input.json"),"expected-source.json"]]) await writeFile(resolve(context.artifactDirectory,to),await readFile(from),{flag:"wx"});
  const identity = await commandIdentity(context.repositoryRoot);
  assert.equal(identity.nodeVersion, "v24.18.0");
  assert.equal(identity.pnpmVersion, "11.15.1");
  const measurement = await beginTestRunMeasurement({
    artifactDirectory: context.artifactDirectory,
    runId: context.manualEvidence.manifestId,
    stageId: context.stageId,
    commandId: context.commandId,
    role: "legacy",
    owner: null,
    identity: {
      gitCommit: identity.gitCommit,
      gitTree: identity.gitTree,
      workingTreeDirty: identity.gitStatus !== "",
      nodeVersion: identity.nodeVersion,
      pnpmVersion: identity.pnpmVersion,
    },
  });
  const rawPath = resolve(context.artifactDirectory, "vitest-report.json");
  const progressPath = resolve(context.artifactDirectory, "progress.jsonl");
  const argv = [
    "exec",
    "vitest",
    "run",
    "--config",
    "vitest.config.ts",
    ...files,
    "--fileParallelism=false",
    "--reporter=verbose",
    "--reporter=json",
    "--reporter=./artifacts/c6e-native-retry-tools/runtime/progress-reporter.mjs",
    `--outputFile=${rawPath}`,
  ];
  measurement.markSetupFinished();
  const result = await runPnpm(argv, {
    timeoutMs: FULL_SUITE_EVIDENCE_TIMEOUT_MS,
    env: {
      ...measurement.probeEnvironment,
      C6A_FOCUSED_PROGRESS: progressPath,
    },
    processStartupObserver: (value) => measurement.observeProcessStartup(value),
  });
  await writeFile(
    resolve(context.artifactDirectory, "child-execution.json"),
    JSON.stringify(
      {
        identity,
        argv: ["pnpm", ...argv],
        files,
        exitCode: result.status,
        signal: result.signal,
        supervision: result.supervision ?? null,
      },
      null,
      2,
    ) + "\n",
  );
  const artifacts = [
    ...["input-before.json","input-after.json","executed-runner.ts","executed-reporter.mjs","expected-source.json"].map(path => ({path,kind:"source-native-retry-input"})),
    {
      path: "vitest-report.json",
      kind: "source-scope-focused-vitest-report",
    },
    { path: "test-run-summary.json", kind: "test-run-summary" },
    { path: "execution.json", kind: "source-scope-focused-execution" },
    { path: "progress.jsonl", kind: "source-scope-focused-progress" },
    { path: "child-execution.json", kind: "source-scope-child-execution" },
  ];
  for (const name of ["stdout", "stderr"] as const) {
    const bytes = result[name] ?? "";
    await writeFile(resolve(context.artifactDirectory, `${name}.log`), bytes);
    if (bytes.length)
      artifacts.push({
        path: `${name}.log`,
        kind: `source-scope-focused-${name}`,
      });
  }
  await observeInput("after");
  assertCommandPassed(result, "Source scope regressions");
  const raw = JSON.parse(await readFile(rawPath, "utf8"));
  assert(raw.numTotalTests > 0);
  assert.equal(raw.numPassedTests, raw.numTotalTests);
  assert.equal(raw.numFailedTests, 0);
  assert.equal(raw.numPendingTests, 0);
  assert.deepEqual(
    raw.testResults
      .map((file) =>
        relative(context.repositoryRoot, file.name).replaceAll("\\", "/"),
      )
      .sort(),
    [...files].sort(),
  );
  assert(
    raw.testResults.every((file) =>
      file.assertionResults.every((test) => test.status === "passed"),
    ),
  );
  await measurement.finish([
    await describeVitestReport({
      artifactDirectory: context.artifactDirectory,
      reportPath: rawPath,
    }),
  ]);
  await writeFile(
    resolve(context.artifactDirectory, "execution.json"),
    JSON.stringify(
      {
        schemaVersion: "source-scope-focused-execution.v1",
        completionEligible: false,
        identity,
        argv: ["pnpm", ...argv],
        tests: raw.numTotalTests,
        files,
      },
      null,
      2,
    ) + "\n",
  );
  await writeReceipt(
    context,
    [
      {
        id: "focused-regressions-executed",
        summary:
          "Every requested test file executed completely, with no failed or skipped tests, using the production measurement probe and original deadlines.",
      },
    ],
    artifacts,
  );
  const receipt = await validateCommandReceiptDirectory({
    directory: context.artifactDirectory,
    expectedStageId: context.stageId,
    expectedCommandId: context.commandId,
    requiredKinds: artifacts.slice(0, 3).map(({ kind }) => kind),
  });
  process.stdout.write(
    JSON.stringify({
      tests: raw.numTotalTests,
      receipt: receipt.receiptPath,
      sha256: receipt.receiptSha256,
    }) + "\n",
  );
} catch (error) {
  await writeManualEvidenceFailure(context, {
    kind: "product",
    message: error instanceof Error ? error.message : String(error),
  });
  throw error;
}
