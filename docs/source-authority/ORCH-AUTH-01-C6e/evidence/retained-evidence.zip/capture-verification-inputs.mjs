import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { lstat,readFile,writeFile,mkdir,realpath } from 'node:fs/promises';
import { resolve,dirname } from 'node:path';

// Observation only, deliberately no PASS/verification receipt. This runs during
// a frozen test invocation using read-only Git operations; the later sequential
// evidence audit must verify the observation and all input hashes independently.
const root=await realpath(process.cwd());
assert.equal(process.version,'v24.18.0');
const output=resolve(root,'artifacts/wp6e-source-publication-20260906/recovery-publication-inputs-1');
await mkdir(output,{recursive:false});
const startedAt=new Date().toISOString();
const git=(...args)=>{
 const result=spawnSync('git',['--no-optional-locks','-C',root,...args],{windowsHide:true,timeout:30000,maxBuffer:64*1024*1024});
 assert(!result.error && result.status===0 && result.signal===null,result.stderr?.toString());
 return result.stdout;
};
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const identity=git('rev-parse','HEAD','HEAD^{tree}','--symbolic-full-name','HEAD');
const tracked=git('ls-files','--cached','-z').toString().split('\0').filter(Boolean);
const untracked=git('ls-files','--others','--exclude-standard','-z').toString().split('\0').filter(Boolean);
const index=git('ls-files','--stage','-z');
const patch=git('diff','--binary','--full-index','HEAD','--');
await writeFile(resolve(output,'tracked.patch'),patch);
await writeFile(resolve(output,'index-entries.bin'),index);
await writeFile(resolve(output,'executed-capture.mjs'),await readFile(import.meta.filename));
const excluded='Implementation-ready improvement plan 8-5-26.txt';
const files=[];
for(const path of [...new Set([...tracked,...untracked])].sort()) {
 assert(!path.startsWith('/') && !path.split('/').includes('..'));
 if(untracked.includes(path) && path!==excluded) assert(path.startsWith('tools/milestone-orchestrator/'),'Unexpected unrelated untracked input: '+path);
 const absolute=resolve(root,path),info=await lstat(absolute);
 assert(info.isFile() && !info.isSymbolicLink());
 assert.equal(await realpath(absolute),absolute);
 const digest=createHash('sha256');
 for await (const chunk of createReadStream(absolute)) digest.update(chunk);
 const sha256=digest.digest('hex');
 const isUntracked=untracked.includes(path);
 if(path===excluded) assert.equal(sha256,'53ea98fb1cb880163a02d3b1d9365963e3fe891025ae3630f00bd4c9232293b1');
 if(isUntracked && path!==excluded) {
  const target=resolve(output,'untracked',path);
  await mkdir(dirname(target),{recursive:true});
  const content=await readFile(absolute);
  assert.equal(hash(content),sha256);
  await writeFile(target,content);
 }
 files.push({path,bytes:info.size,sha256,tracked:!isUntracked,excludedFromCommit:path===excluded});
}
assert(git('rev-parse','HEAD','HEAD^{tree}','--symbolic-full-name','HEAD').equals(identity));
assert(git('ls-files','--stage','-z').equals(index));
assert(git('diff','--binary','--full-index','HEAD','--').equals(patch));
assert.deepEqual(git('ls-files','--others','--exclude-standard','-z').toString().split('\0').filter(Boolean),untracked);
const report={schemaVersion:'wp6e-verification-input-observation.v1',claim:'Read-only input capture during the frozen recovery-publication-focused-1 run; test results and completion are not asserted',verificationClaim:false,completionEligible:false,startedAt,finishedAt:new Date().toISOString(),root,gitIdentity:identity.toString().trimEnd().split('\n'),node:{version:process.version,executable:process.execPath,platform:process.platform,architecture:process.arch},index:{path:'index-entries.bin',bytes:index.length,sha256:hash(index)},trackedPatch:{path:'tracked.patch',bytes:patch.length,sha256:hash(patch)},files};
await writeFile(resolve(output,'inputs.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({observation:output,files:files.length,verificationClaim:false}));
