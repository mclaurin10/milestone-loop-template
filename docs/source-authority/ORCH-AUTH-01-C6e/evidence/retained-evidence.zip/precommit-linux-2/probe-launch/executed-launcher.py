"""Launch only this prepared, unprivileged task in a transient isolated unit."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

evidence=Path('/mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/wp6e-source-publication-20260906')
receiver=evidence/'precommit-linux-2'
metadata=json.loads((receiver/'preparation.json').read_bytes())
root=Path(metadata['root']).resolve(strict=True)
mode=sys.argv[1]
assert os.getuid()==0 and len(sys.argv)==2 and mode in ('probe','verify')
assert root.parent==Path('/home/duncan') and root.name.startswith('c6e-linux-precommit-')
assert json.loads((root/'input/preparation.json').read_bytes())==metadata
assert hashlib.sha256(Path(metadata['worker']['path']).read_bytes()).hexdigest()==metadata['worker']['sha256']
launchers=json.loads((evidence/'linux-namespace-launchers-1.json').read_bytes())['launchers']
for item in launchers:
    path=Path(item['path']).resolve(strict=True)
    assert str(path)==item['canonical'] and path.stat().st_size==item['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
output=receiver/(mode+'-launch')
assert not output.exists()
output.mkdir()
(output/'executed-launcher.py').write_bytes(Path(__file__).read_bytes())
unit='orch-c6e-source-'+str(uuid.uuid4())+'.service'
dependency=metadata['dependencyRoot']
properties=['User=1000','Group=1000','SupplementaryGroups=','MemoryMax=8G','MemorySwapMax=0','CPUQuota=400%','TasksMax=1024','RuntimeMaxSec=28800','TimeoutStopSec=10','KillMode=control-group','LimitFSIZE=2147483648','LimitCORE=0','NoNewPrivileges=yes','CapabilityBoundingSet=','PrivateNetwork=yes','PrivateMounts=yes','PrivateTmp=yes','PrivateDevices=yes','ProtectSystem=strict','ProtectHome=tmpfs','ProtectControlGroups=yes','RestrictSUIDSGID=yes','RestrictAddressFamilies=AF_UNIX AF_INET AF_INET6 AF_NETLINK','InaccessiblePaths=/mnt /root -/run/docker.sock -/var/run/docker.sock -/run/containerd -/var/lib/docker','BindPaths='+str(root)+' '+dependency+'/store '+dependency+'/cache','BindReadOnlyPaths='+dependency+'/bin '+dependency+'/pnpm '+metadata['runtimeRoot'],'ReadWritePaths='+str(root)+' '+dependency+'/store '+dependency+'/cache']
argv=['/usr/bin/systemd-run','--wait','--collect','--pipe','--quiet','--unit='+unit]
for prop in properties:argv+=['--property='+prop]
argv+=['--working-directory='+str(root),'/usr/bin/python3.12',metadata['worker']['path'],str(root),mode]
start=time.time_ns();clock=time.monotonic_ns()
observation={'argv':argv,'unit':unit,'properties':properties,'source':metadata['source'],'parentNamespaces':{kind:os.readlink('/proc/self/ns/'+kind) for kind in ('mnt','net')},'startedEpochNanoseconds':str(start),'qualificationClaim':False,'completionEligible':False}
(output/'start.json').write_text(json.dumps(observation,indent=2)+'\n')
with (output/'stdout.log').open('xb') as stdout,(output/'stderr.log').open('xb') as stderr:
    result=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=28920)
after=subprocess.run(['/usr/bin/systemctl','show',unit,'--property=LoadState,ActiveState,SubState,MainPID,ControlGroup'],capture_output=True,timeout=30)
final={**observation,'exitCode':result.returncode,'durationMs':round((time.monotonic_ns()-clock)/1e6),'unitAfter':{'exitCode':after.returncode,'stdout':after.stdout.decode(),'stderr':after.stderr.decode()},'cgroupAbsent':not (Path('/sys/fs/cgroup/system.slice')/unit).exists()}
(output/'execution.json').write_text(json.dumps(final,indent=2)+'\n')
assert b'MainPID=0' in after.stdout and final['cgroupAbsent']
print(json.dumps({'mode':mode,'exitCode':result.returncode,'unit':unit,'cgroupAbsent':final['cgroupAbsent'],'completionEligible':False}),flush=True)
sys.exit(result.returncode)
