import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { evidenceContext, writeReceipt, writeManualEvidenceFailure } from '../../../tools/evidence.mjs';
import { sourceHistoricalFiles } from '../../../tools/milestone-orchestrator/src/source-authority-evidence.mjs';
import { validateCommandReceiptDirectory } from '../../../tools/milestone-orchestrator/src/verifier.js';

const root=resolve(import.meta.dirname,'../../..');
const evidence=resolve(root,'artifacts/wp6e-source-publication-20260906');
const input=resolve(evidence,'cache-runtime-diagnostic-1');
const output=resolve(evidence,'cache-runtime-report-audit-1');
assert(!existsSync(output));
process.env.LOOP_VERIFY_COMMAND_ARTIFACT_DIR=output;
const context=await evidenceContext('orch-auth-01-c6e','sanitized-offline-cache-runtime-audit');
const hash=(data:Uint8Array)=>createHash('sha256').update(data).digest('hex');
const json=async(path:string)=>JSON.parse(await readFile(resolve(input,path),'utf8'));
try {
  const prepared=await json('preparation.json');
  const observed=await json('verify/observation.json');
  const collected=await json('collection.json');
  const source={commit:'1c386ec95b628a2323f8d5dab351ad72a59abe3a',tree:'4e4d2ae0eae69784263f6d18668c5bb070f94c62',branch:'refs/heads/master',status:''};
  for(const row of [prepared,observed,collected])assert.deepEqual(row.source,source);
  assert.equal(prepared.pins.length,331);
  assert.deepEqual(prepared.pins,observed.pins);
  assert.deepEqual(prepared.pins,collected.pins);
  const historical=sourceHistoricalFiles(resolve(root,'.tools/wp6e-c6e-precommit-20260906'),source.commit,prepared.pins.map((pin:{path:string})=>pin.path));
  for(const pin of prepared.pins){const bytes=historical.get(pin.path)!;assert(bytes,pin.path);assert.equal(bytes.length,pin.bytes,pin.path);assert.equal(hash(bytes),pin.sha256,pin.path);}
  assert.equal(collected.executionExitCode,0);
  assert.equal(collected.pinsUnchanged,true);assert.equal(collected.sourceStateAbsent,true);
  assert.deepEqual(collected.gitAfter.map((row:{stdout:string})=>row.stdout.trim()),[source.commit,source.tree,source.branch,'','']);
  assert(collected.gitAfter.every((row:{exitCode:number;stderr:string})=>row.exitCode===0&&row.stderr===''));
  assert.equal(observed.status,'COMPLETED_REQUIRES_INDEPENDENT_AUDIT');
  for(const key of ['actualImplementationAudit','actualCandidate','actualDockerExecution','sourceStateAdopted','completionEligible'])assert.equal(observed[key],false);
  assert.equal(observed.privateReferencesAbsent,true);
  const worker=await readFile(resolve(input,'executed-worker.py'));
  assert.equal(worker.length,prepared.worker.bytes);assert.equal(hash(worker),prepared.worker.sha256);
  assert(worker.toString().includes("assert os.path.samefile(root/'account','/home/duncan')"));
  const configPath='\\\\wsl.localhost\\Ubuntu'+(prepared.root+'/account/.config/pnpm/config.yaml').replaceAll('/','\\');
  const config=await readFile(configPath);
  assert.equal(config.toString(),`enableGlobalVirtualStore: false\nstoreDir: ${prepared.dependencyRoot}/store\ncacheDir: ${prepared.dependencyRoot}/cache\n`);
  await writeFile(resolve(output,'owned-account-config.yaml'),config,{flag:'wx'});
  for(const mode of ['probe','verify']){
    const launch=await json(mode+'-launch/execution.json');
    const ns=await json(mode==='probe'?'probe-namespace.json':'verify/namespace.json');
    assert.equal(launch.exitCode,0);assert.equal(launch.cgroupAbsent,true);
    assert.match(launch.unitAfter.stdout,/^MainPID=0$/m);assert.match(launch.unitAfter.stdout,/^ActiveState=inactive$/m);assert.match(launch.unitAfter.stdout,/^ControlGroup=$/m);
    assert(launch.properties.includes(`BindPaths=${prepared.root}/account:/home/duncan ${prepared.root} ${prepared.dependencyRoot}/store ${prepared.dependencyRoot}/cache`));
    for(const property of ['User=1000','Group=1000','RuntimeMaxSec=28800','NoNewPrivileges=yes','CapabilityBoundingSet=','PrivateNetwork=yes','PrivateMounts=yes','ProtectHome=tmpfs'])assert(launch.properties.includes(property));
    assert.deepEqual(ns.source,source);assert.equal(ns.uid,1000);assert.equal(ns.gid,1000);
    assert.deepEqual(ns.interfaces,['lo']);assert.equal(ns.loopbackConnectionPassed,true);
    for(const kind of ['mnt','net'])assert.notEqual(ns.namespaceIds[kind],launch.parentNamespaces[kind]);
    assert(ns.dockerSocketDenials.every((row:{errno:number})=>[2,13,88].includes(row.errno)));
    assert.deepEqual(ns.resources,{'memory.max':'8589934592\n','memory.swap.max':'0\n','cpu.max':'400000 100000\n','pids.max':'1024\n'});
  }
  const fixture='tools/milestone-orchestrator/src/candidate-package-runtime.test.ts';
  const command=await json('verify/candidate-runtime.execution.json');
  assert.deepEqual(observed.commands,[command]);
  assert.deepEqual(command.argv,[prepared.dependencyRoot+'/bin/pnpm','--config.verify-deps-before-run=error','exec','tsx','docs/source-authority/ORCH-AUTH-01-C6b/run-focused.ts',fixture]);
  for(const name of ['install','candidate-runtime']){
    const execution=await json('verify/'+name+'.execution.json');
    assert.equal(execution.exitCode,0);assert.equal(execution.timedOut,false);assert.equal(execution.outputLimitExceeded,false);
    assert.equal(execution.cwd,prepared.root+'/source');assert.equal(execution.uid,1000);
    assert(BigInt(execution.finishedEpochNanoseconds)>BigInt(execution.startedEpochNanoseconds));
    assert(execution.durationMs>0&&execution.durationMs<execution.outerTimeoutMs);
  }
  const install=await json('verify/install.execution.json');
  assert.deepEqual(install.argv,[prepared.dependencyRoot+'/bin/pnpm','--config.verify-deps-before-run=error','install','--frozen-lockfile','--offline','--package-import-method=copy']);
  assert(BigInt(command.startedEpochNanoseconds)>BigInt(install.finishedEpochNanoseconds));
  const directory=resolve(input,'commands/candidate-runtime');
  const receipt=await validateCommandReceiptDirectory({directory,expectedStageId:'orch-auth-01-c6b',expectedCommandId:'source-scope-focused',requiredKinds:['source-scope-focused-vitest-report','test-run-summary','source-scope-focused-execution','source-scope-child-execution']});
  const summary=await json('commands/candidate-runtime/test-run-summary.json');
  assert.deepEqual(summary.candidate,{gitCommit:source.commit,gitTree:source.tree,workingTreeDirty:false});
  assert.deepEqual(summary.testCounts,{files:1,tests:1,passed:1,failed:0,skipped:0});
  assert.equal(summary.platform.os,'linux');assert.equal(summary.platform.nodeVersion,'v24.18.0');assert.equal(summary.platform.pnpmVersion,'11.15.1');
  const child=await json('commands/candidate-runtime/child-execution.json');
  const execution=await json('commands/candidate-runtime/execution.json');
  assert.deepEqual(child.files,[fixture]);assert.deepEqual(execution.files,[fixture]);assert.deepEqual(child.argv,execution.argv);
  assert.equal(child.exitCode,0);assert.equal(child.signal,null);
  assert.equal(child.supervision.timedOut,false);assert.equal(child.supervision.outputLimitExceeded,false);assert.equal(child.supervision.streamsClosed,true);assert.equal(child.supervision.drainTimedOut,false);
  for(const stream of ['stdout','stderr']){const data=await readFile(resolve(directory,stream+'.log'));assert.equal(data.length,child.supervision[stream].bytesCaptured);assert.equal(child.supervision[stream].truncated,false);}
  const raw=await json('commands/candidate-runtime/vitest-report.json');
  assert.equal(raw.numTotalTests,1);assert.equal(raw.numPassedTests,1);assert.equal(raw.numFailedTests,0);assert.equal(raw.numPendingTests,0);assert.equal(raw.numTodoTests,0);assert.equal(raw.success,true);
  assert.equal(raw.testResults.length,1);assert(raw.testResults[0].name.endsWith('/'+fixture));
  const cases=raw.testResults[0].assertionResults;assert.equal(cases.length,1);assert.equal(cases[0].status,'passed');
  const report={schemaVersion:'sanitized-cache-runtime-audit.v1',source,verifiedInputPins:prepared.pins.length,fixture,caseName:cases[0].fullName,receiptSha256:receipt.receiptSha256,namespaceBoundaries:['probe','verify'],ownedAccountConfigSha256:hash(config),serviceCleanupObserved:true,originalTestUnchanged:true,actualCandidate:false,actualImplementationAudit:false,sourceQualification:false,completionEligible:false};
  await writeFile(resolve(output,'executed-auditor.ts'),await readFile(import.meta.filename),{flag:'wx'});
  await writeFile(resolve(output,'report.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
  await writeReceipt(context,[{id:'actual-sanitized-offline-fixture',summary:'Independently validated the unchanged actual package-runtime case, raw report and command receipt, all 331 committed input files, owned account cache configuration, denied-network namespaces and completed service cleanup. This diagnostic does not qualify a candidate or source completion.'}],[{path:'report.json',kind:'sanitized-cache-runtime-audit'},{path:'owned-account-config.yaml',kind:'owned-public-cache-configuration'},{path:'executed-auditor.ts',kind:'sanitized-cache-runtime-auditor'}]);
  const checked=await validateCommandReceiptDirectory({directory:output,expectedStageId:context.stageId,expectedCommandId:context.commandId,requiredKinds:['sanitized-cache-runtime-audit']});
  console.log(JSON.stringify({receiptSha256:checked.receiptSha256,tests:1,completionEligible:false}));
}catch(error){await writeManualEvidenceFailure(context,{kind:'product',message:error instanceof Error?error.stack:String(error)});throw error;}
