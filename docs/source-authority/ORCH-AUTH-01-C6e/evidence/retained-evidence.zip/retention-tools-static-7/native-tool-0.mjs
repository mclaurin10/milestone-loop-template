import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { lstat, mkdir, readFile, readdir, realpath, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { commandIdentity, runPnpm, FULL_SUITE_EVIDENCE_TIMEOUT_MS } from '../../../tools/evidence.mjs';

const repository = await realpath(resolve(import.meta.dirname, '../../..'));
const evidence = resolve(repository, 'artifacts/wp6e-source-publication-20260906');
const clone = await realpath(resolve(repository, '.tools/wp6e-c6e-unborn-precommit-20260907'));
const runtime = resolve(clone, 'artifacts/c6e-native-retry-tools/runtime');
const commandOutput = resolve(clone, 'artifacts/c6e-native-retry-1');
const receiver = resolve(evidence, 'unborn-publication-focused-2');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const read = async path => JSON.parse(await readFile(path, 'utf8'));

// The preceding full jobs must have finished before the serial retry starts.
const first = await read(resolve(evidence, 'unborn-publication-focused-1/child-execution.json'));
const firstReport = await read(resolve(evidence, 'unborn-publication-focused-1/vitest-report.json'));
assert.notEqual(first.exitCode, 0);
assert(firstReport.numFailedTests > 0 && firstReport.numTotalTests > 0);
const collection = await read(resolve(evidence, 'precommit-linux-4/collection.json'));
const linuxLaunch = await read(resolve(evidence, 'precommit-linux-4/verify-launch/execution.json'));
assert.equal(collection.executionExitCode, 0);
assert.equal(linuxLaunch.exitCode, 0);
assert.equal(linuxLaunch.cgroupAbsent, true);
assert(linuxLaunch.unitAfter.stdout.includes('MainPID=0\n'));
assert(!existsSync(commandOutput) && !existsSync(receiver));

const preparation = await read(resolve(runtime, 'preparation.json'));
const metadata = await read(resolve(runtime, 'source-input.json'));
assert.equal(metadata.source.commit, '2fa66568407594523380ec33c063cdf52e4c6d2d');
assert.deepEqual(collection.source, metadata.source);
assert.equal(hash(await readFile(resolve(runtime, 'run-focused.ts'))), preparation.runnerSha256);
assert.equal(preparation.runnerSha256, 'deeb26dd22e94b8210197a1ae83b400bb878c3933f02d8b79cd4fc918c09924d');
assert.equal(hash(await readFile(resolve(runtime, 'progress-reporter.mjs'))), preparation.reporterSha256);
const previous = await read(resolve(evidence, 'dependency-repair-focused-1/execution.json'));
const runnerIndex = previous.argv.indexOf('docs/source-authority/ORCH-AUTH-01-C6b/run-focused.ts');
assert(runnerIndex >= 0);
const files = previous.argv.slice(runnerIndex + 1);
assert.equal(files.length, 10);
assert(files.every(path => /\.test\.(?:ts|mjs)$/.test(path)));

const before = await commandIdentity(clone);
assert.equal(before.gitCommit, metadata.source.commit);
assert.equal(before.gitTree, metadata.source.tree);
assert.equal(before.gitStatus, '');
assert.equal(before.nodeVersion, 'v24.18.0');
assert.equal(before.pnpmVersion, '11.15.1');
assert.equal(metadata.pins.length, 331);
for (const pin of metadata.pins) {
  for (const root of [repository, clone]) {
    const bytes = await readFile(resolve(root, pin.path));
    assert.equal(bytes.length, pin.bytes, pin.path);
    assert.equal(hash(bytes), pin.sha256, pin.path);
  }
}
await mkdir(resolve(receiver, 'launcher'), { recursive: true });
await writeFile(resolve(receiver, 'launcher/executed-driver.mjs'), await readFile(import.meta.filename), { flag: 'wx' });
await writeFile(resolve(receiver, 'launcher/preparation.json'), await readFile(resolve(runtime, 'preparation.json')), { flag: 'wx' });
for (const name of ['run-focused.before-receipt-order.ts', 'preparation.before-receipt-order.json']) {
  await writeFile(resolve(receiver, 'launcher/' + name), await readFile(resolve(runtime, name)), { flag: 'wx' });
}
for (const name of ['prepare-native-retry.mjs', 'preserve-native-retry-receipt-kinds.mjs']) {
  await writeFile(resolve(receiver, 'launcher/' + name), await readFile(resolve(import.meta.dirname, name)), { flag: 'wx' });
}
const argv = ['--config.verify-deps-before-run=error', 'exec', 'tsx', 'artifacts/c6e-native-retry-tools/runtime/run-focused.ts', ...files];
const startedAt = new Date().toISOString();
const start = { schemaVersion: 'source-native-retry-launch.v1', startedAt, argv: ['pnpm', ...argv], cwd: clone, commandOutput, before, source: metadata.source, files, originalInnerTimeoutMs: FULL_SUITE_EVIDENCE_TIMEOUT_MS, outerTimeoutMs: FULL_SUITE_EVIDENCE_TIMEOUT_MS + 120000, precedingLinuxCollectionSha256: hash(await readFile(resolve(evidence, 'precommit-linux-4/collection.json'))), precedingNativeExecutionSha256: hash(await readFile(resolve(evidence, 'unborn-publication-focused-1/child-execution.json'))), completionEligible: false };
await writeFile(resolve(receiver, 'launcher/start.json'), JSON.stringify(start, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ phase: 'starting-full-serial-native-retry', source: metadata.source, files: files.length, commandOutput, receiver, startedAt }));
const result = await runPnpm(argv, {
  cwd: clone,
  timeoutMs: start.outerTimeoutMs,
  env: {
    LOOP_VERIFY_COMMAND_ARTIFACT_DIR: commandOutput,
    LOOP_VERIFY_STAGE_ID: 'orch-auth-01-c6b',
    LOOP_VERIFY_COMMAND_ID: 'source-scope-focused',
  },
});
for (const stream of ['stdout', 'stderr']) await writeFile(resolve(receiver, 'launcher/' + stream + '.log'), result[stream] ?? '', { flag: 'wx' });
const after = await commandIdentity(clone);
const execution = { ...start, finishedAt: new Date().toISOString(), after, exitCode: result.status, signal: result.signal, supervision: result.supervision, error: result.error?.message ?? null };
await writeFile(resolve(receiver, 'launcher/execution.json'), JSON.stringify(execution, null, 2) + '\n', { flag: 'wx' });
let copiedBytes = 0;
const copied = [];
async function copy(relativePath = '') {
  const from = resolve(commandOutput, relativePath);
  const info = await lstat(from);
  assert(!info.isSymbolicLink());
  if (info.isDirectory()) {
    if (relativePath) await mkdir(resolve(receiver, relativePath), { recursive: false });
    for (const entry of (await readdir(from)).sort()) await copy(relativePath ? relativePath + '/' + entry : entry);
    return;
  }
  assert(info.isFile() && info.size <= 20000000);
  copiedBytes += info.size;
  assert(copiedBytes <= 64000000);
  const bytes = await readFile(from);
  await writeFile(resolve(receiver, relativePath), bytes, { flag: 'wx' });
  copied.push({ path: relativePath, bytes: bytes.length, sha256: hash(bytes) });
}
if (existsSync(commandOutput)) await copy();
await writeFile(resolve(receiver, 'launcher/collection.json'), JSON.stringify({ source: commandOutput, copiedBytes, copied, receiptBytesRewritten: false, completionEligible: false }, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ phase: 'native-retry-collected', exitCode: result.status, files: copied.length, copiedBytes, receiver }));
assert.deepEqual(after, before);
assert(!result.error && result.status === 0 && result.signal === null, result.stderr);
