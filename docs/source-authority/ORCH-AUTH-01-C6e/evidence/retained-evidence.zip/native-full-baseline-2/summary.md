# Project Verification Result

- Run: `native-full-consumer`
- Profile: `readiness` (Approved orchestrator source qualification)
- Status: **FAIL**
- Exit code: `1`
- Completion eligible: `false`
- Completion claim: `source_machine_qualified_for_human_acceptance`
- Autonomous-readiness equivalent: `false`
- Execution provider: `trusted-container` (unattested, completion eligible: false)
- Started: `2026-09-06T21:31:43.267Z`
- Finished: `2026-09-06T21:34:42.516Z`
- Git commit: `1c48237e3e3aeca064eb6f07d15f2303d6bd0ffe`
- Working tree dirty: `false`

| Stage | Status | Required command gaps/failures |
|---|---:|---|
| Source dependency integrity | FAIL | Command failed with exit 1. |
| Approved source authority integrity | FAIL | Command failed with exit 1. |
| Source formatting, lint and architecture | FAIL | Command failed with exit 1. Command failed with exit 1. Command failed with exit 1. |
| Strict source type checking | FAIL | Command failed with exit 1. |
| Consumed source distribution | FAIL | Command failed with exit 1. |
| Complete source regression suite | FAIL | Command failed with exit 1. |
| Public orchestration workflows | NOT_READY | Required package script "test:orchestration-domain" is not defined. |
| Canonical orchestration parity | NOT_READY | Required package script "verify:source-parity" is not defined. |
| Generated adopter bootstrap qualification | NOT_READY | Required package script "verify:adopter-bootstrap" is not defined. |
| Actual source execution resource bounds | NOT_READY | Required package script "verify:source-bounds" is not defined. |
| Complete source qualification aggregation | NOT_READY | The complete authenticated native-platform source qualifier is not implemented. A dispatch identity or candidate receipt cannot establish this gate. Required package script "verify:source-acceptance" is not defined. |

A required `NOT_READY`, `FAIL`, or `ERROR` is non-passing. A focused, dirty-tree, profile-override, or bootstrap run cannot establish autonomous readiness. See `result.json` for the complete machine-readable record.
