"""Run unchanged source checks as UID 1000 in an owned restricted service."""
import errno
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time

root=Path(sys.argv[1]).resolve(strict=True)
mode=sys.argv[2]
assert len(sys.argv)==3 and mode in ('probe','verify')
assert root.parent==Path('/home/duncan') and root.name.startswith('c6e-linux-precommit-')
metadata=json.loads((root/'input/preparation.json').read_bytes())
assert metadata['root']==str(root) and os.getuid()==1000 and os.getgid()==1000
assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==metadata['worker']['sha256']
source=root/'source'
output=root/'observations'/mode
assert not output.exists()
output.mkdir()
env=metadata['environment']
assert env['HOME']==str(root/'account') and not (root/'account/.docker').exists()
assert os.path.samefile(root/'account','/home/duncan')
assert not Path('/home/duncan/.ssh').exists()
status=Path('/proc/self/status').read_text()
for key,value in [('NoNewPrivs','1'),('CapEff','0000000000000000'),('CapPrm','0000000000000000')]:
    assert next(line.split(':',1)[1].strip() for line in status.splitlines() if line.startswith(key+':'))==value
interfaces=[name for _,name in socket.if_nameindex()]
assert interfaces==['lo'],interfaces
assert not os.access('/mnt',os.R_OK)
denials=[]
for path in ('/run/docker.sock','/var/run/docker.sock'):
    client=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
    client.settimeout(2)
    try:
        client.connect(path)
        raise AssertionError('Host Docker endpoint was reachable: '+path)
    except OSError as error:
        assert error.errno in (errno.EACCES,errno.ENOENT,errno.ENOTSOCK),(path,error)
        denials.append({'path':path,'errno':error.errno})
    finally:client.close()
with socket.socket() as server,socket.socket() as client:
    server.settimeout(2);client.settimeout(2)
    server.bind(('127.0.0.1',0));server.listen(1)
    client.connect(server.getsockname())
    accepted,_=server.accept();accepted.close()
cgroup=Path('/proc/self/cgroup').read_text()
cgroup_path=Path('/sys/fs/cgroup')/cgroup.strip().split('::',1)[1].lstrip('/')
assert cgroup_path.name.startswith('orch-c6e-source-') and cgroup_path.name.endswith('.service')
resources={name:(cgroup_path/name).read_text() for name in ('memory.max','memory.swap.max','cpu.max','pids.max')}
assert resources['memory.max'].strip()==str(8*1024**3)
assert resources['memory.swap.max'].strip()=='0'
assert resources['pids.max'].strip()=='1024'
assert resources['cpu.max'].strip()=='400000 100000'
observation={'schemaVersion':'source-check-namespace-observation.v1','uid':os.getuid(),'gid':os.getgid(),'status':status,'interfaces':interfaces,'routes':Path('/proc/net/route').read_text(),'namespaceIds':{kind:os.readlink('/proc/self/ns/'+kind) for kind in ('mnt','net')},'mounts':Path('/proc/self/mountinfo').read_text(),'dockerSocketDenials':denials,'loopbackConnectionPassed':True,'cgroup':cgroup,'resources':resources,'source':metadata['source'],'platform':'linux','nodeVersionExpected':'v24.18.0','pnpmVersionExpected':'11.15.1','actualDockerExecution':False,'sourceQualification':False,'completionEligible':False}
(output/'namespace.json').write_text(json.dumps(observation,indent=2)+'\n')
def git(*args):
    result=subprocess.run(['/usr/bin/git','--no-optional-locks','-C',str(source),*args],capture_output=True,timeout=120,env=env)
    assert result.returncode==0,result.stderr
    return result.stdout.decode().strip()
def inputs():
    assert git('rev-parse','HEAD')==metadata['source']['commit']
    assert git('rev-parse','HEAD^{tree}')==metadata['source']['tree']
    assert git('symbolic-ref','--quiet','HEAD')==metadata['source']['branch']
    assert git('status','--porcelain')==''
    assert git('for-each-ref','--format=%(refname)','refs/milestone-loop/')==''
    assert not (source/'artifacts/orchestrator/state/state.json').exists()
    for pin in metadata['pins']:
        data=(source/pin['path']).read_bytes()
        assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'],pin['path']
inputs()
if mode=='probe':
    print(json.dumps({'phase':'namespace-observed','source':metadata['source'],'qualification':False,'completionEligible':False}),flush=True)
    sys.exit(0)
commands=[('candidate-runtime','candidate-runtime')]
records=[]
def run(name,argv,timeout):
    print(json.dumps({'phase':'start','command':name}),flush=True)
    started=time.time_ns();clock=time.monotonic_ns()
    timed_out=False;output_limit=False
    with (output/(name+'.stdout.log')).open('xb') as stdout,(output/(name+'.stderr.log')).open('xb') as stderr:
        child=subprocess.Popen(argv,cwd=source,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        while child.poll() is None:
            elapsed=(time.monotonic_ns()-clock)/1e9
            output_limit=any((output/(name+'.'+stream+'.log')).stat().st_size>67108864 for stream in ('stdout','stderr'))
            timed_out=elapsed>=timeout
            if timed_out or output_limit:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=5)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10)
                break
            try:child.wait(timeout=min(15,timeout-elapsed))
            except subprocess.TimeoutExpired:pass
    record={'name':name,'argv':argv,'cwd':str(source),'uid':os.getuid(),'startedEpochNanoseconds':str(started),'finishedEpochNanoseconds':str(time.time_ns()),'durationMs':round((time.monotonic_ns()-clock)/1e6),'exitCode':child.returncode,'timedOut':timed_out,'outputLimitExceeded':output_limit,'outerTimeoutMs':timeout*1000}
    (output/(name+'.execution.json')).write_text(json.dumps(record,indent=2)+'\n')
    assert child.returncode==0 and not timed_out and not output_limit,record
    print(json.dumps({'phase':'completed','command':name,'durationMs':record['durationMs']}),flush=True)
    return record
try:
    pnpm=str(Path(metadata['dependencyRoot'])/'bin/pnpm')
    run('install',[pnpm,'--config.verify-deps-before-run=error','install','--frozen-lockfile','--offline','--package-import-method=copy'],1200)
    for name,command in commands:
        inputs()
        env['LOOP_VERIFY_COMMAND_ARTIFACT_DIR']=str(source/'artifacts/c6e-precommit'/name)
        record=run(name,[pnpm,'--config.verify-deps-before-run=error','exec','tsx','docs/source-authority/ORCH-AUTH-01-C6b/run-focused.ts','tools/milestone-orchestrator/src/candidate-package-runtime.test.ts'],5520)
        inputs()
        records.append(record)
    result={'schemaVersion':'sanitized-cache-fixture-observation.v1','source':metadata['source'],'platform':'linux','commands':records,'pins':metadata['pins'],'sourceStateAdopted':False,'privateReferencesAbsent':True,'actualImplementationAudit':False,'actualCandidate':False,'actualDockerExecution':False,'completionEligible':False,'status':'COMPLETED_REQUIRES_INDEPENDENT_AUDIT'}
    (output/'observation.json').write_text(json.dumps(result,indent=2)+'\n')
finally:
    (output/'completed-commands.json').write_text(json.dumps(records,indent=2)+'\n')
