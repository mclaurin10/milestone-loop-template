import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import { lstat, readFile, realpath, writeFile } from "node:fs/promises";
import { relative, resolve } from "node:path";
import { spawnSync } from "node:child_process";
import { evidenceContext, commandIdentity, writeReceipt, writeManualEvidenceFailure } from "../../tools/evidence.mjs";
import { assertTestRunSummary } from "../../tools/milestone-orchestrator/src/test-run-summary.js";
import { validateCommandReceiptDirectory } from "../../tools/milestone-orchestrator/src/verifier.js";

const root = await realpath(process.cwd());
const evidenceRoot = "artifacts/wp6e-source-publication-20260906/";
const runPrefix = evidenceRoot + "recovery-publication-focused-1/";
const inputPrefix = evidenceRoot + "recovery-publication-inputs-1/";
const hash = (value: Buffer) => createHash("sha256").update(value).digest("hex");
const bytes = (path: string) => readFile(resolve(root, path));
const json = async (path: string) => JSON.parse((await bytes(path)).toString());
// Refuse before evidenceContext: it writes the normal command identity/index
// observation, which must not overlap a still-running source fixture check.
const progressBytes = await bytes(runPrefix + "progress.jsonl");
const events = progressBytes.toString().trimEnd().split("\n").map(line => JSON.parse(line));
assert.deepEqual(events.at(-1), {...events.at(-1),event:"run-end",modules:9,unhandledErrors:0,reason:"passed"});
const completed = await json(runPrefix + "result.json");
assert.equal(completed.status, "PASS");
const context = await evidenceContext("wp6e-c6e", "recovery-integration-audit");
try {
  const observer = await commandIdentity(root);
  const input = await json(inputPrefix + "inputs.json");
  assert.equal(input.schemaVersion, "wp6e-verification-input-observation.v1");
  assert.equal(input.verificationClaim, false);
  assert.equal(input.completionEligible, false);
  assert.equal(input.root, root);
  assert.equal(input.files.length, 650);
  const git = (...args: string[]) => {
    const result = spawnSync("git", ["--no-optional-locks", "-C", root, ...args], {windowsHide:true,timeout:30_000,maxBuffer:64*1024*1024});
    assert(!result.error && result.status===0 && result.signal===null);
    return result.stdout;
  };
  assert.deepEqual(git("rev-parse","HEAD","HEAD^{tree}","--symbolic-full-name","HEAD").toString().trimEnd().split("\n"), input.gitIdentity);
  const observedPaths = git("ls-files","--cached","--others","--exclude-standard","-z").toString().split("\0").filter(Boolean);
  assert.deepEqual([...new Set(observedPaths)].sort(), input.files.map((file: {path:string})=>file.path));
  for (const pin of [input.index,input.trackedPatch]) {
    const content=await bytes(inputPrefix + pin.path);
    assert.equal(content.length,pin.bytes);
    assert.equal(hash(content),pin.sha256);
  }
  assert(git("ls-files","--stage","-z").equals(await bytes(inputPrefix + input.index.path)));
  assert(git("diff","--binary","--full-index","HEAD","--").equals(await bytes(inputPrefix + input.trackedPatch.path)));
  for (const file of input.files) {
    const absolute=resolve(root,file.path);
    assert(!relative(root,absolute).startsWith(".."));
    const info=await lstat(absolute);
    assert(info.isFile() && !info.isSymbolicLink());
    assert.equal(await realpath(absolute),absolute);
    assert.equal(info.size,file.bytes,file.path);
    const digest=createHash("sha256");
    for await (const chunk of createReadStream(absolute)) digest.update(chunk);
    assert.equal(digest.digest("hex"),file.sha256,file.path);
    if (!file.tracked && !file.excludedFromCommit) {
      const saved=await bytes(inputPrefix + "untracked/" + file.path);
      assert.equal(saved.length,file.bytes);
      assert.equal(hash(saved),file.sha256);
    }
  }
  const receipt=await validateCommandReceiptDirectory({directory:resolve(root,runPrefix),expectedStageId:"orch-auth-01-c6b",expectedCommandId:"source-scope-focused",requiredKinds:["source-scope-focused-vitest-report","test-run-summary","source-scope-focused-execution"]});
  const raw=await json(runPrefix + "vitest-report.json");
  assert.equal(raw.numTotalTests,203);
  assert.equal(raw.numPassedTests,203);
  for (const name of ["numFailedTests","numPendingTests","numTodoTests"]) assert.equal(raw[name],0);
  assert.equal(raw.success,true);
  const expectedFiles=["source-authority-publication","source-authority-recovery","source-verifier-consumers","source-authority-evidence","controller-lease","affected-scope","source-schedule","verification-scope","test-ownership"].map(name=>"tools/milestone-orchestrator/src/"+name+".test.ts").sort();
  assert.deepEqual(raw.testResults.map((file:{name:string})=>relative(root,file.name).replaceAll("\\","/")).sort(),expectedFiles);
  for(const file of raw.testResults) {
    assert.equal(file.status,"passed");
    assert(file.assertionResults.length>0);
    const identities=new Set();
    for(const test of file.assertionResults) {
      assert.equal(test.status,"passed");
      assert.equal(test.failureMessages.length,0);
      assert(!identities.has(test.fullName),"Duplicate raw test identity: "+test.fullName);
      identities.add(test.fullName);
    }
  }
  const prior=await json(evidenceRoot + "publication-focused-15/vitest-report.json");
  for(const file of prior.testResults) {
    const fresh=raw.testResults.find((candidate:{name:string})=>candidate.name===file.name);
    assert(fresh);
    assert.deepEqual(fresh.assertionResults.map((test:{fullName:string})=>test.fullName),file.assertionResults.map((test:{fullName:string})=>test.fullName));
  }
  const measurement=assertTestRunSummary(await json(runPrefix + "test-run-summary.json"));
  const stdout=await bytes(runPrefix + "stdout.log");
  const native=stdout.toString().split(/\r?\n/).filter(line=>line.startsWith('{"schemaVersion":"synthetic-publication-native-consumer-observation.v1"')).map(line=>JSON.parse(line));
  assert.equal(native.length,2);
  const nativeReports=[];
  for(const observation of native) {
    assert.equal(observation.execution.exitCode,1);
    assert.equal(observation.execution.signal,null);
    assert.equal(observation.execution.spawnError,null);
    assert.equal(observation.execution.supervision.timedOut,false);
    assert.equal(observation.execution.supervision.streamsClosed,true);
    assert.equal(observation.execution.supervision.drainTimedOut,false);
    for(const stream of ["stdout","stderr"]) {
      const content=Buffer.from(observation.execution[stream+"Base64"],"base64");
      assert.equal(content.length,observation.execution.supervision[stream].bytesCaptured);
      assert.equal(observation.execution.supervision[stream].truncated,false);
    }
    for(const file of observation.files) {
      const content=Buffer.from(file.contentsBase64,"base64");
      assert.equal(content.length,file.bytes);
      assert.equal(hash(content),file.sha256);
    }
    const runId=observation.argv[observation.argv.indexOf("--run-id")+1];
    const file=observation.files.find((item:{path:string})=>item.path==="artifacts/"+runId+"/result.json");
    assert(file);
    const report=JSON.parse(Buffer.from(file.contentsBase64,"base64").toString());
    assert.equal(report.status,"FAIL");
    assert.equal(report.completion.eligible,false);
    const focused=observation.argv.includes("--stage");
    assert.equal(report.scope.purpose,focused?"candidate-support":"full-source-qualification");
    assert.equal(report.scope.qualifierRun===null,focused);
    nativeReports.push({runId,resultSha256:file.sha256,scope:report.scope,completion:report.completion,stages:report.stages.map((stage:{id:string;status:string})=>({id:stage.id,status:stage.status})),nestedFiles:observation.files.map(({contentsBase64: omitted,...pin}: {contentsBase64:string;path:string;bytes:number;sha256:string})=>{assert(typeof omitted==="string");return pin;})});
  }
  const report={schemaVersion:"wp6e-recovery-integration-audit.v1",status:"PASS",claimScope:"dirty-tree-focused-regression-and-input-audit",completionEligible:false,actualImplementationAudit:false,sdkServiceReview:false,actualMigration:false,sourceStateAdopted:false,candidateExecution:false,observer,inputObservation:{path:inputPrefix+"inputs.json",sha256:hash(await bytes(inputPrefix+"inputs.json")),files:input.files.length},focusedReceipt:{path:runPrefix+"result.json",sha256:receipt.receiptSha256,bytes:receipt.receiptBytes,artifacts:receipt.artifacts},tests:203,preservedPriorTests:107,measurement,nativeReports};
  await writeFile(resolve(context.artifactDirectory,"report.json"),JSON.stringify(report,null,2)+"\n");
  await writeReceipt(context,[{id:"frozen-inputs-and-complete-regressions",summary:"Independently rechecked 650 frozen input files, exact patch/index, all selected raw tests and receipt artifacts, preserved all 107 prior test identities, and reconstructed the two actual native observations with correct non-completion scopes."}],[{path:"report.json",kind:"wp6e-recovery-integration-audit"}]);
  console.log(JSON.stringify({status:"PASS",tests:203,inputFiles:650,completionEligible:false}));
} catch(error) {
  await writeManualEvidenceFailure(context,{kind:"infrastructure",message:error instanceof Error?error.stack:String(error)});
  throw error;
}
