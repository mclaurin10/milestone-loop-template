"""Run every prior 203-case file plus source-release regressions on pinned code."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

repo=Path('/mnt/c/Dev/loop-extraction/milestone-loop-template')
evidence=repo/'artifacts/wp6e-source-publication-20260906'
receiver=evidence/'dependency-repair-focused-1'
assert os.getuid()==1000 and not receiver.exists()
receiver.mkdir()
(receiver/'executed-procedure.py').write_bytes(Path(__file__).read_bytes())
root=Path((evidence/'store-diagnostic-2/owned-root.txt').read_text().strip())
assert str(root)=='/home/duncan/c6e-store-diagnostic-0lb9ny6v' and root.resolve()==root
source=root/'source'
env=json.loads((evidence/'store-diagnostic-2/environment.json').read_bytes())
metadata=json.loads((evidence/'precommit-vm-3/input/source.json').read_bytes())
delta=json.loads((evidence/'dependency-repair-linux-1/source-delta.json').read_bytes())
changes={row['path']:row['after'] for row in delta['changes']}
def observe_inputs():
    pins=[]
    for original in metadata['pins']:
        pin={**original,**changes.get(original['path'],{})}
        path=source/pin['path']
        assert path.is_file() and not path.is_symlink()
        raw=path.read_bytes()
        assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],pin['path']
        pins.append(pin)
    return pins
pins=observe_inputs()
files=json.loads((evidence/'recovery-publication-focused-1/child-execution.json').read_bytes())['files']
assert len(files)==9 and len(set(files))==9
assert 'tools/source-release.test.mjs' not in files
files.append('tools/source-release.test.mjs')
assert all((source/name).is_file() for name in files)
output=source/'artifacts/dependency-repair-focused-1'
assert not output.exists()
env['LOOP_VERIFY_COMMAND_ARTIFACT_DIR']=str(output)
argv=[str(root/'bin/pnpm'),'--config.verify-deps-before-run=error','exec','tsx','docs/source-authority/ORCH-AUTH-01-C6b/run-focused.ts',*files]
(receiver/'input-observation.json').write_text(json.dumps({'sourceBase':metadata['source'],'delta':delta['changes'],'pins':pins,'files':files,'workingTreeDirty':True,'verificationClaim':False},indent=2)+'\n')
started=time.time_ns()
clock=time.monotonic_ns()
timed_out=False
with (receiver/'launcher.stdout.log').open('xb') as stdout,(receiver/'launcher.stderr.log').open('xb') as stderr:
    process=subprocess.Popen(argv,cwd=source,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
    try:code=process.wait(timeout=5700)
    except subprocess.TimeoutExpired:
        timed_out=True
        os.killpg(process.pid,signal.SIGTERM)
        try:code=process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL)
            code=process.wait(timeout=10)
record={'argv':argv,'cwd':str(source),'uid':os.getuid(),'startedEpochNanoseconds':str(started),'durationMs':round((time.monotonic_ns()-clock)/1e6),'exitCode':code,'timedOut':timed_out,'completionEligible':False}
(receiver/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
shutil.copytree(output,receiver/'command')
assert observe_inputs()==pins
(receiver/'input-observation-after.json').write_text(json.dumps({'pins':pins,'unchanged':True,'completionEligible':False},indent=2)+'\n')
print(json.dumps(record),flush=True)
assert code==0 and not timed_out
