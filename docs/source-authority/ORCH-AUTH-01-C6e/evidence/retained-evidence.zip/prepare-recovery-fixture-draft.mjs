import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { createHash } from 'node:crypto';
const root = process.cwd();
const draft = resolve(root, 'artifacts/wp6e-source-publication-20260906/recovery-boundaries-draft');
const sourcePath = 'tools/milestone-orchestrator/src/source-authority-publication.test.ts';
const original = await readFile(resolve(root, sourcePath));
const text = original.toString().replaceAll('\r\n', '\n');
const start = text.indexOf('const controller =');
const end = text.indexOf('\ndescribe(\n', start);
assert(start > 0 && end > start);
const imports = `import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { existsSync } from "node:fs";
import { mkdir, mkdtemp, readFile, realpath, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { basename, dirname, resolve } from "node:path";
import { Codex, type ThreadEvent } from "@openai/codex-sdk";
import { expect, vi } from "vitest";
import { SOURCE_AUTHORITY_REQUEST_PATH } from "../src/authority-publication.mjs";
import { createSourceAuthorityRequestBinding, prepareSourceAuthorityTransition, SOURCE_IMPLEMENTATION_EVIDENCE_PATH } from "../src/source-authority-transition.js";
import { SOURCE_AUDIT_PREFIX, SOURCE_REVIEW_CHECK_IDS, sourceGit, sourceGitText, sourceHash, sourceIdentity } from "../src/source-authority-evidence.mjs";
import { SOURCE_GENERATION_PATHS } from "../src/source-authority-generation.mjs";
import { reviewSourceAuthorityRequest } from "../src/source-authority-review.js";
import { syntheticSourceAudit } from "./synthetic-source-audit.js";
`;
const body = text.slice(start, end).replace(/^(const (?:controller|owned|bytes)\b|async function (?:put|requestFixture|review)\b)/gm, 'export $1')
  .replace('afterEach(async () => {', 'export async function cleanupSyntheticPublicationFixtures() {')
  .replace('});\nexport const bytes', '}\nexport const bytes');
const helper = imports + '\n' + body;
let suite = text.slice(0, start) + `import { controller, owned, bytes, put, requestFixture, review, cleanupSyntheticPublicationFixtures } from "../test/synthetic-source-publication.js";\nafterEach(cleanupSyntheticPublicationFixtures);\n` + text.slice(end);
suite = suite.replace('  mkdir,\n', '').replace('  mkdtemp,\n', '').replace('  writeFile,\n', '');
suite = suite.replace('import { tmpdir } from "node:os";\n', '').replace('import { basename, dirname, resolve }', 'import { resolve }');
suite = suite.replace('import { Codex, type ThreadEvent }', 'import { Codex }');
suite = suite.replace(/import \{\n  createSourceAuthorityRequestBinding,[\s\S]*?from "\.\/source-authority-transition.js";\n/, '');
suite = suite.replace('  SOURCE_REVIEW_CHECK_IDS,\n', '').replace('import { syntheticSourceAudit } from "../test/synthetic-source-audit.js";\n', '');
for (const [path, contents] of [[sourcePath, suite], ['tools/milestone-orchestrator/test/synthetic-source-publication.ts', helper]]) {
  await mkdir(dirname(resolve(draft, 'after', path)), {recursive:true});
  await writeFile(resolve(draft, 'after', path), contents);
}
await mkdir(dirname(resolve(draft, 'before', sourcePath)), {recursive:true});
await writeFile(resolve(draft, 'before', sourcePath), original);
await writeFile(resolve(draft, 'baseline.json'), JSON.stringify({claim:'Unexecuted fixture extraction draft only', path:sourcePath, sha256:createHash('sha256').update(original).digest('hex')}, null,2)+'\n');
console.log(JSON.stringify({draft, claim:'prepared, not integrated or verified'}));
