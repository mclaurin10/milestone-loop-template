"""Prepare a fresh C3-policy guest for the nine precommit source checks.

This is input preparation only. The existing 30-minute host lifecycle and all
OCI admission/cleanup checks are unchanged. It cannot prove a 65-minute provider
boundary or source qualification. No shared package/service state is changed.
"""
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import uuid

repo = Path('/mnt/c/Dev/loop-extraction/milestone-loop-template')
receiver = Path(sys.argv[1]).resolve(strict=True)
assert receiver.parent == repo / 'artifacts/wp6e-source-publication-20260906'
assert receiver.name == 'precommit-vm-4'
assert os.getuid() == 1000
source = receiver / 'input'
c3 = repo / 'docs/runtime-qualification/ORCH-AUTH-01-C3'
prior = Path('/home/duncan/oc3-b13lp2vx')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def pin(path):
    assert path.is_file() and not path.is_symlink()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


assert sha(c3 / 'run-host.py') == 'e3e8fd910030f5fe0e7d831960ce4c6ac6cfa51908405b4a8a2702f29ac29c9c'
assert sha(c3 / 'guest-job.py') == '66e437873208c86d938503b63dad989b280108bdc12e951b768805dac05a25ca'
assert sha(prior / 'input/input-manifest.json') == 'f7379ee6eaf49f4373390f4464855021cf4b269ac560a3b6deb54770ab86d555'
old_expected = json.loads((prior / 'expected-b5ae0551-b3eb-4a88-83c8-e5254332259c.json').read_bytes())
retained_expected = json.loads((repo / 'artifacts/wp6e-continuation-20260906/postcommit-extracted/raw/host/expected.json').read_bytes())
assert old_expected == retained_expected
metadata = json.loads((source / 'source.json').read_bytes())
assert metadata['schemaVersion'] == 'c6e-precommit-source-input.v2'
assert metadata['completionEligible'] is False and metadata['actualImplementationAudit'] is False
assert metadata['sourceStateAdopted'] is False and metadata['source']['status'] == ''
for key in ('commit', 'tree'):
    assert re.fullmatch('[a-f0-9]{40}', metadata['source'][key])
assert metadata['source']['commit'] != 'fc2419d8bdfc3658fe76edf2b543b38051b359f1'
assert pin(source / 'source.bundle') == {**metadata['bundle'], 'path': str(source / 'source.bundle')}
assert not (receiver / 'prepared-root.txt').exists()
root = Path(tempfile.mkdtemp(prefix='oc3-c6e-', dir='/home/duncan'))
payload = root / 'input'
payload.mkdir()
(receiver / 'prepared-root.txt').write_text(str(root) + '\n')
(receiver / 'executed-preparer.py').write_bytes(Path(__file__).read_bytes())
old_manifest = json.loads((prior / 'input/input-manifest.json').read_bytes())
reused = []
for item in old_manifest['files']:
    if item['path'] in ('source.bundle', 'guest-job.py'):
        continue
    path = prior / 'input' / item['path']
    assert pin(path) == {**item, 'path': str(path)}
    target = payload / item['path']
    target.parent.mkdir(exist_ok=True, parents=True)
    shutil.copyfile(path, target)
    assert sha(target) == item['sha256']
    reused.append(item)
for name in ('source.bundle', 'source.json'):
    shutil.copyfile(source / name, payload / name)
    assert sha(source / name) == sha(payload / name)

addition = '''    metadata=json.loads(Path('/opt/input/source.json').read_bytes())
    assert head==metadata['source']['commit'] and tree==metadata['source']['tree']
    for pin in metadata['pins']:
        path=Path('/work/source')/pin['path']
        assert path.is_file() and not path.is_symlink()
        assert path.stat().st_size==pin['bytes'] and digest(path)==pin['sha256']
    assert providerStore==store/'v11'
    assert config.read_text()=='enableGlobalVirtualStore: false\\nstoreDir: '+str(store)+'\\n'
    commands=[('typecheck','typecheck'),('lint','lint'),('format','format:check'),('architecture','lint:source-architecture'),('dependencies','verify:source-dependencies'),('invariants','test:invariants'),('orchestrator','test:orchestrator'),('unit','test:unit'),('build','build')]
    records=[]
    for name,command in commands:
        assert run('precommit-'+name+'-clean-before',['/usr/bin/git','status','--porcelain'],'/work/source',True)==''
        environment['LOOP_VERIFY_COMMAND_ARTIFACT_DIR']='/work/source/artifacts/c6e-precommit/'+name
        run('precommit-'+name,['/opt/bin/pnpm','--config.verify-deps-before-run=error',command],'/work/source',True,timeout=1500 if name in ('unit','orchestrator') else 600)
        records.append(json.loads((raw/('precommit-'+name+'.json')).read_bytes()))
        assert run('precommit-'+name+'-clean-after',['/usr/bin/git','status','--porcelain'],'/work/source',True)==''
    assert run('precommit-head-after',['/usr/bin/git','rev-parse','HEAD'],'/work/source',True).strip()==head
    assert run('precommit-tree-after',['/usr/bin/git','rev-parse','HEAD^{tree}'],'/work/source',True).strip()==tree
    assert run('precommit-private-refs-after',['/usr/bin/git','for-each-ref','--format=%(refname)','refs/milestone-loop/'],'/work/source',True).strip()==''
    assert not Path('/work/source/artifacts/orchestrator/state/state.json').exists()
    assert not Path('/work/source/.agent/authority-requests/ORCH-AUTH-01/request.json').exists()
    (raw/'precommit-observation.json').write_text(json.dumps({'schemaVersion':'source-publication-precommit-observation.v1','candidate':{'gitCommit':head,'gitTree':tree,'gitStatus':'','nodeVersion':nodeVersion,'pnpmVersion':pnpmVersion},'platform':'linux','commands':records,'sourceStateAdopted':False,'privateReferencesAbsent':True,'actualImplementationAudit':False,'sdkServiceReview':False,'actualCandidate':False,'completionEligible':False},indent=2)+'\\n')
    send('precommit-completed',sourceCommit=head,sourceTree=tree,commands=len(records),claimScope='Linux-precommit-checks',completionEligible=False)
'''
original = (c3 / 'guest-job.py').read_text()
anchor = "    send('oci-completed',containers=containers,volumes=volumes)\n"
assert original.count(anchor) == 1
guest = original.replace(anchor, anchor + addition)
install_anchor = "    run('source-install',"
assert guest.count(install_anchor) == 1
store_setup = '''    # Pin the same task-owned store before installation and sanitized provider
    # discovery. The first precommit guest retained a real mismatch after C3's
    # fallback relocated an already-installed store; do not weaken that check.
    config=Path(user.pw_dir)/'.config/pnpm/config.yaml'
    assert config.is_relative_to(Path('/home/qualifier')) and not config.exists()
    config.parent.mkdir(parents=True,exist_ok=True)
    config.write_text('enableGlobalVirtualStore: false\\nstoreDir: '+str(store)+'\\n')
    os.chown(config,1000,1000)
    (raw/'precommit-pnpm-config.yaml').write_bytes(config.read_bytes())
    (raw/'precommit-pnpm-config.json').write_text(json.dumps({'path':str(config),'sha256':digest(config),'store':str(store),'scope':'disposable-guest-account-only','sourceFilesChanged':False})+'\\n')
'''
guest = guest.replace(install_anchor, store_setup + install_anchor)
install_command = "run('source-install',['/opt/bin/pnpm','install','--frozen-lockfile','--offline','--ignore-scripts','--package-import-method','copy'],'/work/source',user=True)"
assert guest.count(install_command) == 1
# Match the real dependency replay's normal frozen offline install. The source
# workspace already permits esbuild's required postinstall; this runs only in
# the disposable guest. VM-2 retained the strict installed-byte mismatch caused
# by skipping that existing allowed build script.
guest = guest.replace(install_command, install_command.replace("'--ignore-scripts',", ''))
compile(guest, 'guest-job.py', 'exec')
(payload / 'guest-job.py').write_text(guest)
(receiver / 'guest-program.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True), guest.splitlines(True), fromfile='C3/guest-job.py', tofile='C6e/precommit-guest-job.py')))
shutil.copyfile(payload / 'guest-job.py', receiver / 'guest-job.py')
shutil.copyfile(c3 / 'run-host.py', root / 'run-host.py')
files = [{**pin(path), 'path': path.relative_to(payload).as_posix()} for path in sorted(payload.rglob('*')) if path.is_file()]
manifest = {'schemaVersion': 'orch-c3-input.v1', 'source': {key: metadata['source'][key] for key in ('commit', 'tree')}, 'files': files}
(payload / 'input-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
run_id = str(uuid.uuid4())
iso = root / ('input-' + run_id + '.iso')
for item in [old_expected['base'], *old_expected['launchers']]:
    path = Path(item['path'])
    assert pin(path) == {key: item[key] for key in ('path', 'bytes', 'sha256')}
    if 'prefix' in item:
        with path.open('rb') as stream:
            assert stream.read(64).hex() == item['prefix']
argv = [old_expected['launchers'][2]['path'], '-quiet', '-iso-level', '3', '-rock', '-joliet', '-output', str(iso), str(payload)]
result = subprocess.run(argv, capture_output=True, timeout=300, env={'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C', 'LD_LIBRARY_PATH': '/home/duncan/oc2-1_hj5pul/provider/usr/lib/x86_64-linux-gnu'})
(receiver / 'iso.stdout.log').write_bytes(result.stdout)
(receiver / 'iso.stderr.log').write_bytes(result.stderr)
(receiver / 'iso.json').write_text(json.dumps({'argv': argv, 'exitCode': result.returncode}) + '\n')
assert result.returncode == 0
iso.chmod(0o444)
expected = {**old_expected, 'binding': {**old_expected['binding'], 'runId': run_id, 'nonce': os.urandom(32).hex(), 'sourceCommit': metadata['source']['commit'], 'sourceTree': metadata['source']['tree'], 'inputManifestSha256': sha(payload / 'input-manifest.json')}, 'input': pin(iso), 'guestProgramSha256': sha(payload / 'guest-job.py')}
expected_path = root / ('expected-' + run_id + '.json')
expected_path.write_text(json.dumps(expected, indent=2) + '\n')
shutil.copyfile(expected_path, receiver / 'expected.json')
shutil.copyfile(payload / 'input-manifest.json', receiver / 'input-manifest.json')
(receiver / 'preparation.json').write_text(json.dumps({'root': str(root), 'expectedPath': str(expected_path), 'hostProgram': pin(root / 'run-host.py'), 'guestProgram': pin(payload / 'guest-job.py'), 'reusedPins': reused, 'source': metadata, 'claimScope': 'C3-host-policy-plus-clean-Linux-precommit-checks', 'completionEligible': False, 'provider65MinuteBoundary': False}, indent=2) + '\n')
print(json.dumps({'expected': str(expected_path), 'hostProgram': str(root / 'run-host.py'), 'inputBytes': iso.stat().st_size, 'verificationExecuted': False}), flush=True)
