import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { createHash } from 'node:crypto';
const root=process.cwd(), draft=resolve(root,'artifacts/wp6e-source-publication-20260906/recovery-repair-draft');
const baselines=[];
async function edit(path, change) {
 const bytes=await readFile(resolve(root,path));
 let value=bytes.toString().replaceAll('\r\n','\n');
 const replace=(before,after)=>{assert.equal(value.split(before).length,2,'Expected one replacement: '+before);value=value.replace(before,after);};
 change(replace);
 for(const side of ['before','after']) await mkdir(dirname(resolve(draft,side,path)),{recursive:true});
 await writeFile(resolve(draft,'before',path),bytes);
 await writeFile(resolve(draft,'after',path),value);
 baselines.push({path,sha256:createHash('sha256').update(bytes).digest('hex')});
}
await edit('tools/milestone-orchestrator/src/source-authority-records.mjs', replace=>{
 replace('export function inspectSourcePublicationEvents(bytes, expected, owners) {', `function inspectPublicationEventChain(bytes, expected, owners) {`);
 replace('      "previousSha256",\n    ]);','      "previousSha256",\n      ...(Object.hasOwn(row, "preparedIntent") ? ["preparedIntent"] : []),\n    ]);');
 replace('    if (rows.length === 0) assert.equal(row.event, "attempt-start");',`    if (rows.length === 0) assert.equal(row.event, "attempt-start");
    if (Object.hasOwn(row, "preparedIntent")) {
      assert.equal(rows.length, 0, "Only the first attempt may retain the prepared intent.");
      assert.equal(sourceHash(readSourcePreparedIntent(bytes)), expected.intentSha256);
    }`);
 replace('        "intent-published",','        "intent-published",\n        "intent-observed-durable",');
 replace('    rows.filter((row) => row.event === "intent-published").length,','    rows.filter((row) => ["intent-published", "intent-observed-durable"].includes(row.event)).length,');
 replace('  assert.equal(offset, bytes.length);\n  assert.equal(',`  assert.equal(offset, bytes.length);
  return rows;
}

/** The fsynced first attempt retains exact planned bytes before active intent.
 * Reading them supplies no mutation permission; retry still needs fresh review
 * and the real lease, clean request, exact prior files and original owner. */
export function readSourcePreparedIntent(bytes) {
  assert(Buffer.isBuffer(bytes) && bytes.length > 0 && bytes.includes(10));
  const first = JSON.parse(bytes.subarray(0, bytes.indexOf(10)).toString());
  assert.equal(first.event, "attempt-start");
  assert(typeof first.preparedIntent === "string" && first.preparedIntent.length > 0,
    "The first pre-intent attempt did not retain its exact prepared intent.");
  const intent = Buffer.from(first.preparedIntent, "base64");
  assert.equal(intent.toString("base64"), first.preparedIntent);
  assert.equal(sourceHash(intent), first.intentSha256);
  return intent;
}

export function inspectSourcePreparedPublicationEvents(bytes, expected, owners) {
  const rows = inspectPublicationEventChain(bytes, expected, owners);
  assert(rows.every(row => row.event === "attempt-start"),
    "A pre-intent retry contains active publication events.");
  assert.equal(sourceHash(readSourcePreparedIntent(bytes)), expected.intentSha256);
  assert.deepEqual(rows[0].lease, expected.originalLease);
  return rows;
}

export function inspectSourcePublicationEvents(bytes, expected, owners) {
  const rows = inspectPublicationEventChain(bytes, expected, owners);
  assert.equal(`);
});
await edit('tools/milestone-orchestrator/src/source-authority-publication.ts', replace=>{
 replace('import { inspectSourceLeaseOwner } from "./source-authority-records.mjs";',`import { inspectSourceLeaseOwner, inspectSourcePreparedPublicationEvents, readSourcePreparedIntent } from "./source-authority-records.mjs";`);
 replace('  readonly afterIntent?: () => Promise<void> | void;',`  readonly afterIntentWrite?: () => Promise<void> | void;
  readonly afterIntent?: () => Promise<void> | void;`);
 replace('  readonly afterFinalization?: () => Promise<void> | void;',`  readonly afterFinalization?: () => Promise<void> | void;
  readonly beforeEvidenceFile?: (path: string) => Promise<void> | void;
  readonly afterEvidenceFile?: (path: string) => Promise<void> | void;`);
 replace('  const raw = pending ?? completed;',`  const activeIntent = pending ?? completed;
  const preparedEvents = activeIntent === null ? await sourceRead(root, paths.events, true) : null;
  const raw = activeIntent ?? (preparedEvents === null ? null : readSourcePreparedIntent(preparedEvents));`);
 replace('  if (raw === null) {\n    const identity', '  if (activeIntent === null) {\n    const identity');
 replace('    return {\n      context,\n      paths,\n      state,\n      invocation: identity,', '    if (raw === null) return {\n      context,\n      paths,\n      state,\n      invocation: identity,');
 replace('  const intent = validateIntent(JSON.parse(raw.toString()), context);',`  assert(raw !== null);
  const intent = validateIntent(JSON.parse(raw.toString()), context);
  if (preparedEvents !== null) {
    const owners = new Map();
    for (const line of preparedEvents.toString().trimEnd().split("\\n")) {
      const row = JSON.parse(line);
      const id = row.lease?.objectId;
      assert(typeof id === "string" && /^[a-f0-9]{40}$/.test(id));
      const owner = await sourceRead(root, paths.directory + "/lease-owners/" + id + ".json");
      owners.set(id, inspectSourceLeaseOwner(owner, id));
    }
    inspectSourcePreparedPublicationEvents(preparedEvents, {
      requestSha256: expected.sha256,
      intentSha256: sourceHash(raw),
      originalLease: intent.leaseAtCreation,
    }, owners);
  }`);
 replace('        previousSha256: before === null ? null : sourceHash(before),','        previousSha256: before === null ? null : sourceHash(before),\n        ...(before === null ? {preparedIntent: intentBytes.toString("base64")} : {}),');
 replace('      await assertBoundary(current.intent !== null);','      await assertBoundary(current.pendingPresent || current.completed);');
 replace('      if (current.intent === null) {','      if (!current.pendingPresent && !current.completed) {');
 replace('        await trace("intent-published");\n        await hooks.afterIntent?.();\n      }\n      await assertBoundary(true);',`        await hooks.afterIntentWrite?.();
      }
      // Recovery can observe the exact exclusive intent after a crash before
      // its append observation. Retain that observed fact once under this lease.
      const recordedIntent = expectedTrace!.toString().trimEnd().split("\\n")
        .map(line => JSON.parse(line)).filter(row => ["intent-published", "intent-observed-durable"].includes(row.event));
      assert(recordedIntent.length <= 1, "Duplicate source intent publication events.");
      if (recordedIntent.length === 0) {
        await assertBoundary(true);
        await trace(current.pendingPresent ? "intent-observed-durable" : "intent-published");
      }
      if (!current.pendingPresent && !current.completed) await hooks.afterIntent?.();
      await assertBoundary(true);`);
 replace('      assertInputs: () => assertInputs(true, true),','      assertInputs: () => assertInputs(true, true),\n      hooks,');
});
await edit('tools/milestone-orchestrator/src/source-authority-publication-receipt.ts',replace=>{
 replace('  readonly assertInputs: () => Promise<void>;','  readonly assertInputs: () => Promise<void>;\n  readonly hooks?: {readonly beforeEvidenceFile?: (path: string) => Promise<void> | void; readonly afterEvidenceFile?: (path: string) => Promise<void> | void};');
 replace('  ]) {\n    await boundary();\n    assert.deepEqual(', '  ]) {\n    await input.hooks?.beforeEvidenceFile?.(path);\n    await boundary();\n    assert.deepEqual(');
 replace('    await exactWrite(root, SOURCE_PUBLICATION_EVIDENCE_PREFIX + path, contents);','    await exactWrite(root, SOURCE_PUBLICATION_EVIDENCE_PREFIX + path, contents);\n    await input.hooks?.afterEvidenceFile?.(path);');
});
await edit('scripts/verify.mjs',replace=>{
 replace('  const qualifierDispatch =\n    activeScope === "source"', '  const qualifierDispatch =\n    activeScope === "source" && fullRun');
 replace('  const scope = qualifierDispatch\n    ? sourceVerificationScope(\n        candidate,\n        "full-source-qualification",\n        qualifierDispatch.qualifierRun,\n      )\n    : null;',`  const scope = activeScope === "source"
    ? sourceVerificationScope(
        candidate,
        fullRun ? "full-source-qualification" : "candidate-support",
        qualifierDispatch?.qualifierRun ?? null,
      )
    : null;`);
});
await writeFile(resolve(draft,'baselines.json'),JSON.stringify({claim:'Unexecuted prepared repair; reproduce regressions before integration',files:baselines},null,2)+'\n');
console.log(JSON.stringify({draft,files:baselines.length,claim:'prepared only'}));
