import assert from "node:assert/strict";
import { existsSync } from "node:fs";
import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { evidenceContext, writeReceipt, writeManualEvidenceFailure } from "../../../tools/evidence.mjs";
import { validateCommandReceiptDirectory } from "../../../tools/milestone-orchestrator/src/verifier.js";
import { inspectDependencyRepair } from "../../../docs/source-authority/ORCH-AUTH-01-C6e/inspect-dependency-repair.js";
const repository=resolve(import.meta.dirname,"../../..");
const retained=resolve(repository,"artifacts/wp6e-source-publication-20260906");
const output=resolve(retained,"dependency-repair-focused-audit-1");
assert(!existsSync(output));
process.env["LOOP_VERIFY_COMMAND_ARTIFACT_DIR"]=output;
const context=await evidenceContext("orch-auth-01-c6e","dependency-repair-focused-audit");
try {
 const result=await inspectDependencyRepair(repository,retained);
 await writeFile(resolve(output,"report.json"),JSON.stringify(result,null,2)+"\n");
 await writeFile(resolve(output,"executed-inspector.ts"),await readFile(resolve(repository,"docs/source-authority/ORCH-AUTH-01-C6e/inspect-dependency-repair.ts")));
 await writeFile(resolve(output,"executed-auditor.ts"),await readFile(import.meta.filename));
 await writeReceipt(context,[{id:"complete-dependency-repair-and-regression-evidence",summary:"Validated actual Linux intact/corrupt dependency boundaries, all seven reference/log meanings, 331 unchanged executing pins, the complete 260-case raw report and preserved prior 203 identities, plus four static receipts."}],[{path:"report.json",kind:"dependency-repair-focused-audit"},{path:"executed-inspector.ts",kind:"dependency-repair-inspector"},{path:"executed-auditor.ts",kind:"dependency-repair-auditor"}]);
 const receipt=await validateCommandReceiptDirectory({directory:output,expectedStageId:context.stageId,expectedCommandId:context.commandId,requiredKinds:["dependency-repair-focused-audit","dependency-repair-inspector","dependency-repair-auditor"]});
 console.log(JSON.stringify({tests:result.tests,files:result.files,receiptSha256:receipt.receiptSha256,completionEligible:false}));
}catch(error){await writeManualEvidenceFailure(context,{kind:"product",message:error instanceof Error?error.stack:String(error)});throw error;}
