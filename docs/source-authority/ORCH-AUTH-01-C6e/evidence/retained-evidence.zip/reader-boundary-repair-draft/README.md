# Unexecuted publication-reader repair draft

The primary publication-focused-13 run continues against unchanged production
files. `before/` captures the exact six source/test files before this draft.
`after/` is not integrated, executed, verified, or committed.

The first publisher case failed at the existing 180000 ms boundary. Preserve
the full run's raw failure before using this draft. Source inspection identified
separate ls-tree/cat-file launches for each historical pin and duplicate
lease/permit checks in the packet export boundary. This draft batches immutable
objects within each new inspection, observes attached Git identity in one
rev-parse command, and factors identical same-boundary checks. Every publication
boundary still reobserves the live lease, private review permit, current source,
HEAD/index/branch, state, request/preserved files, intent and all twelve outputs.
No deadline, assertion, command floor or ownership boundary is removed.

Two new regression cases cover independent binary historical observations,
unchanged live-byte rejection and attached versus detached Git identity. A
literal MJS-to-TS re-export also replaces a concatenated import that the existing
architecture checker rejects. This is a code-inspection finding; execute and
retain the actual architecture check before integrating that fix.

After publication-focused-13 exits, independently compare every primary file
against its `before/` bytes. Apply only the matching draft, format, typecheck,
lint and run the complete publisher/evidence/lease files with original deadlines.
The expanded selection then contains 68 cases (12 publisher, 35 evidence,
21 lease). No synthetic fixture is a real implementation audit, SDK service
review, migration, activation, candidate execution or readiness claim.
