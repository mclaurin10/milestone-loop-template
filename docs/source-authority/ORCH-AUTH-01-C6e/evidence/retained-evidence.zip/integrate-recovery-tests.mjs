import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { createHash } from 'node:crypto';
const root=process.cwd(), draft=resolve(root,'artifacts/wp6e-source-publication-20260906/recovery-boundaries-draft');
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const baseline=JSON.parse(await readFile(resolve(draft,'baseline.json')));
assert.equal(hash(await readFile(resolve(root,baseline.path))),baseline.sha256);
const files=[baseline.path,'tools/milestone-orchestrator/test/synthetic-source-publication.ts',
 'tools/milestone-orchestrator/src/source-authority-recovery.test.ts',
 'tools/milestone-orchestrator/src/source-verifier-consumers.test.ts'];
for(const path of files.slice(1)) assert(!existsSync(resolve(root,path)),path+' already exists');
const catalogPath='tools/milestone-orchestrator/config/test-ownership.json';
const testPath='tools/milestone-orchestrator/src/test-ownership.test.ts';
const catalogBytes=await readFile(resolve(root,catalogPath));
const testBytes=await readFile(resolve(root,testPath));
for(const [path,bytes] of [[catalogPath,catalogBytes],[testPath,testBytes]]) {
 await mkdir(dirname(resolve(draft,'before',path)),{recursive:true});
 await writeFile(resolve(draft,'before',path),bytes);
}
const catalog=JSON.parse(catalogBytes);
const owner=catalog.owners.find(o=>o.id==='controller-runtime');
assert(owner.files.length===92);
owner.files.push(...files.slice(2));owner.files.sort();
let test=testBytes.toString();
assert(test.includes('["controller-runtime", 92]') && test.includes('toHaveLength(100)'));
test=test.replace('["controller-runtime", 92]','["controller-runtime", 94]').replace('toHaveLength(100)','toHaveLength(102)');
for(const path of files) await writeFile(resolve(root,path),await readFile(resolve(draft,'after',path)));
await writeFile(resolve(root,catalogPath),JSON.stringify(catalog,null,2)+'\n');
await writeFile(resolve(root,testPath),test);
await writeFile(resolve(draft,'integration-observation.json'),JSON.stringify({observedAt:new Date().toISOString(),claim:'Unverified regression integration; production repair not integrated',checked:baseline,files:[...files,catalogPath,testPath]},null,2)+'\n');
console.log(JSON.stringify({integrated:[...files,catalogPath,testPath],controllerFiles:94,rootFiles:101,catalogueFiles:102}));
