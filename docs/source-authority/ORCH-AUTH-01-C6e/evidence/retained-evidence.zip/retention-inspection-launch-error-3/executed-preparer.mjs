import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const repository = resolve(import.meta.dirname, '../../..');
const source = await readFile(resolve(repository, 'docs/source-authority/ORCH-AUTH-01-C6e/audit.ts'), 'utf8');
const start = source.indexOf('  const invalidPrefix =');
const end = source.indexOf('  const nativePrefix =');
assert(start >= 0 && end > start);
const block = source.slice(start, end);
const header = `import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { lstat, readFile, readdir, writeFile } from 'node:fs/promises';
import { isAbsolute, resolve } from 'node:path';
import { evidenceContext, writeReceipt, writeManualEvidenceFailure } from '../../../tools/evidence.mjs';
import { validateCommandReceiptDirectory } from '../../../tools/milestone-orchestrator/src/verifier.ts';
type Pin = {path: string; bytes: number; sha256: string};
const input = resolve(import.meta.dirname, '..');
const output = resolve(input, 'invalid-native-retry-audit-1');
assert(!existsSync(output));
process.env.LOOP_VERIFY_COMMAND_ARTIFACT_DIR = output;
const context = await evidenceContext('orch-auth-01-c6e', 'invalid-native-retry-audit');
const hash = (bytes: Uint8Array) => createHash('sha256').update(bytes).digest('hex');
const read = async (path: string) => JSON.parse(await readFile(resolve(input, path), 'utf8'));
try {
const unbornInput = await read('precommit/subject/source.json');
const unbornFrozen = await read('unborn-regression-inputs-6/inputs.json');
const failedRuns: unknown[] = [];
`;
const footer = `
const pins: Pin[] = [];
async function walk(path: string) {
  for (const name of (await readdir(resolve(input, path))).sort()) {
    const child = path + '/' + name;
    const info = await lstat(resolve(input, child));
    assert(!info.isSymbolicLink());
    if (info.isDirectory()) await walk(child);
    else {
      assert(info.isFile() && info.size <= 20000000);
      const bytes = await readFile(resolve(input, child));
      pins.push({path: child, bytes: bytes.length, sha256: hash(bytes)});
    }
  }
}
await walk(invalidPrefix);
await writeFile(resolve(output, 'executed-inspector.ts'), await readFile(import.meta.filename));
await writeFile(resolve(output, 'report.json'), JSON.stringify({schemaVersion: 'invalid-native-retry-retained-inspection.v1', observation: failedRuns[0], pins, completionEligible: false, fullSuiteVerified: false, newTestsExecuted: false}, null, 2)+'\n');
await writeReceipt(context, [{id:'retained-invalid-retry-observation',summary:'Checked the preserved partial native run, exact leaked receipt identifiers, clean source pins, byte-preserving collection and actual targeted stop record. This audits retained failure observations and establishes no full-suite result.'}], [{path:'report.json',kind:'invalid-native-retry-observation'},{path:'executed-inspector.ts',kind:'invalid-native-retry-inspector'}]);
const checked = await validateCommandReceiptDirectory({directory:output,expectedStageId:context.stageId,expectedCommandId:context.commandId,requiredKinds:['invalid-native-retry-observation','invalid-native-retry-inspector']});
console.log(JSON.stringify({files:pins.length,partialCases:10,passed:4,failed:6,receiptSha256:checked.receiptSha256,fullSuiteVerified:false}));
} catch(error) {
await writeManualEvidenceFailure(context,{kind:'product',message:error.stack ?? String(error)});
throw error;
}
`;
await writeFile(resolve(import.meta.dirname, 'inspect-invalid-retry.ts'), header + block + footer, {flag:'wx'});
console.log(JSON.stringify({prepared:true,blockStart:start,blockEnd:end,sourceImplementationChanged:false,verificationClaim:false}));
