# Project Verification Result

- Run: `native-focused-consumer`
- Profile: `readiness` (Approved orchestrator source qualification)
- Status: **FAIL**
- Exit code: `1`
- Completion eligible: `false`
- Completion claim: `source_machine_qualified_for_human_acceptance`
- Autonomous-readiness equivalent: `false`
- Execution provider: `trusted-container` (unattested, completion eligible: false)
- Started: `2026-09-06T21:30:47.017Z`
- Finished: `2026-09-06T21:31:36.168Z`
- Git commit: `1c48237e3e3aeca064eb6f07d15f2303d6bd0ffe`
- Working tree dirty: `false`

| Stage | Status | Required command gaps/failures |
|---|---:|---|
| Source dependency integrity | FAIL | Command failed with exit 1. |
| Approved source authority integrity | FAIL | Command failed with exit 1. |

A required `NOT_READY`, `FAIL`, or `ERROR` is non-passing. A focused, dirty-tree, profile-override, or bootstrap run cannot establish autonomous readiness. See `result.json` for the complete machine-readable record.
