import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '../../..');
let source = await readFile(resolve(root, 'artifacts/wp6e-source-publication-20260906/retention-tools-static-5/executed-checker.mjs'), 'utf8');
const replace = (before, after) => { assert(source.includes(before), before); source = source.replace(before, after); };
replace("retention-tools-static-5');", "retention-tools-static-6');");
replace('commandIdentity, evidenceContext, runPnpm,', 'commandIdentity, evidenceContext, runPnpm, superviseEvidenceCommand,');
replace("const files = [...code, prefix + 'README.md'];", `const nativeTools = [
  'artifacts/wp6e-source-publication-20260906/retention-draft/run-native-retry.mjs',
  '.tools/wp6e-c6e-unborn-precommit-20260907/artifacts/c6e-native-retry-tools/runtime/run-focused.ts',
  '.tools/wp6e-c6e-unborn-precommit-20260907/artifacts/c6e-native-retry-tools/runtime/progress-reporter.mjs',
];
const files = [...code, prefix + 'README.md', ...nativeTools];`);
replace("for (const [id, argv] of [['lint', ['exec', 'eslint', ...code]], ['format', ['exec', 'prettier', '--check', ...files]]]) {", `for (const [id, tool, argv] of [
    ['lint', 'pnpm', ['exec', 'eslint', ...code]],
    ['format', 'pnpm', ['exec', 'prettier', '--check', ...code, prefix + 'README.md']],
    ...nativeTools.map((path, index) => ['native-syntax-' + index, 'node', ['--check', resolve(repository, path)]]),
  ]) {`);
replace("const result = await runPnpm(argv, {cwd: repository, timeoutMs: 300_000});", "const result = tool === 'pnpm' ? await runPnpm(argv, {cwd: repository, timeoutMs: 300_000}) : await superviseEvidenceCommand(process.execPath, argv, {cwd: repository, timeoutMs: 30_000});");
replace("argv: ['pnpm', ...argv]", "argv: [tool === 'pnpm' ? 'pnpm' : process.execPath, ...argv]");
replace("const declarations = [", `for (const [index, path] of nativeTools.entries()) await writeFile(resolve(output, 'native-tool-' + index + '.' + (path.endsWith('.ts') ? 'ts' : 'mjs')), await readFile(resolve(repository, path)), {flag: 'wx'});
  const declarations = [
    ...nativeTools.map((path, index) => ({path:'native-tool-' + index + '.' + (path.endsWith('.ts') ? 'ts' : 'mjs'), kind:'retention-native-retry-procedure'})),`);
replace('ESLint and Prettier checked the exact pinned retained-audit, reconstruction, observer and bundle-preparation source; full retained behavioral audit remains separately required.', 'ESLint and Prettier checked the pinned retained-audit sources; pinned Node checked the three retry procedures as syntax without executing them. Full retained behavioral audit and the native retry remain separately required.');
await writeFile(resolve(import.meta.dirname, 'run-retention-static-six.mjs'), source, {flag:'wx'});
console.log(JSON.stringify({prepared: 'run-retention-static-six.mjs', commandsExecuted: false}));
