import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { lstat, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { assertCommandPassed, commandIdentity, evidenceContext, runPnpm, superviseEvidenceCommand, writeReceipt, writeManualEvidenceFailure } from '../../../tools/evidence.mjs';
import { validateCommandReceiptDirectory } from '../../../tools/milestone-orchestrator/src/verifier.ts';

const repository = resolve(import.meta.dirname, '../../..');
const output = resolve(repository, 'artifacts/wp6e-source-publication-20260906/retention-tools-static-6');
assert(!existsSync(output));
process.env.LOOP_VERIFY_COMMAND_ARTIFACT_DIR = output;
const context = await evidenceContext('orch-auth-01-c6e', 'retention-tools-static');
const prefix = 'docs/source-authority/ORCH-AUTH-01-C6e/';
const code = ['audit.ts', 'inspect-frozen-inputs.ts', 'inspect-dependency-repair.ts', 'inspect-revised-input.ts', 'inspect-precommit-reports.ts', 'inspect-linux-precommit.ts', 'observe-precommit.ts', 'prepare-precommit-source.mjs'].map(name => prefix + name);
const nativeTools = [
  'artifacts/wp6e-source-publication-20260906/retention-draft/run-native-retry.mjs',
  '.tools/wp6e-c6e-unborn-precommit-20260907/artifacts/c6e-native-retry-tools/runtime/run-focused.ts',
  '.tools/wp6e-c6e-unborn-precommit-20260907/artifacts/c6e-native-retry-tools/runtime/progress-reporter.mjs',
];
const files = [...code, prefix + 'README.md', ...nativeTools];
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
try {
  const identity = await commandIdentity(repository);
  assert.equal(identity.nodeVersion, 'v24.18.0');
  assert.equal(identity.pnpmVersion, '11.15.1');
  const pins = [];
  for (const path of files) {
    const absolute = resolve(repository, path);
    const info = await lstat(absolute);
    assert(info.isFile() && !info.isSymbolicLink());
    const bytes = await readFile(absolute);
    pins.push({ path, bytes: bytes.length, sha256: hash(bytes) });
  }
  const commands = [];
  for (const [id, tool, argv] of [
    ['lint', 'pnpm', ['exec', 'eslint', ...code]],
    ['format', 'pnpm', ['exec', 'prettier', '--check', ...code, prefix + 'README.md']],
    ...nativeTools.map((path, index) => ['native-syntax-' + index, 'node', ['--check', resolve(repository, path)]]),
  ]) {
    const startedAt = new Date().toISOString();
    const result = tool === 'pnpm' ? await runPnpm(argv, {cwd: repository, timeoutMs: 300_000}) : await superviseEvidenceCommand(process.execPath, argv, {cwd: repository, timeoutMs: 30_000});
    const record = { id, argv: [tool === 'pnpm' ? 'pnpm' : process.execPath, ...argv], startedAt, finishedAt: new Date().toISOString(), exitCode: result.status, signal: result.signal, supervision: result.supervision, error: result.error?.message ?? null };
    for (const stream of ['stdout', 'stderr']) await writeFile(resolve(output, id + '.' + stream + '.log'), result[stream] ?? '');
    await writeFile(resolve(output, id + '.execution.json'), JSON.stringify(record, null, 2) + '\n');
    assertCommandPassed(result, 'C6e retained auditor ' + id);
    commands.push(record);
  }
  for (const pin of pins) assert.equal(hash(await readFile(resolve(repository, pin.path))), pin.sha256);
  await writeFile(resolve(output, 'executed-checker.mjs'), await readFile(import.meta.filename));
  await writeFile(resolve(output, 'report.json'), JSON.stringify({schemaVersion: 'source-publication-retention-static.v1', identity, pins, commands, completionEligible: false, retainedAuditExecuted: false}, null, 2) + '\n');
  for (const [index, path] of nativeTools.entries()) await writeFile(resolve(output, 'native-tool-' + index + '.' + (path.endsWith('.ts') ? 'ts' : 'mjs')), await readFile(resolve(repository, path)), {flag: 'wx'});
  const declarations = [
    ...nativeTools.map((path, index) => ({path:'native-tool-' + index + '.' + (path.endsWith('.ts') ? 'ts' : 'mjs'), kind:'retention-native-retry-procedure'})),
    {path:'report.json',kind:'retention-tools-static-report'},
    {path:'executed-checker.mjs',kind:'retention-tools-static-procedure'},
    ...commands.flatMap(({id}) => [{path:id+'.execution.json',kind:'retention-tools-static-execution'},...['stdout','stderr'].map(stream => ({path:id+'.'+stream+'.log',kind:'retention-tools-static-log'}))]),
  ];
  // Keep zero-byte raw logs on disk, but receipts require nonempty artifacts.
  const artifacts = [];
  for (const item of declarations) if ((await lstat(resolve(output, item.path))).size > 0) artifacts.push(item);
  await writeReceipt(context, [{id:'actual-retention-tool-static-commands',summary:'ESLint and Prettier checked the pinned retained-audit sources; pinned Node checked the three retry procedures as syntax without executing them. Full retained behavioral audit and the native retry remain separately required.'}], artifacts);
  const checked = await validateCommandReceiptDirectory({directory:output,expectedStageId:context.stageId,expectedCommandId:context.commandId,requiredKinds:['retention-tools-static-report','retention-tools-static-procedure','retention-tools-static-execution','retention-tools-static-log']});
  console.log(JSON.stringify({commands:commands.length,files:pins.length,receiptSha256:checked.receiptSha256}));
} catch (error) {
  await writeManualEvidenceFailure(context, {kind:'product',message:error.stack ?? String(error)});
  throw error;
}
