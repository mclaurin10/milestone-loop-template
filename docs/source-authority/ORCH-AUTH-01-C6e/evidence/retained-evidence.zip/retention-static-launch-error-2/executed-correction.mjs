import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const directory = resolve(import.meta.dirname, '../retention-static-launch-error-2');
await mkdir(directory);
const path = resolve(import.meta.dirname, 'run-retention-static-six.mjs');
let source = await readFile(path, 'utf8');
await writeFile(resolve(directory, 'failed-checker.mjs'), source, {flag:'wx'});
await writeFile(resolve(directory, 'executed-preparer.mjs'), await readFile(resolve(import.meta.dirname, 'prepare-static-six.mjs')), {flag:'wx'});
await writeFile(resolve(directory, 'observation.json'), JSON.stringify({observedAt:new Date().toISOString(),kind:'actual-tool-launch-observation',argv:['pnpm','--config.verify-deps-before-run=error','exec','tsx','artifacts/wp6e-source-publication-20260906/retention-draft/run-retention-static-six.mjs'],exitCode:1,diagnostic:"SyntaxError: The requested module '../../../tools/evidence.mjs' does not provide an export named 'superviseEvidenceCommand'",evidenceContextCreated:false,staticCommandsExecuted:false,completionEligible:false},null,2)+'\n',{flag:'wx'});
const replace = (before, after) => {assert(source.includes(before),before);source=source.replace(before,after);};
replace('runPnpm, superviseEvidenceCommand,', 'runPnpm,');
replace("['native-syntax-' + index, 'node', ['--check', resolve(repository, path)]]", "['native-syntax-' + index, 'pnpm', ['exec', process.execPath, '--check', resolve(repository, path)]]");
replace("const result = tool === 'pnpm' ? await runPnpm(argv, {cwd: repository, timeoutMs: 300_000}) : await superviseEvidenceCommand(process.execPath, argv, {cwd: repository, timeoutMs: 30_000});", "const result = await runPnpm(argv, {cwd: repository, timeoutMs: id.startsWith('native-syntax-') ? 30_000 : 300_000});");
await writeFile(path, source);
await writeFile(resolve(directory, 'executed-correction.mjs'), await readFile(import.meta.filename), {flag:'wx'});
console.log(JSON.stringify({preserved:directory,staticCommandsExecuted:false}));
