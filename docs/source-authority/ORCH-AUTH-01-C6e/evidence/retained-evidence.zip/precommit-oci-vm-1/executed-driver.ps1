$ErrorActionPreference='Stop'
$taskRoot='C:\Dev\loop-extraction\milestone-loop-template'
if((Get-Location).Path -ne $taskRoot){throw 'Unexpected workspace'}
$taskEvidence=Join-Path $taskRoot 'artifacts\wp6e-source-publication-20260906'
$taskReceiver=Join-Path $taskEvidence 'precommit-oci-vm-1'
$taskLinuxReceiver='/mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/wp6e-source-publication-20260906/precommit-oci-vm-1'
$taskDraft='/mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/wp6e-source-publication-20260906/retention-draft'
$taskClone=Join-Path $taskRoot '.tools\wp6e-c6e-precommit-20260906'
$env:PATH=(Join-Path $taskRoot '.tools\node-v24.18.0-win-x64')+';'+$env:PATH
if(Test-Path -LiteralPath $taskReceiver){throw 'Fresh VM receiver already exists'}
New-Item -ItemType Directory -Path (Join-Path $taskReceiver 'input')|Out-Null
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $taskReceiver 'executed-driver.ps1')
$taskPrior=Join-Path $taskEvidence 'precommit-revised-source-input-1'
$taskMetadata=Get-Content -LiteralPath (Join-Path $taskPrior 'source.json') -Raw|ConvertFrom-Json
foreach($taskName in @('source.bundle','precommit.bundle','source.json')){
  $taskTarget=Join-Path $taskReceiver ('input\'+$taskName)
  Copy-Item -LiteralPath (Join-Path $taskPrior $taskName) -Destination $taskTarget
  if((Get-FileHash -LiteralPath $taskTarget).Hash -ne (Get-FileHash -LiteralPath (Join-Path $taskPrior $taskName)).Hash){throw 'Copied source differs'}
}
foreach($taskPin in @($taskMetadata.bundle,$taskMetadata.subjectBundle)){
  $taskPath=Join-Path $taskReceiver ('input\'+$taskPin.path)
  if((Get-Item -LiteralPath $taskPath).Length -ne $taskPin.bytes -or (Get-FileHash -LiteralPath $taskPath).Hash.ToLowerInvariant() -ne $taskPin.sha256){throw 'Wrong source bundle'}
}
function Invoke-TaskCapture([string]$Name,[string]$Executable,[string[]]$Arguments){
  $taskStarted=[DateTime]::UtcNow.ToString('o')
  [ordered]@{startedAt=$taskStarted;argv=@($Executable)+$Arguments}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $taskReceiver ($Name+'-start.json'))
  & $Executable @Arguments 1> (Join-Path $taskReceiver ($Name+'.stdout.log')) 2> (Join-Path $taskReceiver ($Name+'.stderr.log'))
  $taskExit=$LASTEXITCODE
  [ordered]@{startedAt=$taskStarted;endedAt=[DateTime]::UtcNow.ToString('o');exitCode=$taskExit;argv=@($Executable)+$Arguments}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $taskReceiver ($Name+'-execution.json'))
  return $taskExit
}
$taskPrepare=Invoke-TaskCapture 'prepare' 'wsl.exe' @('-d','Ubuntu','-u','duncan','--exec','/usr/bin/python3.12',($taskDraft+'/prepare-precommit-oci-vm1.py'),$taskLinuxReceiver)
if($taskPrepare -ne 0){throw 'Preparation failed; see retained raw logs'}
$taskPrep=Get-Content -LiteralPath (Join-Path $taskReceiver 'preparation.json') -Raw|ConvertFrom-Json
$taskExpected=Get-Content -LiteralPath (Join-Path $taskReceiver 'expected.json') -Raw|ConvertFrom-Json
$taskHostPath='\\wsl.localhost\Ubuntu'+$taskPrep.hostProgram.path.Replace('/','\')
$taskGuestPath='\\wsl.localhost\Ubuntu'+$taskPrep.guestProgram.path.Replace('/','\')
$taskHostHash=(Get-FileHash -LiteralPath $taskHostPath).Hash.ToLowerInvariant()
$taskGuestHash=(Get-FileHash -LiteralPath $taskGuestPath).Hash.ToLowerInvariant()
if($taskHostHash -ne 'e3e8fd910030f5fe0e7d831960ce4c6ac6cfa51908405b4a8a2702f29ac29c9c' -or $taskGuestHash -ne $taskExpected.guestProgramSha256){throw 'Program bytes mismatch'}
if($taskExpected.binding.sourceCommit -ne '1c386ec95b628a2323f8d5dab351ad72a59abe3a' -or $taskExpected.binding.sourceTree -ne '4e4d2ae0eae69784263f6d18668c5bb070f94c62'){throw 'Wrong source identity'}
$taskDiff=Get-Content -LiteralPath (Join-Path $taskReceiver 'guest-program.diff') -Raw
if(($taskDiff -split '\r?\n'|Where-Object{$_ -match '^@@'}).Count -ne 2){throw 'Unexpected guest patch hunks'}
if(-not $taskDiff.Contains("+    run('source-install',['/opt/bin/pnpm','install','--frozen-lockfile','--offline','--package-import-method','copy'],'/work/source',user=True)")){throw 'Normal source install missing'}
[ordered]@{at=[DateTime]::UtcNow.ToString('o');hostProgramSha256=$taskHostHash;guestProgramSha256=$taskGuestHash;source=$taskExpected.binding;guestDiffSha256=(Get-FileHash -LiteralPath (Join-Path $taskReceiver 'guest-program.diff')).Hash.ToLowerInvariant();hostUnchanged=$true}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $taskReceiver 'prelaunch-inspection.json')
Write-Output ([ordered]@{phase='prepared';root=$taskPrep.root;runId=$taskExpected.binding.runId;sourceCommit=$taskExpected.binding.sourceCommit}|ConvertTo-Json -Compress)
$taskHost=Invoke-TaskCapture 'host-command' 'wsl.exe' @('-d','Ubuntu','-u','root','--exec','/usr/bin/python3.12',$taskPrep.hostProgram.path,$taskPrep.expectedPath)
$taskCollect=Invoke-TaskCapture 'collect' 'wsl.exe' @('-d','Ubuntu','-u','duncan','--exec','/usr/bin/python3.12',($taskDraft+'/collect-precommit-oci-vm1.py'),$taskLinuxReceiver)
if($taskCollect -ne 0){throw 'Collection failed; no verification claim'}
Push-Location -LiteralPath $taskClone
try{
  $taskAuditNames=@('cleanup','oci')
  if($taskHost -eq 0){$taskAuditNames+=@('host')}
  foreach($taskName in $taskAuditNames){
    $taskOut='artifacts/c6e-oci-vm1-'+$taskName+'-audit'
    if(Test-Path -LiteralPath $taskOut){throw 'Audit output already exists'}
    $taskArgs=switch($taskName){
      'cleanup' {@('docs/runtime-qualification/ORCH-AUTH-01-C3/audit-cleanup.ts',$taskPrep.root,$taskOut)}
      'oci' {@('docs/runtime-qualification/ORCH-AUTH-01-C3/audit-oci.ts',(Join-Path $taskReceiver 'guest'),'artifacts/oci',$taskExpected.binding.sourceCommit,$taskExpected.binding.sourceTree,$taskOut)}
      'host' {@('docs/runtime-qualification/ORCH-AUTH-01-C3/audit-host.ts',(Join-Path $taskReceiver 'host'),(Join-Path $taskReceiver 'guest'),(Join-Path $taskClone 'artifacts/c6e-oci-vm1-oci-audit'),$taskOut)}
    }
    pnpm --config.verify-deps-before-run=error exec tsx @taskArgs
    if($LASTEXITCODE -ne 0){throw ('Independent '+$taskName+' audit failed')}
    Copy-Item -LiteralPath $taskOut -Destination (Join-Path $taskReceiver ($taskName+'-audit')) -Recurse
  }
}finally{Pop-Location}
Write-Output ([ordered]@{hostExitCode=$taskHost;collectionExitCode=$taskCollect;receiver=$taskReceiver;verificationClaim=$false}|ConvertTo-Json -Compress)
exit $taskHost
