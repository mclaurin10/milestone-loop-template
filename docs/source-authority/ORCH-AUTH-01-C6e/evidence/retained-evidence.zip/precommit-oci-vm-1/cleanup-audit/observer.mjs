import fs from 'node:fs/promises';
const inputs=JSON.parse(Buffer.from(process.argv[1],'base64url'));
const absent=async path=>{try{await fs.lstat(path);return false;}catch(e){if(e.code!=='ENOENT')throw e;return true;}};
const start=value=>value.slice(value.lastIndexOf(')')+2).split(' ')[19];
const results=[];
for(const item of inputs){
  let processIdentityAbsent=null, observedStat=null, observedCgroup=null;
  if(item.pid!==null){
    try{observedStat=await fs.readFile('/proc/'+item.pid+'/stat','utf8');observedCgroup=await fs.readFile('/proc/'+item.pid+'/cgroup','utf8');processIdentityAbsent=(item.startStat!==null&&start(observedStat)!==start(item.startStat))||!observedCgroup.includes('/'+item.unit);}
    catch(e){if(e.code!=='ENOENT'&&e.code!=='ESRCH')throw e;processIdentityAbsent=true;}
  }
  results.push({...item,processIdentityAbsent,observedStat,observedCgroup,directoryAbsent:await absent(item.directory),cgroupAbsent:await absent('/sys/fs/cgroup/system.slice/'+item.unit)});
}
process.stdout.write(JSON.stringify({at:new Date().toISOString(),platform:process.platform,nodeVersion:process.version,uid:process.getuid(),bootId:(await fs.readFile('/proc/sys/kernel/random/boot_id','utf8')).trim(),pidNamespace:await fs.readlink('/proc/self/ns/pid'),results})+'\n');
