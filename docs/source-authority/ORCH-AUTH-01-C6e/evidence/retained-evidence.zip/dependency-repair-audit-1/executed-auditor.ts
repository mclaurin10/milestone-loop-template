import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { existsSync } from "node:fs";
import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { commandIdentity, evidenceContext, writeReceipt, writeManualEvidenceFailure } from "../../../tools/evidence.mjs";
import { validateCommandReceiptDirectory } from "../../../tools/milestone-orchestrator/src/verifier.js";
import { inspectSourceAuditReports } from "../../../tools/milestone-orchestrator/src/source-authority-audit-reports.mjs";
import { SOURCE_AUDIT_COMMANDS } from "../../../tools/milestone-orchestrator/src/source-authority-evidence.mjs";
import { assertActiveAuthorityPublication } from "../../../tools/milestone-orchestrator/src/authority-publication.mjs";

const repository = resolve(import.meta.dirname, "../../..");
const evidence = resolve(repository, "artifacts/wp6e-source-publication-20260906");
const input = resolve(evidence, "dependency-repair-linux-1");
const output = resolve(evidence, "dependency-repair-audit-1");
assert(!existsSync(output));
process.env["LOOP_VERIFY_COMMAND_ARTIFACT_DIR"] = output;
const context = await evidenceContext("orch-auth-01-c6e", "linux-dependency-repair-audit");
const hash = (bytes: Uint8Array) => createHash("sha256").update(bytes).digest("hex");
const json = async (path: string) => JSON.parse(await readFile(path, "utf8"));
try {
  const original = await json(resolve(evidence, "precommit-vm-3/input/source.json"));
  const delta = await json(resolve(input, "source-delta.json"));
  assert.deepEqual(delta.baseline, original.source);
  assert.equal(delta.changes.length, 4);
  const changes = new Map<string, {before: {bytes:number;sha256:string};after:{bytes:number;sha256:string}}>(delta.changes.map((row: {path:string;before:{bytes:number;sha256:string};after:{bytes:number;sha256:string}}) => [row.path, row]));
  const implementationFiles = new Map<string, Buffer>();
  for (const pin of original.pins) {
    const changed = changes.get(pin.path);
    if (changed) {
      assert.deepEqual(changed.before, {bytes:pin.bytes,sha256:pin.sha256});
      for (const phase of ["before", "after"] as const) {
        const bytes = await readFile(resolve(input, phase, pin.path));
        assert.equal(bytes.length, changed[phase].bytes);
        assert.equal(hash(bytes), changed[phase].sha256);
      }
    }
    const expected = changed?.after ?? pin;
    const bytes = await readFile(resolve(repository, pin.path));
    assert.equal(bytes.length, expected.bytes, pin.path);
    assert.equal(hash(bytes), expected.sha256, pin.path);
    implementationFiles.set(pin.path, bytes);
  }
  assert.equal(implementationFiles.size, 331);
  const expected = SOURCE_AUDIT_COMMANDS.find((command: {id:string}) => command.id === "dependencies")!;
  const directory = resolve(input, "intact");
  const receipt = await validateCommandReceiptDirectory({directory,expectedStageId:expected.stageId,expectedCommandId:expected.commandId,requiredKinds:expected.requiredKinds});
  const artifacts = new Map();
  for (const pin of receipt.artifacts) artifacts.set(pin.path, {...pin,contents:await readFile(resolve(directory, pin.path))});
  const report = await json(resolve(directory, "report.json"));
  assert.equal(report.schemaVersion, "source-dependencies-report.v2");
  await inspectSourceAuditReports({expected,child:{artifacts},implementation:{commit:original.source.commit,tree:original.source.tree},runtime:{nodeVersion:"v24.18.0",pnpmVersion:"11.15.1",platform:"linux",architecture:"x64"},implementationFiles});
  const commands = await json(resolve(input, "commands.json"));
  assert.deepEqual(commands.map((command: {name:string;exitCode:number;timedOut:boolean}) => ({name:command.name,exitCode:command.exitCode,timedOut:command.timedOut})), [{name:"intact",exitCode:0,timedOut:false},{name:"corrupt",exitCode:1,timedOut:false}]);
  for (const command of commands) {
    assert.deepEqual(command.argv.slice(1), ["--config.verify-deps-before-run=error", "verify:source-dependencies"]);
    assert.equal(command.uid, 1000);
    assert.equal(command.cwd, report.references.actual);
    assert(command.durationMs > 0);
  }
  const failure = await json(resolve(input, "corrupt/manifest.json"));
  assert.equal(failure.status, "ERROR");
  assert.equal(failure.receipt, null);
  assert(!existsSync(resolve(input, "corrupt/result.json")));
  assert.match(failure.failureClassification.message, /Installed dependency bytes differ from frozen reference/);
  const corruption = await json(resolve(input, "corruption.json"));
  assert.equal(corruption.restored, true);
  assert.equal(corruption.sourceFilesChangedByCorruption, false);
  assert.notEqual(corruption.original.sha256, corruption.mutated.sha256);
  const actual = "\\\\wsl.localhost\\Ubuntu" + corruption.path.replaceAll("/", "\\");
  assert.equal(hash(await readFile(actual)), corruption.original.sha256);
  assert.equal(await assertActiveAuthorityPublication(repository), "legacy");
  const observation = {schemaVersion:"source-dependency-repair-audit.v1",status:"PASS",observer:await commandIdentity(repository),sourceBase:original.source,changedSource:delta.changes,sourcePins:331,intactReceipt:receipt.receiptSha256,packages:report.packages.length,presentPackages:report.packages.filter((pkg:{present:boolean})=>pkg.present).length,captures:report.captures.map((capture:{id:string;cwd:string;exitCode:number})=>({id:capture.id,cwd:capture.cwd,exitCode:capture.exitCode})),corruption,failedManifestSha256:hash(await readFile(resolve(input,"corrupt/manifest.json"))),workingTreeDirty:true,actualImplementationAudit:false,sdkServiceReview:false,sourceQualification:false,completionEligible:false};
  await writeFile(resolve(output,"report.json"),JSON.stringify(observation,null,2)+"\n");
  await writeFile(resolve(output,"executed-auditor.ts"),await readFile(import.meta.filename));
  await writeReceipt(context,[{id:"real-dependency-pristine-built-and-corruption-boundaries",summary:"Validated the real Linux dependency receipt and all seven command/log/reference meanings against the exact changed source bytes; independently preserved the actual installed-byte corruption rejection and verified restoration."}],[{path:"report.json",kind:"source-dependency-repair-audit"},{path:"executed-auditor.ts",kind:"source-dependency-repair-auditor"}]);
  const checked=await validateCommandReceiptDirectory({directory:output,expectedStageId:context.stageId,expectedCommandId:context.commandId,requiredKinds:["source-dependency-repair-audit","source-dependency-repair-auditor"]});
  console.log(JSON.stringify({packages:observation.packages,presentPackages:observation.presentPackages,receiptSha256:checked.receiptSha256,completionEligible:false}));
} catch(error) {
  await writeManualEvidenceFailure(context,{kind:"product",message:error instanceof Error?error.stack:String(error)});
  throw error;
}
