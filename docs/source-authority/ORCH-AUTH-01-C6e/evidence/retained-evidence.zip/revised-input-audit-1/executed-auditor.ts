import assert from "node:assert/strict";
import { existsSync } from "node:fs";
import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { evidenceContext, writeReceipt, writeManualEvidenceFailure } from "../../../tools/evidence.mjs";
import { validateCommandReceiptDirectory } from "../../../tools/milestone-orchestrator/src/verifier.js";
import { inspectRevisedInput } from "../../../docs/source-authority/ORCH-AUTH-01-C6e/inspect-revised-input.js";
const repository=resolve(import.meta.dirname,"../../..");
const retained=resolve(repository,"artifacts/wp6e-source-publication-20260906");
const output=resolve(retained,"revised-input-audit-1");
assert(!existsSync(output));
process.env["LOOP_VERIFY_COMMAND_ARTIFACT_DIR"]=output;
const context=await evidenceContext("orch-auth-01-c6e","revised-input-bundle-audit");
try {
 const dependency=JSON.parse(await readFile(resolve(retained,"dependency-repair-focused-audit-1/report.json"),"utf8"));
 await validateCommandReceiptDirectory({directory:resolve(retained,"dependency-repair-focused-audit-1"),expectedStageId:"orch-auth-01-c6e",expectedCommandId:"dependency-repair-focused-audit",requiredKinds:["dependency-repair-focused-audit"]});
 const result=await inspectRevisedInput({repository,originalDirectory:resolve(retained,"precommit-vm-1/input"),revisedDirectory:resolve(retained,"precommit-revised-source-input-1"),scratch:resolve(output,"reconstruction"),originalCommit:dependency.sourceBase.commit,originalTree:dependency.sourceBase.tree,expectedPins:dependency.pins,expectedChanges:dependency.changes});
 await writeFile(resolve(output,"report.json"),JSON.stringify(result,null,2)+"\n");
 await writeFile(resolve(output,"executed-inspector.ts"),await readFile(resolve(repository,"docs/source-authority/ORCH-AUTH-01-C6e/inspect-revised-input.ts")));
 await writeFile(resolve(output,"executed-auditor.ts"),await readFile(import.meta.filename));
 await writeReceipt(context,[{id:"actual-original-and-revised-git-bundles",summary:"Imported both actual retained incremental Git bundles into a fresh owned object store and independently verified commit/tree/parent identities, the exact four-file delta and all 331 original and revised source pins."}],[{path:"report.json",kind:"revised-input-bundle-audit"},{path:"executed-inspector.ts",kind:"revised-input-inspector"},{path:"executed-auditor.ts",kind:"revised-input-auditor"}]);
 const receipt=await validateCommandReceiptDirectory({directory:output,expectedStageId:context.stageId,expectedCommandId:context.commandId,requiredKinds:["revised-input-bundle-audit","revised-input-inspector","revised-input-auditor"]});
 console.log(JSON.stringify({source:result.source,pins:result.verifiedPins,receiptSha256:receipt.receiptSha256,completionEligible:false}));
}catch(error){await writeManualEvidenceFailure(context,{kind:"product",message:error instanceof Error?error.stack:String(error)});throw error;}
