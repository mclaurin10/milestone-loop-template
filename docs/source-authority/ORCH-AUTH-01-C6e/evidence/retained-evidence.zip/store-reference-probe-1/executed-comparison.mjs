import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { compareInstalledDependencyGraphs } from "file:///home/duncan/c6e-store-diagnostic-0lb9ny6v/source/tools/source-release-inspection.mjs";
import { commandIdentity, evidenceContext, writeReceipt, writeManualEvidenceFailure } from "file:///home/duncan/c6e-store-diagnostic-0lb9ny6v/source/tools/evidence.mjs";
import { validateCommandReceiptDirectory } from "file:///home/duncan/c6e-store-diagnostic-0lb9ny6v/source/tools/milestone-orchestrator/src/verifier.ts";
const receiver="/mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/wp6e-source-publication-20260906/store-reference-probe-1";
const source="/home/duncan/c6e-store-diagnostic-0lb9ny6v/source";
const reference="/home/duncan/c6e-store-diagnostic-0lb9ny6v/reference-built";
const context=await evidenceContext('orch-auth-01-c6e','dependency-reference-probe');
try {
  const packages=await compareInstalledDependencyGraphs(JSON.parse(await readFile(resolve(receiver,'actual-graph.stdout.log'),'utf8')),source,JSON.parse(await readFile(resolve(receiver,'reference-graph.stdout.log'),'utf8')),reference,['.','tools/milestone-orchestrator']);
  const identity=await commandIdentity(source);
  assert.equal(identity.gitCommit,'082e4369a8e637243ff45e9e66d368452c74eced');
  assert.equal(identity.gitStatus,'');
  const commands=JSON.parse(await readFile(resolve(receiver,'commands.json'),'utf8'));
  assert(commands.length===5&&commands.every(command=>command.exitCode===0));
  await writeFile(resolve(context.artifactDirectory,'report.json'),JSON.stringify({schemaVersion:'source-dependency-reference-probe.v1',identity,packages,commands,productionCheckerChanged:false,sourceQualification:false,completionEligible:false},null,2)+'\n');
  await writeReceipt(context,[{id:'actual-pristine-store-and-built-reference',summary:'Actual pristine frozen offline installation passed pnpm store status; the normal frozen installation matches every installed package byte and graph identity in the unchanged source checkout.'}],[{path:'report.json',kind:'dependency-reference-probe'}]);
  const receipt=await validateCommandReceiptDirectory({directory:context.artifactDirectory,expectedStageId:context.stageId,expectedCommandId:context.commandId,requiredKinds:['dependency-reference-probe']});
  console.log(JSON.stringify({packages:packages.length,receiptSha256:receipt.receiptSha256,completionEligible:false}));
}catch(error){await writeManualEvidenceFailure(context,{kind:'product',message:error.stack??String(error)});throw error;}
