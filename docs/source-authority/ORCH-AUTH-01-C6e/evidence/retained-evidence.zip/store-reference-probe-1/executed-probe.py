"""Exercise a proposed two-reference dependency check without editing source."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

repo=Path('/mnt/c/Dev/loop-extraction/milestone-loop-template')
receiver=repo/'artifacts/wp6e-source-publication-20260906/store-reference-probe-1'
assert os.getuid()==1000 and not receiver.exists()
receiver.mkdir()
(receiver/'executed-probe.py').write_bytes(Path(__file__).read_bytes())
prior=repo/'artifacts/wp6e-source-publication-20260906/store-diagnostic-2'
root=Path((prior/'owned-root.txt').read_text().strip())
assert str(root)=='/home/duncan/c6e-store-diagnostic-0lb9ny6v' and root.resolve()==root
env=json.loads((prior/'environment.json').read_bytes())
source=root/'source'
pnpm=root/'bin/pnpm'
pristine=root/'reference-pristine'
built=root/'reference-built'
assert not pristine.exists() and not built.exists()
manifest_paths=['package.json','tools/milestone-orchestrator/package.json','pnpm-lock.yaml','pnpm-workspace.yaml']
for directory in [pristine,built]:
    directory.mkdir()
    for name in manifest_paths:
        target=directory/name
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source/name,target)
records=[]
def run(name,argv,cwd):
    start=time.monotonic_ns()
    result=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=300)
    for stream in ['stdout','stderr']:(receiver/(name+'.'+stream+'.log')).write_bytes(getattr(result,stream))
    row={'name':name,'argv':[str(arg) for arg in argv],'cwd':str(cwd),'exitCode':result.returncode,'durationMs':round((time.monotonic_ns()-start)/1e6)}
    records.append(row)
    (receiver/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert result.returncode==0, name
run('pristine-install',[pnpm,'install','--frozen-lockfile','--offline','--ignore-scripts','--side-effects-cache=false','--package-import-method=copy','--store-dir',str(root/'store/v11')],pristine)
run('pristine-store-integrity',[pnpm,'store','status'],pristine)
run('reference-install',[pnpm,'install','--frozen-lockfile','--offline','--package-import-method=copy','--store-dir',str(root/'store/v11')],built)
for name,directory in [('actual-graph',source),('reference-graph',built)]:
    run(name,[pnpm,'list','--recursive','--depth','Infinity','--json'],directory)
probe=root/'compare-dependencies.mjs'
assert not probe.exists()
probe.write_text('''import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { compareInstalledDependencyGraphs } from '''+json.dumps((source/'tools/source-release-inspection.mjs').as_uri())+''';
import { commandIdentity, evidenceContext, writeReceipt, writeManualEvidenceFailure } from '''+json.dumps((source/'tools/evidence.mjs').as_uri())+''';
import { validateCommandReceiptDirectory } from '''+json.dumps((source/'tools/milestone-orchestrator/src/verifier.ts').as_uri())+''';
const receiver='''+json.dumps(str(receiver))+''';
const source='''+json.dumps(str(source))+''';
const reference='''+json.dumps(str(built))+''';
const context=await evidenceContext('orch-auth-01-c6e','dependency-reference-probe');
try {
  const packages=await compareInstalledDependencyGraphs(JSON.parse(await readFile(resolve(receiver,'actual-graph.stdout.log'),'utf8')),source,JSON.parse(await readFile(resolve(receiver,'reference-graph.stdout.log'),'utf8')),reference,['.','tools/milestone-orchestrator']);
  const identity=await commandIdentity(source);
  assert.equal(identity.gitCommit,'082e4369a8e637243ff45e9e66d368452c74eced');
  assert.equal(identity.gitStatus,'');
  const commands=JSON.parse(await readFile(resolve(receiver,'commands.json'),'utf8'));
  assert(commands.length===5&&commands.every(command=>command.exitCode===0));
  await writeFile(resolve(context.artifactDirectory,'report.json'),JSON.stringify({schemaVersion:'source-dependency-reference-probe.v1',identity,packages,commands,productionCheckerChanged:false,sourceQualification:false,completionEligible:false},null,2)+'\\n');
  await writeReceipt(context,[{id:'actual-pristine-store-and-built-reference',summary:'Actual pristine frozen offline installation passed pnpm store status; the normal frozen installation matches every installed package byte and graph identity in the unchanged source checkout.'}],[{path:'report.json',kind:'dependency-reference-probe'}]);
  const receipt=await validateCommandReceiptDirectory({directory:context.artifactDirectory,expectedStageId:context.stageId,expectedCommandId:context.commandId,requiredKinds:['dependency-reference-probe']});
  console.log(JSON.stringify({packages:packages.length,receiptSha256:receipt.receiptSha256,completionEligible:false}));
}catch(error){await writeManualEvidenceFailure(context,{kind:'product',message:error.stack??String(error)});throw error;}
''')
(receiver/'executed-comparison.mjs').write_bytes(probe.read_bytes())
env['LOOP_VERIFY_COMMAND_ARTIFACT_DIR']=str(source/'artifacts/store-reference-probe')
run('compare',[pnpm,'exec','tsx',probe],source)
shutil.copytree(source/'artifacts/store-reference-probe',receiver/'comparison')
(receiver/'observation.json').write_text(json.dumps({'commands':records,'sourceFilesChanged':False,'sourceQualification':False,'completionEligible':False},indent=2)+'\n')
