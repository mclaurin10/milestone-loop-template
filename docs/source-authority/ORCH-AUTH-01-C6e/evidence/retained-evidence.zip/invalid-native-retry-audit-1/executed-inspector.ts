import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { lstat, readFile, readdir, writeFile } from 'node:fs/promises';
import { isAbsolute, resolve } from 'node:path';
import { evidenceContext, writeReceipt, writeManualEvidenceFailure } from '../../../tools/evidence.mjs';
import { validateCommandReceiptDirectory } from '../../../tools/milestone-orchestrator/src/verifier.ts';
type Pin = {path: string; bytes: number; sha256: string};
const input = resolve(import.meta.dirname, '..');
const output = resolve(input, 'invalid-native-retry-audit-1');
assert(!existsSync(output));
process.env.LOOP_VERIFY_COMMAND_ARTIFACT_DIR = output;
const context = await evidenceContext('orch-auth-01-c6e', 'invalid-native-retry-audit');
const hash = (bytes: Uint8Array) => createHash('sha256').update(bytes).digest('hex');
const read = async (path: string) => JSON.parse(await readFile(resolve(input, path), 'utf8'));
try {
const unbornInput = await read('precommit/subject/source.json');
const unbornFrozen = await read('unborn-regression-inputs-6/inputs.json');
const failedRuns: unknown[] = [];
  const invalidPrefix = "unborn-publication-focused-2";
  const invalidRead = (path: string) => read(invalidPrefix + "/" + path);
  const invalidChild = await invalidRead("child-execution.json");
  const invalidLauncher = await invalidRead("launcher/execution.json");
  const invalidManifest = await invalidRead("manifest.json");
  const invalidBefore = await invalidRead("input-before.json");
  const invalidAfter = await invalidRead("input-after.json");
  assert.equal(invalidManifest.status, "ERROR");
  assert.equal(invalidManifest.receipt, null);
  for (const path of ["result.json", "vitest-report.json"])
    assert(!existsSync(resolve(input, invalidPrefix, path)));
  assert.deepEqual(invalidBefore.identity, invalidAfter.identity);
  assert.deepEqual(invalidBefore.pins, invalidAfter.pins);
  assert.equal(invalidBefore.completionEligible, false);
  assert.equal(invalidAfter.completionEligible, false);
  assert(
    Date.parse(invalidAfter.observedAt) > Date.parse(invalidBefore.observedAt),
  );
  assert.deepEqual(invalidBefore.pins, unbornFrozen.pins);
  assert.equal(invalidBefore.identity.gitCommit, unbornInput.source.commit);
  assert.equal(invalidBefore.identity.gitTree, unbornInput.source.tree);
  assert.equal(invalidBefore.identity.gitStatus, "");
  assert.deepEqual(invalidChild.identity, invalidBefore.identity);
  assert.deepEqual(invalidLauncher.before, invalidBefore.identity);
  assert.deepEqual(invalidLauncher.after, invalidBefore.identity);
  for (const execution of [invalidChild, invalidLauncher]) {
    assert.equal(execution.exitCode, 1);
    assert.equal(execution.signal, null);
    assert.equal(execution.supervision.timedOut, false);
    assert.equal(execution.supervision.outputLimitExceeded, false);
    assert.equal(execution.supervision.streamsClosed, true);
    assert.equal(execution.supervision.drainTimedOut, false);
  }
  const invalidProgress = (
    await readFile(resolve(input, invalidPrefix, "progress.jsonl"), "utf8")
  )
    .trimEnd()
    .split(/\r?\n/)
    .map((line) => JSON.parse(line));
  assert.equal(invalidProgress[0].event, "run-start");
  assert.equal(invalidProgress[0].modules, 10);
  assert(
    !invalidProgress.some((event) =>
      ["run-end", "module-end"].includes(event.event),
    ),
  );
  const partialCases = invalidProgress.filter(
    (event) => event.event === "case-end",
  );
  assert.equal(partialCases.length, 10);
  assert.equal(
    partialCases.filter((event) => event.state === "passed").length,
    4,
  );
  const partialFailures = partialCases.filter(
    (event) => event.state === "failed",
  );
  assert.equal(partialFailures.length, 6);
  for (const event of partialFailures) {
    assert.equal(event.errors.length, 1);
    assert(
      event.errors[0].message.includes(
        "+ 'orch-auth-01-c6b'\n- 'source-authority-review'",
      ),
    );
  }
  const invalidDriver = await readFile(
    resolve(input, invalidPrefix, "launcher/executed-driver.mjs"),
    "utf8",
  );
  assert(invalidDriver.includes("LOOP_VERIFY_STAGE_ID: 'orch-auth-01-c6b'"));
  assert(
    invalidDriver.includes("LOOP_VERIFY_COMMAND_ID: 'source-scope-focused'"),
  );
  const invalidCollection = await invalidRead("launcher/collection.json");
  assert.equal(invalidCollection.copied.length, 21);
  assert.equal(invalidCollection.copiedBytes, 226935);
  assert.equal(invalidCollection.receiptBytesRewritten, false);
  assert.equal(
    new Set(invalidCollection.copied.map((pin: Pin) => pin.path)).size,
    21,
  );
  assert.equal(
    invalidCollection.copied.reduce(
      (sum: number, pin: Pin) => sum + pin.bytes,
      0,
    ),
    invalidCollection.copiedBytes,
  );
  for (const pin of invalidCollection.copied as Pin[]) {
    assert(!isAbsolute(pin.path) && !pin.path.split(/[\\/]/).includes(".."));
    const bytes = await readFile(resolve(input, invalidPrefix, pin.path));
    assert.equal(bytes.length, pin.bytes);
    assert.equal(hash(bytes), pin.sha256);
  }
  const invalidStop = await invalidRead("termination/scope-observation.json");
  assert.equal(invalidStop.schemaVersion, "owned-native-stop-observation.v1");
  assert.equal(invalidStop.target, 12336);
  assert.equal(invalidStop.exitCode, 0);
  assert.deepEqual(invalidStop.argv.slice(1), ["/PID", "12336", "/T", "/F"]);
  assert.deepEqual(invalidStop.remaining, []);
  assert.equal(invalidStop.verificationClaim, false);
  assert.equal(invalidStop.completionEligible, false);
  const stopStdout = await readFile(
    resolve(input, invalidPrefix, "termination/stdout.log"),
    "utf8",
  );
  const terminated = [
    ...stopStdout.matchAll(
      /SUCCESS: The process with PID (\d+) \(child process of PID (\d+)\) has been terminated\./g,
    ),
  ].map((match) => ({ pid: Number(match[1]), parent: Number(match[2]) }));
  assert.equal(terminated.length, 8);
  assert.deepEqual(invalidStop.acknowledged, terminated);
  assert.equal(new Set(terminated.map((entry) => entry.pid)).size, 8);
  assert.equal(invalidStop.collectorDefect.beforeCount, 153);
  assert.equal(invalidStop.collectorDefect.afterCount, 145);
  for (const excluded of invalidStop.excludedRawInventory) {
    assert(
      excluded.preservedAt.includes(
        "retention-draft\\overbroad-stop-inventory\\",
      ),
    );
    assert(
      !existsSync(
        resolve(input, invalidPrefix, "termination", excluded.originalName),
      ),
    );
  }
  failedRuns.push({
    name: invalidPrefix,
    passed: 4,
    failed: 6,
    partial: true,
    failureClassification: invalidManifest.failureClassification,
    interpretation:
      "Outer receipt identity overrides invalidated nested review evidence; stopped after ten partial cases. No full-suite result.",
    stopObservation: invalidStop,
  });

const pins: Pin[] = [];
async function walk(path: string) {
  for (const name of (await readdir(resolve(input, path))).sort()) {
    const child = path + '/' + name;
    const info = await lstat(resolve(input, child));
    assert(!info.isSymbolicLink());
    if (info.isDirectory()) await walk(child);
    else {
      assert(info.isFile() && info.size <= 20000000);
      const bytes = await readFile(resolve(input, child));
      pins.push({path: child, bytes: bytes.length, sha256: hash(bytes)});
    }
  }
}
await walk(invalidPrefix);
await writeFile(resolve(output, 'executed-inspector.ts'), await readFile(import.meta.filename));
await writeFile(resolve(output, 'report.json'), JSON.stringify({schemaVersion: 'invalid-native-retry-retained-inspection.v1', observation: failedRuns[0], pins, completionEligible: false, fullSuiteVerified: false, newTestsExecuted: false}, null, 2)+'\n');
await writeReceipt(context, [{id:'retained-invalid-retry-observation',summary:'Checked the preserved partial native run, exact leaked receipt identifiers, clean source pins, byte-preserving collection and actual targeted stop record. This audits retained failure observations and establishes no full-suite result.'}], [{path:'report.json',kind:'invalid-native-retry-observation'},{path:'executed-inspector.ts',kind:'invalid-native-retry-inspector'}]);
const checked = await validateCommandReceiptDirectory({directory:output,expectedStageId:context.stageId,expectedCommandId:context.commandId,requiredKinds:['invalid-native-retry-observation','invalid-native-retry-inspector']});
console.log(JSON.stringify({files:pins.length,partialCases:10,passed:4,failed:6,receiptSha256:checked.receiptSha256,fullSuiteVerified:false}));
} catch(error) {
await writeManualEvidenceFailure(context,{kind:'product',message:error.stack ?? String(error)});
throw error;
}
