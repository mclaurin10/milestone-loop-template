import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync } from "node:fs";
import { mkdir, readFile, realpath, writeFile } from "node:fs/promises";
import { dirname, isAbsolute, relative, resolve } from "node:path";

const repository = await realpath(resolve(import.meta.dirname, "../../.."));
const evidence = resolve(repository, "artifacts/wp6e-source-publication-20260906");
const clone = await realpath(resolve(repository, ".tools/wp6e-c6e-precommit-20260906"));
const output = resolve(evidence, "precommit-clone-input-1");
const read = async path => JSON.parse(await readFile(path, "utf8"));
assert.equal((await read(resolve(evidence, "recovery-publication-focused-1/result.json"))).status, "PASS");
const inputAudit = await read(resolve(evidence, "recovery-integration-audit-1/report.json"));
assert.equal(inputAudit.status, "PASS");
assert.equal(inputAudit.tests, 203);
assert.equal(inputAudit.inputObservation.files, 650);
assert(!existsSync(output));
const observationDirectory = resolve(evidence, "recovery-publication-inputs-1");
const observation = await read(resolve(observationDirectory, "inputs.json"));
assert.equal(observation.schemaVersion, "wp6e-verification-input-observation.v1");
assert.equal(observation.files.length, 650);
const hash = bytes => createHash("sha256").update(bytes).digest("hex");
const commandEnv = { ...process.env };
for (const key of ["GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_OBJECT_DIRECTORY", "GIT_ALTERNATE_OBJECT_DIRECTORIES"]) delete commandEnv[key];
const git = (...args) => {
  const result = spawnSync("git", ["-C", clone, ...args], { env: commandEnv, windowsHide: true, timeout: 120_000, maxBuffer: 64 * 1024 * 1024 });
  assert(!result.error && result.status === 0 && result.signal === null, result.stderr?.toString());
  return result.stdout;
};
const prior = git("rev-parse", "HEAD", "HEAD^{tree}", "--symbolic-full-name", "HEAD").toString().trimEnd().split("\n");
assert.deepEqual(prior, observation.gitIdentity);
assert.equal(git("status", "--porcelain").toString(), "");
assert.equal(git("for-each-ref", "--format=%(refname)", "refs/milestone-loop/").toString(), "");
const patch = await readFile(resolve(observationDirectory, observation.trackedPatch.path));
assert.equal(patch.length, observation.trackedPatch.bytes);
assert.equal(hash(patch), observation.trackedPatch.sha256);
await mkdir(output);
await writeFile(resolve(output, "executed-preparer.mjs"), await readFile(import.meta.filename), { flag: "wx" });
await writeFile(resolve(output, "before.json"), JSON.stringify({ observedAt: new Date().toISOString(), clone, identity: prior, verificationExecuted: false }, null, 2) + "\n", { flag: "wx" });
try {
  git("apply", "--index", "--binary", "--whitespace=error-all", resolve(observationDirectory, observation.trackedPatch.path));
  for (const file of observation.files.filter(file => !file.tracked && !file.excludedFromCommit)) {
    assert(!isAbsolute(file.path) && !file.path.split(/[\\/]/).includes(".."));
    const target = resolve(clone, file.path);
    assert(relative(clone, target) && !relative(clone, target).startsWith(".."));
    assert(!existsSync(target));
    const content = await readFile(resolve(observationDirectory, "untracked", file.path));
    assert.equal(content.length, file.bytes, file.path);
    assert.equal(hash(content), file.sha256, file.path);
    await mkdir(dirname(target), { recursive: true });
    assert.equal(await realpath(dirname(target)), dirname(target));
    await writeFile(target, content, { flag: "wx" });
  }
  const files = observation.files.filter(file => !file.excludedFromCommit);
  for (const file of files) {
    const content = await readFile(resolve(clone, file.path));
    assert.equal(content.length, file.bytes, file.path);
    assert.equal(hash(content), file.sha256, file.path);
  }
  assert(!existsSync(resolve(clone, "Implementation-ready improvement plan 8-5-26.txt")));
  git("config", "user.name", "WP6e continuation verification input");
  git("config", "user.email", "wp6e-verification@example.invalid");
  git("add", "--", ".");
  git("diff", "--cached", "--check");
  const stagedTree = git("write-tree").toString().trim();
  git("commit", "--quiet", "-m", "Prepare exact C6e inputs for isolated verification");
  const identity = git("rev-parse", "HEAD", "HEAD^{tree}", "--symbolic-full-name", "HEAD").toString().trimEnd().split("\n");
  assert.equal(identity[1], stagedTree);
  assert.equal(git("rev-parse", "HEAD^").toString().trim(), prior[0]);
  assert.equal(git("status", "--porcelain").toString(), "");
  assert.equal(git("for-each-ref", "--format=%(refname)", "refs/milestone-loop/").toString(), "");
  const report = { observedAt: new Date().toISOString(), clone, identity, prior, files: files.length, inputObservationSha256: hash(await readFile(resolve(observationDirectory, "inputs.json"))), isolatedVerificationInputOnly: true, primaryCommitCreated: false, verificationExecuted: false, sourceStateAdopted: false, completionEligible: false };
  await writeFile(resolve(output, "observation.json"), JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
  console.log(JSON.stringify(report));
} catch (error) {
  await writeFile(resolve(output, "failure.json"), JSON.stringify({ observedAt: new Date().toISOString(), message: error.stack ?? String(error), verificationExecuted: false }, null, 2) + "\n", { flag: "wx" });
  throw error;
}
