# Read-only continuation planning observations

Recorded during the frozen recovery-publication-focused-1 run. This file is
planning evidence, not a successful command receipt or implementation change.

The original archived WP6e plan, lines 83–88, 304–308 and 562–565, requires
the four canonical partition commands to receive exactly 3,900,000 ms at the
real execution-provider boundary, with that value retained in tier evidence.
It preserves other focused commands' 1,200,000 ms bound and all inner,
exact-closure, measurement and test/hook deadlines. It does not prescribe a
65-minute idle or expiration experiment. Do not invent such a requirement,
or substitute a shadow/metadata-only dispatch for the actual candidate call.

The C3 host's fixed 30-minute lifecycle cannot preserve a partition's full
65-minute outer allowance. A later bounded candidate-host increment must
establish its own longer finite lifecycle, retain the original C3 policy and
evidence unchanged, qualify the actual provider and host settings, and inspect
the real candidate partition calls and resulting execution evidence. No host
policy or candidate execution is changed by this observation.

The clean-precommit VM scripts in retention-draft are prepared but unexecuted.
They reuse the original C3 host policy for ordinary precommit source checks.
They are neither the source implementation audit nor candidate/timeout proof.
