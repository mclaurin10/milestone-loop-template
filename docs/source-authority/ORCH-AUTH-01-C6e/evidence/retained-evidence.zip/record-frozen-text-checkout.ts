import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { evidenceContext, writeReceipt, writeManualEvidenceFailure } from "../../tools/evidence.mjs";
const context = await evidenceContext("wp6e-c6e", "frozen-text-checkout");
const root = context.repositoryRoot;
const inputRoot = resolve(root, "artifacts/wp6e-source-publication-20260906");
const clone = resolve(root, ".tools/wp6e-c6e-precommit-20260906");
const hash = (bytes: Uint8Array) => createHash("sha256").update(bytes).digest("hex");
try {
  const inputBytes = await readFile(resolve(inputRoot, "recovery-publication-inputs-1/inputs.json"));
  const input = JSON.parse(inputBytes.toString());
  const rows = [];
  const artifacts = [];
  for (const pin of input.files.filter((file: { excludedFromCommit: boolean }) => !file.excludedFromCommit)) {
    const checkout = await readFile(resolve(clone, pin.path));
    if (checkout.length === pin.bytes && hash(checkout) === pin.sha256) continue;
    const working = await readFile(resolve(root, pin.path));
    assert.equal(working.length, pin.bytes, pin.path);
    assert.equal(hash(working), pin.sha256, pin.path);
    const text = working.toString("utf8");
    assert(Buffer.from(text).equals(working) && !working.includes(0));
    assert(text.includes("\r\n"));
    assert(Buffer.from(text.replaceAll("\r\n", "\n")).equals(checkout), pin.path);
    const checked = spawnSync("git", ["--no-optional-locks", "-C", clone, "check-attr", "--cached", "-z", "text", "eol", "--", pin.path], { windowsHide: true, timeout: 30_000 });
    assert(!checked.error && checked.status === 0 && checked.signal === null);
    assert.deepEqual(checked.stdout.toString().split("\0"), [pin.path, "text", "auto", pin.path, "eol", "lf", ""]);
    const path = "raw/" + pin.path;
    await mkdir(dirname(resolve(context.artifactDirectory, path)), { recursive: true });
    await writeFile(resolve(context.artifactDirectory, path), working, { flag: "wx" });
    artifacts.push({ path, kind: "frozen-working-text-bytes" });
    rows.push({ path: pin.path, raw: { path, bytes: working.length, sha256: hash(working) }, checkout: { bytes: checkout.length, sha256: hash(checkout) }, transformation: "CRLF pairs to LF only; every other byte is equal", attributes: { text: "auto", eol: "lf" }, attributeArgv: ["git", "check-attr", "--cached", "-z", "text", "eol", "--", pin.path], crlfPairs: (text.match(/\r\n/g) ?? []).length });
  }
  assert.equal(rows.length, 13);
  assert(rows.every(row => row.path === ".gitignore" || row.path.startsWith("docs/")));
  const report = { schemaVersion: "frozen-working-text-checkout.v1", status: "PASS", completionEligible: false, actualMigration: false, sourceStateAdopted: false, inputObservationSha256: hash(inputBytes), originalInputFiles: 650, checkedOutFiles: 649, lineEndingRepresentations: rows, claimScope: "exact frozen Windows raw bytes and Git LF checkout relationship; no production content change or verification rerun" };
  await writeFile(resolve(context.artifactDirectory, "report.json"), JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
  await writeReceipt(context, [{ id: "exact-git-text-representations", summary: "Every differing checkout file is one of thirteen explicitly retained original frozen text files. Git attributes require LF; replacing only CRLF pairs gives the exact checkout bytes. Source/test/config payload bytes already agree." }], [{ path: "report.json", kind: "frozen-working-text-checkout" }, ...artifacts]);
  console.log(JSON.stringify({ status: "PASS", differingTextFiles: rows.length, productionContentChanged: false, completionEligible: false }));
} catch (error) {
  await writeManualEvidenceFailure(context, { kind: "product", message: error instanceof Error ? error.stack : String(error) });
  throw error;
}
