import { spawnSync } from "node:child_process";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { cleanupSyntheticPublicationFixtures, requestFixture, review, put } from "../test/synthetic-source-publication.js";
import { trustedTestExecutionProvider } from "../test/fixtures.js";
import { publishSourceAuthority, SOURCE_STATE_PATH } from "./source-authority-publication.js";
import { SOURCE_GENERATION_PATHS, SOURCE_PUBLICATION_EVIDENCE_PREFIX } from "./source-authority-generation.mjs";
import { sourceGit, sourceIdentity, sourceRead, sourceHash } from "./source-authority-evidence.mjs";
import { runVerificationTier } from "./verification-tier.js";
import { expectedSourceFloor, SOURCE_VERIFICATION_STAGE_IDS, SOURCE_QUALIFIER_DISPATCH_ENV, inspectSourceQualifierDispatch } from "./verification-scope.mjs";

describe("actual source consumers of a committed synthetic publication", () => {
  let fixture: Awaited<ReturnType<typeof requestFixture>>;
  let activated: ReturnType<typeof sourceIdentity>;
  beforeAll(async () => {
    fixture = await requestFixture();
    const checked = await review(fixture);
    await publishSourceAuthority({repositoryRoot: fixture.root, request: fixture.requestIdentity, reviewPermit: checked.permit});
    sourceGit(fixture.root, ["add", "--", ...SOURCE_GENERATION_PATHS, SOURCE_PUBLICATION_EVIDENCE_PREFIX]);
    sourceGit(fixture.root, ["commit", "--quiet", "-m", "Synthetic source publication for native consumer boundary tests"]);
    activated = sourceIdentity(fixture.root, true);
  }, 180_000);
  afterAll(cleanupSyntheticPublicationFixtures);

  it("runs native full and focused envelopes with honest unavailable prerequisites and scope", async () => {
    for (const focused of [false, true]) {
      const runId = focused ? "native-focused-consumer" : "native-full-consumer";
      const argv = ["scripts/verify.mjs", "--run-id", runId, ...(focused ? ["--stage", "contract-integrity"] : [])];
      const environment = {...process.env};
      delete environment[SOURCE_QUALIFIER_DISPATCH_ENV];
      const execution = spawnSync(process.execPath, argv, {cwd:fixture.root, encoding:"utf8", env:environment, timeout:90_000, maxBuffer:16*1024*1024});
      await put(fixture.root, "artifacts/" + runId + "-stdout.log", Buffer.from(execution.stdout ?? ""));
      await put(fixture.root, "artifacts/" + runId + "-stderr.log", Buffer.from(execution.stderr ?? ""));
      expect(execution.error).toBeUndefined();
      expect(execution.signal).toBeNull();
      expect(execution.status).not.toBe(0);
      const report = JSON.parse(await readFile(resolve(fixture.root, "artifacts", runId, "result.json"), "utf8"));
      expect(report.schemaVersion).toBe("3.0.0");
      expect(report.completion.eligible).toBe(false);
      expect(report.scope.purpose).toBe(focused ? "candidate-support" : "full-source-qualification");
      expect(report.scope.sourceCandidate).toMatchObject({gitCommit:activated.commit, gitTree:activated.tree, workingTreeDirty:false});
      expect(report.status).not.toBe("PASS");
      expect(report.stages.find((stage: {id:string}) => stage.id === "contract-integrity").status).toBe("PASS");
      if (focused) {
        expect(report.scope.qualifierRun).toBeNull();
        expect(report.stages.map((stage:{id:string}) => stage.id)).toEqual(["environment", "contract-integrity"]);
        expect(report.completion.reasons).toContain("focused_stage_selection");
      } else {
        expect(report.scope.qualifierRun).not.toBeNull();
        expect(report.stages.map((stage:{id:string}) => stage.id)).toEqual(SOURCE_VERIFICATION_STAGE_IDS);
        expect(report.stages.find((stage:{id:string}) => stage.id === "source-full-qualification").status).toBe("NOT_READY");
      }
    }
    expect(sourceIdentity(fixture.root, true)).toEqual(activated);
    expect(await sourceRead(fixture.root, SOURCE_STATE_PATH, true)).toBeNull();
  }, 180_000);

  it.each(["candidate", "milestone"] as const)("binds actual %s dispatch and rejects synthetic exit-zero without a receipt", async (tier) => {
    const observed: string[] = [];
    const provider = trustedTestExecutionProvider(async (command, options) => {
      observed.push(command.id);
      expect(command.id).toBe("test-invariants");
      expect(options.timeoutMs).toBe(1_200_000);
      const stdoutPath = resolve(options.artifactDirectory, "stdout.log");
      const stderrPath = resolve(options.artifactDirectory, "stderr.log");
      await put(fixture.root, stdoutPath, Buffer.from("Synthetic provider exit-zero without child evidence\n"));
      await put(fixture.root, stderrPath, Buffer.from(""));
      const now = new Date().toISOString();
      return {id:command.id, displayCommand:[command.executable,...command.args].join(" "), status:"PASS", exitCode:0, signal:null, startedAt:now, finishedAt:now, durationMs:0, stdoutPath, stderrPath, stdoutSha256:sourceHash(await readFile(stdoutPath)), stderrSha256:sourceHash(await readFile(stderrPath)), parser:"exit-code", parsedArtifactPath:null, message:"Synthetic provider boundary only", receipt:null, receiptAbsenceReason:"Intentional unit-test omission"};
    });
    const result = await runVerificationTier({repositoryRoot:fixture.root, tier, baseCommit:activated.commit, requireClean:true, executionProvider:provider});
    expect(result.schemaVersion).toBe("2.0.0");
    expect(result.status).toBe("ERROR");
    expect(result.exitCode).toBe(3);
    expect(result).toHaveProperty("scope");
    if (!("scope" in result)) throw new Error("Source dispatch lost its scope");
    expect(result.completionEligible).toBe(false);
    expect(result.scope.purpose).toBe(tier === "candidate" ? "candidate-support" : "full-source-qualification");
    expect(result.scope.sourceCandidate).toMatchObject({gitCommit:activated.commit, gitTree:activated.tree, workingTreeDirty:false});
    expect(result.actualCheckIds).toEqual([...expectedSourceFloor().map(command=>command.id), ...(tier === "milestone" ? ["exact-readiness"] : [])]);
    expect(observed).toEqual(["test-invariants"]);
    expect(result.commands).toHaveLength(1);
    expect(result.commands[0]).toMatchObject({status:"ERROR", exitCode:0, receipt:null});
    expect(result.commands[0]!.message).toContain("required command-owned receipt");
    expect(result.exactVerification).toBeNull();
    const dispatchBytes = await sourceRead(fixture.root, "artifacts/verification-tiers/" + result.runId + "/source-qualifier-dispatch.json", true);
    if (tier === "candidate") {
      expect(dispatchBytes).toBeNull();
      expect(result.scope.qualifierRun).toBeNull();
    } else {
      expect(dispatchBytes).not.toBeNull();
      const dispatch = inspectSourceQualifierDispatch(JSON.parse(dispatchBytes!.toString()), result.candidate, provider.identity);
      expect(result.scope.qualifierRun).toEqual(dispatch.qualifierRun);
    }
    expect(sourceIdentity(fixture.root, true)).toEqual(activated);
    expect(await sourceRead(fixture.root, SOURCE_STATE_PATH, true)).toBeNull();
  }, 180_000);
});
