import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { requestFixture, review, cleanupSyntheticPublicationFixtures } from "../test/synthetic-source-publication.js";
import { AUTHORITY_MIGRATION_PENDING_PATH } from "./authority-publication.mjs";
import { publishSourceAuthority, sourceTransactionPaths, SOURCE_STATE_PATH, type SourcePublicationHooks } from "./source-authority-publication.js";
import { assertSourceReviewPermit } from "./source-authority-review.js";
import { sourceFilePin, sourceGitText, sourceHash, sourceIdentity, sourceRead } from "./source-authority-evidence.mjs";
import { SOURCE_PUBLICATION_EVIDENCE_PREFIX } from "./source-authority-generation.mjs";
afterEach(cleanupSyntheticPublicationFixtures);

describe.each(["afterStaged", "beforeIntent"] as const)("actual retry after %s with synthetic SDK input", (phase) => {
  let fixture: Awaited<ReturnType<typeof requestFixture>>;
  let originalReview: Awaited<ReturnType<typeof review>>;
  let originalEvents: Buffer;
  beforeEach(async () => {
    fixture = await requestFixture();
    originalReview = await review(fixture);
    let reached = false;
    const hooks: SourcePublicationHooks = {
      [phase]: () => {
        reached = true;
        throw new Error("Interrupted before source intent: " + phase);
      },
    };
    await expect(publishSourceAuthority({repositoryRoot: fixture.root, request: fixture.requestIdentity, reviewPermit: originalReview.permit, hooks})).rejects.toThrow("Interrupted before source intent: " + phase);
    expect(reached).toBe(true);
    const paths = sourceTransactionPaths(fixture.requestIdentity.sha256);
    originalEvents = (await sourceRead(fixture.root, paths.events))!;
    expect(originalEvents.length).toBeGreaterThan(0);
    expect(await sourceRead(fixture.root, AUTHORITY_MIGRATION_PENDING_PATH, true)).toBeNull();
    expect(await sourceRead(fixture.root, paths.completedIntent, true)).toBeNull();
    expect(await sourceRead(fixture.root, SOURCE_PUBLICATION_EVIDENCE_PREFIX + "result.json", true)).toBeNull();
    for (const output of fixture.request.outputs)
      expect(sourceFilePin(output.path, await sourceRead(fixture.root, output.path, true))).toEqual(output.prior);
    expect(sourceIdentity(fixture.root, true)).toEqual(fixture.identity);
    await expect(assertSourceReviewPermit(originalReview.permit, fixture.root, fixture.requestIdentity)).rejects.toThrow("live permit");
    expect(sourceGitText(fixture.root, "for-each-ref", "--format=%(refname)", "refs/milestone-loop/")).toBe("");
  }, 180_000);
  it("retains the first attempt and review while a fresh actual lease completes publication", async () => {
    const fresh = await review(fixture);
    const published = await publishSourceAuthority({repositoryRoot: fixture.root, request: fixture.requestIdentity, reviewPermit: fresh.permit});
    expect(published.result.status).toBe("PASS");
    expect(published.result.completionEligible).toBe(false);
    expect(published.result.reviewReceiptSha256).toBe(originalReview.receipt.receiptSha256);
    expect(published.result.freshReviewReceiptSha256).toBe(fresh.receipt.receiptSha256);
    expect(published.result.freshReviewReceiptSha256).not.toBe(published.result.reviewReceiptSha256);
    expect(published.eventBytes.subarray(0, originalEvents.length)).toEqual(originalEvents);
    const rows = published.eventBytes.toString().trimEnd().split("\n").map(line => JSON.parse(line));
    expect(rows.filter(row => row.event === "attempt-start")).toHaveLength(2);
    expect(rows.filter(row => row.event === "intent-published")).toHaveLength(1);
    expect(new Set(rows.map(row => row.intentSha256))).toEqual(new Set([sourceHash(published.intentBytes)]));
    expect(rows[0].lease.objectId).not.toBe(rows.at(-1).lease.objectId);
    expect(sourceIdentity(fixture.root)).toEqual(fixture.identity);
    expect(await sourceRead(fixture.root, SOURCE_STATE_PATH, true)).toBeNull();
    expect(await sourceRead(fixture.root, AUTHORITY_MIGRATION_PENDING_PATH, true)).toBeNull();
    expect(sourceGitText(fixture.root, "for-each-ref", "--format=%(refname)", "refs/milestone-loop/")).toBe("");
    expect(await sourceRead(fixture.root, published.receipt.path)).not.toBeNull();
  }, 180_000);
});
