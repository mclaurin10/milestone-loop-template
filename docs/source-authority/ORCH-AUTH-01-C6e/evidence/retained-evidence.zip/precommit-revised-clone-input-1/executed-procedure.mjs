import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { lstat, mkdir, readFile, realpath, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const repository=await realpath(resolve(import.meta.dirname,'../../..'));
const clone=await realpath(resolve(repository,'.tools/wp6e-c6e-precommit-20260906'));
assert.equal(clone,resolve(repository,'.tools/wp6e-c6e-precommit-20260906'));
const evidence=resolve(repository,'artifacts/wp6e-source-publication-20260906');
const output=resolve(evidence,'precommit-revised-clone-input-1');
assert(!existsSync(output));
await mkdir(output);
await writeFile(resolve(output,'executed-procedure.mjs'),await readFile(import.meta.filename));
const commands=[];
const git=(...args)=>{
 const result=spawnSync('git',['--no-optional-locks','-C',clone,...args],{windowsHide:true,timeout:120000,maxBuffer:16000000});
 commands.push({argv:['git','--no-optional-locks','-C',clone,...args],exitCode:result.status,signal:result.signal,error:result.error?.message??null,stdout:result.stdout.toString(),stderr:result.stderr.toString()});
 assert(!result.error&&result.status===0&&result.signal===null,result.stderr.toString());
 return result.stdout;
};
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const json=async path=>JSON.parse(await readFile(resolve(evidence,path),'utf8'));
try {
 const original=await json('precommit-vm-3/input/source.json');
 const delta=await json('dependency-repair-linux-1/source-delta.json');
 assert.deepEqual(delta.baseline,original.source);
 const audited=await json('dependency-repair-focused-audit-1/report.json');
 const receipt=await json('dependency-repair-focused-audit-1/result.json');
 assert.equal(receipt.status,'PASS');
 assert.deepEqual(audited.changes,delta.changes);
 assert.equal(audited.tests,260);
 assert.equal(git('status','--porcelain').toString(),'');
 assert.equal(git('rev-parse','HEAD').toString().trim(),original.source.commit);
 assert.equal(git('rev-parse','HEAD^{tree}').toString().trim(),original.source.tree);
 assert.equal(git('for-each-ref','--format=%(refname)','refs/milestone-loop/').toString(),'');
 for(const row of delta.changes) {
  const target=resolve(clone,row.path);
  assert(target.startsWith(clone+'\\')&&!row.path.includes('..'));
  assert(!(await lstat(target)).isSymbolicLink());
  const old=await readFile(target),current=await readFile(resolve(repository,row.path));
  assert.equal(old.length,row.before.bytes);assert.equal(hash(old),row.before.sha256);
  assert.equal(current.length,row.after.bytes);assert.equal(hash(current),row.after.sha256);
 }
 for(const row of delta.changes) await writeFile(resolve(clone,row.path),await readFile(resolve(repository,row.path)));
 const paths=delta.changes.map(row=>row.path).sort();
 assert.deepEqual(git('diff','--name-only').toString().trimEnd().split('\n').sort(),paths);
 assert.equal(git('ls-files','--others','--exclude-standard').toString(),'');
 await writeFile(resolve(output,'implementation.diff'),git('diff','--binary','--no-ext-diff'));
 git('add','--',...paths);
 assert.deepEqual(git('diff','--cached','--name-only').toString().trimEnd().split('\n').sort(),paths);
 git('commit','-m','Verify pristine store and normal built dependency references');
 assert.equal(git('status','--porcelain').toString(),'');
 assert.equal(git('rev-parse','HEAD^').toString().trim(),original.source.commit);
 const identity=git('rev-parse','HEAD','HEAD^{tree}','--symbolic-full-name','HEAD').toString().trimEnd().split('\n');
 assert.equal(identity.length,3);
 const observation={schemaVersion:'c6e-revised-precommit-input.v1',originalSource:original.source,source:{commit:identity[0],tree:identity[1],branch:identity[2],status:''},changes:delta.changes,completionEligible:false,primaryCommitted:false,actualImplementationAudit:false};
 await writeFile(resolve(output,'observation.json'),JSON.stringify(observation,null,2)+'\n');
 console.log(JSON.stringify(observation.source));
}finally{await writeFile(resolve(output,'commands.json'),JSON.stringify(commands,null,2)+'\n');}
