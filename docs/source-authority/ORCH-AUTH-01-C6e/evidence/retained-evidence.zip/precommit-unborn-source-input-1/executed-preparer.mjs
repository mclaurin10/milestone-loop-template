import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { copyFile, mkdir, readFile, realpath, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { sourceHistoricalFiles } from '../../../tools/milestone-orchestrator/src/source-authority-evidence.mjs';
import { validateCommandReceiptDirectory } from '../../../tools/milestone-orchestrator/src/verifier.ts';

const root=await realpath(resolve(import.meta.dirname,'../../..'));
const evidence=resolve(root,'artifacts/wp6e-source-publication-20260906');
const previous=JSON.parse(await readFile(resolve(evidence,'precommit-revised-source-input-1/source.json'),'utf8'));
const frozen=JSON.parse(await readFile(resolve(evidence,'unborn-regression-inputs-6/inputs.json'),'utf8'));
const output=resolve(evidence,'precommit-unborn-source-input-1');
const clone=resolve(root,'.tools/wp6e-c6e-unborn-precommit-20260907');
assert(!existsSync(output)&&!existsSync(clone));
assert.equal(previous.source.commit,'1c386ec95b628a2323f8d5dab351ad72a59abe3a');
const focused=resolve(evidence,'unborn-scope-focused-6');
const receipt=await validateCommandReceiptDirectory({directory:focused,expectedStageId:'orch-auth-01-c6b',expectedCommandId:'source-scope-focused',requiredKinds:['source-scope-focused-vitest-report','source-scope-child-execution','test-run-summary']});
const raw=JSON.parse(await readFile(resolve(focused,'vitest-report.json'),'utf8'));
assert.equal(raw.success,true);assert.equal(raw.numFailedTests,0);assert.equal(raw.numPendingTests,0);assert.equal(raw.numTodoTests,0);assert(raw.numTotalTests>=118);
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const expected=['authority-publication.mjs','verification-scope.test.ts','private-ref-store.ts','state-generation-store.test.ts'].map(name=>'tools/milestone-orchestrator/src/'+name).sort();
assert.equal(frozen.pins.length,331);assert.equal(previous.pins.length,331);
const changes=[];
for(let i=0;i<frozen.pins.length;i++){
  const pin=frozen.pins[i],before=previous.pins[i];assert.equal(pin.path,before.path);
  const bytes=await readFile(resolve(root,pin.path));assert.equal(bytes.length,pin.bytes,pin.path);assert.equal(hash(bytes),pin.sha256,pin.path);
  if(before.sha256!==pin.sha256)changes.push({path:pin.path,before:{bytes:before.bytes,sha256:before.sha256},after:{bytes:pin.bytes,sha256:pin.sha256}});
}
assert.deepEqual(changes.map(row=>row.path).sort(),expected);
await mkdir(output);
const executions=[];
function run(cwd,args){const r=spawnSync('git',['--no-optional-locks','-C',cwd,...args],{encoding:null,windowsHide:true,timeout:180000,maxBuffer:128*1024*1024});executions.push({cwd,argv:['git','--no-optional-locks','-C',cwd,...args],exitCode:r.status,signal:r.signal,error:r.error?.message??null,stdout:r.stdout?.toString()??'',stderr:r.stderr?.toString()??''});assert(!r.error&&r.status===0&&r.signal===null,r.stderr?.toString());return r.stdout;}
run(root,['clone','--no-hardlinks','--branch','master',resolve(root,'.tools/wp6e-c6e-precommit-20260906'),clone]);
const git=(...args)=>run(clone,args).toString().trimEnd();
assert.equal(git('rev-parse','HEAD'),previous.source.commit);assert.equal(git('status','--porcelain'),'');
git('config','--local','core.autocrlf','false');git('config','--local','gc.auto','0');git('config','--local','maintenance.auto','false');
for(const path of expected)await copyFile(resolve(root,path),resolve(clone,path));
git('add','--',...expected);
assert.deepEqual(git('diff','--cached','--name-only').split('\n').sort(),expected);
git('-c','user.name=Codex','-c','user.email=codex@openai.com','commit','-m','Verify unborn legacy authority and typed state object reads');
const source={commit:git('rev-parse','HEAD'),tree:git('rev-parse','HEAD^{tree}'),branch:git('symbolic-ref','--quiet','HEAD'),status:git('status','--porcelain')};
assert.equal(source.branch,'refs/heads/master');assert.equal(source.status,'');assert.equal(git('rev-parse','HEAD^'),previous.source.commit);
assert.deepEqual(git('diff','--name-only',previous.source.commit,'HEAD').split('\n').sort(),expected);
assert.equal(git('for-each-ref','--format=%(refname)','refs/milestone-loop/'),'');
assert(!existsSync(resolve(clone,'.agent/authority-requests/ORCH-AUTH-01/request.json')));assert(!existsSync(resolve(clone,'artifacts/orchestrator/state/state.json')));
const contents=sourceHistoricalFiles(clone,source.commit,frozen.pins.map(pin=>pin.path));
for(const pin of frozen.pins){const data=contents.get(pin.path);assert(data);assert.equal(data.length,pin.bytes,pin.path);assert.equal(hash(data),pin.sha256,pin.path);assert.deepEqual(data,await readFile(resolve(clone,pin.path)),pin.path);}
const bundles={};
for(const [key,name,base] of [['bundle','source.bundle',null],['subjectBundle','precommit.bundle','fc2419d8bdfc3658fe76edf2b543b38051b359f1'],['deltaBundle','delta.bundle',previous.source.commit]]){
  const path=resolve(output,name);git('bundle','create',path,'HEAD',...(base?['^'+base]:[]));git('bundle','verify',path);const bytes=await readFile(path);bundles[key]={path:name,bytes:bytes.length,sha256:hash(bytes)};
}
const metadata={schemaVersion:'c6e-precommit-source-input.v3',source,...bundles,pins:frozen.pins,originalSource:previous.source,changes,focusedReceiptSha256:receipt.receiptSha256,focusedTests:raw.numTotalTests,claimScope:'clean owned verification input after the four-file unborn/state-object regression repair; earlier source identities and failures remain separate',completionEligible:false,actualImplementationAudit:false,sourceStateAdopted:false};
assert.equal(git('status','--porcelain'),'');
await writeFile(resolve(output,'source.json'),JSON.stringify(metadata,null,2)+'\n',{flag:'wx'});
await writeFile(resolve(output,'git-executions.json'),JSON.stringify(executions,null,2)+'\n',{flag:'wx'});
await writeFile(resolve(output,'executed-preparer.mjs'),await readFile(import.meta.filename),{flag:'wx'});
console.log(JSON.stringify({source,pins:frozen.pins.length,changes:expected,bundles,verificationExecuted:false}));
