# Unintegrated audit report validation

This draft is not imported or executed. Publication-focused-14 is testing the
integrated six-file reader/boundary repair against frozen production inputs.
It must finish before this separate draft is integrated. Run 13 remains a
retained 63 PASS/3 timeout FAIL result; typecheck-19's intermediate failure is
also retained. Typecheck-20/lint-10/architecture-focused-2 passed for the repair.

The canonical draft is now `after/`, preserving repository-relative paths.
The earlier flat helper/fixture files are preparation snapshots, not integration
inputs. `before/` and `baselines.json` capture six unchanged primary inputs;
`draft-inventory.json` records their comparisons and two absent new paths. These
are observations, not PASS receipts. The unchanged test-ownership catalogue need
not be copied. Integrate the five changed existing files and two new files only
after all captured baselines still match. No production files were changed while
the publication run was active.

The helper is intended for inspectSourceImplementationEvidence's already
validated committed graph. It requires actual child execution, supervisor and
raw-log agreement; clean implementation/runtime binding; the real static report
schemas; exact root-unit file coverage and the existing measurement parser;
five independently validated nested invariant receipts; and an inspected real
release archive matching every audited implementation payload file, linked to
the retained nested build receipt and external generation output.

Prepared but unexecuted:

- The producer records exact execution schema, fixed 90-minute timeout and error.
  The committed reader binds every nested receipt/artifact to the same outer
  packet, observes audited historical policy/payload files with a private reader,
  checks serial command timing and calls the new pure semantic decoder.
- Static identities and supervision, package manifest/edge bindings, retained
  installed/reference graph equality, exact root-unit file coverage and summary
  binding, all five nested invariant receipts and the original 13 integrity IDs
  are checked. Build inspection checks the archive against actual implementation
  payloads, the consumer/nested receipt and complete output inventory. The build
  architecture report must equal the separately audited source architecture.
- Test-only synthetic-source-audit.ts builds explicit synthetic observations with
  actual Git/archive bytes and architecture inspection. It never claims to have
  run the eight commands or contacted the SDK. The publication fixture retains
  all original test bodies/deadlines and adds a rehashed committed raw-execution
  rejection before the SDK boundary plus 38 pure decoder cases. Expected complete
  selection: 107 cases (51 publication/audit, 35 evidence, 21 lease), to be checked
  against actual raw results rather than assumed.
- Report shapes were inspected as data against retained typecheck, lint, build,
  dependency and hosted invariant outputs. The normalized actual/reference pnpm
  graphs from the clean fc2419d build/dependency observation compared equal in a
  read-only shape probe. This does not verify the draft.

Before use:

- Recheck report details and type inference against actual retained reports. No
  fabricated metadata fixture may be described as actual command execution.
- Verify the drafted fixed execution schema, error and timeout fields in the real audit
  producer (the existing outer timeout is 90 minutes, distinct from the four
  partitions' required 65-minute execution-provider timeout).
- Verify the drafted implementation reader loads a fresh batch of actual implementation
  policy/payload, ownership, registry, lock and package-graph input objects.
  Call the helper only after the outer receipt binds the complete child graph.
  Its nested-receipt callback must use the same private committed reader and
  bind every returned nested receipt/artifact to the outer audit packet.
- Validate command time ordering and raw execution for all eight fixed commands.
- Check the drafted build kinds, runtime policy and adopter packaging additions.
- Execute the actual-shaped synthetic reports and negative cases; repair ordinary
  schema/fixture defects without weakening production validation or deadlines.
- Run typecheck/lint/architecture, complete affected files and clean actual
  eight-command audit before any real request or SDK service review.

The current catalogue has 92 controller files, 5 repository-tooling files,
2 adopter files and 1 separately executed OCI case: 100 catalogue entries,
99 files selected by root vitest.config.ts. Earlier shorthand calling all 100
"root files" was incorrect. The reader must derive and check the 99 selected
files, then separately retain exactly-once root-plus-OCI reconciliation later.

Remaining substantive follow-ups include stricter report graph cross-bindings,
the fixed publication packet's partial-export fault/recovery evidence, source
tier dispatch/receipt tests and native full/focused NOT_READY tests. No actual
audit, request, service review, migration, candidate or 5(a)/5(b) is claimed.
