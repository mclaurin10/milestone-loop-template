"""Copy bounded actual source-check observations after their service exits."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

evidence=Path('/mnt/c/Dev/loop-extraction/milestone-loop-template/artifacts/wp6e-source-publication-20260906')
assert os.getuid()==1000 and len(sys.argv)==2
name=sys.argv[1]
assert name=='precommit-linux-4'
receiver=evidence/name
metadata=json.loads((receiver/'preparation.json').read_bytes())
root=Path(metadata['root']).resolve(strict=True)
assert root.parent==Path('/home/duncan') and root.name.startswith('c6e-linux-precommit-')
launch=json.loads((receiver/'verify-launch/execution.json').read_bytes())
assert launch['cgroupAbsent'] and 'MainPID=0\n' in launch['unitAfter']['stdout']
assert not (Path('/sys/fs/cgroup/system.slice')/launch['unit']).exists()
total=0
def inspect(path):
    global total
    assert not path.is_symlink()
    if path.is_dir():
        for child in path.iterdir():inspect(child)
    else:
        assert path.is_file() and path.stat().st_size<=20_000_000
        total+=path.stat().st_size
        assert total<=64_000_000
for origin,target in [(root/'observations/verify',receiver/'verify'),(root/'source/artifacts/c6e-precommit',receiver/'commands')]:
    assert not target.exists()
    inspect(origin)
    shutil.copytree(origin,target)
shutil.copyfile(root/'input/worker.py',receiver/'executed-worker.py')
assert hashlib.sha256((receiver/'executed-worker.py').read_bytes()).hexdigest()==metadata['worker']['sha256']
git=[]
for args in [('rev-parse','HEAD'),('rev-parse','HEAD^{tree}'),('symbolic-ref','--quiet','HEAD'),('status','--porcelain'),('for-each-ref','--format=%(refname)','refs/milestone-loop/')]:
    result=subprocess.run(['/usr/bin/git','--no-optional-locks','-C',str(root/'source'),*args],capture_output=True,timeout=120)
    git.append({'argv':['git','--no-optional-locks','-C',str(root/'source'),*args],'exitCode':result.returncode,'stdout':result.stdout.decode(),'stderr':result.stderr.decode()})
for pin in metadata['pins']:
    data=(root/'source'/pin['path']).read_bytes()
    assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256']
report={'schemaVersion':'owned-source-check-collection.v1','root':str(root),'source':metadata['source'],'executionExitCode':launch['exitCode'],'gitAfter':git,'pinsUnchanged':True,'pins':metadata['pins'],'copiedBytes':total,'sourceStateAbsent':not (root/'source/artifacts/orchestrator/state/state.json').exists(),'verificationClaim':False,'completionEligible':False}
(receiver/'collection.json').write_text(json.dumps(report,indent=2)+'\n')
(receiver/'executed-collector.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'name':name,'exitCode':launch['exitCode'],'copiedBytes':total,'verificationClaim':False}),flush=True)
