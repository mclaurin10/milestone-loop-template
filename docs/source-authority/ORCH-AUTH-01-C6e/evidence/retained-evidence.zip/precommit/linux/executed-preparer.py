"""Prepare an owned Linux source checkout; no controller or service is run."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

repo=Path('/mnt/c/Dev/loop-extraction/milestone-loop-template')
evidence=repo/'artifacts/wp6e-source-publication-20260906'
receiver=evidence/'precommit-linux-4'
assert os.getuid()==1000 and not receiver.exists()
receiver.mkdir()
root=Path(tempfile.mkdtemp(prefix='c6e-linux-precommit-',dir='/home/duncan'))
(receiver/'owned-root.txt').write_text(str(root)+'\n')
(receiver/'executed-preparer.py').write_bytes(Path(__file__).read_bytes())
metadata=json.loads((evidence/'precommit-unborn-source-input-1/source.json').read_bytes())
assert metadata['schemaVersion']=='c6e-precommit-source-input.v3'
assert metadata['originalSource']['commit']=='1c386ec95b628a2323f8d5dab351ad72a59abe3a'
assert metadata['source']['commit']!=metadata['originalSource']['commit']
source_bundle=evidence/'precommit-unborn-source-input-1/source.bundle'
assert source_bundle.stat().st_size==metadata['bundle']['bytes']
assert hashlib.sha256(source_bundle.read_bytes()).hexdigest()==metadata['bundle']['sha256']
for name in ('input','account','tmp','observations'):(root/name).mkdir()
shutil.copyfile(source_bundle,root/'input/source.bundle')
worker=evidence/'retention-draft/run-linux-precommit4.py'
shutil.copyfile(worker,root/'input/worker.py')
(root/'input/worker.py').chmod(0o444)
env=json.loads((evidence/'store-diagnostic-2/environment.json').read_bytes())
env['HOME']=str(root/'account')
env['TMPDIR']=str(root/'tmp')
config=root/'account/.config/pnpm'
config.mkdir(parents=True)
(config/'config.yaml').write_text('enableGlobalVirtualStore: false\nstoreDir: '+env['pnpm_config_store_dir']+'\ncacheDir: '+env['pnpm_config_cache_dir']+'\n')
result=subprocess.run(['git','clone','--no-hardlinks',str(root/'input/source.bundle'),str(root/'source')],capture_output=True,timeout=180,env=env)
(receiver/'clone.stdout.log').write_bytes(result.stdout)
(receiver/'clone.stderr.log').write_bytes(result.stderr)
assert result.returncode==0,result.stderr
def git(*args):
    result=subprocess.run(['git','-C',str(root/'source'),*args],capture_output=True,timeout=120,env=env)
    assert result.returncode==0,result.stderr
    return result.stdout.decode().strip()
assert git('rev-parse','HEAD')==metadata['source']['commit']
assert git('rev-parse','HEAD^{tree}')==metadata['source']['tree']
assert metadata['source']['branch']=='refs/heads/master'
git('switch','--create','master',metadata['source']['commit'])
assert git('symbolic-ref','--quiet','HEAD')==metadata['source']['branch']
assert git('status','--porcelain')==''
git('config','--local','gc.auto','0')
git('config','--local','maintenance.auto','false')
for pin in metadata['pins']:
    data=(root/'source'/pin['path']).read_bytes()
    assert len(data)==pin['bytes'] and hashlib.sha256(data).hexdigest()==pin['sha256'],pin['path']
observed={'schemaVersion':'c6e-owned-linux-input.v1','root':str(root),'source':metadata['source'],'pins':metadata['pins'],'environment':env,'worker':{'path':str(root/'input/worker.py'),'bytes':worker.stat().st_size,'sha256':hashlib.sha256(worker.read_bytes()).hexdigest()},'runtimeRoot':'/home/duncan/oa1-CKn8x9/node-v24.18.0-linux-x64','dependencyRoot':'/home/duncan/c6e-store-diagnostic-0lb9ny6v','verificationExecuted':False,'completionEligible':False}
(root/'input/preparation.json').write_text(json.dumps(observed,indent=2)+'\n')
(receiver/'preparation.json').write_text(json.dumps(observed,indent=2)+'\n')
print(json.dumps({'root':str(root),'source':metadata['source'],'verificationExecuted':False}),flush=True)
