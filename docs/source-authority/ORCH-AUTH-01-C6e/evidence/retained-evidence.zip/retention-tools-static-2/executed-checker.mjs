import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { lstat, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { assertCommandPassed, commandIdentity, evidenceContext, runPnpm, writeReceipt, writeManualEvidenceFailure } from '../../../tools/evidence.mjs';
import { validateCommandReceiptDirectory } from '../../../tools/milestone-orchestrator/src/verifier.ts';

const repository = resolve(import.meta.dirname, '../../..');
const output = resolve(repository, 'artifacts/wp6e-source-publication-20260906/retention-tools-static-2');
assert(!existsSync(output));
process.env.LOOP_VERIFY_COMMAND_ARTIFACT_DIR = output;
const context = await evidenceContext('orch-auth-01-c6e', 'retention-tools-static');
const prefix = 'docs/source-authority/ORCH-AUTH-01-C6e/';
const code = ['audit.ts', 'inspect-frozen-inputs.ts', 'observe-precommit.ts', 'prepare-precommit-source.mjs'].map(name => prefix + name);
const files = [...code, prefix + 'README.md'];
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
try {
  const identity = await commandIdentity(repository);
  assert.equal(identity.nodeVersion, 'v24.18.0');
  assert.equal(identity.pnpmVersion, '11.15.1');
  const pins = [];
  for (const path of files) {
    const absolute = resolve(repository, path);
    const info = await lstat(absolute);
    assert(info.isFile() && !info.isSymbolicLink());
    const bytes = await readFile(absolute);
    pins.push({ path, bytes: bytes.length, sha256: hash(bytes) });
  }
  const commands = [];
  for (const [id, argv] of [['lint', ['exec', 'eslint', ...code]], ['format', ['exec', 'prettier', '--check', ...files]]]) {
    const startedAt = new Date().toISOString();
    const result = await runPnpm(argv, {cwd: repository, timeoutMs: 300_000});
    const record = { id, argv: ['pnpm', ...argv], startedAt, finishedAt: new Date().toISOString(), exitCode: result.status, signal: result.signal, supervision: result.supervision, error: result.error?.message ?? null };
    for (const stream of ['stdout', 'stderr']) await writeFile(resolve(output, id + '.' + stream + '.log'), result[stream] ?? '');
    await writeFile(resolve(output, id + '.execution.json'), JSON.stringify(record, null, 2) + '\n');
    assertCommandPassed(result, 'C6e retained auditor ' + id);
    commands.push(record);
  }
  for (const pin of pins) assert.equal(hash(await readFile(resolve(repository, pin.path))), pin.sha256);
  await writeFile(resolve(output, 'executed-checker.mjs'), await readFile(import.meta.filename));
  await writeFile(resolve(output, 'report.json'), JSON.stringify({schemaVersion: 'source-publication-retention-static.v1', identity, pins, commands, completionEligible: false, retainedAuditExecuted: false}, null, 2) + '\n');
  const declarations = [
    {path:'report.json',kind:'retention-tools-static-report'},
    {path:'executed-checker.mjs',kind:'retention-tools-static-procedure'},
    ...commands.flatMap(({id}) => [{path:id+'.execution.json',kind:'retention-tools-static-execution'},...['stdout','stderr'].map(stream => ({path:id+'.'+stream+'.log',kind:'retention-tools-static-log'}))]),
  ];
  // Keep zero-byte raw logs on disk, but receipts require nonempty artifacts.
  const artifacts = [];
  for (const item of declarations) if ((await lstat(resolve(output, item.path))).size > 0) artifacts.push(item);
  await writeReceipt(context, [{id:'actual-retention-tool-static-commands',summary:'ESLint and Prettier checked the exact pinned retained-audit, reconstruction, observer and bundle-preparation source; full retained behavioral audit remains separately required.'}], artifacts);
  const checked = await validateCommandReceiptDirectory({directory:output,expectedStageId:context.stageId,expectedCommandId:context.commandId,requiredKinds:['retention-tools-static-report','retention-tools-static-procedure','retention-tools-static-execution','retention-tools-static-log']});
  console.log(JSON.stringify({commands:commands.length,files:pins.length,receiptSha256:checked.receiptSha256}));
} catch (error) {
  await writeManualEvidenceFailure(context, {kind:'product',message:error.stack ?? String(error)});
  throw error;
}
