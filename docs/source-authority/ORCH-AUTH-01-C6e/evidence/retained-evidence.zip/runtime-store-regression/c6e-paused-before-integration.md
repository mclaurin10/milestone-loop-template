# Current Execution Plan

Status: C6e paused for actual C6d Windows regression repair. Updated: 2026-09-06 UTC. Owner: authorized WP6e continuation.

## Objective

Complete compatible source-generation validation, actual implementation-audit/reviewer boundaries and recoverable leased authority publication while legacy remains active. The immediate consumer is the public migration command, exercised against real disposable Git histories with publication faults. Once verified and committed, proceed to the actual separately committed request, independent review and approved activation.

## Goal Constraints

Approved ORCH-AUTH-01 r2 digest 53d38a2c2038cd9c5ffc240275043709d23dd33a81237e3d12018a38a8378108 and TRANSITION-CONTRACT.md remain authoritative. Preserve original authority/acceptance meaning, complete commissioning/amendment prefix, readiness history, protected public argv/workflows and state. No source state initialization/adoption, implicit commit/reset, generic pending override, claim substitution or WP6f interpretation. Approval and metadata binding are not activation.

## Baseline Evidence

C6d 96abed900ba141afb4ae644a691e7d5bb0569ca0, tree 0c281b952da8e0aecb29b120fc15e5edf8d2db3a, is committed and pushed. Its 31 request and 132 boundary cases, static/source architecture checks and five invariants pass. Retained audit validates 533 files/70 receipts; ZIP SHA256 8c956082766765d8af2e5a33bd4dfb9606cd1f75c68d3a9bb2b14cb2e0d9c093. Clean remote-free .tools/wp6e-c6d-postcommit reproduced audit (01b1fa38ed71dabaa187f8bb710a313455f0655d4705ef155f32901b37d165ca), dependencies (1a3d516a19ec40ee43e4eea02a2f1b9ed0f557a6aab00c77fed08a35a34611d4) and consumed build (291488df8793412cb73a890bd6a6c4240924b87ad1afee3ab47a84a0e377a907). Exact gitStatus is empty; private source refs/state absent. Evidence is artifacts/wp6e-source-transition-20260906/postcommit-*. Retain the first observer missing-identity-argument refusal without PASS.

C6b e072287 run 34033743564 completed all five protected jobs; each controller passed 915 controller and 1089 root-unit cases. Five provider archives/43 receipts pass independent audit and are sealed in C6d. Preserve the new 96abed9 hosted cohort before any successor same-ref push.

C6d projects twelve exact outputs from strict actual C4 ancestry and inspects a separate direct-child committed request, preserving the complete old ledger. It intentionally authenticates neither referenced audit success nor independent review. Normal source generations and reserved source schedules remain refused.

## Steps

1. Implement native-compatible strict source-generation/evidence readers and historical rollback refusal. Validate actual request/implementation/snapshot objects, independent audit/review artifacts, full outputs and preserved history. Keep pending/mixed consumers closed and original legacy behavior executable.
2. Add command-owned implementation audit and actual fresh SdkCodexGateway reviewer invocation with exact request/implementation/output bindings and retained real events. Candidate-authored flags and inspection receipts cannot satisfy review or approval.
3. Extend the existing mutation lease with exact same-request recovery admission and held-owner rechecks. Stage contained regular outputs, fsync an exclusive intent before mutation, and recheck HEAD/tree/branch/index, request/review, lease, intent, prior/new files and canonical state at every boundary. No implicit commit/reset/adoption.
4. Integrate authority, commissioning, invariant, planner, verifier and state consumers. Fence old state; leave missing source qualification non-passing. Source candidate evidence remains supporting and retains the four-owner floor and existing 65-minute binding without overlapping legacy commands.
5. Test real Git/native CLI/concurrency, every before/after fault, exact recovery, all normal pending consumers and foreign-byte preservation. Run applicable original checks, audit, commit and clean post-commit reproduction; continue actual request/review/activation and candidate/mutations.

## Acceptance Criteria

Readers agree on a complete authenticated source generation and refuse missing, unknown, mixed, pending or rolled-back publication. Actual separate request and fresh independent review precede the existing lease and durable intent. Regression faults reach actual boundaries; recovery requires the same request and exact prior/new states. Foreign files, competing owners and lost lease refuse without overwriting. Source candidate receipts have correct scope and independent child validation; original legacy/adopter meaning and public argv/workflows remain valid.

## Verification

Use Node 24.18.0/pnpm 11.15.1 and strict dependency checks. Add meaningful boundary regressions; run complete affected files, five invariants, typecheck/lint/format/source architecture, consumed distribution build and retained audit. Preserve original deadlines and failures. Use the qualified disposable Linux VM for Docker-dependent evidence as needed; it supplies neither native Windows nor the future actual 65-minute provider proof. No visual change.

## Risks and Recovery

Avoid native Node TS/.js resolution regressions, recursive authority validation and arbitrary output/path/command/approval inputs. Bind the epoch ledger through the existing canonical subject digest; real request and review commits remain separate. Actual reviewer execution is required; synthetic test transcripts are fixture evidence only. Old state remains fenced pending separately authorized exact verification and resumable reconciliation. Post-activation authority reversal requires an explicit appended human revision; ordinary implementation fixes use source control.

## Progress and Evidence

Actual hosted run 34038506240 at 96abed9 completed with four protected jobs passing and Windows controller job 101500874916 failing one of 950 cases. candidate-package-runtime.test.ts could not find @eslint/js 10.0.1 in the implicit temporary-fixture offline store; 949 cases passed, no controller PASS receipt and no subsequent root-unit run. All five provider ZIPs/hash-checked extractions and Windows log are retained under artifacts/wp6e-source-publication-20260906/hosted-96abed9. Pause feature expansion. The isolated remote-free repair clone .tools/wp6e-c6d-runtime-store-fix has its bounded C6d-R1 plan; saved-c6e-plan.md and original test bytes are retained under artifacts/wp6e-source-publication-20260906/runtime-store-regression. Local store path observations did not reproduce a cross-drive difference, so the precise hosted selection mechanism is unproven. Reproduce using an owned empty implicit fixture store, then bind the actual installed source store without changing original assertions/deadlines or sanitized environment. C6e typecheck-5 completed PASS; publication remains unexecuted.

Trust correction before activation: consistent committed reviewer transcripts are metadata, not an authenticated service invocation. The publisher must require an in-memory capability issued only by the actual SdkCodexGateway review producer; a candidate-authored transcript/flag cannot create it. Do not invent a new cryptographic authority system or initialize source state. A normal migrate invocation reviews the immutable committed request in an owned clean Git view, obtains the capability, then takes the existing lease. Recovery obtains a fresh actual review of the same request before taking the lease; the original intent-bound review artifacts remain preserved. Review/publication evidence can be committed together with the twelve active outputs after actual publication; only the request itself must be a separate prior commit. Ordinary readers require committed completed-publication evidence. The current metadata-only prerequisite reader and draft publisher still need this integration and must not be used for activation.

Drafted source-authority-publication.ts with read-only canonical-state observation, strict same-request pending/completed intent admission, twelve-file staging/publication/rechecks, completed-intent retention before pending removal, and fault hooks. It has not executed. ControllerLease now has assertHeld/ownershipPin and draft dedicated authority-migrate admission. The held-owner suite passed 21 cases (ab35ff0576cf2ef0b721ba4c276ecfae88bf635195607a64dc904413fd6c2ffa). Typecheck-4/lint-2/source architecture passed before the draft publisher; typecheck-5 is running. Current source authority reader still refuses activation, and there is no actual request/SDK invocation/lease/state mutation in the primary source.

Implemented but not yet committed: source-authority-evidence.mjs strict native committed receipt/audit/reviewer transcript consumers; source-authority-control.ts and CLI with fixed eight-command actual implementation audit and a fresh real SdkCodexGateway reviewer producer; source-authority-generation.mjs with actual request/review introduction, snapshot/implementation ancestry, old ledger/preserved pin and twelve-output inspection. None is wired to authorize ordinary source activation yet. The actual implementation audit and actual reviewer have not run. Synthetic review transcripts are unit fixtures only.

The first native evidence selection passed 17 cases; the second passed 18 including actual native Node loading plus approved Git snapshot inspection (receipt 1b7576146b5d2940261e1f52cafb5f1e56c0eb90121f65743fe73e8afdadcb7b). Typecheck-1 passed before tests were added. Typecheck-2 exposed MJS default-null inference for the committed receipt parameter; add its explicit JSDoc union without weakening runtime checks. Evidence is artifacts/wp6e-source-publication-20260906. New 96abed9 hosted run is 34038506240 and remains in progress at last observation.

Still required in this increment: complete publication provenance validation and rollback history refusal; actual existing lease same-request recovery admission and held checks; staged fsynced intent, exact fault recovery and command-owned publisher; state/authority/commissioning/invariant/planner/verifier integration; substantive full migration fixture tests; final clean implementation audit and actual request/review only after commit. Preserve a durable completed intent outside active roots before dropping the pending fence so a crash after finalization can resume the same request. Normal readers should require committed complete publication evidence; no generic allowPending flag or state initialization.

Tracked tree was clean at entry except this plan. Preserve the untracked roadmap (53ea98fb1cb880163a02d3b1d9365963e3fe891025ae3630f00bd4c9232293b1). No actual source request, intent, epoch ledger or state has been created. Historical WP6e remains BLOCKED at e590e38c32de2b5baa7423f66bbd8a0230b61839. Root-unit PASS does not establish unit-domain PASS.

## Next Action

Complete and test the generation/review/publication boundary, commit its audited implementation, then create the actual separate request and obtain fresh independent review. Continue the clean committed candidate/four partitions/raw coverage reconciliation/65-minute provider boundary, committed 5(a)/5(b), exact hosted evidence and historical/fresh/unresolved acceptance matrix. Do not stop at this precursor.
