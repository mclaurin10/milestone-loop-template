import assert from "node:assert/strict";
import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { commandIdentity, evidenceContext, writeReceipt, writeManualEvidenceFailure } from "../../tools/evidence.mjs";
import { SOURCE_AUDIT_COMMANDS, readSourceEvidenceReceipt, sourceHistoricalFiles, sourceHash } from "../../tools/milestone-orchestrator/src/source-authority-evidence.mjs";
import { inspectSourceAuditReports } from "../../tools/milestone-orchestrator/src/source-authority-audit-reports.mjs";

// Retained report decoder conformance only. No eight-command implementation
// audit, raw outer audit execution, new parent command run or migration claim.
const context = await evidenceContext("source-authority-audit-report-probe", "retained-audit-report-probe");
try {
  const root = context.repositoryRoot;
  const observer = await commandIdentity(root);
  assert.equal(observer.nodeVersion, "v24.18.0");
  assert.equal(observer.pnpmVersion, "11.15.1");
  const implementation = {commit: "fc2419d8bdfc3658fe76edf2b543b38051b359f1", tree: "e8afdd61b47db88f4c6964b77c90ee8db9c1b4b1", branch: "master"};
  const policyPath = "tools/source-release-policy.json";
  const policy = JSON.parse(sourceHistoricalFiles(root, implementation.commit, [policyPath]).get(policyPath).toString());
  const implementationFiles = sourceHistoricalFiles(root, implementation.commit, [...new Set([policyPath, ...policy.payloadFiles, ...policy.sourceCheckFiles, "tools/milestone-orchestrator/config/test-ownership.json", "tools/milestone-orchestrator/config/invariant-suite.json", "pnpm-lock.yaml", "pnpm-workspace.yaml"])]);
  const base = "artifacts/wp6e-source-publication-20260906/";
  const hosted = base + "hosted-fc2419d/controller-linux/";
  const samples = [
    ...["typecheck", "lint", "format", "invariants", "unit"].map(id => ({id, prefix: hosted + id + "/", platform: "linux"})),
    {id: "dependencies", prefix: base + "transition-cleanup-postcommit/postcommit-dependencies/", platform: "win32"},
    {id: "build", prefix: base + "transition-cleanup-postcommit/postcommit-build/", platform: "win32"},
  ];
  const observations = [];
  for (const sample of samples) {
    const expected = SOURCE_AUDIT_COMMANDS.find(command => command.id === sample.id);
    const child = await readSourceEvidenceReceipt(root, sample.prefix, expected);
    const nested = [];
    await inspectSourceAuditReports({expected, child, implementation, implementationFiles, runtime: {nodeVersion: "v24.18.0", pnpmVersion: "11.15.1", platform: sample.platform, architecture: "x64"}, execution: null, readNestedReceipt: async (prefix, expected) => {
      const receipt = await readSourceEvidenceReceipt(root, sample.prefix + prefix, expected);
      nested.push({path: sample.prefix + prefix + "result.json", bytes: receipt.bytes.length, sha256: receipt.sha256, artifacts: receipt.receipt.artifacts});
      return receipt;
    }});
    observations.push({id: sample.id, historicalReceipt: {path: sample.prefix + "result.json", bytes: child.bytes.length, sha256: child.sha256, artifacts: child.receipt.artifacts}, nested, historicalPlatform: sample.platform});
  }
  const paths = ["tools/milestone-orchestrator/src/source-authority-audit-reports.mjs", "tools/milestone-orchestrator/src/source-authority-evidence.mjs"];
  const decoder = await Promise.all(paths.map(async path => {const contents = await readFile(resolve(root, path)); return {path, bytes: contents.length, sha256: sourceHash(contents)};}));
  const report = {schemaVersion: "retained-source-audit-decoder-probe.v1", status: "PASS", claimScope: "retained-report-decoder-conformance", completionEligible: false, actualImplementationAudit: false, outerAuditExecutionValidated: false, historicalCommandsRerun: false, sdkServiceReview: false, activationAuthorized: false, sourceStateAdopted: false, observer, historicalImplementation: implementation, decoder, observations};
  await writeFile(resolve(context.artifactDirectory, "report.json"), JSON.stringify(report, null, 2) + "\n");
  await writeReceipt(context, [{id: "retained-reports-decoded", summary: "Seven retained command report meanings and all nested artifacts were checked against actual historical source objects. This does not validate an outer migration audit execution or rerun those commands."}], [{path: "report.json", kind: "retained-source-audit-decoder-report"}]);
  process.stdout.write(JSON.stringify({status: "PASS", sampleCount: observations.length, scope: report.claimScope}) + "\n");
} catch (error) {
  await writeManualEvidenceFailure(context, {kind: "infrastructure", message: error.stack ?? String(error)});
  throw error;
}
