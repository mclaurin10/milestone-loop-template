import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync } from "node:fs";
import { cp, mkdir, readFile, realpath, writeFile } from "node:fs/promises";
import { relative, resolve } from "node:path";
import { assertCommandPassed, evidenceContext, runPnpm, writeReceipt, writeManualEvidenceFailure } from "../../../tools/evidence.mjs";
import { validateCommandReceiptDirectory } from "../../../tools/milestone-orchestrator/src/verifier.js";
import { inspectSourceAuditReports } from "../../../tools/milestone-orchestrator/src/source-authority-audit-reports.mjs";
import { SOURCE_AUDIT_COMMANDS } from "../../../tools/milestone-orchestrator/src/source-authority-evidence.mjs";
const repository=await realpath(resolve(import.meta.dirname,"../../.."));
const evidence=resolve(repository,"artifacts/wp6e-source-publication-20260906");
const output=resolve(evidence,"dependency-repair-native-copy-1");
const clone=resolve(repository,".tools/wp6e-c6e-native-copy-20260907");
assert(!existsSync(output)&&!existsSync(clone));
process.env["LOOP_VERIFY_COMMAND_ARTIFACT_DIR"]=output;
const context=await evidenceContext("orch-auth-01-c6e","native-dependency-copy-observation");
const hash=(bytes:Uint8Array)=>createHash("sha256").update(bytes).digest("hex");
const metadata=JSON.parse(await readFile(resolve(evidence,"precommit-revised-source-input-1/source.json"),"utf8"));
const records=[];
try {
 await writeFile(resolve(output,"executed-procedure.ts"),await readFile(import.meta.filename));
 const cloned=spawnSync("git",["clone","--no-hardlinks",resolve(repository,".tools/wp6e-c6e-precommit-20260906"),clone],{windowsHide:true,timeout:300000,maxBuffer:16000000});
 await writeFile(resolve(output,"clone.stdout.log"),cloned.stdout);
 await writeFile(resolve(output,"clone.stderr.log"),cloned.stderr);
 await writeFile(resolve(output,"clone-execution.json"),JSON.stringify({argv:["git","clone","--no-hardlinks",resolve(repository,".tools/wp6e-c6e-precommit-20260906"),clone],exitCode:cloned.status,signal:cloned.signal,error:cloned.error?.message??null},null,2)+"\n");
 assert(!cloned.error&&cloned.status===0&&cloned.signal===null);
 assert.equal(await realpath(clone),clone);
 const git=(...args:string[])=>{const result=spawnSync("git",["--no-optional-locks","-C",clone,...args],{windowsHide:true,timeout:120000,maxBuffer:16000000});assert(!result.error&&result.status===0&&result.signal===null,result.stderr.toString());return result.stdout.toString().trimEnd();};
 assert.equal(git("rev-parse","HEAD"),metadata.source.commit);
 assert.equal(git("rev-parse","HEAD^{tree}"),metadata.source.tree);
 assert.equal(git("status","--porcelain"),"");
 const implementationFiles=new Map<string,Buffer>();
 for(const pin of metadata.pins){const bytes=await readFile(resolve(clone,pin.path));assert.equal(bytes.length,pin.bytes);assert.equal(hash(bytes),pin.sha256);implementationFiles.set(pin.path,bytes);}
 const commandDirectory=resolve(clone,"artifacts/c6e-native-dependencies");
 for(const [id,argv] of [["install",["--config.verify-deps-before-run=error","install","--frozen-lockfile","--offline","--package-import-method=copy"]],["dependencies",["--config.verify-deps-before-run=error","verify:source-dependencies"]]] as const){
  const startedAt=new Date().toISOString();
  const result=await runPnpm(argv,{cwd:clone,timeoutMs:600000,env:{...process.env,LOOP_VERIFY_COMMAND_ARTIFACT_DIR:commandDirectory}});
  const record={id,argv:["pnpm",...argv],cwd:clone,startedAt,finishedAt:new Date().toISOString(),exitCode:result.status,signal:result.signal,error:result.error?.message??null,supervision:result.supervision};
  records.push(record);
  for(const stream of ["stdout","stderr"] as const)await writeFile(resolve(output,id+"."+stream+".log"),result[stream]??"");
  await writeFile(resolve(output,id+".execution.json"),JSON.stringify(record,null,2)+"\n");
  if(id==="dependencies"&&existsSync(commandDirectory))await cp(commandDirectory,resolve(output,"command"),{recursive:true,force:false,errorOnExist:true});
  assertCommandPassed(result,"Native dependency copy "+id);
 }
 assert.equal(git("status","--porcelain"),"");
 assert.equal(git("rev-parse","HEAD"),metadata.source.commit);
 assert.equal(git("for-each-ref","--format=%(refname)","refs/milestone-loop/"),"");
 assert(!existsSync(resolve(clone,"artifacts/orchestrator/state/state.json")));
 const expected=SOURCE_AUDIT_COMMANDS.find((item:{id:string})=>item.id==="dependencies")!;
 const directory=resolve(output,"command");
 const receipt=await validateCommandReceiptDirectory({directory,expectedStageId:expected.stageId,expectedCommandId:expected.commandId,requiredKinds:expected.requiredKinds});
 const artifacts=new Map();
 for(const pin of receipt.artifacts){const path=relative(directory,pin.path).replaceAll("\\","/");artifacts.set(path,{...pin,path,contents:await readFile(pin.path)});}
 await inspectSourceAuditReports({expected,child:{artifacts},implementation:{commit:metadata.source.commit,tree:metadata.source.tree},runtime:{nodeVersion:"v24.18.0",pnpmVersion:"11.15.1",platform:"win32",architecture:"x64"},implementationFiles});
 const report=JSON.parse(await readFile(resolve(directory,"report.json"),"utf8"));
 const observation={schemaVersion:"native-dependency-copy-observation.v1",source:metadata.source,platform:"win32",nodeVersion:process.version,pnpmVersion:"11.15.1",commands:records,dependencyReceiptSha256:receipt.receiptSha256,packages:report.packages.length,presentPackages:report.packages.filter((pkg:{present:boolean})=>pkg.present).length,captures:report.captures.map((capture:{id:string;cwd:string;exitCode:number})=>({id:capture.id,cwd:capture.cwd,exitCode:capture.exitCode})),sourceQualification:false,nativeWorkflowQualification:false,completionEligible:false};
 await writeFile(resolve(output,"report.json"),JSON.stringify(observation,null,2)+"\n");
 await writeReceipt(context,[{id:"actual-clean-native-dependency-copies",summary:"A fresh owned Windows checkout performed normal frozen offline copy installation and passed the production dependency command; the independent report reader verified all seven actual capture and reference meanings. This does not qualify native workflows."}],[{path:"report.json",kind:"native-dependency-copy-observation"},{path:"executed-procedure.ts",kind:"native-dependency-copy-procedure"},{path:"clone-execution.json",kind:"native-dependency-clone-execution"},{path:"install.execution.json",kind:"native-dependency-install-execution"},{path:"dependencies.execution.json",kind:"native-dependency-command-execution"}]);
 const checked=await validateCommandReceiptDirectory({directory:output,expectedStageId:context.stageId,expectedCommandId:context.commandId,requiredKinds:["native-dependency-copy-observation","native-dependency-copy-procedure"]});
 console.log(JSON.stringify({source:metadata.source,packages:observation.packages,receiptSha256:checked.receiptSha256,nativeWorkflowQualification:false,completionEligible:false}));
}catch(error){await writeManualEvidenceFailure(context,{kind:"product",message:error instanceof Error?error.stack:String(error)});throw error;}
