# Autonomy Log

## 2026-09-07 05:10 UTC — Complete the full clean native retry

Native attempt 3 completed all 266 cases across the original ten files with zero failed/pending/todo/unhandled cases. Its real command-owned receipt is `fc0e082d5aa56450e46a0fa3b6d0771da280bfc632b87def7eb6817e82933824` at `artifacts/wp6e-source-publication-20260906/unborn-publication-focused-3/result.json`. Run-end was 05:08:34.453 UTC; collection finished at 05:08:36.831. Exec 79324 is closed with exit 0. The child and outer supervisors report no timeout/output cap/drain failure and closed streams. Original test/hook/command limits and all 331 inputs are unchanged.

The executing checkout remains clean at isolated `2fa66568407594523380ec33c063cdf52e4c6d2d`, tree `a66441b9156667a0a18d44a102f30caad9ee9c3b`, on master, Node 24.18.0/pnpm 11.15.1, Windows 11 build 26200. Before/after identity and all pins agree. Collection copied 14 command files / 583878 bytes without rewriting receipts; complete raw stdout/stderr are 192137/1095 bytes. The stderr contains Git line-ending warnings and remains retained. The actual terminal completion result is recorded separately in the receiver. Fresh read-only observations found the verification checkout clean, private refs absent and both clone/primary source state absent.

Both preceding native failures retain their original outcomes and identities. The latest PASS does not relabel them, establish native workflow/Server 2022 qualification, activate source authority or satisfy actual candidate/readiness/human gates. All current source verification jobs are now closed. Next: curate the completed evidence, extract and run the complete retained auditor, then commit the verified C6e implementation and record a clean continuation checkpoint with remaining post-commit/hosted/migration/candidate obligations explicit.

## 2026-09-07 04:46 UTC — Preserve operational snapshots and keep the live handoff mutable

The full native publication, verification-scope, controller-lease, source-evidence and source-release files completed with 215 PASS and zero failures. Recovery then passed both previously timed-out retry cases: afterStaged at 04:40:20.138 and beforeIntent at 04:44:20.546. The full ten-file run remains active as exec 79324, with original bounds and no source changes.

Static-9 passed five commands over twelve pins (receipt `9db08d26b2d75e968501d4e4b414c65a08e6b3a46cb7c2872c6db84f5a0a3688`). Subsequent continuity work changes only the unsealed retention tooling: exact plan/autonomy/decision copies are archived under `operational-records/`, while executable source/test/config and retention procedure pins remain mandatory. This avoids binding future append-only log and handoff updates to immutable past bytes. The original 650-file reconstruction is unchanged. Static-10 passed the changed audit/README and retry procedures, receipt `d2f056199253fa0fbc9dfdfae7a57a4db067d11cf7dec775fd8e17ff436f3949`; exec 28921 is closed. Curation and its complete behavioral audit remain pending the final native result. No source implementation, authority generation, state, private ref, primary commit or push changed.

## 2026-09-07 04:20 UTC — Execute corrected native retry and audit the invalid predecessor

After static-8 passed five commands over twelve pins (receipt `e0e37f16a556bd9f221d76e8519d83e3737c5ecfbbe5bbf90d7e479d8aaeb16e`), the corrected driver started at 04:07:49.026 UTC as unified exec 79324. It asserts both receipt-identity environment overrides absent, verifies the previous jobs/owned stop completed, rechecks clean 2fa6656 and all 331 source pins, and runs the original ten files with unchanged supervision and deadlines. Live output is `.tools/wp6e-c6e-unborn-precommit-20260907/artifacts/c6e-native-retry-2`; final byte-preserving collection targets `artifacts/wp6e-source-publication-20260906/unborn-publication-focused-3`. No concurrent source suite or VM has been launched. Eight cases have passed as of the observed 04:16:53 event; the run is incomplete.

The independent invalid-retry inspection passed at `invalid-native-retry-audit-1/result.json`, receipt `d9fe970c3ecee6cc1e63a92a68e0d827fed6f8042d523895b5983b4d8506ed79`. It checks 37 preserved files, the exact ten partial cases and six receipt-ID errors, clean before/after source identity/pins, the 21-file byte-preserving collection, actual taskkill acknowledgments and absence observation. It expressly establishes no full-suite result and executes no test. Its first generated helper failed to parse before creating an evidence context; `retention-inspection-launch-error-3` preserves that failed source, executed generator and honest launch observation. The corrected executed helper is a receipt-owned artifact.

The retained auditor and curator now require native attempt 3's actual full result, separately preserve attempt 2 as invalid/partial, and require the independent invalid-retry receipt. The README records the completed Linux observer and these separate meanings. Final static-9, curation and the full retained audit remain pending. The primary HEAD, all production inputs, legacy authority, source-state absence, five stashes and excluded roadmap remain unchanged. The user's requested fresh-task checkpoint will record any unexecuted post-commit/hosted/activation/candidate gates explicitly rather than imply completion.

## 2026-09-07 04:06 UTC — Record completed observer and invalid native retry; condense handoff

The independent precommit observer executed successfully against the completed clean 2fa6656 Linux and same-input C3 OCI observations. Receipt `aed573837d5de96108d17e90949f8aee2c9023069eee6902ecf719f35a3e1b98` at `artifacts/wp6e-source-publication-20260906/precommit/result.json` validates all nine source commands, 1250 root identities and three host/OCI/cleanup audits. Its completion eligibility is false; it is not the actual implementation audit or candidate proof.

Native retry 2 was invalidated by its outer observation launcher exporting `LOOP_VERIFY_STAGE_ID` and `LOOP_VERIFY_COMMAND_ID`. Those inherited overrides mislabeled nested source-review receipts. The original source/tests/deadlines remain unchanged. The owned inner PNPM/Vitest process tree rooted at PID 12336 was stopped, preserving the receipt writer and collector. The partial run contains 4 PASS / 6 FAIL / 10 cases, ERROR, no full report/run-end/PASS. All 21 command files / 226935 bytes were collected byte-for-byte to `unborn-publication-focused-2`; the checkout remains clean at 2fa6656 with all 331 pins intact.

The stop script's initial diagnostic traversal over-included unrelated process records. Only explicit PID 12336 was passed to taskkill. A separate numeric PID inspection confirmed all eight actually acknowledged terminated processes absent. The corrected scope observation and exact executed procedures are retained under that attempt's termination directory. Overbroad raw snapshots remain private under `retention-draft/overbroad-stop-inventory` and are excluded from curation; their counts are not interpreted as owned descendants. Exec 66273 is closed. The corrected full retry must omit both inherited receipt identifiers and run serially at the same source with the same ten files and deadlines.

Per the user's continuity request, the active plan is now a concise rolling handoff with required scope, acceptance, risks and commands; exact primary/isolated identities, working changes, verified evidence, job IDs and the next action are explicit. Historical narrative remains here. At this checkpoint no jobs are active, primary remains fc2419d with 56 unstaged C6e paths plus the excluded roadmap, five stashes are preserved and all actual migration/candidate obligations remain open. A clean committed fresh-task checkpoint is to be identified after current verification and evidence closure.

## 2026-09-07 03:49 UTC — Retain native deadline failures and start the clean serial retry

unborn-publication-focused-1 finished with 258 PASS / 8 FAIL / 266 across all ten files, zero pending/todo/unhandled. The actual stderr identifies five tests and three hooks reaching their original 180000ms bounds and five lease-release errors involving removed fixture directories. The full child supervisor did not time out or truncate output; raw stdout/stderr are 183507/7794 bytes. The ERROR manifest, complete reports and tool-return observation remain preserved under the dirty fc2419d identity. Contention from overlapping Linux/QEMU work is a hypothesis, not an established explanation.

The new observation tooling preserves a missing-export launch error before any checks and the subsequent static-6 regex-style failure. Static-7 passed all five commands over twelve pinned files, receipt dd0f0817a7ad84d3abb84baa826713ccfb4b7d05ac13977ea8903acc8b9989d9. No production input, assertion or deadline changed. The complete clean serial retry started at 03:48:32.120 UTC at 2fa6656/a66441b, after both earlier jobs completed. Its driver checks all 331 inputs and captures bounded live errors, before/after identity and byte-preserving collection. It writes clone artifacts/c6e-native-retry-1, then copies to unborn-publication-focused-2. No other source suite or VM will run concurrently. Independent inspection of already completed Linux/OCI artifacts may proceed; full curation/acceptance awaits the native result. Primary remains uncommitted with legacy authority, and every actual migration/candidate obligation remains open.

## 2026-09-07 03:26 UTC — Collect complete clean Linux source checks

precommit-linux-4 completed all nine unchanged source commands at clean isolated input 2fa66568407594523380ec33c063cdf52e4c6d2d / a66441b9156667a0a18d44a102f30caad9ee9c3b. Controller passed 1076/1076 (a01653284cff438646e779a0e4e1cf62c57e5afab094707437140a71c6a31f77), root unit passed 1250/1250 across 101 files (043fdc505bc508e43acc44176d9c55f8c8ab84ce42e5c7eef4321406a8e2b6db), and the consumed build passed (e3125027df86417b0c3a48012bde42eb8c55d7bf9c52924d9c2c61b1581da844). The finite service exited 0 at 3064793ms; its unit/cgroup are gone. Collection retained 2507865 bytes and rechecked the clean attached source, all 331 pins, absent private refs and absent source state. Independent complete report inspection and retention remain pending.

Separate C3 OCI execution at that same source passed all six cases in its unchanged lifecycle, 553687ms. Independent cleanup, host and OCI receipts are 2d8b1a9fcc07b5b02ee9e155ce9183f295c2eb71567dc8dc02c48c2ee7838680, 5935d7f8cd2025daee5590e566aef3aa1fadbc29473dcf6ac1e7e42f08faa710 and 2fa00867b0a156690619ee41976e51fffb6f25359e36251e6d729460177b841e. It dispatched no long source suite. The Windows ten-file publication run still has multiple failures and is active; complete raw errors remain pending. A clean serial retry is prepared with original files/deadlines and bounded live error observations, but has not run. Primary remains uncommitted on fc2419d with legacy authority. Actual audit/request/review/publication/activation, candidate, mutation proofs and hosted completion remain open.

## 2026-09-07 02:44 UTC — Freeze the verified unborn/state-object repair for broader checks

The final affected run passed all 130 cases across six complete files, receipt b471d57e357cf80e8cb64b5ce6364081188359538d6a19a362011cd4ec9635db. Typecheck-28 and lint-17 also passed. The preceding native runs remain failed at their original bounds: 107/7, 112/2 and 113/1 after the earlier 99/13 and 111/3 results. The durable decision records the strict single history/type query and the combined typed commit read; original tests and state fences remain intact.

Only the owned verification checkout advanced to 2fa66568407594523380ec33c063cdf52e4c6d2d / a66441b9156667a0a18d44a102f30caad9ee9c3b, direct child of 1c386ec. All 331 source pins and the exact four-file delta were checked against real Git objects. The full bundle is c88c8b8be45aeaefb94d06978ce877c427416c1eef1c847205f19aaa7dbf0895; its retained incremental bundle is b8c56276d165d9c5d2e30945848b7a96806098ae6bd3aed3d17fe88751d3e5aa. Primary remains uncommitted at fc2419d with legacy authority.

Fresh precommit-linux-4 uses owned root /home/duncan/c6e-linux-precommit-xbcd24l3. Its actual namespace probe and independent audit passed (2da428b09d3957c661da87310e5c9774aede6f75a2a2ead0a961fd091e2f92bc); the first six source commands passed and the controller suite is running. A separate unchanged C3 OCI lifecycle at the same source input runs under /home/duncan/oc3-c6e-ipheh_c7. The broader Windows publication run has reported a first-case failure; its full report is pending. No aggregate, primary commit, actual audit/request/review/activation, candidate or mutation-proof claim is made.

## 2026-09-07 02:18 UTC — Preserve remaining native failures and isolated cache diagnostic

The single-history-query affected run retained 111 PASS / 3 FAIL / 114 with no pending/todo/unhandled: two unchanged state-store 5000ms deadlines expired at 5194ms and 5181ms, and the new non-commit HEAD rejection failed. Actual retained Git probes show log --all --reflog silently ignores a branch pointing at a blob. The plan now requires a concurrent bounded explicit HEAD object-type check and history read, with all state fences and original tests/deadlines preserved. No failure is promoted to PASS.

The cache-runtime-diagnostic-1 owned namespace completed its normal frozen offline copy install and the unchanged full candidate-package-runtime test (one PASS). Its private mount makes the sanitized UID home resolve to task-owned pnpm store/cache configuration; no host home, account or shared configuration changed. The independent namespace audit passed and the service/cgroup are gone. The test/report audit remains open. Primary remains uncommitted on fc2419d with legacy authority; no audit/request/review/publication/activation or candidate claim follows from these diagnostics.

## 2026-09-07 01:50 UTC — Preserve full controller failures and repair unborn legacy compatibility

The actual clean namespace controller run finished with 1024 PASS / 42 FAIL, zero pending/todo, exit 1 at 1207072ms. Its owned unit and cgroup are gone. Collection retained 1349430 bytes at precommit-linux-3, including the complete raw report and command logs. Six preceding source commands passed and their actual report meanings were independently validated (22e597dcbf188cc97c9170ff770bf372dc188c2ec122ed01d9a7e1c77feaa567). Root unit/build did not run; the source aggregate remains failed. The separate same-input C3 OCI/host/cleanup PASS does not alter that result.

Failures are 19 doctor, 20 state-store, one operation-intent, one safety-demonstration and one candidate-package-runtime case. The state/doctor fixtures use actual newly initialized Git repositories with unborn HEAD; the new rollback-history reader rejects them before their original boundaries. Restore that compatible legacy behavior only after proving a valid unborn branch and inspecting available ref/reflog history for source publication. Corrupt/detached or source-history-bearing cases must still reject. Original tests remain unchanged. The package fixture lost its public pnpm metadata cache under sanitized execution in the newly empty HOME; point only the next task-owned config at the existing pinned cache and prove the original offline test. The active plan records this regression-first scope before implementation; source authority remains legacy and primary remains uncommitted on fc2419d.

## 2026-09-07 01:32 UTC — Separate source checks from bounded OCI qualification

The fourth precommit VM failed at the original 30-minute lifecycle deadline (1815930ms), while the controller suite was active. No guest archive survived; its collector preserved host observations then failed with FileNotFoundError. Early clean-after events are observations only. Independent cleanup passed with receipt 6d7019c2d24ad0754d6dcf30d7cff24768574597ca8f1023c7822bd88a69b77b. The failed aggregate and missing child artifacts remain explicit.

The fresh same-input C3 run e954e85e-4419-42f4-ba79-3badd26183bb completed in 410037ms with all six real OCI cases and independent host/OCI/cleanup audits passing. It retains unchanged C3 bounds and dispatches no long source suite. Its source is exact clean 1c386ec/4e4d2ae. Raw evidence is at precommit-oci-vm-1.

All nine unchanged source commands now run separately under an owned finite Linux service with private mount/network/tmp/device boundaries, no capabilities/new privileges, inaccessible host Docker sockets and /mnt, an owned HOME and preserved public deadlines. Namespace attempt 1 failed its interface probe before commands; AF_NETLINK was then allowed for kernel inspection. Attempt 2 passed the probe but correctly failed test ownership because the HEAD-only bundle cloned detached. Its five completed source receipts and full invariant failure remain retained. Fresh attempt 3 explicitly restores master and checks attachment before/after every command. Probe audit 8d1d017f0a33d256d42d3ba40106c7c5642c6da3a5a60ba6c0d58fe04f8f745a passed; the controller suite is currently running after six completed commands. No full source PASS is claimed.

The retained observer/auditor is being adapted to independently bind the two runtimes to the same clean input while preserving every prior failure. The active plan snapshot is at plan-consolidation/before-fresh-linux-3.md. Primary remains uncommitted on fc2419d; legacy authority remains active and every real audit/request/review/activation/candidate obligation continues.

## 2026-09-07 00:48 UTC — Prove the native dependency copy boundary

The actual primary Windows dependency run failed at the unchanged independent-copy check. The retained metadata observation identifies ESLint bin/eslint.js with 19 hard links; its ERROR manifest and seven completed raw capture streams remain at dependency-repair-native-1. No source rule or shared installed package was changed. A fresh owned checkout at the exact revised input 1c386ec used normal frozen offline copy installation, then the real production verifier passed. The independent report reader validated all seven Windows reference/log meanings, 192 graph entries and 138 installed packages. Inner receipt b3e0ad985dd5509836dc03f7a392ade1ad412d3ac77564a12cfc1e38b910344f; outer observation receipt 68607f685f92d9021430d6df89ca8ceb75378d5bdcd1518e5912712110a40354. Native workflow/Server 2022 qualification remains incomplete.

Retained precommit inspection now also consumes the real fixed report readers against the actual bundled Git implementation, with explicit absence of the separate implementation-audit producer's outer timing claim. The owned reconstruction has a local alternate-object reference for later read-only Git batches; source refs/index/config are untouched and its disposable cache is excluded from curation. Revised-input-audit-2 passed (cc6961c6ac9ac502037518d3143e70b238a64c7ff8afa8846a5f2b9963bb30b3), and the seven code files plus README passed lint/format at retention-tools-static-4 (0541ac0efba3f1601ccba804cf54b76b9e1aac330123dcdc96483864b34c4259). The later native-retention additions still require the final code check.

VM-4's full controller command remains active after the six preceding commands reached their clean-after events. Its original finite host/job bounds remain enforced; no complete nine-command result or aggregate qualification is claimed. Preserve actual termination, archive availability and cleanup before choosing the next bounded execution arrangement. The original and revised verification inputs, actual Linux/native diagnostics and failed VM history remain separate from the pending primary C6e commit and full authorized migration/candidate obligations.

## 2026-09-07 00:31 UTC — Preserve the verified dependency delta in a clean input

The complete Linux dependency-repair-focused-1 run finished at 00:18:54.551 UTC, exit 0: 260 PASS across ten full files, no failures/pending/todo/unhandled, and unchanged before/after executing pins. All prior 203 raw identities remain; eleven new evidence cases and 46 unchanged source-release cases are included. Independent dependency-repair-focused-audit-1 passed (2a7702abc5c1026aa1717237bed2cec88e4df950c88e391730620920c1a5f1d7), validating the actual dependency/corruption evidence and four static receipts.

Only the exact four verified files were committed atop 082e in the owned precommit clone, producing 1c386ec95b628a2323f8d5dab351ad72a59abe3a, tree 4e4d2ae0eae69784263f6d18668c5bb070f94c62. The source-input v2 producer preserved all 331 pins and the explicit original/delta identities. Independent revised-input-audit-1 imported both real incremental bundles, verified their commits/trees/parents, exact four-file change list and all original/revised pins (bebf438f8c14c89a41ea222add4da1aa3faed5f2017b8b1bb101f06ad3ddb057). The primary remains uncommitted on fc2419d; these are isolated verification inputs.

VM-4 launched at 00:24:16.1906812 UTC with that exact input, guest d72562f1-da1f-4192-b870-d6e73ca23ba4 in /home/duncan/oc3-c6e-azlssv66. It preserves the unchanged C3 host policy, task-owned store pin and normal source install. Real OCI execution has reached its completed event and serial precommit checks are active. No aggregate result is claimed. The saved driver will collect raw observations and independently audit cleanup/OCI and actual host success.

The retained auditor now preserves separate original and revised bundle proofs, all three failed guests, actual dependency diagnostics and new focused evidence. Its six code files and README passed actual lint/format at retention-tools-static-3 (3190eca3424aefe30f8b4328b33abd5356d63b4ce21994f03764693a71e0900c). An earlier outer launch mistakenly used native node for this TS-dependent audit graph and failed import resolution before any evidence context/static command; retention-static-launch-error-1.json records that actual tool observation, explicitly not a redirected raw stream. The corrected tsx invocation passed. Full retained audit/curation, primary commit and the authorized migration/candidate sequence remain pending.

## 2026-09-07 00:19 UTC — Validate separate pristine and built dependency references

VM-3 failed at the mandatory pnpm store status (host ERROR, 461759ms). Its independent cleanup and six-case OCI audits passed with receipts 6daf8bc96dbc8dba7f91cf171d991f0a14fec5e423bbda6375a5cce748d8e004 and 753f5ceb641842f2afc664493e0e4632c0a9fe9751854302932de0f05bc44e84. Later precommit commands did not run. Actual pinned Linux diagnostics established that pnpm 11.15.1 compares installed files with the unbuilt index, so esbuild's legitimate postinstall output causes the old check to reject normal installation. The original diagnostic preparation failure and all three failed VMs remain retained.

The repair keeps the actual store check mandatory against a fresh frozen offline unbuilt reference, and independently compares all working dependency files with a normal frozen offline built reference. Report v2 binds separate paths, cwd, argv and raw log hashes; v1 decoding requires the exact original inspector hash. Four implementation/test files form the exact retained delta. The real Linux command passed intact packages (27231ms), rejected a deliberately changed esbuild README at the original byte-comparison boundary (15330ms, exit 1, no PASS receipt), and restored the exact original bytes. No shared package or service state changed.

Independent dependency-repair-audit-2 passed, receipt 29e8eff7af187bccc6dffab5f656a28284aae92a6b608ebd051e698e1c05909f: all 331 original-or-delta pins, seven capture meanings, 192 graph entries / 138 installed packages, failed manifest and restoration agree. Audit-1 retained ERROR because its adapter incorrectly keyed validated absolute artifact paths instead of the report reader's relative paths; its executed auditor is retained (8d1e913edd1b1cf92f234986917f4f440949928d295c213e65823916a14a79e7). Correcting only the adapter resolved it. Typecheck-27, lint-16 and architecture-focused-5 passed; the complete prior nine-file selection plus unchanged source-release tests is still executing on pinned Linux bytes. These are dirty working-input observations, not a clean implementation audit, activation, qualification or candidate.

Next: finish affected/static checks, prepare a clean owned input by committing only the four proven changes atop 082e, and retain the exact original proof plus new delta/bundles. Execute all nine precommit commands in a fresh unchanged-policy C3 guest, independently audit, complete curation, commit C6e and continue the authorized real audit/request/review/activation/candidate/mutation sequence. The plan snapshot before this update is retained at plan-consolidation/before-dependency-repair-pass.md.

## 2026-09-06 23:27 UTC — Correct the second disposable precommit setup mismatch

VM-2 retained ERROR at 463813ms. Its guest-local store pin allowed the unchanged dependency validator to reach the independent package comparison. The inherited --ignore-scripts source install left esbuild's 9350-byte wrapper, while the normal frozen offline reference installation ran the repository's existing allowBuilds.esbuild=true postinstall and produced the 11407472-byte native binary. The strict comparison correctly failed. Four static checks and the six OCI cases completed; invariants/controller/root/build did not run. Independent native cleanup passed and bounded raw collection is in progress. Preserve both failed VMs as failures.

VM-2 collection subsequently retained 234 guest members; the independent six-case OCI audit passed (6d5a8a14f22b931b0bdf9684c7b843c42f0279fdf4d9c95b3e3e928692768329) and native cleanup passed (4256f3cb68b69dee473826f6458ae4cf33ea8acc6a1e54b1b885938ef4c27ec9). The next guest, 95ba5a31-c39c-4c3b-b554-9ed55ece92de in /home/duncan/oc3-c6e-yl2ydymm, launched at 23:30:17.1386129Z. It keeps the exact source bundles, store pin and unchanged C3 host policy. Only --ignore-scripts was removed from the initial source installation so its semantics match the real production dependency replay. The allowed build runs only in the task-owned disposable guest; no shared package/service state or production check changes. Its bounded driver retains input inspection, launch and collection records and performs independent cleanup/OCI/host auditing after the actual outcome. Continue all nine checks and audits, then the complete authorized C6e/migration/candidate sequence.

New retained-audit source passed actual ESLint/Prettier checks. The first wrapper's zero-byte log declaration was rejected by the unchanged receipt validator; retain its ERROR manifest and raw exit-zero child records with no PASS receipt. The corrected wrapper preserves empty raw files while declaring only nonempty receipt artifacts. Retention-tools-static-2 passed with receipt 3506f3f5fcf7b94e5bee7dafc79a7b27059e372612a1506bd4ddacf34db378d7. The full retained behavioral audit remains pending.

## 2026-09-06 23:22 UTC — Retain precommit store mismatch and verify owned cleanup

The first actual Linux precommit guest failed at verify:source-dependencies, exit 1, after typecheck, lint, format and source architecture passed. Its installed metadata named /home/qualifier/.local/share/pnpm/store/v11; later sanitized provider discovery in the inherited C3 setup relocated that store to /work/.pnpm-store/v11. The production strict equality assertion correctly rejected it. Invariants, controller, root unit and build did not run. Host ERROR at 463674ms remains non-passing. Raw collection retained 225 guest members plus bounded host observations. Independent OCI validation passed all six completed cases (95c04127bc7ce704733c64a154f869d9b19ad01c5926416a2d70d09910d2663c). Independent native cleanup observed the owned process identity, cgroup and guest directory absent (2717e7212748328f2a2697d701c1f144d30e0971a38e6a8a1201d6c344d31d1d). Neither supporting audit changes the failed aggregate.

Frozen reconstruction passed for all 649 included files, the thirteen proved raw/Git text representations and the real incremental input bundle: commit 082e4369a8e637243ff45e9e66d368452c74eced, tree e45498ae34c9aa23ed17aceeea6f222fb854f518, direct parent fc2419d. The roadmap remains excluded. Fresh VM-2 launched at 23:17:52.2723002Z with those exact source bundles and the unchanged C3 host program/policy. Its task-owned guest account now pins the same store before installation and provider discovery; the source check and all original deadlines are unchanged. Its two-hunk guest patch, program/input hashes and outer invocation are retained. Results remain pending. Primary C6e remains uncommitted; continue the complete authorized migration and candidate obligations after verified C6e closure.

## 2026-09-06 22:46 UTC — Complete C6e recovery/consumer regressions and frozen-input audit

The nine-file recovery-publication-focused-1 run completed at 22:44:58.621 UTC, exit 0: 203 PASS with zero failed/pending/todo/unhandled. Receipt c99cd98be09949dfa54fe9dd093b04e1546b0efa67c34975b1a25fe66642c557. Independent recovery-integration-audit-1 passed (9c947bbc6b628374a81dc61a3ef032f8eba909176e8f984ad51516a53f951958), rechecking every artifact, all 650 frozen input files, the exact retained index/patch, all raw tests and preservation of the prior 107 focused identities. Both native invocations remain honest non-passing aggregate observations with correct full/focused purposes and completion false. All six new recovery/export/foreign-byte cases and all original publication/committed-consumer cases passed at unchanged original deadlines. Earlier failures remain retained.

The plan is consolidated, with its exact prior bytes retained in plan-consolidation/before-recovery-pass.md. Prepared but unexecuted retention/VM scripts will construct a clean input commit in the owned parent clone, run the nine original applicable precommit commands under unchanged C3 host policy, and independently audit raw host/OCI/cleanup/command evidence. Primary C6e remains uncommitted and legacy authority remains active. Continue the real audit/request/SDK review/activation, candidate/four partitions/timeout propagation and committed 5(a)/5(b); no source state initialization/adoption or historical WP6e/WP6f claim.

The first input preparation failed on CRLF versus LF and remains at precommit-clone-input-1. The owned frozen-text-checkout-1 receipt proves thirteen exact frozen text/Git-checkout relationships, all limited to .gitignore/documentation, with raw bytes retained and actual text=auto/eol=lf attributes checked. Source/test/config bytes agree exactly. The checked partial preparation resumed without resetting and created isolated input 082e4369a8e637243ff45e9e66d368452c74eced (tree e45498ae34c9aa23ed17aceeea6f222fb854f518); the primary is still uncommitted. Its bundled input and 331 source/test/config pins prepared successfully. The unchanged C3 host program launched guest 285ebd50-c24d-4b52-b055-7cec5c198e51 at 22:57:01.3886887Z in /home/duncan/oc3-c6e-7rrbbv81. The appended nine-command precommit job is pending; host/OCI/cleanup and command receipts remain to be independently audited.

## 2026-09-06 21:38 UTC — Native focused-scope defect isolated; source tier collision corrected

Recovery-consumer-baseline-2 completed at 21:37:29.834 UTC, exit 1: 89 PASS/1 FAIL/90, zero pending/todo/unhandled and no PASS receipt. The sole failure is the completed focused native run declaring full-source-qualification instead of candidate-support. Both source tier tests reached the actual provider/receipt boundary and correctly rejected synthetic exit-zero without evidence. The complete full native invocation finished with six failed prerequisites and five NOT_READY missing stages, completion false; its regression passed. All scope, schedule, ownership and source/legacy catalogue cases passed.

Completed native report/log snapshots are retained at native-focused-baseline-2 (report c33034b8856b8ce50d3c771c3156ea2e59087049609b72912103c6abf4522ef5) and native-full-baseline-2 (679346631291e6600ebae86518b41785c599d417c5680870adb53f790cd99107). Exact nested files and actual child supervision are also encoded in the command's retained stdout. These are real native executions against explicitly synthetic committed publications; neither establishes real source activation or qualification.

Next is exact-before integration of the isolated publication/scope repair and four new actual intent-write/export/foreign-byte faults, preserving original failed retry bodies and all original deadlines. C6e remains uncommitted; the real audit/request/SDK review/activation/candidate/provider/mutation obligations remain open.

All four exact before hashes matched; the repair and four additional cases are now integrated. Typecheck-26, lint-15 and architecture-focused-4 passed and all receipt artifacts were independently size/hash checked. The nine complete files in recovery-publication-focused-1 are active with 203 expected cases and frozen inputs. No outcome is claimed before actual completion. Continue evidence preparation read-only, then the broader checks and complete authorized continuation.

## 2026-09-06 21:23 UTC — Actual pre-intent and source catalogue failures reproduced

Recovery-consumer-baseline-1 finished at 21:22:53.893 UTC, exit 1: five failures, zero pending/todo/unhandled, no PASS receipt. Both retry cases reached inspectSourcePublicationEvents and rejected different first-attempt/retry intent hashes. Candidate and milestone source dispatch both failed at buildScopeCheckCatalogue because the canonical source dependencies entry collided with the legacy auxiliary. The new native test's own 90000ms spawnSync capture expired before a full aggregate report; its focused half did not run. Preserve raw reports, stdout/stderr and progress. A later live observation found no matching fixture Node processes, but did not recover the already-cleaned nested native logs; do not claim those logs were retained.

The plan requires a source-specific auxiliary repair with legacy duplicate rejection preserved, plus a corrected new native harness using separate actual invocations, production process supervision and exact diagnostic retention. Only these new native test capture/case limits change to 300000/330000ms; original publisher/test/public verification deadlines remain unchanged. Correct mistaken draft expectations for an unavailable invariant child and the source-acceptance stage. Re-run the complete consumer file against the unchanged native scope producer before integrating the isolated scope/retry/export repair. C6e remains uncommitted and all real activation/candidate obligations remain open.

The catalogue and new native harness are integrated, with two fast catalogue regressions. Typecheck-24 failed on missing optional commissioning metadata in the generic/legacy manifest types; a guarded optional identity projection fixed it. Typecheck-25 and lint-14 passed with independently checked artifacts; lint-14 precedes that type-only correction. The five complete files in recovery-consumer-baseline-2 are now running with frozen production inputs. Publication recovery, focused-scope and additional export-fault changes remain isolated drafts. No actual SDK service or activation/candidate operation has occurred.

## 2026-09-06 21:05 UTC — C6e strict audit and committed consumer suite passed

Publication-focused-15 completed at 21:04:58.819 UTC, exit 0: 107 PASS, zero failed/pending/todo/unhandled (51 publication/audit, 35 evidence, 21 lease). All six receipt artifacts were independently checked for exact bytes and SHA256; receipt b7f838ec86af2b67f5db50841c9445cd92d511cb7dfbd8df7786294532e57016. The committed/rehashed incorrect execution record was rejected before the SDK boundary. Original recovery, committed native readers/state fencing, rollback refusal, raw/report semantic negatives and lease cases passed at unchanged deadlines. Synthetic unit fixtures confer no actual audit/review/activation/candidate claim.

The active plan is consolidated with prior bytes preserved at artifacts/wp6e-source-publication-20260906/plan-consolidation/before-recovery-regressions.md, SHA256 7c458e8cdb483a345ceb9943aab5bec0240b855a4d04fd2b57ced732a69ba45d. The exact-before-checked shared synthetic fixture, two new recovery/consumer files and ownership additions are integrated, pending checks. Next: record actual baseline failures before applying the isolated pre-intent/intent-write-gap/export-hook/native-scope repair. C6e remains uncommitted; legacy authority remains active; all actual activation/candidate/provider/mutation obligations remain open. Continue the full authorized task.

## 2026-09-06 UTC — C6e reader repair and complete committed-consumer regression pass

Publication-focused-14 completed at 20:24:51.661 UTC with exit 0: 68 PASS, zero failed/pending/todo/unhandled errors (12 publication, 35 evidence, 21 lease). All six command-owned artifact byte counts and SHA256 values were independently checked; receipt 056e0245fd8ca0f00fcf773df4e1a50cdb83f4edb71dd1c5c33b8b189376516b. The exact-before-checked historical batching/native-import/export-boundary repair passed all original recovery cases, both new Git observations and both committed-consumer cases with unchanged individual deadlines. Native authority/commissioning/schedule/integrity readers agree, legacy state is fenced, ordinary code fixes remain readable and altered schedules/receipts/committed rollback are refused. Run 13's actual timeout failures and typecheck-19's intermediate type failure remain retained.

While the production inputs remained frozen, an unexecuted audit-report-validation-draft was prepared with fixed execution records, strict raw/report/implementation bindings, complete nested invariant and consumed-build checks, explicit synthetic fixtures and semantic negative cases. The active plan specifies exact baseline comparison, integration and complete verification next. Pre-intent retry, partial packet export and native/tier source execution remain additional concrete regression obligations. C6e is still uncommitted; no actual SDK service review, implementation audit/request, migration/activation, candidate or committed 5(a)/5(b) has run. Continue the full authorized continuation, preserving historical WP6e BLOCKED and separate runtime/readiness/human gates.

After the run finished, every captured audit-draft baseline matched and seven changed/new files were integrated. Typecheck-21's implicit-any fixture failure was corrected by an explicit archive-file type; typecheck-22, lint-11 and architecture-focused-3 passed. Native audit-reader-retained-1 validated seven actual parent command report meanings and six nested receipts against historical fc2419d source, with an explicit retained-decoder-only claim and no outer audit execution validation or historical rerun. Its receipt is 30d0ff7c8ca6feeec28741426cd3fd92290a5b31c1cbece9b944e629d3173db8; all four successful check artifacts were independently size/hash checked. Publication-focused-15 is active (107 expected cases); production inputs are frozen again and complete results are pending. This remains an uncommitted implementation increment.

## 2026-09-06 UTC — C6e completed failure diagnosis and bounded reader repair

Publication-focused-13 completed at 19:25:14.906 UTC, exit 1: 63 PASS/3 FAIL/66, zero pending/todo/unhandled errors and no PASS receipt. All 33 evidence cases, all 21 lease cases and all four original recovery boundaries passed. The positive publisher body and both committed-consumer setup hooks hit their unchanged 180000ms deadlines; stderr retains the actual diagnoses, while raw Vitest failureMessages contain STACK_TRACE_ERROR. The subsequent architecture-baseline-1 reproduced an unbounded dynamic-import rejection in source-authority-anchor.ts. Neither failure is normalized or converted to performance evidence.

The active plan now requires exact before-hash comparison and integration of the prepared six-file reader-boundary-repair-draft, with no deadline or boundary removed, then fresh formatting, typecheck, lint, architecture and all 68 selected cases. The separate audit reader draft remains unexecuted. The catalogue contains 100 entries but root Vitest selects 99 files; its union with the separate OCI fixture contains 100. C6e is still uncommitted, legacy authority remains active, and no real audit/request/SDK review/activation/candidate or committed mutation has run. Continue the full authorized continuation after this repair.

The six baseline comparisons matched and integration completed at 19:33:16 UTC. Typecheck-19 retained a possible-undefined Git identity failure; explicit runtime string checks corrected it. Typecheck-20, lint-10 and architecture-focused-2 passed and all receipt artifact bytes/hashes were independently checked. The complete 68-case publication-focused-14 run is active, with production inputs frozen. Separate audit drafts are not execution evidence.

## 2026-09-06 UTC — C6e in-progress integration and completed parent observations

C6e remains uncommitted and legacy authority remains active. Final parent fc2419d8bdfc3658fe76edf2b543b38051b359f1 run 34047573294 completed all five protected jobs successfully. All five provider archives and final job metadata are retained in artifacts/wp6e-source-publication-20260906/hosted-fc2419d. Independent hosted-fc2419d-audit-1 validates five archives and 43 child receipts (998b2bd13eb83fc2929720f8fa4a4009a7a218491e982d62d61136dcc547b377); the Windows archive is 132819 bytes, SHA256 7cf4fe08a5685b0423eda47448dfb1befc59a1c483446ea3ac40fbe8c5e47932. These observations supersede the prior entry's pending parent wording, not its historical failures or unresolved native qualification.

Integrated draft consumers now require separately committed request and publication evidence, inspect historical outputs and active source authority, preserve ordinary implementation fixes, reject source rollback and fence legacy state after source activation. A fixed exporter retains publication/review/lease/raw evidence under the held publisher; the additive migrate CLI performs no commit or adoption. Source aggregate and tier envelopes carry actual scope and fresh dispatch correlation. Full source qualification is still unimplemented and non-passing. No actual implementation audit, SDK service review, migration request, activation, candidate run or committed 5(a)/5(b) has occurred.

Preserve the expanded publication-focused-11 result, 54 PASS/1 FAIL: the owned corrupt-object fixture failed before reaching the reader. Its canonical fixture-only chmod correction passed the complete reader-focused-12 file, 24 cases (e0e3d85cb13b68a1081ad3ad0b191cee6722e649e41d8ee786254d16138108b6). A real process regression then reproduced twelve/thirteen beforeExit/exit listener pairs: lifecycle-baseline-1 retained 6 PASS/3 FAIL. One shared handler pair now tracks every context without suppressing warnings; nonzero exits revoke all finalized receipts and unfinished contexts remain ERROR. Lifecycle-focused-2 passed all nine cases (aa1b614376a72c8a6038c6ebffb6c6b8c32f5be5b9b0d704e3dddfcf00816785). Source-consumers-1 passed all 69 scope/schedule cases; all six receipt artifacts were independently checked (1d3dd16e8ab24533f113fd9ae25f1b4e2d6c6f4e14db831d81d938a92811cc52).

Typecheck-18 and lint-9 passed after retained earlier failures, with later small edits still requiring final checks. The complete 66-case publication-focused-13 run is active and its first publication case failed at the unchanged three-minute boundary; raw completion is still pending. Preserve the run and frozen production files. An unexecuted contained repair draft batches historical objects within each inspection, combines actual Git identity observations and removes duplicate checks at the same export boundary while retaining every live lease/permit/input recheck. Test it only after collecting the current run. Continue the bounded plan through the actual audit/request/review/publication and candidate/provider/mutation obligations; historical WP6e remains BLOCKED at e590e38 and no WP6f inference is made.

## 2026-09-06 UTC — C6d-R2 owned source-transition fixture cleanup

Pause C6e for bb312f3 Linux job 101513230820, run 34043089595: 949 PASS/1 FAIL among 950 controller cases, ENOTEMPTY in a disposable .git/objects/info teardown. No controller PASS receipt or later Linux root-unit execution; the runtime-store test passed. No captured observation identifies the background writer. Retain the four then-available hosted archives as a partial snapshot; collect the still-running Windows job separately before a successor same-ref push.

An unchanged native baseline passed all 32 transition/runtime cases (5b82254214621040da5a3922b97670d6f32a5b311472edfec0cd2d491491f6da). Suppress automatic Git housekeeping only in each new clone, validate exact canonical owned Git/CLI output paths, and use five native rm retries with 25ms linear backoff. Original complete suite syntax trees, identities, assertions and deadlines remain equal. The first repair overlooked the two existing CLI output directories and actually failed 30 PASS/2 FAIL; preserve it and correct only that guard. Final full files pass 32 (3228b6c9ccf1e30fc3f7858ab86b7fed6ac5ca229af3b830ab0e1135c0fc635a). Final typecheck/lint/format and applicable source architecture/dependency checks pass; all five invariants pass in 84754ms, without performance interpretation.

Retention: docs/ci-regressions/source-transition-cleanup, 409 regular files, 3908229 raw bytes, 49 validated command-owned receipts; ZIP 1816614 bytes, SHA256 7a7f61733e455c405e9ebb193efa625b7870ab4a1024d4b6a116eacf2e6d4f6e. Fresh extraction/audit passes (87c444475a3c25fbde0965eec1d37231453aabfff330ed4e2c6899c5811eef85). The seal includes the independently rechecked clean R1 audit/focused/dependency/consumed-build evidence at bb312f3. Its complete hosted cohort remains separate. The new auditor uses the production pending-path export, correcting only the supplemental R1 observer spelling without rewriting sealed history.

The clean repair commit's independent audit/focused/dependency/consumed-build and exact new five-job hosted observations remain required at the committed plan's ignored destination. Restore C6e without losing a byte, then continue the full authorized migration, actual candidate/four partitions/raw reconciliation, real 65-minute provider boundary and committed 5(a)/5(b). Historical WP6e remains BLOCKED at e590e38, source state absent, no activation/readiness/human-acceptance or WP6f claim.


## 2026-09-06 UTC — C6d-R1 native package-runtime fixture store binding

Pause C6e after actual C6d Windows job 101500874916 in run 34038506240 fails one of 950 controller cases: an offline temporary-fixture install cannot find locked @eslint/js 10.0.1. Retain all five exact-commit archives and their 38-receipt audit, four successful jobs, Windows 949 PASS/1 FAIL, and Windows root-unit NOT_EXECUTED. The failure did not reach a timeout. Local store-path observations do not establish the precise hosted selection mechanism.

In an owned remote-free clone at 96abed9, reproduce the same real installation failure using an empty fixture-local implicit store, then pin the actual source-installed store for the existing offline install and strict sanitized/CI children. Preserve every original assertion, identity and deadline; no runner/environment/public argv/workflow/authority changes. The first option spelling fails at pnpm exec and is retained; --config.store-dir works for both commands. Complete affected files pass 15 cases (6f02577f78c24ebbb2ae2a98d0266d7f99a0645ee8cf2e3968e55cd2ea9f4b9c); typecheck/lint/format/source dependency/architecture and five invariants pass. Dirty-tree build refusal and an interrupted accidental full-unit launch remain unverified without PASS receipts.

Retention/auditor: docs/ci-regressions/candidate-installed-store. Fresh extraction validates 468 files/56 receipts and preserves eight original assertion expressions; ZIP SHA256 9f6fb78dc131c0de7d2f80e9fc80608286741c920c7f390c71c4e1e0c07c3a72, audit 2f3a666c9d1e3eab71b491ad4f4fa9c7e879740fec84ccdb21739b0ea4d9b5a4. Exact clean post-commit consumed build, independent reproduction and the new five-job hosted cohort remain required at the committed plan's ignored destination. C6e stays preserved and unactivated; continue the full authorized candidate/provider/mutation closure. Historical WP6e remains BLOCKED at e590e38, source state absent, no readiness/human-acceptance or WP6f claim.

Append one entry per completed increment: date, plan objective, verification
evidence (commands, result paths), commit id, and known gaps. Newest first.

## 2026-09-06 UTC — C6d exact source transition and committed request bindings

At parent ab19211e3663acc7b14acc847bdc3dde11414d19, add a receipt-owning read-only transition inspector and strict committed-request binding reader. Project exactly twelve approved authority/package/commissioning/policy/manifest/epoch-ledger files from strict actual C4 ancestry. Preserve the original complete amendment ledger, authority roots, protected argv/workflow, readiness marker and source-state absence. The request subject digest avoids a self-referential output/request-commit hash cycle; a later actual request and review bind real commits separately. Metadata binding PASS authenticates neither implementation-audit success nor independent review and authorizes no publication.

The complete native request suite passed 31 cases (27aa1e1b18060f9ddfb8106a619b342f35cea6257cfe3a80e983bfb4576f512c); the corrected six-file boundary suite passed 132 (f5eeac9a6fe36d59fc1b1fca95b589162dd055795f8b211617c6563af4ce6bf7). Typecheck, lint, format, source architecture and all five invariants passed; invariant duration 68552 ms has no performance interpretation. Fresh projection-2 retains thirteen validated artifacts with receipt 2fb747464be787c46dc25cc239662017812257b67f75c182250a269eb3b0b636. Explicit ownership now counts ninety controller files and ninety-eight root files.

Retain initial type errors, missing process-boundary ownership, three failing reserved-source fallback cases and the 85/86 adopter run. The actual generated base 047cee6f2f26bf7c0ad63b591afd3175e9904162 incidentally matched d31 in a prose prohibition. Preserve the original regex and all other assertions; validate that single opaque field against actual HEAD^ before scanning remaining text. Production adopter bytes are unchanged. A subsequent raw 86/86 run remains non-passing because my selection included a nonexistent source-release path; the production harness correctly refused a receipt. The final selection uses tools/source-release.test.mjs. Preserve all failure evidence without invented success.

The C6b e072287 exact hosted cohort 34033743564 completed all five jobs successfully before any successor push. Each controller passed 915 controller and 1089 root-unit cases. Five provider archives and forty-three child receipts pass independent audit e0385a66dcd57f6853654b429cc1864609c5c9ec6110119180f1ae4ec0ebe3a7. These observations identify e072287, not this increment or a native Windows full-qualification result.

Seal: docs/source-authority/ORCH-AUTH-01-C6d/evidence, 533 regular files / 5711231 raw bytes / 70 independently validated receipts, ZIP 2305267 bytes SHA256 8c956082766765d8af2e5a33bd4dfb9606cd1f75c68d3a9bb2b14cb2e0d9c093. Fresh checked extraction and audit passed at artifacts/wp6e-c6d-retained-audit-1, receipt 77923a5f96294d28e921d91ae7fb0050173642d87ea63469b24c085b02315dff. The seal includes independent clean C6c post-commit dependency/build/audit observations and the full C6b hosted cohort.

This entry belongs to the cohesive C6d commit; its clean post-commit audit/build and exact successor hosted evidence remain next. Continue the complete compatible generation readers, authenticated implementation audit, real separately committed request/review, existing lease and recoverable publication, then actual candidate/four partitions/65-minute provider boundary and committed 5(a)/5(b). Historical WP6e remains BLOCKED at e590e38. Preserve the roadmap, absent private source refs/state, original unit-domain meaning and separate readiness/human gates. No WP6f conclusion.

## 2026-09-06 UTC — Stabilize candidate package configuration and discovery identities

C6c fixes the two observed candidate prerequisites at parent e072287ac054197a469b39031f2a348a6c47a100. Set enableGlobalVirtualStore: false in the source workspace; preserve the production environment allowlist and strict dependency verification. A new real command-runner regression installs the workspace's pinned manifests/lock under CI and consumes TypeScript through sanitized and CI-present strict children, asserting unchanged installed metadata/lock hashes. The baseline actually failed with ERR_PNPM_VERIFY_DEPS_BEFORE_RUN because the setting changed. Correct the new test's parser type to the existing exit-code value; retain its typing failure and both baseline attempts without PASS receipts.

Four unsafe-PATH parameter rows receive distinct stable labels. The full-file transformation proves original platform/path expressions and rejection assertion unchanged. The unchanged production comparator detects the old three-observation collision and accepts forty distinct current discovery identities. The audit emits an exact four-row mapping with thirty-six unchanged observations; this does not claim the future candidate's full historical/exactly-once reconciliation. Ownership explicitly adds the new controller regression, with 89 controller files and 97 discovered files.

The complete seven-file native focused selection passed 118 cases, receipt b3b2956752385de095a75b301b9f32b1cb4ea0d2ac039688362961c7e4b34b6b. Typecheck, lint, formatting, source architecture and all five invariants passed; invariants took 69962 ms with no performance interpretation. Preserve the first strict root refusal and the subsequent unflagged typecheck's automatic refresh of ignored local installation metadata. Later outer invocations use strict mode; shared user configuration was not changed.

Retained seal docs/candidate-runtime/ORCH-AUTH-01-C6c/evidence has 130 regular files / 1678939 bytes / 15 valid receipts. ZIP 752700 bytes, SHA256 f527f5b954750844cc4cb3acf8ee837f7437670e4008c21f30d4d4c50ca463b5; independent audit receipt 274c681b20a930927528ff64307ecc036b5c74583ba2fcaae517dc52ebd2d9bf. The initial curator's missing numeric console total was corrected; the independent extractor/auditor always checked actual byte bounds. Prior curation/audit observations remain retained locally. C6b clean exact post-commit audit/dependencies/consumed build are included and independently validated, with empty gitStatus and no source state/private refs.

C6b was pushed as e072287, tree 16e6437bbcec22023a6208236b76f699cff6f88a. Its exact hosted run 34033743564 has four successful jobs and Windows controller 101487939786 still running. Preserve all five final artifacts before a successor same-ref push. This entry belongs to the cohesive C6c commit; fresh clean post-commit audit/build follow. Continue complete source-generation readers, separately committed request, real independent review, leased recoverable publication, actual candidate/four partitions/65-minute provider boundary and committed 5(a)/5(b). Active authority/history, user roadmap and source-state absence remain preserved. Historical WP6e stays BLOCKED; no root-unit/unit-domain conflation, native full qualification, readiness or WP6f claim.

## 2026-09-06 UTC — Validate explicit source verification scope without activation

C6b adds shared source aggregate 3.0.0/tier 2.0.0 metadata, eleven source stages, strict source tier bodies, incomplete aggregate receipt/artifact consumption and approved source integrity inspection. Trusted expected source/fixture/qualifier scope is checked before status, including nested exact closure. Legacy schemas, thirteen integrity checks, original assertions/deadlines and native verifier execution remain. The common MJS dependency is explicitly distributed. Live authority and complete commissioning/amendment history remain unchanged; source state/private refs are absent. Parent c708945e4ba8e0b75f09bc9e564b4afc5cb47a0a and final fifteen-path development projection 12b2e205abab2d728b4c749da8926754acda9686 identify the tested source. This entry belongs to the cohesive C6b commit; clean exact post-commit reproduction follows.

Native focused commands passed 140 source/verifier cases, 103 foundation/adopter cases and 30 publication cases. Typecheck, lint, formatting, source architecture and all five invariants passed with owned receipts. Preserve the actual earlier typing, malformed-diagnostic, nested-scope and native-import failures. The legacy contract-integrity module was restored byte for byte after a real native Node import failure. Three fixture copy lists now include the required MJS file; original test assertions are unchanged.

VM-1 was prepared but never launched. VM-2's full real unit command passed 1088/1089; preserve its missing-runtime-fixture failure, unit/host ERROR and verified cleanup. After the one-line copy-list fix, VM-3's actual pnpm test:unit passed all 1089 cases, zero skipped. Independent six-case OCI and host lifecycle audits passed; process, cgroup and directory cleanup are verified. All 1043 earlier unit observations are preserved as a multiset plus 46 new source-reader cases. This does not close candidate exactly-once coverage; three earlier discovery rows still share one report name. Original deadlines and measurement checks remain intact.

A real clean offline independent-copy build at cb6b91235bdd8de8f86eb0c3a7c44c7d9575b56f / 7dfaa338d0882ffb35fe69fe3d8df90395f9947c produced and consumed the release. Actual Git objects are retained and independently checked; final source differs only by the later test-fixture copy line. Root dirty-tree build and hard-linked dependency refusals remain failures; no shared package configuration was changed. A final clean exact-commit build remains the next operation.

Seal docs/source-authority/ORCH-AUTH-01-C6b/evidence contains 1217 raw files / 8361545 bytes and 67 independently valid receipts. ZIP 3160537 bytes, SHA256 ce14a5038173670af024009991ec1956df302c079c68ca3bd8473c2449eb6a47. Actual audit artifacts/wp6e-c6b-retained-audit-1 passed with receipt 10ecc958f3e6d575654343a3af84ecad0efc514c511cee56aaad2fe53e1ee7dd. Its partial hosted snapshot remains unchanged. The separate final c708945 hosted archive retains all five successful jobs in run 34029390274, 43 valid child receipts, both 869-case controller suites and both 1043-case unit suites. Final audit d70bbbac52835c1f1d09ebba1abe3a10a5f72b12ea3eeee4dea067804b16e836; ZIP SHA256 b6a59ab7462238114c44f4e2316cf5b19bbc9744fcbca0f0ce629f5839758b29. Windows completed 12:28:42 UTC before any successor push.

Continue through independently audited post-commit evidence, exact C6b hosted jobs, complete compatible generation readers, separately committed approved request, real independent review, lease and recoverable publication, then actual clean candidate/four partitions/65-minute boundary and committed 5(a)/5(b). Historical WP6e remains BLOCKED at e590e38. Root-unit success never establishes unit-domain success. Native full workflow qualification, source readiness, human acceptance and WP6f remain unclaimed. Preserve the user's roadmap and recovery stashes.

## 2026-09-06 UTC — Restore original fixtures under strict authority inspection

Changed ten fixture setup writes to valid legacy package/lock JSON, preserving every original assertion, case, fault loop and deadline. Production authority/state/verification code, protected scripts/workflows, commissioning history and live source state are unchanged. Parent is 6ae4efb808652e24d565cf5562c0611aac5ed25a; tested fixture-only tree is c94eb34007a13d2d342f331fb1422b8325cc0141. This entry belongs to the cohesive repair commit; exact post-commit identity and audit are the next recorded operation, before unfinished C6b resumes.

Retained the exact failed C6a five-job cohort: both controller jobs have the same 59 failed cases of 869; the two adopter jobs and OCI job succeeded, with 33 independently valid child receipts. Native reproduction failed four of eleven cases. The complete repaired native selection passed 62/67 with five original deadline failures, zero skipped/unhandled errors and no PASS receipt. The unchanged pre-C6a dba20a6 diagnostic executed the same five cases: two inspection cases passed, three original deadlines failed, 34 cases were skipped, and ENOTEMPTY/cleanup-hook failures remain recorded. Neither diagnostic supplies native full qualification. Typecheck, lint, format and five invariants pass; the 132262 ms invariant advisory miss receives no performance interpretation.

VM-1's actual full unit command passed 1042/1043, including all 67 affected cases, but failed the original omission test before reduction. Preserve its ERROR lifecycle and cleanup. Strict Linux diagnostics identified pnpm's CI-dependent global-virtual-store setting across the unchanged sanitized child boundary. VM-2 directly retained the same pre-configuration failure, then set only that disposable guest account's pnpm setting explicitly. The unchanged full unit command passed 1043/1043 with receipt 2b2fa086a77948641b54742049f559553c806527f0031f0291e74ccd7693cd3f. The unchanged finite C3 host policy completed run a0655068-5890-48c1-a8af-65b4b68fb43a and owned cleanup; independent OCI/host audits pass. No shared configuration, service, package or clock was changed.

Seal: docs/ci-regressions/authority-fixture-json/evidence, 1347 regular files / 6491526 raw bytes, 49 independently validated receipts, ZIP SHA256 15d0ff6141b51179e31e0cb792f31d85999842dbc8d6e681a8f6044e0e95d89b. The exact extraction and audit.ts command in its README passed at artifacts/wp6e-authority-fixture-repair-20260906/retained-audit-2, receipt 0f86dcd448a20d36e02820bc95bff18e01c3ad782c73452a54789fc9fe79d89e. It reconstructs the real Git projection, compares all original fixture/assertion bytes, checks active authority pins, raw counts, measurement summary and independent clock observations. The first failed auditor incorrectly assumed unique display names; its code, input manifest and failure are retained. Three pre-existing host-discovery parameter rows share one Linux display name, yielding 1041 distinct names for 1043 observations. Both complete unit reports have exactly the same multiplicity. The production exactly-once comparator remains unchanged; resolve this explicit candidate-proof gap in the continuation without weakening it.

Next: clean post-commit audit and all five exact hosted jobs, then restore C6b stash 88f748f1a26dfa01d347ee9fd13652222abbb9a3 against all thirteen recorded hashes. Continue compatible source consumers, safeguarded request/review/leased authority publication and actual candidate/four partitions/65-minute boundary/committed 5(a)/5(b). Historical WP6e remains BLOCKED at e590e38; source readiness, native full qualification and human acceptance remain incomplete. Preserve the untracked roadmap and absent source controller state.

## 2026-09-06 UTC — C6a: refuse pending/mixed authority and inspect the approved anchor

Added a shared native-Node publication fence at authority, config, commissioning, lease, state and verifier boundaries, including write/dispatch rechecks. New approved-anchor inspection requires the exact seven source roots, settled approval and real strict-ancestor C4 snapshot; inspection never activates source authority. Live goal/acceptance/commissioning/readiness history and absent source controller state remain unchanged. The explicit distribution inventory includes the runtime modules; two new suites add 43 cases. Original legacy assertions/deadlines remain intact. Doctor's fixture now supplies parseable legacy lock JSON while its manifest stays absent.

Final native boundary 56 and Doctor/state 52 cases pass, alongside typecheck/lint/format/source architecture and five invariants. Retained 23/226 and 10/132 failed affected attempts include fixture defects and original local deadlines. An unchanged detached dba20a6 baseline reproduced all three amendment deadlines. The no-checkout and inspected direct-Git diagnostic attempts remained non-passing; the original fixture was restored. No timing or WP6f claim follows from these observations or the 106,809 ms invariant advisory miss.

Two complete WSL runs each passed all 282 raw cases but failed the unchanged production timestamp check without a PASS receipt. The independent clock observer reproduced backwards wall-clock steps. A fresh task-owned Ubuntu VM reused the unchanged C3 coordinator and finite 30-minute policy. Run 94e44109-2f6e-43c6-abe7-0b887505ee84 passed the real OCI matrix at clean dba20a6, then the exact C6a development projection and all 282 cases with a valid measured receipt (8e0ff0a2c3a1c40af2dce6f19c9780f821879c14e69bd8dbcd6348d0ed6e7a1a). Its process/cgroup/directory cleanup and independent C3 host/OCI audits pass. Shared packages/services/clocks were not changed. All failures and original raw identities remain retained under artifacts/wp6e-source-readers-20260906.

All five earlier repair jobs at 42871f6/run 34015911019 passed; five provider ZIPs and 43 command receipts are independently validated. Clean dba20a6 post-commit C5 portable/follow-up audits also passed without source-object/state mutation. These observations do not verify a later commit. This entry belongs to the narrow publication-fence commit; its fresh clean retained audit and exact hosted cohort remain post-commit work. Continue full compatible consumers, approved request/review/leased migration, actual candidate/four partitions/65-minute boundary and committed 5(a)/5(b). Historical WP6e remains BLOCKED; native full workflows, source readiness and human acceptance remain separate incomplete gates.

The final sealed C6a archive contains 984 files/6,312,436 raw bytes and 69 validated receipts; archive SHA256 7c4453a6c01a493b4dde14c5957457d16f395ded185f568b64a50bf30e195ac8. The independent retained-audit-1 passes actual Git projection and original case identity reconciliation, unchanged authority hashes, all failed/no-PASS boundaries, successful VM observations and the exact older hosted cohort. Its receipt is 95bba0cd763d6b5af547370eaf34ebd2a7a01740296afe10a4f6cb6c0bd31f31. Post-commit observations remain separate.

## 2026-09-06 UTC — Make C5 retained evidence reproducible from published history

The real build/dependency/architecture commands passed in a clean branch-only no-local clone of committed C5 0b7a820aa589b227993781474de2d00b79628a6b. The original retained audit failed there because its two supporting side-branch objects were absent. Retained that failure and the successful production receipts in the separate 60-file/six-receipt archive (SHA256 58137c5f9e2d1ad50b947885d757d28ae8da3a208442c6f6b74f007b3cb2d83c). Preserve the original 318-file archive, manifest and auditor unchanged.

Captured actual raw Git commit objects and added a portable wrapper that validates their original IDs, reconstructs exact sealed trees in a temporary object cache, runs the unchanged auditor and checks source HEAD/index/refs/status/state remain unchanged. The prototype passed in the clone without supporting branches; a one-byte object mutation failed before child audit with no PASS receipt. The independent follow-up audit rehashes all 60 files, validates six receipts and the actual post-commit archive/consumer, and passes at artifacts/wp6e-source-build-20260906/portable-followup-audit-5. Four initial auditor defects remain non-passing in preceding directories. Prototype dirtiness is explicit; no source controller state or authority was created.

Commit identity is the narrow commit with subject "Retain actual Git objects for portable source evidence audits" containing this entry. Fresh clean post-commit portable-wrapper verification is the immediate next action, then C6 compatible authority consumers and the approved migration/candidate obligations. Repair CI 34015911019 still has four passing jobs and a running Windows controller. Historical WP6e remains BLOCKED; readiness, native full workflow and human gates remain incomplete.

## 2026-09-06 UTC — C5: consume a portable source release and inspect real dependency bytes

Implemented the explicitly approved supporting source distribution and additive build/dependency/architecture commands while legacy authority remains active. Existing package argv, protected workflows, immutable authorities and commissioning/amendment history remain unchanged. The shared build wrapper retains the real archive, manifest, detached generation observation and owned child evidence only after independent output inspection; its original clone/install/output safety remains. Generated adopters receive the original universal AGENTS template and their own authority/bootstrap history.

Actual clean supporting commits 6dd6463cf630176783c084dda4537386021045bd and c3617cb5be2c05203a3a2e5205396c2242c4f118 each built and consumed a 173-file/2,663,446-byte portable payload on native Windows Node 24.18.0/pnpm 11.15.1. The latter also passed the complete independent frozen dependency comparison (192 graph entries, 138 installed packages, 3,431 files/543,736,116 bytes) and all 79 affected tests. Python's standard tar reader separately inspected both archives; its Linux observer does not establish a Linux build. These different-commit supporting builds cannot claim full repeated/native build qualification.

Retained initial import/URL/scaffold, five-of-78 focused and typecheck failures; repaired the implementation errors without changing original assertions/deadlines. The original root absence-of-build test now targets an explicitly undeclared fixture with the same exit-2/no-PASS/NOT_READY assertions. The real dependency check first failed on pnpm's concrete/link duplicate representation; path-checked alias normalization and a redirected-alias regression precede its passing full byte comparison. A failed initial Python name-case assertion is retained as an executed script and labelled transcription, not invented raw stderr. Static checks and five invariants pass; final invariants took 64,073 ms, above the advisory target without a timing claim.

The 318-file/29-receipt archive at docs/source-release/ORCH-AUTH-01-C5/evidence/ has SHA256 2bb249859bd63731956b76a753ab87ba5cf88154e176f914a454c3f96a555763. Fresh audits reconstruct both exact committed archives, check active-generation hashes, every receipt/consumer and the independent tar inventories. C5 paused for the failed Windows full-unit repair cohort, then resumed after 42871f6 with all 24 file hashes and the roadmap preserved. Both recovery stashes remain. Run 34015911019 is pending; retain all five outcomes before another master push. The post-repair C5 audit reports the inert C4 snapshot as a strict ancestor with activation false.

Commit identity is the scoped commit with subject "Build and consume the portable orchestrator source release" containing this entry. Fresh exact post-commit build/check/audit observations remain next, followed immediately by strict compatible consumers, the approved migration and actual candidate/four partitions/committed 5(a)/5(b). Historical WP6e remains BLOCKED at e590e38; all existing source state stays absent. Supporting source checks, root unit success and synthetic receipt fixtures do not satisfy product-domain, candidate mutation, native full workflow, readiness or human gates. No WP6f interpretation.

## 2026-09-06 UTC — Preserve strict launcher discovery through canonical Windows fixtures

Paused C5 when exact repair run 34012032506 at 827ebbf finished with four successful jobs and a failed Windows complete-unit suite. Its controller suite passed; complete unit results were 929/937, with eight failures confined to host-discovery fixture paths. Retained all five provider ZIPs and checked their digests. A native Windows uppercase TEMP/TMP reproduction reached the identical eight full failure identities (32/40 passed), with no receipt. An earlier redirection setup failure never launched pnpm and is separately recorded.

Changed only the owned test fixture's mkdtemp result to its realpath and added that import. The production scanner and every original test assertion/deadline remain unchanged. The actual repository-tooling partition passed 128/128 under the same alias environment; typecheck, lint, format and five invariants passed (44,836 ms, no timing interpretation). Independent fresh extraction/audit passed over 113 regular files/ten receipts, raw matched failures, corrected cases and the exact two-line test-source change. Archive SHA256 daa7575dfa33966dba915c0779475f17b4365e0506b7f087885231854b80c97d; reproduction is documented at docs/ci-regressions/host-discovery-path/README.md.

Commit identity is the scoped commit with subject "Canonicalize owned discovery fixtures for Windows CI" containing this entry. Fresh post-commit observations and the new exact hosted cohort remain pending at commit time. Preserve and restore all paused C5 bytes, then continue its consumed-build closeout, strict compatible readers, approved recoverable authority transition, actual candidate/four partitions and committed 5(a)/5(b). Historical WP6e remains BLOCKED; source state, legacy authorities and settled inactive r2 approval are unchanged. No Windows workflow qualification, source readiness, human acceptance or WP6f conclusion follows from this fixture repair.

## 2026-09-06 UTC — C4: exact inert authority snapshots and strict Git-object inspection

Resumed C4 after integrating the narrow C3 fixture repair 827ebbf27b98fb1e2a3ea97cb5c1c0100618818d. Its clean 42-case native Windows alias run and independent retained audit passed before push. Exact repair CI run 34012032506 is still pending; the original C3 cohort remains failed. Preserved all nineteen paused C4 files through stash/fast-forward/explicit plan conflict resolution and verified every restored SHA256. The recovery stash remains and the user's roadmap hash is unchanged.

Prepared seven approved source and five exact original legacy authority files at their fixed inert epoch prefixes. Added a module-bound control-plane approval pin, real exact-commit/ancestry/Git-mode/blob checks and receipt-owning read-only inspection CLI. Candidate-selected approval paths or success flags cannot activate anything. Same-commit inspection explicitly reports strictAncestor false. Existing legacy authority-anchor behavior and all live authorities, package commands and commissioning/amendment history remain unchanged; complete active-generation readers and migration are still required.

Initial focused evidence failed 12/21 on the newly written suite's unconfigured five-second Git/subprocess timeout, and initial typecheck found two typing errors. These actual failures remain retained without PASS receipts. A bounded sixty-second timeout applies only to the new suite; original deadlines and tests remain. Final focused verification passed all 30 cases (seventeen new snapshot, four original anchor and nine ownership); typecheck, lint, format and five invariants passed. The current explicit ownership counts are 85/4/2/1, 92 files. Invariants took 76,046 ms; the advisory warm target remains unmet and no performance claim is made.

Curated evidence at docs/source-authority/ORCH-AUTH-01-C4/evidence/ has 98 regular files/eleven validated command receipts. Archive SHA256 07c74696083b638f88d9b48735d8fb9117053557b32f5b558a39502929abba2d. Fresh extraction and audit.ts passed at artifacts/wp6e-source-prerequisites-20260906/closeout-1, rehashing all files and current implementation/live authorities and reconstructing tested index 36856c6b16482157f5752e595d8df8b1a4b82d70 on 827ebbf from the retained binary patch. This audits dirty supporting executions, not fresh tests or source readiness. A real committed-snapshot inspection remains post-commit work; no fabricated future hash is supplied.

Commit identity is the scoped commit with subject "Commit approved inert authority snapshots with strict inspection" containing this entry. Immediately inspect that real commit and continue compatible source readers, consumed build/checks and the separately committed/reviewed/recoverable authority transition, then actual candidate and committed mutation obligations. Historical WP6e remains BLOCKED at e590e38, approval remains settled but unactivated, source private refs/state remain absent, and full native workflow qualification/readiness/human gates remain incomplete. No WP6f interpretation.

## 2026-09-06 UTC — Repair the two exact C3 hosted test-fixture regressions

Paused uncommitted C4 work and reproduced the actual c967579 hosted failures in an isolated checkout. C3 run 34010283121 finished with Linux controller 808/809 and Windows controller 783/809 passing, both failed overall; the two adopter jobs and original Docker fixture passed. Retained all five provider ZIP artifacts with matching provider digests and final job metadata. C3's successful disposable-host/retained closeout and failed hosted cohort remain separate scopes.

Updated the mutable current catalogue expectation from historical 83/1/2/1 (87 files) to the actual 84/4/2/1 (91), explicitly accounting for four B/C1/C2/C3 qualification test additions. Normalized only the qualification-input test fixture's newly created owned temporary root with realpath, matching existing artifact fixtures. Production path/link/binding/receipt guards and all rejection cases remain unchanged. A real differently cased native Windows TEMP/TMP path reproduced all 25 fixture setup failures, then passed all 42 qualification-input/container-artifacts/ownership cases after the repair. The separate catalogue baseline failed 1/9 and corrected run passed 9/9. Five invariants and final typecheck, lint and format checks passed with receipts. Invariants took 61,233 ms, above the advisory warm target; no timing interpretation or deadline change.

The retained archive at docs/ci-regressions/wp6e-inventory/evidence/ contains 130 regular files, fourteen local supporting receipts, both failed baselines, a failed audit attempt without a PASS receipt, the test-source diff and original five hosted ZIP artifacts. Archive SHA256 ae7b798fb47acd44a717f67ffc789b2d6eed13596c1b548fe40beef9d21ea05f. The executable extractor inspects all entries before writes; audit.ts verifies the entire retained inventory, raw outcomes, actual ownership discovery and every local receipt/artifact. Supporting executions are dirty and completion-ineligible. See that directory's README for exact reproduction and paths.

Commit identity is the scoped commit with subject "Repair qualification fixtures exposed by exact hosted CI" containing this entry. Fresh post-commit verification and a new exact five-job cohort are still pending at commit time. Preserve and resume C4 after ordinary Git integration; continue the full authorized WP6e obligations. Original WP6e remains BLOCKED at e590e38, r2 approval remains settled but inactive, and no controller state/adoption, frozen authority, protected CI, package script or readiness/human gate changed. The user's untracked roadmap remains outside this isolated commit.

## 2026-09-06 UTC — C3: qualified disposable Linux Docker host and audited OCI evidence

Continued the explicitly authorized WP6e continuation from 29dafb5668b125919a01779b1c8f168ad18332c1. Read the required frozen authorities, historical WP6e closeout and approved ORCH-AUTH-01 r2 transition package; reproduced C2's unchanged retained closeout (159 files/sixteen receipts) and freshly audited its input signatures/hashes. Approval remains settled but unactivated. Historical WP6e at e590e38 remains BLOCKED, with its unit-domain recording obligation satisfied without a unit-domain PASS.

Prepared eighty-two authenticated Ubuntu package inputs plus exact Node 24.18.0/pnpm 11.15.1, the pinned OCI image, public package-content store and default-policy metadata cache. No shared installation or codex.lab access occurred. A trusted task-owned coordinator launches QEMU as UID/GID 65534 in one bounded transient unit; actual cgroup/process/QMP/mount observations and six small real kernel faults establish the configured resource and filesystem/network limits. The guest receives read-only inputs, has no NIC or host directory/socket share, and runs its own Docker daemon. The fixed nonce-bound dispatch is limited to the unchanged OCI qualification. No source controller/state initialization or adoption occurred.

Fourteen host attempts failed and cleaned up before the successful fifteenth. Retained failures include cgroup namespace/masked-socket assumptions, unsupported userspace APIC, offline package/pnpm metadata/store setup, QEMU thread exhaustion and guest ENOSPC. Attempt fourteen was manually interrupted after preserving a hash-bound crash snapshot; a full disk prevented the guest error-file write and therefore its error message. Read-only offline diagnostics retain the Docker ENOSPC log. The repair uses a finite 16 GiB disk/17 GiB file ceiling, moves rather than duplicates the store, supervises the guest job in its own service and makes bounded heartbeat/error delivery independent of disk writes. Original OCI limits did not change. The matching-kernel explanation of PID zero remains an inference; full-cgroup disappearance is mandatory. Earlier missing executed-program snapshots are explicitly disclosed, not fabricated.

Successful run b5ae0551-b3eb-4a88-83c8-e5254332259c ran clean runtime source 29dafb5/tree 4a136e2bf740d32e15ad1f719b8ec123f30ff8f3 under legacy-source.v1. The bounded lifecycle took 370,642 ms; the original six-case OCI matrix took 44,361 ms and retained the normal child receipt/build/one raw fixture test. Independent host/OCI audits pass. A separate native Linux observer confirmed all fifteen guest directories/cgroups and captured process identities absent. Fresh provenance audit checked eighty-two packages and rehashed ninety-four declared files. Its first receipt attempt was rejected for declaring empty stderr; that attempt has no PASS receipt. Three actual altered copies were rejected by the real host auditor without a PASS receipt; these are retained-evidence tests, not candidate 5(a)/5(b).

Focused 37/37 and affected repository-tooling 128/128 tests pass. Final typecheck, lint, format and all five invariant entries pass (47,484 ms). Root pnpm build remains exit 2/NOT_READY without a receipt because productionBuild is absent. The real source candidate and its required mutation boundaries have not executed. A native Windows metadata follow-up records Windows 11 Pro build 26200 and absent checked Docker Desktop/QEMU paths; it grants no Windows/Server 2022 qualification or shared installation authorization.

The sealed archive at docs/runtime-qualification/ORCH-AUTH-01-C3/evidence/ contains 1,168 selected raw files/nineteen validated receipts. SHA256 91a368398226b631d8a739acebafa7c1dd6f2a521580b4866e1af97c017ac2b4; supporting source index 681f0a0d8af7b47a1a08ee936b99af18b86626e3. Fresh extraction and verify-closeout.ts passed at artifacts/wp6e-continuation-20260906/closeout-1/, reconstructing supporting trees and rerunning independent retained OCI/host/resource audits. This reproduces retained observations, not a fresh VM/signature execution. README.md provides exact post-commit reproduction and remaining acceptance rows. Commit identity is the scoped commit with subject "Qualify a disposable Docker host with audited OCI evidence" containing this entry; the post-commit command must run in a new output directory.

Continue compatible source/legacy readers and a consumed production build, the approved separately reviewed/recoverable authority transition, actual clean candidate/four partitions/raw identity coverage, committed 5(a)/5(b), and required exact new pushed-candidate five-job CI. Do not stop at C3 if the next necessary increment can proceed. Native Windows/Server 2022, full readiness and separate human acceptance stay incomplete; no WP6f interpretation. Original authorities, commissioning/amendment history and protected gates remain unchanged. The untracked roadmap stays outside commits at SHA256 53ea98fb1cb880163a02d3b1d9365963e3fe891025ae3630f00bd4c9232293b1.

## 2026-09-06 UTC — ORCH-AUTH-01-C2: bounded Ubuntu VM lifecycle and input provenance

Continued from C1 commit a649611ee7be1834b915c377b93d7d71c02a7028 after reading the required authorities, active plan and newest logs. Reproduced C1's unchanged curated closeout with Node 24.18.0/pnpm 11.15.1 against 174 raw files/fifteen receipts before editing. Its discovery-only and NOT_READY meanings remain unchanged, including the disclosed unintended codex.lab LXD installation. C2 did not access or modify that host.

Selected and documented one task-local unprivileged QEMU TCG lifecycle route. Verified Ubuntu signatures, signed package indexes and 29 package hashes before payload-only extraction; no host package install or maintainer script ran. The fixed 20260826 Ubuntu image hash is d0fe84bb5f80853425fa6be28e2c106f30104c3cfe8611933f2e65c9b63f0e30. The cached updates index is a signed historical selection, not a latest-patch claim. Newly selected tools/launchers were inspected as data first.

The final diagnostic guest ran in 212,508 ms with 1,024 MiB guest RAM, two vCPUs, no NIC or host directory/device passthrough, immutable base plus owned overlay/read-only seed, and bounded lifetime/output. Real QMP, native process and guest observations confirmed the configured VM, UID/capability/seccomp state, Ubuntu 24.04 userspace/kernel 6.8.0-138-generic, loopback-only networking and fresh nonce marker. QMP quit and owned cleanup completed; base/provider/package hashes and outside sentinel stayed equal. A separate Linux observer confirmed both pilot/final QEMU PIDs and guest directories absent. Six actual filesystem/launcher probes exercised success and safe refusals.

The first boot emitted through cloud-init's prefixed logger; the parser missed it and reached its deadline. This remains ERROR without a PASS receipt, with real cleanup evidence. The repair emits directly to ttyS0 during cloud-init bootcmd, before unrelated services; it does not claim service readiness or a workload speedup. Two preparation failures (package plus-sign path and dangling documentation link) lack retained raw stderr because stdout-only capture emitted no file. Explicit operator transcriptions and executed collector snapshots preserve that limitation. A curation attempt refused those missing files before their accurate classification. An initial focused test fixture also shared expected/reported objects; its one failing report remains retained and independent fixtures fixed it.

All 35 focused and 91 repository-tooling owner tests passed, preserving all existing 56 tests. Typecheck, lint, format and all five invariant entries passed with owned receipts; invariants took 56,802 ms. Root build remained exit 2 / NOT_READY without a PASS receipt. A real one-byte addition to copied serial evidence was rejected by the unchanged independent auditor without a PASS receipt.

The genuine tested index is 93f0fe82053ba95cd7fae79e10b2ae7cb2fbc772 on a649611. A separately inspected/extracted curated archive and closeout reconstructed that source, compared current implementation blobs, and validated 159 raw files/sixteen supporting receipts. Evidence and exact reproduction are in docs/runtime-qualification/ORCH-AUTH-01-C2/README.md and evidence/. Large input payloads remain outside Git; the curated audit checks retained signature-command observations and signed metadata mappings, not a fresh boot or signature execution. The separate support command actually rehashed live inputs and reran signatures. Later audit/reproduction records do not relabel the earlier dirty supporting executions as a clean candidate.

Record identity is the scoped commit with subject "Prove bounded Ubuntu VM lifecycle and input provenance" containing this entry. Native Windows options are documented from vendor sources and current executor code. No Docker-controller host, native Windows workflow or Server 2022 reference route is qualified. Guest resource settings alone are not host admission/resource enforcement. Root build, authority migration/activation, full source readiness and human acceptance remain unfinished. Source state/private refs remain absent, sealed authorities/gates unchanged, and the untracked roadmap retains SHA256 53ea98fb1cb880163a02d3b1d9365963e3fe891025ae3630f00bd4c9232293b1 outside the commit. Continue C with provisioned guest/OCI qualification before Docker-dependent controller dispatch; settled r2 approval remains unchanged.
## 2026-09-05 — ORCH-AUTH-01-C1: inspect qualification routes without launching discovered programs

Reproduced B's unchanged curated closeout from 13b013d with Node 24.18.0/pnpm
11.15.1 before editing. The fresh archive audit checked 430 frozen files,
94 archived tests, six OCI cases, 104 workflow files, 152 matrix files and
eleven supporting receipts. It remains archive inspection, not fresh C
workflow execution. The approved r2 digest and all sealed/live authorities,
locks, commissioned records, protected CI and package scripts remain unchanged.

Inspected native Windows, WSL Ubuntu and the previously recorded codex.lab SSH
route. No authorized disposable Docker-controller host or native Windows
workflow route was established. The WSL environment exposes /mnt/c and its KVM
device is inaccessible to this user; noninteractive group-switch privilege was
unavailable. The remote had no discovered Docker/QEMU/virsh executable or KVM
device. These are bounded observations, not a claim that all possible host
routes have been exhausted.

An intended read-only remote lxc version query unexpectedly invoked Ubuntu's
installer shim and installed LXD snap 5.21.7-1018661 revision 40585 (snap change 2,
23:35–23:36 UTC). The local probe was interrupted but installation completed;
the daemon was observed active and the probe processes ended. No instance or
controller was requested. No remote uninstall or state deletion was attempted.
This is an actual unintended configuration change, explicitly retained in
inspection/incident.json and corroborated by raw post-event script/package/
service observations. The original query description is labeled a transcription;
it is not fabricated raw output.

Selected and documented C1 before implementation: a standalone metadata-only
scanner and receipt-owning outer audit. It never invokes discovered launchers,
including version commands. It keeps the first candidate, refuses linked or
aliased paths before content reads, bounds PATH/candidate/prefix/report sizes,
and captures only the declared fixed-name search. The outer command selects
native route/platform and fresh source/run/nonce/scanner bindings, supervises
the real Node subprocess, separately pins the capture hash, and rechecks retained
bytes. It grants neither host authorization nor provider/workflow qualification.

Final Windows/WSL/SSH discovery took 414/5,114/428 ms respectively, one scanner
per dispatch. All three audited observations remain NOT_READY. WSL process
identity is Linux. Initial observations with the over-specific linked-path label
are retained; the final linked-or-aliased-path label and fresh recaptures avoid
misstating native Windows canonical-case differences as symlinks.

All 40 focused regressions passed, including a real installer-shaped script
whose marker remained absent. The full affected repository-tooling partition
passed all 56 tests across both owner files. Its first attempt failed before
testing because Git tree identity was unavailable during concurrent checks.
The serial rerun passed without code or gate changes; index-lock contention is
an inference, not a proven root cause because that helper omitted subprocess
stderr. Typecheck, lint, format and five invariant entries passed with receipts
(the invariant aggregate took 61,254 ms). Root build remains exit 2 / NOT_READY
with no PASS receipt. No OCI/candidate execution policy changed or container ran.

The genuine tested index is 822426b10089f90ae6fcbe397a322914ec97b757 on 13b013d.
Its binary patch and executable identities are retained. C1's closeout reconstructs
that tree in a separate bare database, checks current executable blobs, preserved
authorities, 174 raw files and fifteen supporting receipts. A one-byte mutation
of the retained remote report was rejected with no PASS receipt. Reproduction,
actual incident/failed attempts, supported Windows route limits and exact
arguments are in docs/runtime-qualification/ORCH-AUTH-01-C/README.md and its
curated evidence. The final commit adds records to the tested implementation;
these dirty-tree supporting results are not exact source readiness.

Record identity is the scoped commit containing this entry and the C1 plan.
Source controller state/private refs remain uninitialized and unadopted; the
user roadmap is unchanged and excluded. General host qualification, native
Windows workflows, root production build, migration/activation, full source
readiness and live human acceptance remain incomplete. Continue C with a bounded
disposable-host lifecycle/provenance route before Docker-controller dispatch;
do not treat the new LXD installation as qualified infrastructure.

## 2026-09-05 — ORCH-AUTH-01-B: qualify public planning and authenticated evidence delivery

Continued from e01298b after reproducing A's closeout audit. The approved r2
normative digest remains unchanged; the user authorized this increment with
“Begin”. Planning needs no Docker control plane, so both disposable controller
copies ran inside the real restricted Linux OCI executor. The public plan --json
dispatch and production SDK gateway adapter admitted one tooling proposal and
rejected a schema-valid PROJECT_GOAL.md proposal on both bounded attempts,
recording PROTECTED_SCOPE and PLANNER_POLICY_LIMIT. The deterministic transport
supplied responses only. Actual state, policy decisions, role observations and
run summaries were retained; no worker, target change or source state adoption
occurred.

The new input channel binds purpose, coordinator/run/nonce, source, authority,
fixture, cases, platform and independently obtained provider/producer identity.
The outer coordinator pins its digest outside delivered artifacts. The optional
mount has one fixed read-only destination and bounded regular-file inventory;
the existing four-mount path and all resource/privilege limits remain intact.
The local runner refuses the input. A separate real container validated actual
producer receipts and observations, owned its consumer receipt, and received
EROFS on an attempted input write. Outer and transferred-archive audits repeated
the checks. Both containers, exporters and their bounded volumes were removed.

The final tested source is genuine disposable commit
ae4e4fe5950d0a4711aadcf957bdb75479895911, tree
0e81e7d8236d34c6982f363c9fb6a2bf7d45f5de. Its patch and Git bundle are retained.
Producer/consumer duration was 16,494/10,268 ms. Independent archive inspection
verified 104 files; envelope SHA256 is
2f4c885e6fda2bb0c0c1b97405f20d9280399b5682a81732d90a06758310a1d8.
The unchanged complete OCI matrix passed on that same source in 37,707 ms:
normal/boundary PASS; artifact-link/quota/output-flood ERROR; hang TIMEOUT.
The unchanged A auditor verified its raw normal build/Vitest evidence, policies
and cleanup against the 152-file combined archive. Both workflows and the matrix
reused image sha256:e405e2790e743243dd669f8e58eeaff6c585df3cbc77e9a4316a7f07b4e2eaad
with tracked input hash 0392ec049d9c168fdefb9ab22fe38f9127953639aa96701a6369fa10ed9556a3;
zero image builds occurred.

The first functional producer/consumer passed in 8,451/6,031 ms, but its audit
inventory included still-open stdout. Its refusal is preserved; finalized-root
inventory replaced that defect and a fresh producer/consumer supplied the final
evidence. Initial lint (unused variable) and invariant ownership ordering failures
were corrected and rerun. Command-owned evidence now passes 94 focused tests,
typecheck, lint, format and all five invariant entries (66,029 ms). An actual
one-byte transferred producer-report mutation was refused without a PASS receipt.
The root build remains exit 2 / NOT_READY because its production-build contract
is undeclared. No full owner floor, candidate tier, source readiness or CI run
was claimed by these focused supporting checks.

Reproduction and archive seals are in
docs/runtime-qualification/ORCH-AUTH-01-B/README.md and evidence/manifest.json.
The closeout validator compares the bundled tested source with current executable
blobs, preserves frozen authority and revalidates raw artifacts, owned receipts
and remaining NOT_READY/refusal outcomes. Later closeout files are record-only.
Record identity is the commit containing this entry and the completed B plan.

Native Windows discovery remains NOT_READY, with no discovered Docker/VM command
among inspected providers; no host configuration changed. A general disposable
host for controllers that launch Docker remains unqualified. Next is
ORCH-AUTH-01-C host/native Windows feasibility before run/integration expansion.
Authority reader/migration work, bounded target/build, activation, complete native
coverage and the live human gate remain incomplete. Source private refs remain
absent and the untracked user roadmap is unchanged and excluded.

## 2026-09-05 — ORCH-AUTH-01-A: qualify the local Linux OCI runtime and retain raw evidence

Continued the approved r2 handoff from 2ec1d25. Exact Node/pnpm reproduced the
committed handoff audit (98 files/five historical receipts) and the fresh
13-check protected-integrity receipt. A standalone Linux clone at
/home/duncan/oa1-CKn8x9/src uses task-local Node 24.18.0 and pnpm 11.15.1,
frozen root dependencies and a separately hydrated exact OCI fixture store.
Docker 29.1.3 was neither replaced nor reconfigured. Initial installer failure
selected pnpm.cjs rather than the package-declared pnpm.mjs; the corrected
launcher and persistent Linux task directory retain the actual setup records.

The unchanged six-case OCI matrix reached every expected outcome, but the
independent audit reproduced missing raw build/Vitest reports after temporary
candidate cleanup. The narrow repair retains exported workspace evidence with
the existing bounded publisher, compares its complete size/hash inventory to
the actual executor record, and verifies the retained copy before cleanup.
Three regressions cover post-cleanup persistence, missing reports and tampering.
No case, fixture, policy, image recipe, limit or source authority was weakened.

The repaired complete matrix passed at the real frozen source tree
73050cad83ec0f312498792c47bd55bff5bea060 on HEAD 2ec1d25. Its source.patch is
retained for exact reconstruction. Normal/boundary passed; artifact link,
quota and output flood returned their expected ERRORs; the evidenced stubborn
descendant timed out and was removed. All six containment reports, normal
command receipt, raw build and Vitest artifacts, effective policy and separate
zero-survivor observations passed independent inspection. A one-byte mutation
of the retained Vitest report was rejected without a PASS receipt.

The curated raw archives, successful runtime receipt/report and receipt-owning
closeout are under docs/runtime-qualification/ORCH-AUTH-01-A/evidence/;
README.md and audit-runtime.ts document and reproduce the claim. Development
originals remain under artifacts/orch-auth-01-a/. Matrix runs took 44,259 and
52,863 ms, reused immutable image e405e279...e2eaad and performed zero image
builds or hosted dispatches. The first run remains incomplete for raw evidence;
the second qualifies this local Linux runtime only. Later record paths differ
from the tested tree; production source/test bytes remain identical to it.

All 24 focused tests passed. The invariant aggregate and its five entries,
typecheck, lint and format passed with independently validated receipts.
pnpm build returned exit 2 / NOT_READY because the unchanged live legacy
package has no productionBuild declaration; no source build or readiness pass
is asserted. Full candidate owner coverage, native Windows qualification,
isolated qualification-host suitability, authenticated evidence delivery,
source migration, live human acceptance and state adoption remain incomplete.
The next bounded increment must inspect and prove one public workflow with a
correct rejection and trusted handoff; inspect Windows feasibility early.

Commit identity: the scoped commit containing this entry, discoverable through
git log. The roadmap, sealed approval packages, prior log bytes, active
authority/lock/commissioning/ledger, readiness marker, scripts and protected CI
remain preserved. No source controller state or private refs were initialized.


## 2026-09-05 — ORCH-AUTH-01 r2 approved; fresh-session handoff prepared

The maintainer's direct “Proposal approved.” message authorizes ORCH-AUTH-01
r2 at normative digest
`53d38a2c2038cd9c5ffc240275043709d23dd33a81237e3d12018a38a8378108`.
The separate transcription is
`evals/authority-revisions/ORCH-AUTH-01/approval.json`; the sealed r1/r2
proposal packages retain all original review bytes and preparation status.
Approval is settled for that unchanged scope. It is neither live product
acceptance nor automatic authority activation or state adoption.

The user then asked about a fresh session. The living plan now specifies the
first bounded WSL runtime qualification increment; the byte-exact prior
WP6e plan is retained at `.agent/history/wp6e-e590e38.md`. The resume guide is
`docs/authority-handoffs/ORCH-AUTH-01/README.md`. The package-specific Git
binary attributes preserve sealed bytes and prevent automatic text merging.
The first import audit retained whitespace diagnostics confined to those
already-sealed payloads; their literal diff context, blank lines and CRLF
inventory remain intact. Editable files keep normal text checks and
executable/source rules are untouched.

Preparation-state proposal recheck passed all thirteen groups at
`docs/proposals/ORCH-AUTH-01-r2/audit/run-20260905203403713-21436/` before
recording the separate approval. The new handoff audit validates the actual
staged/committed file inventory, approved digest, five retained proposal
receipts and unchanged live execution/authority bytes. Fresh receipts are
under `artifacts/orch-auth-01-handoff/`. The staged audit passed at
`run-20260905204508347-7576/result.json`; the production contract-integrity
command passed all thirteen checks and its independently validated evidence
is committed under `docs/authority-handoffs/ORCH-AUTH-01/evidence/contract-integrity/`.
Recheck the final staged inventory before commit and the committed identity
afterward. No broad product or CI suite is
required for this record-only checkpoint, and none is claimed. The exact
checkpoint identity is in Git history and its final document-audit receipt.

Read-only WSL preflight confirmed Docker Engine 29.1.3 accessible to UID 1000
through root:docker socket 0660. Linux Node is absent and the discovered pnpm
path is Windows-hosted. No installation, Docker reconfiguration, pinned-image
build or OCI matrix was run. The next session must qualify the real Linux
fixture and preserve its distinction from native Windows evidence.

WP6e's e590e38 final closeout is already retained at
`artifacts/wp6e-amendment-dev/final-closeout/`: all five activation CI jobs
passed (run 33951754449), with independently validated artifacts; actual
candidate and 5(a)/(b) tier boundaries remain unresolved. The prior plan's
pending hosted wording is historical. This approved source transition does
not retroactively complete WP6e or permit WP6f interpretation. All prior logs,
frozen live files, commissioning history and user roadmap remain intact.

## 2026-09-05 — WP6e active generation verified; final execution gates pending

The corrected v2 application remains the actual tool-owned publication from
clean `b03a6cd`, with ledger entry
`4fbdbb3528043e35d6859fa9846da5d38d039249a162ca8a698b33c04e6f3c74`. The
first complete active-generation run exposed 14 historical fixture-policy
mismatches (756/770 passed). The original failed source clone remains at
`/tmp/e6v-yLhrvj`; its retained diagnostic archive is
`artifacts/wp6e-amendment-dev/active-generation-fixture-failure.tar.gz`,
SHA256 `63db41c40ecbf4d8570b315fe4c8998ff10f14ce677135c7938cb8cf33ecf53c`.

Only historical/generic test setup now loads the original committed v1
policy through the commissioning anchor. The active-source fixture still
loads the live manifest and policy together. Every test assertion and
identity is preserved; production mixed-generation rejection is unchanged.
All 55 focused affected-scope, benchmark, tier, and source-schedule tests
passed.

On Linux `/tmp/e6w-9YTJJg`, exact Node 24.18.0/pnpm 11.15.1 passed
typecheck, lint, format, all five invariants, all 770 orchestrator tests,
all 786 root tests, and diff checking. Independently validated evidence is
exported to `C:/w/wp6e-active-linux-evidence.zip`; the workspace audit at
`artifacts/wp6e-amendment-dev/active-precommit-audit/` verifies twelve
receipts, every artifact, the source bytes, all prior 786 identities, the
actual amendment and Doctor, immutable files/scripts/owner order, and log
history. This fixture repair adds or removes no test identity.

Protected run `33944911461` passed all five jobs on `4338f47`.
`artifacts/wp6e-amendment-dev/compatible-hosted-audit/` independently
validated all archive digests and 43 command receipts, including real Docker
containment. Repair `b03a6cd` was then pushed; its separate protected run is
`33948310909`. Do not push this activation before those five jobs pass.

The coherent activation commit, clean after-state
shadow/unit-domain/mutation executions, final-head historical statistics
validation, and the activation's own five-job hosted gate remain post-commit
work. The inherited unavailable trusted runtime, project placeholders, and
absent production build remain full-candidate prerequisites. WP6e is not
complete and no readiness or performance benefit is claimed.

## 2026-09-04 — WP6e corrected source generation applied and format-verified

The compatible repair was committed locally as
`b03a6cd6ff5eef0dc571bc6d606b6a30c80ed184` (tree
`ac2e0f8759285842c08085652bdff15325639ad4`). Its complete local verification
and independent audit are recorded in the preceding entry. Its push waits
for protected run `33944911461` on `4338f47` to finish, preventing workflow
cancellation. Every pushed candidate still requires all five exact-runtime
jobs and independent artifact validation.

Clean Windows clone `C:/w/e6-b` captured all three before-state contexts,
then executed
`pnpm loop:commission:amend -- --descriptor tools/milestone-orchestrator/config/wp6e-partition-amendment.json`
using Node 24.18.0 and pnpm 11.15.1. The operation passed and generated the
input, policy, manifest, and ledger as one recoverable publication. Evidence
is under `artifacts/wp6e-amendment/`; entry SHA-256 is
`4fbdbb3528043e35d6859fa9846da5d38d039249a162ca8a698b33c04e6f3c74` and
ledger SHA-256 is
`a11322a36258c821a80c24f112e7d2a76abfcf522122cb92b6d3392e62f0fc11`.

The independent `artifacts/wp6e-application-audit.ts C:/w/e6-a` procedure
validated the actual operation receipt, live generation, Git anchor/chain,
commissioning Doctor PASS, and all twelve identical-context plan
comparisons. It also revalidated the already-executed historical CLI
receipts from `C:/w/e6-a`; this does not claim a new historical invocation
on `b03a6cd`. Its receipt is under `artifacts/wp6e-application-audit/`. The
unchanged `pnpm format:check` passed the actual generated files at
`artifacts/wp6e-application-format/`. The preserved first failed generation
in `C:/w/e6-a` was not edited or reused as this candidate.

README, CONTRACT, and the configuration guide now describe the active source
schedule, legacy diagnostics, formatter-compatible committed requests,
semantic no-op rejection, recovery/reversal, and partition deadline. Full
Doctor output at `artifacts/doctor-after.log` remains blocked on the dirty
publication plus the inherited build/placeholders/runtime prerequisites. The
complete active-generation precommit cohort, coherent commit, clean
candidate/unit-domain/shadow/mutation evidence, final-head historical CLI
validation, and hosted after-state gates remain pending. WP6e is incomplete.

## 2026-09-04 — WP6e active-generation format regression and repair

Compatible commit `4338f47c8c7abbdc02ac96725c121742bce8c4e3` (tree
`0b5ff97bfa731c0bc02b571843e998144308e4cd`) was pushed normally. Protected
run `33944911461` has passed Linux controller, both adopter jobs, and Docker;
the Windows controller remains pending at this record.

In clean exact-runtime Windows clone `C:/w/e6-a`, both retained WP6d platform
records passed `loop:measurement-statistics --validate-existing`. Receipts
are under `artifacts/wp6e-historical-{linux,windows}/`, and copied statistics
are byte-identical to the retained independent matrix records. The real
committed descriptor application then passed at `artifacts/wp6e-amendment/`,
producing commissioning Doctor PASS and ledger entry
`a07fcd351a5e521b288eb5ccc2db832a742818173f1d6458fb7dc136aa0ae5f3`.
The independent `artifacts/wp6e-application-audit.ts` procedure validated
that receipt, complete generation, historical receipts, and all twelve
same-context tier projections; its receipt is under
`artifacts/wp6e-application-audit/`. These results remain application
evidence only, and the generation has not been committed.

The Linux copy `/tmp/e6a-Ymzn2r` passed typecheck and lint but failed the
unchanged format command on generated input/policy JSON. Evidence is retained
at `artifacts/broad2/f2.log`, `artifacts/f2/`, and the original source
snapshot `C:/w/e6-a/artifacts/active-source.{json,tar}`. Both files used
valid expanded JSON arrays that the existing formatter would compact. No
active files were manually repaired and no failed generation was published.

A new full-file regression reproduced the defect by applying formatter-valid
descriptor text; the pre-fix run failed at the original byte-only v2 predicate
under `/tmp/e6a-Ymzn2r/artifacts/fr/`. The repair formats proposed descriptor
text with the existing pinned formatter and validates all parsed v2 fields
against the exact reviewed transformation. Descriptor/ledger hashes still
bind every actual byte; canonical manifest output and byte-exact v1 reversal
remain required. This does not permit a field, schedule, policy, or provenance
change. Focused and complete broad verification of the repair are pending.
The source checkout remains valid v1. The preserved failed clone is diagnostic
evidence; a subsequent application must start from a new clean repair commit.

The formatting-only request regression initially reproduced an incorrect
successful amendment (36 passed / 1 failed) under
`/tmp/e6a-Ymzn2r/artifacts/fnr/`. The first attempted guard still compared
the parsed result's raw-generation wrapper; snapshot 7's full orchestrator
run retained that one failure (769/770 passed) at
`/tmp/e6g-9O7vuV/artifacts/o2/`. The guard now compares only parsed input,
policy, and manifest fields in both publication and ledger validation.
Failure archives remain under `artifacts/wp6e-amendment-dev/`, including
`format-noop-guard-failure.tar.gz` (SHA-256
`76e5194c5647b43a1fdafdb3a37ec3eeabe55b9bc916cbb921fbd44a173798f9`).

Final source snapshot 8 passed all 58 focused cases and the complete six-command
Linux cohort at `/tmp/e6h-9w91Pt`: typecheck, lint, format, all five invariants,
770 orchestrator tests, 786 unit tests, and diff checks. The focused receipt
SHA-256 is
`8909a1b21328bff9213b3430c45e6c4c840efc5e2d62cda32121bf1f44a28a28`.
The independent source/artifact audit is
`artifacts/wp6e-amendment-dev/repair-precommit-audit/evidence-audit.json`;
it validates all 11 broad/child receipts plus the focused receipt, preserves
all 784 compatible-checkpoint identities, classifies the two new controller
regressions, and verifies every protected surface and committed log history.
Archive `C:/w/wp6e-repair-linux-evidence.zip` SHA-256 is
`1d5d73fc625ee8cb1bfaa61355df824f5402a84327eb3309936578389f4aacf7`.
This is verified compatible-v1 development evidence, with completion
eligibility false. Commit the repair before a fresh source amendment; retain
all five exact-runtime gates for every pushed candidate. WP6e remains open.

## 2026-09-04 — WP6e compatible amendment implementation under verification

The projection checkpoint's retained post-commit closeout is complete at
`da8f6c93450dca352895722b6b40c72193b0c2d7`. Its Windows retry passed 727 unit
cases, and hosted run `33938071620` passed all five jobs. The receipt and
independent audits remain under `artifacts/wp6e-entry-20260904/closeout/`,
`windows-final-audit-2/`, and `hosted-record-audit/`.

The compatible amendment implementation adds the committed-descriptor CLI,
Git-anchored generation ledger, recoverable publication, v1/v2 schedule and
policy support, guarded partition subsumption, and command-bound timeouts.
The prepared descriptor is
`tools/milestone-orchestrator/config/wp6e-partition-amendment.json`; preparation
has left all three active v1 files unchanged. New regression files are
classified under the existing controller owner. Existing package scripts,
the exact-runtime workflow, frozen authorities, and measurement identities
remain unchanged; `loop:commission:amend` is additive.

Exact-runtime Linux focused run 1 passed 95 cases at
`/tmp/wp6e-amend-URWNk0/c/artifacts/f1/`. Run 2 passed 192 of 193 cases and
failed the generated-adopter lint boundary: unsafe-finally and unused-variable
defects in the new modules. Those defects were repaired without changing the
test. Run 3 passed all 195 cases across eleven complete test files, including
the generated-adopter typecheck/lint boundary. Its independently validated
command-owned receipt SHA-256 is
`a5762460c23bd73a6d38347fb800e09d8f644da002b1a12c44de18223e49ecc1`
at `/tmp/wp6e-amend-URWNk0/c/artifacts/f3/result.json`. Procedures and source
snapshots are under `artifacts/wp6e-amendment-dev/`; failed runs remain retained.
Local exact-runtime lint also passed at `artifacts/wp6e-amendment-dev/lint-2/`.
The expanded source snapshot 5 focused run passed 236/236 cases, including
staged-file crash recovery, ownership, partition, and benchmark regressions.
The first broad invariant run exposed a noncanonical ownership file order;
the sorted catalogue correction retained all owners and files. Failed source
snapshots and reports remain available.

The corrected complete Linux cohort at `/tmp/e6i-oq5WCU/artifacts/broad2/`
passed typecheck, lint, format, all five invariants, 768 orchestrator tests,
784 unit tests, and diff checks. The source snapshot and artifact export
are independently validated by
`artifacts/wp6e-amendment-dev/precommit-audit/evidence-audit.json` and its
command-owned receipt. Export archive
`C:/w/wp6e-compatible-linux-evidence.zip` SHA-256:
`8afd1598ca8fbb629235d0124df8629b9262f75f7dc1f6e83d1e2cf47a8fd66e`.
The audit validates all 11 broad/child receipts and artifacts, preserves the
previous 727 test identities, and enumerates 57 controller-owned additions.
It also verifies frozen files, every existing script, original log history,
unchanged active v1 generation, and commissioning Doctor PASS. This is dirty
development evidence with completion eligibility false. Commit/hosted
evidence, historical CLI revalidation, and actual amendment application remain
subsequent work. WP6e is not closed by this record.

## 2026-09-04 — WP6e projection hosted checkpoint and remaining verification gaps

**Committed checkpoint.** `2a6e49828dbb29e59addcc1889342245dc42bb3f`, tree
`47825d47f1fffa5925bb2d032557c5fbcb7a78cc`, was pushed normally. Exact-runtime
CI run `https://github.com/mclaurin10/milestone-loop-template/actions/runs/33934052224`
passed all five jobs. Both platform controllers passed all 727 unit and 711
orchestrator cases. Independent hosted verification is retained in
`artifacts/wp6e-entry-20260904/hosted-audit/`, produced by
`audit-hosted-evidence.ts` over `C:/w/wp6e-ci-33934052224`. It checks full
run/job/artifact metadata, five archive digests, 22 controller receipts, 20
generated-adopter receipts and browser proofs, and a real Docker fixture
receipt plus all six containment cases. The archive SHA-256 values are:

- controller Linux: `f74283042d079ba29e1051150002ad8ccc0bd58837e25be8b99c75935077e911`
- controller Windows: `94598fd1068a870b4a01ebe438f86eeec9558a7d17f3c69022df9056d167a568`
- adopter Linux: `53e68b645cd00c6e0c1b9429c0172549b83228a1aa4c2b6779ed40ad80cd94a3`
- adopter Windows: `5399f9f49a1506f1bf104436d9a17f2020eecf7105088df4b5b95a92d024c4bc`
- trusted container: `bc59b66e7d2bbc1dfca087c324b568312bc1ff3f902ae711b26e8a91e451d09e`

**Retained local failure.** The serial `C:/w/wp6e-p-unit-3` full unit command
exited 1 with 726/727 passing and no pending cases. Its worked-example
cross-link drift case failed at the unchanged five-second limit with
Vitest's generic `STACK_TRACE_ERROR`. The test and production validator are
byte-identical to baseline. The complete ten-case file then passed in both
baseline and current clones using the production measurement probe and
unchanged deadlines. Both diagnostic receipts were independently validated;
the procedure is `artifacts/wp6e-entry-20260904/diagnose-worked-example.ts`.
This suggests a transient timeout but does not establish its cause or turn
the failed full attempt into a pass. A fresh, clean `2a6e498` full-unit retry
is pending in `C:/w/wp6e-p-unit-4`; its recorded procedure is
`run-windows-unit-4.ps1`. The final Windows audit must consume that complete
result and retain prior failed and invalid-receipt attempts separately.

**Historical CLI compatibility.** Both prescribed historical statistics
revalidation commands were executed from clean exact-runtime `2a6e498` at
`C:/w/wp6e-stats-1` and exited 1 with
`Measurement matrix candidate differs from expectation.` The original
records identify `93e03e2`; `measurement-statistics-cli.ts` instead supplies
the caller's current commit to the production validator. Logs, exit records,
and ERROR manifests are retained under that clone's
`artifacts/wp6d-revalidation-{linux,windows}*`. The procedure is
`artifacts/wp6e-entry-20260904/run-historical-revalidation.ps1`. An earlier
shell attempt could not open its output log because the artifacts directory
did not yet exist, so it did not invoke either validation command. No
historical record or measurement implementation was changed. The active
plan now carries this reproduced compatibility gap as unresolved.

**Handoff.** The projection has a passing hosted checkpoint, while amendment,
recovery, v2 support, recomposition, and remaining acceptance stay open. The
updated records will be committed with unchanged executable bytes; the
active plan assigns final exact-record-commit CI, the Windows retry audit,
and a completion-ineligible closeout receipt to post-commit verification.
No performance or readiness claim is made.

## 2026-09-04 — WP6e baseline pinned and ordered schedule projection verified

**Outcome.** The first bounded Step 1 increment exposes the production
planner's ordered check IDs, argv, and expected artifact kinds through
commissioning Doctor v2 and lifecycle Status. A strict versioned projection
schema and runtime validator preserve focused-count and exact-closure
semantics. Canonical comparisons retain array order and omit candidate,
timestamp, and policy metadata. Generated adopters receive the schema through
the existing runtime-file allowlist. Nineteen new regression identities are
classified under the existing controller owner; exact catalogue file-count
assertions now include that file. The active v1 input, policy, manifest,
package scripts, execution rules, protected workflow, measurement identities,
and frozen authorities are unchanged. No amendment or schedule transition is
implemented, and no performance benefit or readiness is claimed.

**Baseline.** Clean `ac4e9a2f43049d446356c2bc00b3f395df33e5b6` executions on
`codex.lab` at `/tmp/wp6e-yVASGa/b` passed invariants, the complete partition
shadow, and an independent inventory audit. Root-unit discovery matches the
executed fast/migration union of 708 identities; this is not a separate
baseline `test:unit` invocation. Candidate-before contains 1,368 executions,
708 unique identities, and 660 duplicated identities. The four disjoint
owners cover 709 identities; the sole extra is the OCI fixture case. Every
one of the 18 mandatory/workspace replacement rows retains its prior
coverage; the two fast-only direct rows add the 32 migration identities.
All four production tier plans were captured in three distinct changed-path
contexts. Windows/Linux baseline planner projections match for each context.

The verified baseline export is at `C:/w/wp6e-linux-baseline-evidence`, with
ZIP SHA-256
`2f6e9ee93ae66b76f4e9dbdecf39bd39c749a474e42e0136d74f8c56e0b5e367`.
Its inventory artifact SHA-256 is
`b0a55f87500620728475238ae22a54bf70153af9f83bcd1af29faf250d33e16a`.
The plan retains the exact procedures, failed attempts, and archive mappings.
Windows baseline shadow failed ten cases under a long artifact root; one
retained Git ref independently reproduced a 266-character path limitation.
The first Linux shadow failed before its final fixture because its Unix
socket path was too long. A shorter-path Linux run passed unchanged commands,
tests, Git defaults, and limits. The duplicate Windows baseline retry was
stopped and remains incomplete. None of those earlier runs is a shadow PASS.

**Verification.** Node `24.18.0` and pnpm `11.15.1` were used throughout.
The complete precommit cohort in `/tmp/wp6e-yVASGa/p` passed `pnpm typecheck`,
`pnpm lint`, `pnpm format:check`, `pnpm test:invariants`,
`pnpm test:orchestrator`, `pnpm test:unit`, and `git diff --check`, with
command-owned receipts. Source fingerprints stayed unchanged. The exported
101-file evidence bundle at `C:/w/wp6e-linux-projection-evidence` has ZIP
SHA-256 `183d13f7632df5016ca8ea2e34e8e8135bf80af8ab6e0ae9ae8f325657d3b387`.
The retained runner/export procedures are in
`artifacts/wp6e-entry-20260904/`.

Independent audit `audit-linux-precommit-evidence-2.ts` passed, with its
receipt at `artifacts/wp6e-entry-20260904/linux-precommit-audit-2/result.json`.
It revalidated the 11 Linux command/child receipts and their artifacts,
15 executable/schema/catalogue/test source hashes, 727 full-unit identities,
711 orchestrator identities, all baseline identities plus exactly 19 new
tests, all 12 same-context command projections, 23 protected files, and
preserved log history. It independently revalidated the imported baseline
receipts/reports and the real CLI projection evidence. Actual `pnpm
loop:doctor` and `pnpm loop:status` at `C:/w/wp6e-p-typecheck-4` expose the
same four projections and leave working-tree status unchanged; their valid
receipt and full reports are in `artifacts/cli/`. Doctor remains `blocked`.

Windows static checks and invariants also passed in separate short clones.
The serial orchestrator run at `C:/w/wp6e-p-orchestrator-3` passed 711/711
tests; its receipt and exact identity equality with Linux were independently
validated by the precommit audit. The serial full unit run at
`C:/w/wp6e-p-unit-3` is the remaining local Windows execution at this record.
All broad failures and superseded runs remain retained. Earlier concurrent
orchestrator/unit runs each failed four cases beyond their original limits
and a stale ownership-count assertion; the count assertion was repaired,
and the complete serial orchestrator now passes with limits unchanged.

The earlier five-case diagnostic observed five passing cases, but its receipt
declared a zero-byte stderr artifact and is invalid. The first independent
Linux audit caught that defect and failed; both that procedure/output and
the malformed diagnostic receipt remain intact. The successor audit
explicitly rejects it and uses the valid complete Windows orchestrator
receipt instead. No empty log was padded, no retained receipt was edited,
and no filtered-out case was counted as passing. The initial projection
schema parity failure was fixed by implementing strict positional/tail
`prefixItems` support in the test-only evaluator; subsequent broad suites
exercise those regressions and the adopter packaging assertions.

**Checkpoint and next gate.** Prepare the cohesive commit titled
`Expose ordered verification schedule projections`; its exact identity is
available from Git history. Require all five jobs of the protected exact-
runtime workflow on that pushed commit, then independently audit the
downloaded archive digests, receipts, raw reports, generated bootstrap
browser proof, and real Docker outcomes. The prepared hosted audit is
`artifacts/wp6e-entry-20260904/audit-hosted-evidence.ts`. Finish and audit the
remaining serial Windows run without reusing failed evidence. Preserve the
untracked roadmap and initial plan/log history. Then continue Step 1's
descriptor, anchored audit chain, and recoverable publication; Steps 2–7
remain open. Inherited dependencies/architecture placeholders, missing
production-build configuration, and the local trusted-provider gap still
prevent full-candidate/readiness acceptance and remain non-passing.


## 2026-09-04 — WP6e approval recorded and execution plan revised

**Outcome.** The maintainer approved the reviewed Step 0 recommendation.
The plan now records the decision, removes the routine-confirmation pause,
and specifies five requirements before the schedule can change: a scoped
65-minute partition timeout; a compatible v1/v2 descriptor/publication
transition; an anchored amendment chain covering input, policy, and manifest;
explicit per-trigger/workspace scope mappings; and planner/runner enforcement
of the invariant prerequisite. The decision log records the rationale and
supersedes the earlier lack of an amendment path without rewriting history.
This completes the documentation revision, not WP6e implementation or its
baseline evidence pin.

**Inspection.** Read `PROJECT_GOAL.md`, `AGENTS.md`, `.agent/PLANS.md`, the
active plan, recent logs, and the affected commissioning, planner, selector,
package, and verifier definitions. `git status --short --branch` showed
`master` at `ac4e9a2f43049d446356c2bc00b3f395df33e5b6` (tree
`db1da52cdf388bd3aadd90b975bf157bb37cbea8`), with the draft plan already
modified and the protected roadmap untracked. `Get-FileHash -Algorithm
SHA256` confirmed the immutable lock, exact-runtime workflow, and protected
roadmap remain at their recorded hashes ending `33050`, `19bf`, and `93b1`.
No hosted state was refreshed and no retained performance record was
reinterpreted.

Inspection found additional evidence requirements: doctor currently returns
tier counts without the ordered IDs needed for an exact diff; broad selector
logic still adds `test-unit`; and final test counts must account for newly
added regressions. The plan now captures these explicitly. It also records
the inherited dependencies/architecture placeholders, absent production-build
declaration, and the actual `unit-domain` stage's additional `test:domain`
requirement as execution gaps, not passing verification.

**Verification and remaining work.** `git diff --check` passed. A read-only
`node -e` audit compared the prior log headers and full historical bodies
against `git show HEAD:<path>` and proved all pre-existing bytes unchanged;
it also rechecked the three protected SHA-256 values and limited tracked
changes to the plan and these two logs. No product tests, baseline clone
executions, amendment, or new CI run occurred in this documentation increment.
Changes are uncommitted. Next: preflight
the candidate prerequisites and pin Step 0 planner/ownership/shadow evidence
from a clean clone, then begin compatible amendment infrastructure. Steps
1–7 and every WP6e execution acceptance criterion remain open.

## 2026-08-31 — WP6d hosted matrix completed and independently reproduced

**Outcome.** Test-only repair commit
`93e03e2ff28d295f38590b7723d5d6b1460eae07`, tree
`e421903de5505dee20fd59dde487a031511c209b`, is pushed to `origin/master`.
Exact-runtime run `33397675209` passed Windows/Linux controllers, both
fresh-adopter smokes, and trusted-container execution. Downloaded evidence at
`C:/w/wp6d-ci-33397675209` independently matched 42 PASS manifests, 62
declared artifacts, exact clean candidate identity, both 203-suite/692-test
orchestrator reports, both 205-suite/708-test unit reports, and all expected
adopter/container boundaries. Controller Windows/Linux, adopter
Windows/Linux, and trusted-container GitHub artifact digests are respectively
`ee172554ab4b49ea3c06d00f7598cbd25b66ba03e31efd33555ecc648620090b`,
`fb9b018091e66ac63bce8954f28d2d5164737f94e3793d9bbd968638376ccbfe`,
`6ecfdfc73047c7897755e5fdfc2069f031da97ce06b49596b149c6c09f30e75d`,
`29f2a174f157fbdf13ed594913350e9a26b1aa1d6fe6881d88949173fe74be91`,
and
`bd1747fcd35287752d9a6cf79ba7fc4f432ecf635b5942f8d287fdd3980c8b03`.

**Hosted matrix.** Manual run `33402460152` passed all ten pair jobs and both
statistics jobs. It retains exactly five cold and five immediately paired warm
lane records per platform on the same candidate. Linux pair archive digests
for ordinals 1-5 are
`c4bfa40e4f3709d77929bc6d4f51e337a071093412c62dc3b8ee6eeecc63a33d`,
`cab7477e16a3b49916582b369e8354fc55a31eda27ab3a296f9c0322dc06ab35`,
`762c0132a59686af9a1aed57d9fc692533fab0b4f14bc8e8ad489f1e4c4505f7`,
`95a965bde4244cb176dc54ff9eedad9c97181f5a2a82f327f1848845ad35f9e1`,
and
`d538392d5b8571d04eeed8a6d8072b10e05948af7bddb4061ce38dc6a0eb20c2`.
Windows ordinal 1-5 digests are
`01bb40e1ffefe2fed3eba29e165b9e12aecba2d64a2c6bc9a560378ea2954b25`,
`7b451aeeff2256f0cc08881cfd1847414273ca5c48901c0c656858b663816536`,
`bb2ae0e2706e4cff8fd3b5238a166f2670aab1860bc85bb3c617ec55d532e824`,
`896469abda556da9ab577a774fe9e9f6f72247fbbfc7d8710512e52a4e7294a2`,
and
`245e80c02c670b529c38dcbe62b32bc71a4761378a646e48c591152aab104758`.
Statistics archive digests are Linux
`1bd87841d16ac5f2e08502dd9c37dc490d4677f4517e786c8c4e3deaf0359617`
and Windows
`494f3c81af3668a356fec665720e4afbb72338c14f3a90b02a406d5fdf3ec54e`.

**Independent validation.** All archives were downloaded under
`C:/w/wp6d-matrix-33402460152`. A read-only audit matched hash and size for
162 PASS manifests and 732 declared artifacts and found no reparse point.
Every one of the 20 lane records binds the exact clean candidate, hosted
source context, seven-command catalogue, platform, unique ordinal and run ID,
classification, validated reduction, and paired dependency state; all
non-semantic authority flags are false. The sorted lane path/file-hash
inventory SHA-256 is
`24240c2c6c17435a66c78e8091c78d1f54ab86946a3f3f1d5250075fa923c646`.
A clean no-local/no-hardlink checkout at
`C:/w/wp6d-validate-33402460152` then ran the production validator with
`--validate-existing` over each exact merged platform root. PASS evidence is
at `C:/w/wp6d-independent-33402460152/{linux,windows}-validation-2`.
Retained statistics file hashes are Linux
`216d45e5774a6bdf7293e4403978bfa40af80edd282c14d4d4369248014beb2c`
and Windows
`ce7ea64ccca9f5416065375d4b0dd6e1f37afc2842c937ffe1f5843a19dfa0ef`;
the independent PASS result hashes are
`1ff582e75adae1eff93bfd38b22fab62974c5b9fd69aed4e3b75a1e6ef681d6b`
and
`6c8a0e163c814e0829c2ef30b3539aa184fd99a3b3e15356cf6b0b00733bb557`.

**Retained procedural failure.** The first two validation invocations are
retained as ERROR manifests at
`C:/w/wp6d-independent-33402460152/{linux,windows}-validation`, with SHA-256
`bec247bc4edd6f5e788361d6364706a7b248fff078acbf8f8aec3c7e5fd53e8d`
and
`4bcebec7c3035c25418c0c6f89b24f4321663bee4a73df5060ffbad4aef151a8`.
They preserved per-archive wrapper directories while the producing workflow
used `merge-multiple: true`, so relative input paths differed. Reassembling
the exact `platform/ordinal/...` topology made both retained records reproduce
without altering any downloaded or repository byte.

**Boundary and handoff.** WP6d supplies descriptive, non-semantic evidence
only. It neither compares performance nor changes test success, thresholds,
the commissioned benchmark, cutover authority, or readiness. Intended WP6e
alone owns any manifest/tier/slow-registry recomposition that consumes this
evidence; intended WP6f owns interpretation and go/no-go. The record-only
closeout working tree passed typecheck, lint, and format at
`C:/w/wp6d-closeout-{typecheck,lint,format}-1`; orchestrator passed 203/203
suites and 692/692 tests at `C:/w/wp6d-closeout-orchestrator-1` (report
SHA-256
`fe784c3cfe02906324ba5d2f575cb07076b10cefa851bb2a306385a8283b7d5d`),
and complete unit passed 205/205 suites and 708/708 tests at
`C:/w/wp6d-closeout-unit-1` (report SHA-256
`ee9c545461ef6ea98841a15b1780b1cff5a4e04f885c38b36089ef0d930ff469`).
After these records were written, all five invariant commands passed at
`C:/w/wp6d-closeout-invariants-1` (report SHA-256
`6ca10df459cf5429b3514a951998a7edca2c4378c61abfd71fb6dc496524b4cd`).
The closeout commit and its exact-runtime gate remain before final handoff.

## 2026-08-31 — WP6d completed-crash observation seam locally qualified

**Objective and outcome.** Remove host PID-reuse timing from the
candidate-prepare transaction matrix without changing production lease
semantics. The test now records only crash-worker PIDs backed by the expected
point marker and exit status 86, substitutes a deterministic dead observation
only for those exact completed workers, and delegates every other bounded
spawn. A regression proves the platform command parser and verified-PID
boundary. The dedicated controller-lease suite continues to exercise real
process liveness and deterministic unavailable, matching, and reused
incarnations.

**Verification.** The selected hard-loss matrix passed all 16 rows (13
automatic convergences and 3 preserved ambiguous blocks) with no remaining
temporary repository at
`C:/w/wp6d-step7-crash-observation-focused-1`; report SHA-256 is
`7572c6106e403b3b5b24d72934ef771692d40235cc588beda4b84966d456443d`.
The complete candidate and controller-lease files passed 10/10 and 18/18 tests
at `C:/w/wp6d-step7-crash-observation-{candidate-suite-1,lease-suite-1}`.
Typecheck, lint, and the post-Prettier format check passed. Fast passed 202/202
suites and 676/676 tests at `C:/w/wp6d-step7-crash-observation-fast-1`
(report SHA-256
`56cd71d480d0cf62a7dad98abf1523d45f022b8436fa179c99b4464c1912921f`),
and orchestrator passed 203/203 suites and 692/692 tests at
`C:/w/wp6d-step7-crash-observation-orchestrator-1` (SHA-256
`4cc642ec18cb105245336c8d1768f9d5d0a4ed5f79b57c7a7c85615198fca36f`).

**Retained failures and disposition.** The initial format check is retained as
non-passing because the edited test had not yet been formatted. The first
complete-unit attempt at `C:/w/wp6d-step7-crash-observation-unit-1` passed
699/708 tests but nine tests in three unrelated files expired at their
existing 60-second budgets during one host-wide slowdown. Those exact files
then passed 30/30 unchanged at
`C:/w/wp6d-step7-crash-observation-timeout-repro-1`; a fresh complete-unit
aggregate passed 205/205 suites and 708/708 tests at
`C:/w/wp6d-step7-crash-observation-unit-2` (report SHA-256
`50b16de1a2ad690e1a6f8deefa2f2e245a8b6cb196e82507197493e5d87c2525`).
No timeout was raised and no production source changed. After these execution
records were written, all five invariant commands passed at
`C:/w/wp6d-step7-crash-observation-invariants-1` (report SHA-256
`03cc58c17d9c3c19c4540ec82fc9ead004dd51dce3a851502dafcd111e1937a0`).

**Commit and remaining boundary.** The candidate is not yet committed.
Protected-file checks, a pushed commit, and a fully green five-job exact-runtime
run remain mandatory before a fresh measurement matrix. No failed or partial
run supports a performance, cutover, or readiness claim.

## 2026-08-31 — WP6d hosted candidate-prepare lease race retained

**Outcome.** Test-harness repair commit
`31fb2274f82153d378db9f9bca6d7c394eb266db`, tree
`2c69984b51d6c9e69691e672d09c7f549e49d3da`, is pushed to `origin/master`.
Exact-runtime run `33370485616` passed the Linux controller, both adopter
smokes, and trusted-container jobs, but its Windows controller aggregate failed
the candidate-prepare hard-loss matrix after passing 690/691 tests. The
measurement matrix was not dispatched.

**Failure evidence and diagnosis.** The retained report at
`C:/w/wp6d-ci-fail-33370485616-controller-windows/orchestrator/orchestrator-report.json`
has SHA-256
`2bc06e9210c1568ba26ad311d105549cc3605a55529ddb1a3b7cefcd06553931`;
GitHub reports controller archive digest
`365906e11da0dcce1ded5e4d5625b5b75c5f67a7aa0f10de834f5c3d757d3607`.
The failure occurred only after the real crash worker had exited with its
expected marker and status: Windows reused or retained that PID within the
production ten-second process-start tolerance, so lease acquisition correctly
failed closed as though the recorded owner were still live. A direct
exact-runtime rerun passed the selected matrix with 13 automatic convergences,
3 preserved ambiguous blocks, and no remaining `cpb-*` directories at
`C:/w/wp6d-step7-hosted-lease-race-repro-1`; its report SHA-256 is
`9c501aedad02fcf3a1d3b2680e1384b5f133fd23671644c06217619f394ecbd`.

**Repair boundary.** Keep production liveness, tolerance, and fail-closed
behavior unchanged. The candidate transaction fault matrix may substitute a
dead observation only for exact worker PIDs whose real marker and exit 86 were
already verified; the dedicated lease suite remains responsible for real
live-owner and deterministic unavailable/matching/reused-incarnation semantics.
A focused matrix, lease suite, all broad local gates, a new commit, and a fully
green five-job exact-runtime run remain mandatory before any fresh measurement
dispatch.

## 2026-08-31 — WP6d Windows measurement harness repair locally qualified

**Objective and outcome.** Preserve the production controller lease's
five-second, fail-closed process-incarnation probe while making its verification
deterministic under the non-semantic measurement preload. Exact-runtime run
`33350041568` passed all five jobs on candidate
`f5de977f973ed68cec250cdadea890ec9817ec35`, but measurement run `33353378514`
proved a second defect after all five Linux pairs passed: every Windows cold
lane passed 674/675 fast tests, exhausted both real PowerShell observations,
and correctly refused to steal the simulated live lease. The repaired test
still launches a real external process and delegates one real OS observation,
then explicitly proves unavailable and matching-start observations remain
blocking while only a known different start time permits exact-old recovery.
No production source or timeout changed. Qualification also exposed and fixed
an independent 10-second `afterEach` budget that could expire while the
candidate-prepare hard-loss matrix continued its genuine recursive cleanup;
only that hook now has a 120-second budget.

**Verification.** Ten consecutive probe-instrumented lease repetitions and the
full 18-test lease file passed under
`C:/w/wp6d-step7-incarnation-{probed-repeat-1,lease-suite-1}`. Typecheck, lint,
format, the five-command invariant suite, and the measured fast partition
passed; fast retained 202/202 suites and 675/675 tests at
`C:/w/wp6d-step7-incarnation-fast-1` (report SHA-256
`40d7c052d83a6c487ee3e7685a04ad011661f4bc9b1019a829ab4bacf7943ce4`).
The orchestrator aggregate passed 203/203 suites and 691/691 tests at
`C:/w/wp6d-step7-incarnation-orchestrator-1` (SHA-256
`4ee58e77928f4c00f20faef859e752bd3b375ff75887a08f3f8156160f427e47`).
The first complete-unit attempt retained the cleanup-hook failure at
`C:/w/wp6d-step7-incarnation-unit-1`; the focused matrix then passed and left
zero temporary repositories at `C:/w/wp6d-step7-cleanup-focused-1`. The final
complete-unit rerun passed 205/205 suites and 707/707 tests at
`C:/w/wp6d-step7-incarnation-unit-2` (SHA-256
`410847cee40937d01559f99c5cd5e99c0ab318f50c9358b50ecf0b062fb6bea7`).
The final five-command invariant suite passed again after all repository
records were written, at `C:/w/wp6d-step7-incarnation-invariants-3`.
The immutable lock, protected exact-runtime workflow, and protected untracked
roadmap hashes remain unchanged.

**Commit and remaining boundary.** The locally qualified candidate commit is
not yet assigned; its exact identity and hosted result will be appended after
commit and push rather than predicted. A green exact-runtime run, a wholly
passing five-pair Windows/Linux measurement matrix, and independent validation
of all retained pairs and both statistics records remain mandatory. Failed or
partial matrix artifacts are diagnostic only, make no performance claim, and
do not support readiness.

## 2026-08-30 — WP6d one-repetition measurement runner qualified

**Objective and outcome.** Add a non-semantic one-repetition runner before
authoring the repeated hosted matrix. Commit
`9f1767cba800b551faa648e8a317715fe282f6a4`, tree
`4a2c6c13a9068c51e7580a50a32ca04b3aa4ac6d`, is pushed to
`origin/master`. Its additive CLI runs a canonical selection from the seven
existing measured commands, validates every command receipt and compact
summary, rereads clean candidate/runtime identity, writes and reproduces one
reduction, and hash-binds exact cold/warm workspace semantics without an OS
cache claim. Warm execution independently validates and binds its cold pair.

**Qualification.** Focused fail-closed and ownership regressions, typecheck,
lint, format, and invariants passed under `C:/w/wp6d-step5-*`. A first broad
run honestly failed the stale ownership-count expectation; after the exact
79/83 totals were corrected, controller passed 201/201 suites and 685/685
tests, while complete unit passed 203/203 suites and 701/701 tests with no
pending results. Clean checkout `C:/w/m5` then passed a real `legacy-fast`
cold/warm pair under `C:/w/m5e`; exact record/reduction hashes are in the
active plan. Hosted exact-runtime run
`https://github.com/mclaurin10/milestone-loop-template/actions/runs/33309783742`
passed all five jobs on the same candidate; GitHub archive digests are also
in the plan. The immutable lock, protected workflow, and protected untracked
roadmap hashes remain unchanged.

**Remaining boundary.** This closes only the one-repetition runner. The
dispatch-only repeated Windows/Linux matrix, deterministic descriptive
statistics, one completed hosted matrix and independent download validation,
and WP6e/WP6f handoff remain open. No result compares performance, changes
test success, sets a threshold, or authorizes cutover.

## 2026-08-30 — WP6d measurement-contract repair qualified

**Objective and outcome.** Close the externally demonstrated summary,
reduction, and omission-evidence acceptance defects before building the WP6d
measurement lane. The cohesive repair is commit
`09eae95b719aeaa13f1a5ef626a4067088313d1c`, tree
`507a25788e0aeaa4521f34dc835ae814112f03d7`, pushed to `origin/master`.
It tightens producer-coherent runtime acceptance without changing the
`1.0.0` wire shape, shares the production shadow finalizer with the real
omission mutation, and preserves the frozen authorities and measurement's
non-semantic boundary.

**Local qualification.** Exact Node `24.18.0` / pnpm `11.15.1` typecheck,
lint, format, invariants, orchestrator (198/198 suites, 679/679 tests), and
complete unit (200/200 suites, 695/695 tests) passed under
`C:/w/wp6d-repair-*`. The first clean production-shadow attempt at
`C:/w/wp6d-repair-shadow-09eae95` retained a real failure: its overlong
Windows evidence root caused six crash-recovery assertions to exhaust Git
path length. No result was relabelled or discarded. Repetition from short
clean checkout `C:/w/r6` with evidence at `C:/w/e6` passed 696 unique tests
across all 82 disjoint files and reduced eight validated summaries. The PASS
receipt, proof, reduction, and reduction-content SHA-256 values are
`9f8d1ee6e6ec5360ba23df77ed0812401676f392af87a9cb23dd58b7fc7379c8`,
`e57a05f205f030a52835ff33ad56ff867a7aba2a7fb826a08d2c216ed2742611`,
`cd487b22903e5f37a8290fe5e8572b848d3771462cef0cb31bde84d069eb66d7`,
and `9821432511f1936224a6e68d315951eb1c924652c892daacf0a9ac11af6a57cd`.

**Hosted qualification and gaps.** Exact-runtime run
`https://github.com/mclaurin10/milestone-loop-template/actions/runs/33296797971`
passed Windows/Linux controllers, Windows/Linux fresh-adopter smoke, and the
trusted Linux container. GitHub archive digests are recorded in the active
plan. The protected workflow remains byte-identical. This closes the repair
increment only; the WP6d measurement runner, repeated matrix, statistics,
independent artifact validation, and WP6e/WP6f handoff remain open.

## 2026-08-29 — WP6d corrective record for measurement acceptance

**Correction.** The preceding 2026-08-29 closeout said all contradictory
summary/reduction input failed closed. That statement was overbroad. Runtime
acceptance still admitted: measured wall/setup/startup/test-body durations
with zero samples; nonzero measured Git time with zero samples; an unavailable
probe with nonzero synchronous launches or measured Git/startup/test-body/CPU/
RSS observations; measured CPU/RSS coverage differing from the probe record
count; reduction disposition rows inconsistent with their counters or
`inputCount`; nonzero duration/CPU aggregates with zero measured inputs; and a
null partition owner or non-null legacy/legacy-extra owner. The prior omission
FAIL manifest also said the aggregate rejected the mutation and issued no PASS
receipt even though that test-only CLI had exercised only the production
semantic comparator. Historical bytes and entries are preserved; this entry
corrects their scope.

**Repair outcome.** Summary and reduction runtime validators now reject every
listed class after receipt-byte/hash and semantic-content-hash matching, and
genuine producer boundaries remain accepted. Producer output with an
unavailable preload probe withholds fine-grained metrics; measured zero-sample
Git remains valid only at zero nanoseconds. The shadow's existing comparison,
candidate check, summary validation, reduction, proof, and receipt decision
are one shared finalizer. The real two-test omission mutation now traverses
that finalizer, retains a valid two-summary reduction and FAIL proof with one
named missing identity, and throws before the PASS-receipt callback. Its
manual FAIL text now claims only the comparator result.

**Retained-Q recalibration.** Exact candidate Q remains
`b1d43a2abaf46ad16a79e32b08b3a9b9a548eace`, tree
`acdf9100b96ce17ec5fd2a1df10aba75362b3ce9`, clean. All eight external
receipt-bound summaries under `C:/w/ea/shadow` passed the tightened loader and
reducer expectations. Every probe is measured; every measured wall/setup/
startup/test-body count is positive; the three legitimate zero-Git summaries
also have zero Git nanoseconds; and every CPU/RSS process count equals its
probe count. Re-reduction reproduced the retained reduction exactly. Its file
SHA-256 remains
`5b2fbfa886fbd386d1a1d44360b9c848a0ee0f3fd0411dba4e135510c701eca5`,
content SHA-256 is
`c16a8f80bca8646afb1dbfcf4d2c520ed4ed766920196d808527b7ec8fa89234`,
and `inputCount` is eight. This confirms the prior retained-evidence
recalibration; no historical artifact was edited.

**Verification and boundary.** The compact summary/reduction suite passed
16/16 and the partition/omission suite passed 20/20 under exact Node `24.18.0`
and pnpm `11.15.1`; receipt-owning typecheck evidence is retained under
`C:/w/wp6d-step{1,2,3}-typecheck*`. The new omission evidence at
`C:/w/wp6d-step3-omission` has no `result.json`; proof, reduction, and manifest
SHA-256 values are
`454e4af1d2caa670687856734d4b7a78afe566bf8ad7173cec2c57a49547e24a`,
`bd12e54f3ca43b5b7e386eb50b9d87d9e4dd3b67f81e8c69b7fc4ad192232c1d`,
and `07e32dd2a84bc75a00502dcd4e06fce382fd012ef016810e86948cc7894a1bfa`.
The cohesive repair commit and broad clean-candidate qualification are not yet
assigned; their exact identity will be appended at qualification rather than
fabricated here. This is not WP6d completion: the measurement runner, hosted
matrix, statistics, independent validation, and WP6e/WP6f handoff remain open.

## 2026-08-29 — Intended WP6b summaries and intended WP6c acceptance closeout

**Objective and crosswalk.** Complete intended WP6b's compact non-semantic
measurement summaries and repair intended WP6c's omission acceptance surface.
Repository history used “WP6b” for owner-derived partition/shadow execution;
that historical package corresponds to intended **WP6c**. The forward sequence
is WP6a inventory, WP6b summaries/instrumentation, WP6c ownership/shadow, WP6d
benchmark CI, WP6e manifest/tier recomposition, and WP6f measurement go/no-go.
This crosswalk preserves history and does not amend the commissioned schedule.

**Outcome.** Protocol `milestone-loop-test-run-measurement.v1` now has strict
`1.0.0` runtime and JSON Schema contracts for one command-owned run summary and
one deterministic summary-only reduction. A summary binds run/stage/command,
role/owner, exact candidate commit/tree/cleanliness, Windows/Linux and pinned
runtime provenance, report hashes/counts, units, explicit timing boundaries,
and measured/unavailable/not-applicable dispositions for wall, setup, Git
fixture, process-startup, test-body, CPU, and peak-RSS observations. Peak RSS is
truthfully the maximum instrumented-process peak, not a concurrent process-tree
peak. Genuine producer receipts hash-bind summaries; the shadow receipt
hash-binds the reduction. Missing, malformed, contradictory, stale, duplicate,
or candidate/command-mismatched input fails closed. Metrics cannot alter test
success, authorize cutover, or make a benchmark claim.

WP6c regressions now pin separate missing and unexpected semantic test
identities. A production-boundary omission mutation executes a real two-test
Vitest fixture, removes one executed assertion from the partition report, and
proves aggregate failure, no PASS `result.json`, retained raw reports, and an
exact named `missingTests` entry. Its retained proof at
`C:/w/wp6b-i1/omission-mutation/test-partition-omission-mutation-proof.json`
has SHA-256
`5c1fc94219b59ba73616e4679c3029b9aad58f3724a65d0c454c9bdbcd6c5e97`;
the FAIL manifest hash is
`16044abc56e91789c23516e593971be7f9e3e6ac79ead019aeab7fe6825926d1`.

**Qualification-discovered regression.** The first clean shadow on initial
implementation commit `75788cbb6bec6d820df343bd102372a9417bae9e`
(tree `b6014911da834b72edbfb09f74638888f26a77a5`) retained a genuine FAIL at
`C:/w/e9/shadow`: legacy orchestrator passed 665/666 assertions, but hard-loss
candidate recovery mistook an unrelated live process for a crashed controller
after PID reuse. Probe records independently showed repeated PID reuse,
including one reuse within 55 seconds. Same-host lease liveness now compares
the recorded start time with a bounded Windows `Get-Process` or POSIX `ps`
observation for every live PID; a different incarnation is stale and an
unavailable observation remains fail-closed. The focused 18-test lease suite
preserves genuine external live-owner exclusion and proves reclaimed reuse.
The original 16-row hard-loss matrix then passed under the WP6 probe at
`C:/w/e9/pid-fix-focused/candidate-prepare-matrix.json`.

**Exact clean qualification.** Fix-forward executable candidate Q is
`b1d43a2abaf46ad16a79e32b08b3a9b9a548eace`, tree
`acdf9100b96ce17ec5fd2a1df10aba75362b3ce9`. Fresh short clone `C:/w/za`
used Node `24.18.0`, pnpm `11.15.1`, and a frozen offline copy install; final
external evidence is `C:/w/ea`. Focused summary/reducer/schema, omission,
ownership, supervision/receipt, exact-workflow, and PID regressions passed
103/103. Ownership passed for 82 files; standalone partitions passed
663/16/4/1 tests for controller/repository/adopter/trusted owners. The
five-command invariants suite passed. Exact `test:unit` passed 683/683 in 200
suites, exact `test:orchestrator` passed 667/667 in 198 suites, and typecheck,
lint, format, exact-runtime workflow 5/5, demo safety 6/6, and
`git diff --check` passed.

The final `C:/w/ea/shadow` aggregate passed 684 unique tests over the exact
82-file disjoint union. It reduced 1,351 legacy observations to the same 684
semantic identities as the owner partitions with every conflict/delta list
empty. Its receipt/proof/reduction SHA-256 values are
`74cd01dffdeb7073eebd331600a8473778a2e636d09ec57e86944cf26841cc55`,
`5e356ebc80013dd2cde2962da8f2dbebe20749c108969b609326b92a7f9ace42`,
and
`5b2fbfa886fbd386d1a1d44360b9c848a0ee0f3fd0411dba4e135510c701eca5`.
Independent runtime validation accepted all eight summary inputs and the
reduction; all declared receipt/artifact sizes and hashes, raw passing
dispositions, exact clean candidate identities, resource dispositions, and
false non-semantic flags were rechecked.

**Honest readiness result.** Exact no-argument `pnpm verify` ran for 59.8
minutes at
`C:/w/za/artifacts/verify-2026-08-29T060015-721Z-1184/result.json` (SHA-256
`82a062381ed983fdae49d99a96b387a65a09907b88e905f2d7ebeac2ea24e7eb`).
It ended FAIL/exit 1 with 2 PASS, 2 FAIL, 11 NOT_READY, and 0 ERROR stages.
The nested full unit command passed 683/683 with valid receipt and summary;
contract integrity passed; every supervised command had clean timeout/output/
drain facts; and start/final candidate identity stayed exact clean Q with no
drift. Existing dependency/architecture placeholders, undeclared build/domain/
readiness scripts, and the unattested provider are the only causes. Completion
is ineligible and no autonomous-readiness claim is made.

**Commits and boundary.** Intended WP6b/WP6c implementation commit is
`75788cbb6bec6d820df343bd102372a9417bae9e`; qualification fix-forward Q is
`b1d43a2abaf46ad16a79e32b08b3a9b9a548eace`. The successor containing this
entry is documentation-only and is not represented as shadow-tested. The
active manifest, commissioned source, exact-runtime workflow, slow registry,
`benchmark.ts`, package/verify entry points, frozen authorities, acceptance
meaning, CAL-1, tiers, and readiness gates are unchanged. The protected human
roadmap remains byte-identical at SHA-256
`53ea98fb1cb880163a02d3b1d9365963e3fe891025ae3630f00bd4c9232293b1`.

**Known gaps / handoff.** No benchmark matrix or Linux performance result was
run, and these observations support no improvement or cutover claim. Intended
WP6d must begin under a new plan and add only the benchmark CI lane plus the
prescribed repeated cold/warm Windows/Linux matrix consuming these summaries.
The legacy schedule remains authoritative. WP6e alone owns any later
manifest/tier recomposition; WP6f owns interpretation and go/no-go.

## 2026-08-26 — WP6b closed on exact executable candidate X

**Outcome.** WP6b is closed on executable commit
`0400c32f93ebf0b7d8e6be165e880dd9aff2ebbe`, tree
`8723d791f7a1bbd30eb15d57d674fa092188b433`. Basename-only incidental text no
longer establishes a durable citation; exact manifest-ID and normalized-path
references retain legitimate behavior, and uncited external evidence remains
truthfully uncited at creation. Every legacy and partition Vitest report used
by shadow evidence now requires `success:true`, coherent suite/test counters,
zero failed/pending/todo outcomes, and passing normalized dispositions before a
PASS receipt is possible. The qualification-discovered aggregate unit timeout
and synchronous-Git event-loop stall were also fixed with finite fail-closed
bounds and regressions. Product behavior, frozen contracts, commissioning,
tiers, exact-workflow commands, and WP6c scope are unchanged.

**Exact qualification.** Pinned Node `24.18.0` / pnpm `11.15.1` qualification
from a fresh clean short-path clone passed focused 43/43, ownership over all 81
files, shadow equivalence over 672 unique tests, standalone unit 671/671,
orchestrator 655/655, serial invariants 5/5, protected contract integrity
13/13, typecheck, lint, format, exact-workflow coverage, `git diff --check`, and
safety 6/6. All command receipts and declared sizes/hashes validate at exact X;
the ownership split is 77/1/2/1 with six empty intersections and exact union.
Legacy shadow observations are 1,327, deduplicating to the same 672 IDs and
outcomes as the partitions, with no conflicts, multiple selection, missing,
unexpected, or mismatched results. The compact authoritative path/hash ledger
is `.agent/current-exec-plan.md`; raw reports remain external.

**Honest no-argument result.** Exact `pnpm verify` ran for 59.5 minutes under
the package-default readiness profile and ended FAIL/exit 1: 2 PASS, 2 FAIL,
11 NOT_READY, 0 ERROR. Candidate start/final identity is exact X, clean, with
no drift; all seven supervised commands have zero timeout/output/drain defects.
The nested unit command passed 195/195 suites and 671/671 tests, after which
`unit-domain` became NOT_READY solely because `test:domain` is undefined. The
remaining causes are explicit project-owned placeholders, undeclared/absent
product-readiness scripts, and an unattested provider. Completion is therefore
ineligible and no autonomous-readiness claim is made.

**Retained failures and history.** Candidate `668c9d9c...` remains rejected for
the genuine 900,000 ms aggregate unit timeout it exposed. Candidate
`c616777b...` remains rejected for the genuine synchronous-Git stall it
exposed. Their retained diagnostics are not evidence for X. Historical `q3`
also remains accurately classified: two state-store failures/timeouts during a
concurrently launched focused run, followed by a serial 66/66 PASS; it is
neither a proven product regression nor a clean first attempt.

**Handoff.** The protected human roadmap remains the only worktree entry and is
byte-identical at SHA-256
`53ea98fb1cb880163a02d3b1d9365963e3fe891025ae3630f00bd4c9232293b1`.
The successor commit containing this entry is documentation-only Y and was not
represented as the shadow-tested identity. WP6c is next but unstarted; it may
begin only after the final X-to-Y documentation-only diff and Y integrity gates
are proven.

## 2026-08-25 — WP6b executable partition candidate; qualification pending

**Outcome.** WP6a's canonical catalogue now drives four independently
invokable shadow partitions: `controller-runtime`, `repository-tooling`,
`adopter-template`, and `trusted-container-fixture`. Selection reads only the
passing ownership report. Each normalized file is assigned to the deepest
containing Vitest config seen by repeated independent discovery, with lexical
tie-breaking; the invocation uses that discovered root/config boundary. Every
successful owner command issues a genuine receipt for its deterministic
selection report and raw Vitest report(s).

The clean-only `test:partitions:shadow` aggregate runs the legacy fast,
migration, and orchestrator commands under their existing evidence
identities, adds the independently discovered remainder, validates all legacy
and partition child receipts, and stops with the exact child nonzero when a
child fails. Its authenticated proof records the ownership/catalogue identity,
81-file discovery identity, normalized 77/1/2/1 memberships, all six empty
pairwise intersections, exact union equality, candidate commit/tree/runtime,
child-receipt hashes, and the normalized semantic comparison. Legacy results
are deduplicated by repository file plus full test name; disposition and
normalized failure output must match, while timestamps, absolute roots,
ordering, and durations are excluded.

**Regression and diagnostic evidence.** The receipt-owning focused run at
`artifacts/manual/wp6b-focused-partitions-3/` passes 8/8 suites and 23/23 tests,
including exact-runtime workflow ownership. Eleven partition regressions cover
stable proof rendering/public commands, cross-platform paths/config
provenance, disjointness, incomplete union, unexpected membership, legacy
deduplication, semantic mismatch, multiply selected tests, and exact/missing
aggregate exit propagation; the seven WP6a ownership regressions remain green.
The integrated invariant suite at `artifacts/manual/wp6b-invariants-1/` passes
all five receipt-owning commands. Dirty-tree diagnostic executions passed the
four owner commands at
`artifacts/manual/wp6b-partition-controller-runtime-1/`,
`wp6b-partition-repository-tooling-1/`,
`wp6b-partition-adopter-template-3/`, and
`wp6b-partition-trusted-container-fixture-1/`. The first adopter attempt
retained a real non-passing manifest/report when its nested config root was not
supplied; the root cause was fixed by deriving the same root and config basename
used by independent discovery.

**Clean candidate qualification.** The first exact clean-candidate aggregate at
`artifacts/manual/wp6b-clean-shadow-1/` failed closed before later children:
the legacy fast selector was still actively executing when its stale 20-minute
supervisor expired. The aggregate propagated exit 1, emitted no PASS receipt,
and retained the child timeout logs and authenticated failure manifest. This was
a small directly blocking entry-surface defect: the same serial suite takes
roughly 49–51 minutes under the pinned runtime. Its bound now matches the
existing one-hour full-suite command bound without changing selection,
file/test timeouts, or exact-runtime workflow argv. A regression pins that
limit.

The second exact clean-candidate aggregate at
`artifacts/manual/wp6b-clean-shadow-2/` also failed closed before later
children and issued no PASS receipt. The legacy-fast raw report reached all 625
selected tests, but 33 failed because nested Git fixtures exceeded the Windows
path limit under the long evidence/runtime root. The failures are uniformly
`Filename too long`; they do not establish semantic equivalence. This retained
diagnostic requires no product-code relaxation: final qualification must run
the same committed commands from short clean-clone and evidence roots, then
inspect every receipt, declared artifact hash/size, raw test disposition,
proof delta, and candidate identity. The increment remains incomplete until
that aggregate and the clean focused/broad closure pass.

The first short-path complete aggregate at `C:\\w\\e3` then passed on clean
commit `c4a1f0380cd2d3d38df449f0912453f87541b5a2` (tree
`69fa43ab8d98bf45bc5c7dd921313ee9fa7b3780`). Its eight PASS manifests and
receipts bind 12 aggregate artifacts with independently rechecked byte counts
and SHA-256 values. The proof records 81 files split 77/1/2/1, all six empty
intersections, an exact union, and 655 partition observations. It deduplicates
1,293 legacy observations to the same 655 semantic identities (638 duplicate
observations removed), with empty conflict, multiply-selected, missing,
unexpected, and outcome-mismatch lists. Partition test counts are 634
controller, 16 repository tooling, 4 adopter, and 1 OCI fixture.

Clean candidate checks at `C:\\w\\q1` passed focused 33/33, ownership discovery
for 81 files with zero diagnostics, all five invariants, typecheck, lint,
format, and the 6/6 safety demonstration. The standalone full-unit run at
`C:\\w\\q1\\unit` failed closed exactly at its 3,600,000 ms evidence-wrapper
limit, emitted no PASS receipt or raw report, and was still producing fresh
runtime state. Because the same commit's split fast/migration children had
already passed 625 plus 29 tests, only the full unit/orchestrator receipt
wrapper bound advances to a finite 90 minutes; a focused regression passes
34/34 after the change. Selection, serialism, per-test limits, package/workflow
argv, and receipt semantics are unchanged. Final qualification must bind the
amended commit, so these `c4a1f038` results are implementation-candidate
evidence rather than the final handoff identity.

The next exact clean shadow at `C:\\w\\e4` retained another genuine failure on
commit `3a600203ea70f15cadaf393b0df96edc09330153`. All legacy children passed,
but the `controller-runtime` owner reported 634/635 tests: the crash-boundary
state-store case completed its assertions, then Windows recursive fixture
cleanup raised `ENOTEMPTY`. The surviving `state.json` was last written several
minutes before teardown, excluding an unawaited state write and identifying a
transient owned-directory removal race. State fixture teardown now retries only
bounded transient filesystem codes with linear backoff, rejects permanent
errors immediately, and still fails after the retry ceiling. Three deterministic
regressions pin those outcomes. The dirty-tree focused state-store run at
`C:\\w\\d3\\state-store` passes 32/32; typecheck, lint, and format receipts at
`C:\\w\\d3` also pass. Preserve `C:\\w\\e4` and completely rerun same-commit
qualification after amending the candidate.

**Preservation and boundary.** The active commissioned manifest and its source
input, `scripts/verify.mjs`, exact-runtime workflow, slow registry, benchmark,
immutable lock, default `readiness` profile, and all legacy package argv retain
their entry identities. The sole legacy implementation adjustment is the
directly blocking fast/migration wrapper bound above. The added commands are not commissioned tiers and do
not change no-argument or exact-runtime closure selection. No recommissioning,
tier cutover, 5x platform matrix, timing aggregator, benchmark change, or
performance claim occurred. The protected human roadmap remains byte-identical
at SHA-256
`53ea98fb1cb880163a02d3b1d9365963e3fe891025ae3630f00bd4c9232293b1`.
Commit: the cohesive local commit containing this entry; the final handoff names
its exact identity.

**Known gap / next action.** First complete WP6b qualification from short paths
on one clean immutable commit. After that succeeds, the commissioned legacy
schedule remains active and WP6c begins with normalized per-run timing
summaries and measurement-protocol instrumentation, then the required
cold/warm Windows/Linux matrix. Only material improvement beyond noise may
justify a separately commissioned cutover; exact closure remains fresh
regardless.

## 2026-08-24 — WP6a canonical test ownership closed

**Outcome.** WP6a now has one tracked canonical ownership catalogue for the
complete independently discovered source-test universe. Vitest discovery is
run twice for every tracked or unignored config and twice for the orchestrator
filter, with real-path containment, forward-slash normalization, sorted output,
duplicate/case ambiguity detection, and repeated-set comparison. The gate also
reconciles package scripts, current commissioned candidate commands, the
existing fast/migration discovery, direct invariant selections, the OCI
fixture, and the executable exact-runtime workflow contract. The final
universe is 80 files owned exactly once: 76 `controller-runtime`, one
`repository-tooling`, two `adopter-template`, and one
`trusted-container-fixture`.

The code allowlists owner identifiers independently from the catalogue. Stable
fail-closed diagnostics cover unclassified, multiply owned, stale,
invalid-owner, malformed/noncanonical path, duplicate/case-ambiguous, and
nondeterministic discovery states. Seven focused regressions cover the required
failure fixtures and stable rendering. The first intentional red run at
`artifacts/manual/wp6a-ownership-gate-1/` proved that adding the gate test
without classifying it produces exactly one `UNCLASSIFIED_TEST`, no PASS
receipt, and report SHA-256
`72eb9f8a89cabd32efe9b8c0ce1c73c4a10efb0763edaf03655ad3810c3e3bb8`.

**Integration and verification.** The receipt-owning gate is the fifth
substantive child of `pnpm test:invariants`; PASS owns a validated
`test-ownership-report`, while classification failure retains its report but
cannot issue a receipt. Exact clean-candidate gate, focused, integrated
invariant, typecheck, lint, and format evidence is retained respectively at
`artifacts/manual/wp6a-clean-ownership-gate-1/`,
`artifacts/manual/wp6a-clean-focused-1/`,
`artifacts/manual/wp6a-clean-invariants-1/`,
`artifacts/manual/wp6a-clean-typecheck-1/`,
`artifacts/manual/wp6a-clean-lint-1/`, and
`artifacts/manual/wp6a-clean-format-1/`. Their manifests identify the exact
WP6a commit with `workingTreeDirty: false`; all expected receipts and artifacts
were independently inspected.

Pinned clean-candidate `pnpm test:orchestrator` at
`artifacts/manual/wp6a-clean-orchestrator-1/` passes 186/186 suites and 626/626
tests. Pinned clean-candidate `pnpm test:unit` at
`artifacts/manual/wp6a-clean-unit-1/` passes 188/188 suites and 642/642 tests.
Both have zero failures, skips, pending tests, or todos and valid command-owned
receipts. `pnpm loop:demo-safety` passes all 6/6 scenarios, and
`git diff --check` passes. Earlier dirty-tree broad receipts show the same
counts but are corroboration only, not the clean-candidate qualification.

**Integrity and boundary.** The successful hosted exact-runtime run
`32785374927` binds the starting commit `b01467b4d14cb842da7645c6aba00dfabfb9ab37`
and is recorded only as a correctness baseline; it predates WP6 instrumentation
and supplies no timing evidence. Package scripts, active commissioned manifest,
commissioning identity, exact-runtime commands, slow-suite executor registry,
and `benchmark.ts` are unchanged. Immutable hashes still equal their baselines,
CAL-1 remains `open_not_started`, and the human roadmap remains byte-identical
at SHA-256
`53ea98fb1cb880163a02d3b1d9365963e3fe891025ae3630f00bd4c9232293b1`.
No executor cutover, tier recomposition, recommissioning, timing matrix,
product/readiness work, or success-definition change occurred. Commit: the
cohesive local commit containing this entry; the final handoff names its exact
identity.

**Known gap / next action.** Candidate execution still intentionally overlaps.
WP6b1 starts by consuming the catalogue in disjoint owner-based executors with
command-owned receipts, running them in shadow beside the current commands,
and comparing normalized file/test inventories and outcome semantics. The
commissioned manifest stays authoritative and unchanged until that shadow
equivalence is proven; timing and cutover remain later work.

## 2026-08-24 — WP2 candidate-prepare Session 2 closed

**Outcome.** The omitted `candidate-prepare` boundary is behaviorally complete
and fully verified. State `1.11.0` publishes exact pre-launch intent, resumes
only the unchanged pre-launch window, preserves three post-launch ambiguous
windows, stores reproducible canonical Worker response bytes, regenerates only
derived evidence, validates exact paths/Git/policy/Worker/checkpoint identity,
uses one semantic completion reducer, and serializes recovery through the
controller lease and state CAS. Runtime/shipped schema, migration, immutable-
field fencing, earlier-operation compatibility, and byte-preserving status/
Doctor/inspection owners are green.

**Timeout root cause and correction.** Broad unit final-2 timed out at its
unchanged 3,600,000 ms evidence-child bound. The completed final-1 report and a
Git Trace2 diagnostic identified 368 Git processes in one uninterrupted
candidate and five 17-process standalone-identity sweeps. The identity checker
now preserves every path, standalone Git, branch, config, remote, and active-
operation assertion using one combined rev-parse, one exact six-key local-
config query with duplicate detection, one remote query, and direct markers
under the already proven `.git` directory. No timeout, classification, test,
or gate changed. Two slower harness experiments—bounded-parallel fixture
provisioning and a cloned seed repository—were reverted before qualifying
evidence.

**Qualifying evidence.** The exact-tree dedicated fault receipt at
`artifacts/manual/candidate-prepare-session2-fault-matrix-final-5/` passes 9/9
tests with zero skips/todos; its 16-row Node `v24.18.0` matrix is 13 automatic
convergences and 3 preserved ambiguous blocks. Receipt/report/matrix SHA-256
are
`0b09967f47b0f2c09fd97e834cec57818202c881f96fafb9d8d422007e29a2e7`,
`1c4342c8225d7e68009047a038fbc9d7b12e3d53d104696133db777d7d5e64f8`,
and
`3aef037641d2a4a9fa51d53903914872a1a6198d8bfdb4ac661c4db2fc71895c`.
The exact 23-owner receipt at
`artifacts/manual/candidate-prepare-session2-focused-closure-final-4/` passes
56/56 suites and 203/203 tests with zero skips/todos; receipt/report SHA-256 are
`fec242a211b5d305b379acda662c4f5ab11147625e3621f28aed3a1f203027d9`
and
`669852c4070eb48af598845b479db8133a8b9c3c53e2b571b5ec1f543c29b140`.

Pinned final-tree `pnpm test:unit` at
`artifacts/manual/candidate-prepare-session2-broad-unit-final-3/` passes
186/186 suites and 635/635 tests with zero failures/skips/pending/todo in
3,457,613 ms; receipt/report SHA-256 are
`c469776611ad60d1cca228f39cf60159618f32d1caca8cdcdc2b92aebdcf68b8`
and
`13b46bdecc5efb78ebe537bfa760f672e4aa045629fe46e60f8dbff8ebaa335d`.
Pinned final-tree `pnpm test:orchestrator` at
`artifacts/manual/candidate-prepare-session2-broad-orchestrator-final-4/`
passes 184/184 suites and 619/619 tests with zero failures/skips/pending/todo
in 3,373,893 ms; receipt/report SHA-256 are
`484bcc81be31df27f478a43adbaf9428d99e95aa42e4885baa7567ee1cdbb5b8`
and
`8de7d2f485bf80d966df99c2fd6ea695d1728a621f4d31b6d32f36df2ef676d3`.
`pnpm loop:demo-safety` passes 6/6 scenarios; its retained artifact SHA-256 is
`e141e76d7de88d2895e56a8800252c2389bbe8c111bb8c626de20cbdc5b40ce3`.
Final post-document `pnpm typecheck`, `pnpm lint`, and `pnpm format:check`
PASS receipts have SHA-256
`5ba59474a2ec71d943a9ae12111a7c0abc6cc01abcb21b10c9b170a716e9d1f1`,
`21b250e8a5a0921571bdc0df6dad934783db26d137ab78a423534bca7b58ddbc`,
and
`de65188c06f01e578cf371152fbbc84454a2c81b0d150ba9668ef7e14f3a3f0a`;
`git diff --check` passes.

**Integrity and boundary.** Frozen lock hashes equal baseline/active values,
CAL-1 remains `open_not_started`, state and shipped schema are `1.11.0`, and
the untracked human plan remains
`53ea98fb1cb880163a02d3b1d9365963e3fe891025ae3630f00bd4c9232293b1`.
No source no-argument verify, template proof, hidden validation, CAL-1, WP6,
push, or product/readiness work occurred. The exact staged set contained the 22
modified scoped paths plus the new resume-worker owner, no protected path, no
ignored evidence, and not the human plan. Commit: the cohesive local commit
containing this entry; the final handoff names its resulting identity.

## 2026-08-24 — WP2 candidate-prepare Session 2 broad-unit timeout checkpoint

**Safe-boundary outcome.** The final-tree pinned `pnpm test:unit` rerun was
allowed to finish without interruption. It exited non-passing when the
unchanged 3,600,000 ms evidence-child bound expired. Its retained ERROR
manifest at
`artifacts/manual/candidate-prepare-session2-broad-unit-final-2/manifest.json`
spans 3,602,512 ms and has SHA-256
`3d006e241b5745c0d54842e6b31a5211beb4ab754722453e4411eefbe3b3ef1d`;
no test report or PASS receipt exists. The retained candidate matrix has
SHA-256
`dc4750752bb2a5e47537b5c249b046d90dc945653a4f0a5e1edf21661d9762c3`.
This timeout is not credited as passing and its partial output is not used to
infer test totals.

**Changes and prior broad evidence.** The preceding unit attempt at
`artifacts/manual/candidate-prepare-session2-broad-unit-final-1/` completed in
3,532,934 ms but passed only 634/635 tests (184/186 suite entries, 1 failed
test, 0 skipped/pending/todo): the sole failure was a 5,391 ms commissioning
fixture test against the unchanged 5,000 ms bound. That owner now reuses one
repository fixture for its sequential missing/unrelated-base assertions;
focused evidence at
`artifacts/manual/candidate-prepare-session2-commissioning-final-2/` passes
13/13 tests with zero skips and the selected test takes 3,198.799 ms. Two
formerly POSIX-skipped process-tree tests now execute real Windows `taskkill`
tree behavior; focused evidence at
`artifacts/manual/candidate-prepare-session2-process-supervisor-final-1/`
passes 21/21 with zero skips. Before the commissioning edit, pinned
`pnpm test:orchestrator` at
`artifacts/manual/candidate-prepare-session2-broad-orchestrator-final-3/`
passed 184/184 suites and 619/619 tests with zero skips in 3,299,024 ms. The
earlier final-2 orchestrator receipt passed 617/619 with two skips and was
correctly rejected as non-qualifying.

**Candidate evidence and integrity.** The fresh receipt-owning baseline at
`artifacts/manual/candidate-prepare-session2-fault-matrix-final-3/` passes 9/9
tests in 910,272 ms with zero skips/todos. Its independently inspected 16-row
matrix records Node `v24.18.0`, 13 automatic convergences, and 3 preserved
ambiguous blocks; matrix/receipt/report SHA-256 values are
`f14bc61c521690ae902020cbd286c2f1ef41c14acd0baa45a167979949d4500c`,
`ac9bfc211743299c4d2327395a6120b1fff244fcb885927c9485f32d7ef70207`,
and
`2165e47d660dd234439e74bbf1f0132f4a57fb730e0cb989983d4fb1425ede9e`.
The protected human plan remains byte-identical at SHA-256
`53ea98fb1cb880163a02d3b1d9365963e3fe891025ae3630f00bd4c9232293b1`.

**Diagnosis and next action.** No focused semantic failure is known. The
remaining blocker is owner-level runtime attribution: after substantive
Windows supervisor coverage, the serial unit aggregate no longer completed
within the existing one-hour evidence bound. First identify the last completed
and highest-cost removable fixture/teardown boundary, beginning with the
15-minute candidate hard-loss owner and the changed supervisor/commissioning
owners; add a focused performance regression and correct the root cause without
changing tests, behavior, or timeouts. Then rerun both broad commands and all
final static/demo/integrity checks. Commit: none. Candidate-prepare and WP2
remain open; no partial commit, push, WP6, CAL-1, hidden validation,
product/readiness work, source no-argument verify, or template proof occurred.

## 2026-08-24 — WP2 candidate-prepare Session 2 verification checkpoint

**Objective and current outcome.** Continue Session 1 sequentially and finish
the omitted `candidate-prepare` recovery boundary without beginning WP6,
CAL-1, hidden validation, product/readiness work, or unrelated cleanup. State
`1.11.0` now retains canonical redacted Worker-response bytes, regenerates
derived Worker/checkpoint evidence only from canonical authority, safely
resumes only a pre-launch intent, blocks every ambiguous post-launch window,
validates real contained workspace/evidence paths and full Git/policy/Worker
context, fences immutable operation transitions, projects recovery read-only,
and preserves legacy/unowned/conflicting state. The complete hard-loss,
adversarial, repeated-resume, and synchronized two-contender owners are
implemented. This is a verification checkpoint, not closure.

**Performance root cause and correction.** The first broad orchestrator run
at `artifacts/manual/candidate-prepare-session2-broad-orchestrator-final-1/`
hit its unchanged 3,600,000 ms child bound and produced no report or PASS
receipt; its manifest spans 1:18:35.858. A later candidate-only run at
`artifacts/manual/candidate-prepare-session2-fault-matrix-parallel-final-1/`
passed 7/9 and failed two unchanged 60-second cases. Git trace showed that
every durable phase publication rewalked the complete immutable pending-
operation generation lineage after canonical CAS, creating quadratic work.
The state store now treats an exact transition-fenced successor that wins CAS
as inductively lineage-validated in the same mutation-capable store; every
fresh/mutation open still validates the complete chain. Candidate recovery
also avoids redundant same-lease whole-worktree inspections between purely
controller-owned transitions, while every restart, checkpoint preparation,
and commit boundary retains full validation. Child crash execution is real and
uses bounded batching rather than excessive parallel pressure. No timeout,
test, gate, or success definition changed.

**Passing focused evidence.** The pinned receipt command
`node tools/run-tool-evidence.mjs invariant-vitest tools/milestone-orchestrator/src/candidate-prepare-baseline.test.ts --fileParallelism=false`
passed 2/2 reported suites and 9/9 tests with zero failures, skips, pending
tests, or todos at
`artifacts/manual/candidate-prepare-session2-fault-matrix-final-2/`. Its
manifest spans 15:18.984; receipt/report SHA-256 values are
`0d2f061747e2056b35c57ea05d4505a5ea400c56ca699d591e3ff2d48bf993d8`
and
`e12cf3db4771fb9889211860a9691347abb49a3e6ea63366e2415894301de123`.
The synchronized lease/CAS case is included. The separate standalone matrix
output variable was omitted, so a fresh retained 16-row JSON remains the first
unresolved evidence action.

The exact 23-owner command is retained as `displayCommand` in
`artifacts/manual/candidate-prepare-session2-focused-closure-final-3/manifest.json`.
It passed 56/56 reported suites and 203/203 tests with zero failures, skips,
pending tests, or todos. The manifest spans 24:06.836 and the report records
1,435,719.655 ms of assertion time. Receipt/report SHA-256 values are
`c8aa59afee3b15b01d42c60d985bbca284cc75badf56a3bdf4d4f6b626eec9ae`
and
`63850bdb790bcf0e6781a2cff2269638cab6d8db3ede90261236168406519b59`.
It covers candidate/schema/store/status/Doctor/CLI plus candidate identity,
lease, deterministic operations, reconciliation, path safety, lifecycle,
cleanup, retention, and all four earlier operation-recovery kinds. Both
receipts bind dirty iteration evidence to HEAD
`069527e92744149f0041dcaa3c978cf773adace9` / tree
`9972099e5f47a4246961dc81a01f869a4bf4662d` and ran only after pinned shell
assertions for Node `v24.18.0` and pnpm `11.15.1`.

**Other non-passing diagnostics.** The earlier focused owner receipt at
`artifacts/manual/candidate-prepare-session2-focused-owners-final-1/` passed
96/97 tests; its sole stale Doctor expectation was corrected. The first long-
TEMP compatibility run at
`artifacts/manual/candidate-prepare-session2-focused-compat-final-1/` passed
92/115; all 23 failures were Windows fixture path-length setup defects, and
the unchanged 115 tests passed under short unique TEMP at
`artifacts/manual/candidate-prepare-session2-focused-compat-final-2/`. Two
pre-fix filtered checkpoint diagnostics timed out at the unchanged 60-second
test limit; after the lineage correction the same selected test passed in
45,567 ms. Filtered diagnostics have eight expected filter skips and are not
used as qualifying evidence.

**Integrity, commit, and next gap.** The protected untracked human plan remains
byte-identical at SHA-256
`53ea98fb1cb880163a02d3b1d9365963e3fe891025ae3630f00bd4c9232293b1`.
No source no-argument verify, template proof, hidden validation, CAL-1, WP6,
push, or partial commit occurred. Commit: none; Session 2 and WP2 remain in
progress. First rerun the full nine-test candidate owner with a current-tree
`CANDIDATE_PREPARE_FAULT_MATRIX_OUTPUT`, inspect all 16 rows and the expected
13 automatic/3 preserved split, then run fresh typecheck, lint, format,
orchestrator, unit, demo-safety, and diff checks before any closure or cohesive
commit.

## 2026-08-23 — WP2 candidate-prepare Session 1 core authority

**Objective.** Establish executable red evidence for the omitted candidate
checkpoint authority gap, publish durable intent before Worker mutation, and
implement the uninterrupted path plus exact post-checkpoint recovery and the
no-intent out-of-band block. This increment is explicitly smaller than the full
`candidate-prepare` fault matrix and does not close WP2.

**Red baseline.** Exact Node `24.18.0` / pnpm `11.15.1` evidence is retained at
`artifacts/manual/candidate-prepare-session1-red-v5/`. A real child controller
was terminated immediately after the checkpoint commit advanced the workspace
but before checkpoint artifact/state completion; restart entered `verifying`
with no pending intent or Worker call. A separately created valid clean
descendant received the same automatic treatment. The causal observations have
SHA-256
`e7e56ba987b90d02cd86bc36a7f4fd8626f76d4ee2d3657d10b9fa8459ff49ed`
and `1280fdd8eb5282787abafc5ddd7b09a7957a1c0629e709ad1cbaf878b28926d0`.
The intentionally failing 0/2 report has SHA-256
`ef073e2e444d06399c33f5dd7c26974ca6c7325e602783d3e187c303837f504d`
and remains red; earlier setup-defect attempts are retained but not cited as
causal evidence.

**Outcome.** State `1.10.0` adds the fifth strict pending operation, virtual
`1.9.0` migration, phase topology, diagnostics, pure canonical reducers, and
closed-union/schema/status/Doctor coverage. The Worker path persists intent
before gateway invocation, accounts invocation/thread/result inside that
operation, and authorizes a controller checkpoint by exact parent/tree/message
only after Worker completion is durable and policy validation passes. Leased
startup validates and adopts the exact authorized post-commit result through
the same completion reducer as the uninterrupted path. Candidate output with
no intent is preserved as external/ambiguous and cannot reach verification;
this preservation overrides ordinary delete-on-failure policy through the
existing recoverable cleanup reducer. Worker/checkpoint artifacts remain
derived evidence.

**Verification.** The pinned command-owned existing-kind/migration matrix at
`artifacts/manual/invariant-vitest-3240/` passed 30/30 suites and 110/110 tests
with zero failures or skips; its report SHA-256 is
`771031ebc3a00f59677222db459bbcc4ffef09b3b45da77c0823603da3e4d499`.
After strengthening policy-independent preservation, the fresh candidate and
ordinary/crash cleanup matrix at `artifacts/manual/invariant-vitest-16196/`
passed 10/10 suites and 18/18 tests with zero failures or skips; its report
SHA-256 is
`7eb0091f1d03b002b52bd24a22d44c99f6aca02ea020889bade220f0bb082686`.
Final formatted-tree typecheck, lint, and format-check passed with matching
command receipts and declared artifact hashes under
`artifacts/manual/typecheck-9636/`, `artifacts/manual/lint-15348/`, and
`artifacts/manual/format-check-21424/`; `git diff --check` passed. The protected
human plan still has SHA-256
`53ea98fb1cb880163a02d3b1d9365963e3fe891025ae3630f00bd4c9232293b1`.
All four immutable files match both lock hashes, HEAD equals `origin/master` at
`96c3eb2da170da5eed4cf99dc0becf5eb256d138`, readiness remains active, and
CAL-1 remains `open_not_started`. Source no-argument `pnpm verify`, template
proof, hidden validation, CAL-1, and WP6 were not invoked.

**Commit.** Not committed at record time; the final Session 1 handoff must name
the resulting cohesive commit if all remaining static/hash checks stay green.

**Known gaps.** `candidate-prepare` and WP2 remain incomplete. Session 2 starts
with deterministic loss immediately after `after-intent-persisted`, then owns
the remaining Worker/evidence/checkpoint/completion fault boundaries,
concurrent and repeated resume, dirty and Worker-self-commit cases, retry with
prior commits, exact Git/path/protected/policy/artifact/thread adversaries, and
broader orchestrator/unit evidence. WP6, CAL-1, hidden validation, product
implementation, product completion, autonomous readiness, and human acceptance
were not started or claimed.

## 2026-08-23 — WP5 Session 3 hosted CI repair loop

**Failed hosted run retained.** Exact runtime CI run `32638898310`, attempt 1,
failed on candidate `43e609bc6b754bcfee0c3af88a05be68b9e26850` / tree
`3258c1c65835c275b2462eb6dd8f67c346a4d88e`. Controller Linux/Windows,
fresh-adopter Linux, and real trusted-container Linux succeeded; only the
Windows fresh-adopter job failed, while all five unconditional uploads
succeeded. Run/job/check/artifact metadata, five annotation sets, the failed
job log, all five server-digest-matching archives, and safely extracted
contents are retained under `artifacts/hosted/run-32638898310/`. The failed
Windows archive is 9,712 bytes with SHA-256
`4184d3799bdcb5d2b4636425b1d90869e102486318d67f3e02aa5039b9dafbf8`.
The annotation inventory has one failure and zero warnings, confirming that
the prior Node 20 action-runtime warning is closed.

The exact six-command ledger passed `template-create` and `install`, then
`commission` exited 1 for documented argv
`pnpm loop:commission -- --input tools/milestone-orchestrator/config/commissioning-input.json`
from the generated repository with inherited job environment plus `CI=true`.
Manifest add/commit and generated verify never ran; neither `smoke-result.json`
nor `receipt-audit.json` exists. The retained ERROR is not reinterpreted as a
pass.

**Causal reproduction and red invariant.** A no-local/no-hardlink clean clone
of exact `43e609b` was installed frozen with copy imports under Node `24.18.0`,
pnpm `11.15.1`, `CI=true`, isolated writable roots, and a genuine NTFS short
TEMP spelling beneath `C:\w5s3r1\HOSTED~1`. The exact workflow smoke command
reproduced commission exit 1 before manifest or verify. A spawned child probe
retains short cwd/input, while `realpath` and Git report the expanded root;
lexical `relative()` consequently begins with `..` and the unchanged strict
commissioning guard correctly refuses the apparent escape. The 488-byte probe
and 1,852-byte smoke log have SHA-256
`56572f1f931f45e2984d58b4cc2d3418127b44a9e2c90d55070c04bdad5132db`
and `d08520003770cc12dec9fcd4d5f1917e10ee85c360c4f428ad4f6a0667769c43`.

The new root-creation test was then run against old production semantics in
that exact clone. It failed only because
`createCanonicalFreshAdopterTemporaryRoot` did not exist; the other 19 tests,
including all 13 commissioning tests, passed. The 8,852-byte failing Vitest
report at
`artifacts/hosted/run-32638898310/reproduction/windows-8dot3-pre-fix/focused-regression-red/`
has SHA-256
`91d829f2b86846fbb13efe0d6fb65c1337e1e2a8c10d27ff843293b4debd7947`.

**Correction and focused evidence.** The fresh-adopter coordinator now
canonicalizes only its newly created temporary root once, equivalent to
`realpath(await mkdtemp(...))`, before deriving the generated repository. The
regression injects a hosted-style short spelling and requires create-then-
canonicalize call order plus the expanded result. Commissioning
implementation, CLI, and tests remain blob-identical to `43e609b`; no
caller-controlled input, containment rule, command ledger, platform branch,
receipt rule, or cleanup behavior changed. This reuses the existing durable
producer-owned canonical-root decision, so no decision-log entry is added.

Pinned receipt-owning focused verification at
`artifacts/manual/wp5-session3-focused-green-v1/` passed 20/20 tests with zero
failures or skips. Its 7,688-byte report, 663-byte PASS receipt, and 1,533-byte
PASS manifest have SHA-256
`f0f0f30f005ff631d9719d537af43addd6b9e47ac24dae2db205b28f135b5be5`,
`269275fdab68319b2cf37d4afea265f254d7344205170b5b81bb70d13cbeccda`,
and `986f90f199ea89c1433f9600e0faa21dc9114e77969792fef354934c958b718c`.
Pre-freeze typecheck, lint, and format also passed with independently matching
receipts/artifacts under their `artifacts/manual/wp5-session3-*-pre-freeze-v1/`
roots. These dirty-tree runs are iteration evidence only.

**First repair commit and local candidate evidence.** Commit
`812dc9fe90c44688fb6b4558ea5ea14331c82363` / tree
`7922b78332a417056d9a2e389f806f5df4589fb0` contains the canonical temporary-
root repair. An exact clean no-local/no-hardlink clone then passed the real
Windows six-command adopter journey under pinned Node/pnpm and a genuine short
TEMP spelling. The generated three-commit bootstrap repository passed its sole
no-argument verify with 9 stages, 10 valid receipts/manifests, 18 artifacts /
135,779 bytes, and 4 tests. All 38 shared-audit and 51 retained inventory
entries recomputed exactly; the substantive browser screenshot and diagnostics
were inspected and clean. Byte-identical retained evidence is under
`artifacts/manual/wp5-session3-windows-adopter-final/`. Exact-clone typecheck,
lint, and format passed under
`artifacts/manual/wp5-session3-final-local-checks/`.

Two local orchestrator aggregates had one unchanged timing-only nonpass each:
`target-integration-recovery` exceeded its explicit 600-second limit once and
`worked-example` exceeded the default 5-second limit once. Each exact owner
passed immediately in isolation, and both blobs had passed the retained prior
hosted Windows run. No timeout, test, or success definition changed; all four
records are retained under their named `wp5-session3-*` evidence roots. The
normal push of `812dc9f` created only push run `32651184672`; no manual dispatch
occurred.

**Second hosted defect.** In run `32651184672`, fresh-adopter Linux and trusted
container Linux pass. Windows fresh-adopter proves the first correction by
passing template creation, generated install, commissioning, manifest add, and
manifest commit. Its only failure is the production-build stage inside the
generated repository's sole no-argument verify. The exact failed artifact is
12,651 bytes with server- and local-matching SHA-256
`5deb8fb362232dd94b0675c10b286669b0f4d1e2ce3218b01ed71bdfe730347a`
and is safely extracted under `artifacts/hosted/run-32651184672/`.

Direct job evidence places the source checkout at
`D:\a\milestone-loop-template\milestone-loop-template`, its populated pnpm
store at `D:\.pnpm-store\v11`, and the generated repository plus disposable
production-build clone under Node's `C:` temporary root. The fresh-adopter
install explicitly reuses the `D:` source store and passes. The copied
`production-build.mjs` then starts another frozen offline install without a
store argument; pnpm selects by the `C:` workspace boundary and exits 1 before
the build command. Linux passes because checkout and temporary workspace share
one volume. Current failure reporting also discards the preparation stdout and
stderr, which will be corrected without weakening the nonzero failure.

The same run later reached the controller job's outer 60-minute ceiling on
Windows. Invariants and the controller suite had already passed; the retained
orchestrator report has 597 passes, zero failures, and two explicitly Windows-
skipped POSIX process-group tests. The complete unit command started at
`2026-08-23T16:48:49.965Z`, was cancelled at
`2026-08-23T17:17:06.078Z`, and retained an ERROR manifest with no receipt.
Typecheck, lint, and format were consequently skipped; the unconditional
controller upload passed. The 49,231-byte artifact has matching server/local
SHA-256 `69e6801ce22a8e2c37518f02cf4cf5c03d34d6cf816ba8ec7c059623db61f90c`
and is safely extracted under the same failed-run evidence root.

**Second-repair local evidence.** The two new regressions first failed on the
old semantics: production preparation omitted its seeded store (exit 23), and
the generated environment helper was absent. Their JSON reports have SHA-256
`6f4e8f1ba9b7995642b9c45e7227576b1a21c10f2ca9f4091aed661e7887e0a7`
and `f3cadeb764792c88f188cffac39458bfe106d8714960e07f2077e61d40e03f36`.
After correction, all 15 production-build tests pass and the receipt-owning
distributor/coordinator selection passes 16/16 at
`artifacts/manual/wp5-session3-store-repair-focused-v3/`. Exact Node
`24.18.0` / pnpm `11.15.1` typecheck, lint, and format receipts pass and
independently match at their `*-pre-freeze-v2` roots.

An initial broad unit launch was stopped after process inspection proved pnpm
had started package scripts under ambient Node `25.9.0`; it produced no receipt
and is nonqualifying. With the exact Node directory prepended, the sole valid
broad launch passed 182/182 suites and 612/614 tests with zero failures; its two
skips are the declared Windows-only POSIX process-group tests. The 213,584-byte
report's recomputed SHA-256 is
`cbb56f1ce90e007c14417b3601803ccad94a073804c581a3c608c5f633e57122`,
matching its PASS receipt at
`artifacts/manual/wp5-session3-store-repair-unit-pre-freeze-v2/`. The command
took about 57 minutes by itself, directly confirming that the unchanged
controller command sequence cannot reliably fit a 60-minute Windows outer job
bound.

The workflow-contract timeout invariant then failed on the old fixed 60-minute
job with report SHA-256
`34b811f722eb25969f35b5b10e1615e2b2cddda39ca97bdf9c3e063559d45d4a`.
The workflow now retains Linux at 60 minutes and selects 120 only for Windows
through the controller matrix; every command, order, evidence root, internal
supervisor, per-test limit, upload, and success criterion is unchanged. Final
exact-runtime focused evidence passes 21/21 tests with report SHA-256
`82241b660204c493550ca1494ddab866f3a6c1d4091f994f3bf25e98dda4f9b2`
at `artifacts/manual/wp5-session3-store-and-timeout-focused-v2/`. Final
pre-freeze exact Node/pnpm typecheck, lint, and format receipts also pass and
independently match under their `wp5-session3-store-timeout-*-pre-freeze-v2`
roots. One preceding format invocation correctly failed on an unformatted
validator and remains non-passing evidence; Prettier changed only formatting
before those final reruns.

A pre-freeze `test:invariants` launch is also retained as non-passing at
`artifacts/manual/wp5-session3-store-timeout-invariants-pre-freeze-v1/`.
Its protected-integrity owner passed all 13 immutable/readiness checks with a
valid receipt. The next schema entry stopped before Vitest because this shared
working copy's `node_modules` records the earlier custom
`C:\wp5tsr1\pnpm-home\store\v11`, while the trusted invariant child correctly
removes outer store and CI overrides; pnpm refused the resulting non-TTY purge.
This is the already documented operator-preparation mismatch, not a source
regression. Final candidate checks will use a newly installed clean clone whose
default store matches its modules metadata.

**Second repair candidate and third hosted defect.** Commit
`97a94775a0ccbec6393fde15430e42c08b32e8fd` / tree
`10f401c011835819fe90c0ce6a332670bfea4fd0` passed a real local cross-volume
journey with source and store on `D:` and generated TEMP on `C:`. Its nested
production-build report proves store discovery and offline preparation both use
`D:\.pnpm-store\v11`. Independent audit matched all 38 declared and 51
retained inventory entries, 10 manifests, 11 results, the exact six-command
ledger, one generated/zero source no-argument verifies, and the substantive
122,990-byte clean Chrome screenshot. Exact clean-clone invariants passed all
four commands; the controller aggregate passed 597/599 tests with only the two
declared Windows POSIX process-group skips; typecheck, serial lint, and format
passed with exact clean candidate binding. The normal push created only run
`32660428700`.

That run finishes fresh-adopter Linux/Windows, trusted-container Linux, and
controller Linux green. Windows invariants and all 597 controller tests pass;
unit then runs 28 minutes and exits 1 rather than being cancelled. Its
server-digest-matching 78,642-byte archive has SHA-256
`be5ee04ae33af0129a483a75f56e4a356849d0a75941a4be4192bfc7ed4f3d80`
and is safely extracted under `artifacts/hosted/run-32660428700/`. The retained
unit report has 603 passes, 9 failures, and the two declared skips. All nine
failures are `production-build.test.mjs` fixtures resolving nonexistent
`C:\Users\runneradmin\AppData\Local\pnpm\store\v11`; both hosted adopter
production builds pass with real source stores. The production existing-store
guard is therefore correct, while legacy fixtures accidentally depend on an
ambient machine store.

**Fixture-isolation correction.** An exact Node 24 reproduction against
`97a94775` points pnpm at a deliberately absent ambient store and reproduces
the same 6/15 pass, 9/15 fail split. Its 12,610-byte JSON report has SHA-256
`6818a44b1533c3cba1cd54490482dac2fd9ed314038bf444b4b4df849ce44dd0`
under the failed-run reproduction root. Each fixture now creates its own exact
versioned `pnpm-store/v11`, direct executions temporarily install the canonical
`pnpm_config_store_dir` while restoring every prior case variant, and the
spawned evidence-wrapper fixture receives the same sanitized environment.
Production code and its fail-closed store validation are unchanged. The
hosted-missing-store focused rerun passes 16/16 while proving the absent ambient
path remains absent; its 5,422-byte report has SHA-256
`36d340b74f5b357eaf2ec3cefaa251b2dfb4ad2a46603e36cac91c2818cced2e`.
After the final clarity cleanup, the focused owner passes 16/16 again with
report SHA-256
`5d66b9f27cca20631b66713763d0bcaa2d3c5a2e48fcba1bd662185cdd0927a6`.
The exact pinned receipt-owning complete unit suite passes all 182 suites and
613/615 tests with zero failures; its two skips are exactly the declared
Windows POSIX process-group tests. The 213,968-byte report and 484-byte PASS
receipt independently match SHA-256
`f6940d74167fc6a2635d5eca7c77b7e3fa9f644067d4ab6e17244b5add6fb4b3`
and `6d107a7022ffe9b788cbf813cabbc5f689301c7ab44432e2f2638019fef83f8f`
under `artifacts/manual/wp5-session3-fixture-store-unit-pre-freeze-v1/`.
Exact Node `24.18.0` / pnpm `11.15.1` typecheck, lint, and format then pass
serially with independently matching receipts/artifacts under their
`wp5-session3-fixture-store-*-pre-freeze-v2` roots. The report SHA-256 values
are `20d7553aaf6d2c95d7df10c1980b3fd83da80269d54e7494e81f729b06a47159`,
`9c3ce499bc8880beab24cc5068dfc8f78cb8af43eeabf4cb0076b3ef3d32b137`,
and `59bec308c2145302b7cbe21ce6e7179a8f255a539c280a5afcdd012e8d50bff2`.

**Fixture-isolation candidate.** Commit
`97ee125b4ac2ab3f6823862fb9275b0e3297a153` / tree
`9c60d3150dccfc88f4cc947977d5d9ed1b11bb24` contains only the fixture-store
repair and its execution/autonomy records. An exact clean no-local/no-hardlink
clone passed the missing-store owner 16/16 and typecheck, lint, and format with
report SHA-256 values
`43b9fed3bf59296ba6920726d84c2a89d38abda4bda205bd0ea7d50a0db293b5`,
`3b1789ebd4c2a0df74844fb25acc2623e330e7b4933122ba411ffc7e277f8692`,
and `e5eddea6f2afe341a6ec7146726e68430f01307685fadfdc4e9d9fbb054e1412`.
A complete clean-clone unit run passed 611/615 tests, with two declared skips
and two unchanged Windows recovery owners reaching their existing 600-second
limits under local timing pressure; the exact two-file receipt rerun passed
all 6 tests with report SHA-256
`dbe4f86a1a457ca4f80ce967795b27218898415c98315217f0c40f2535f4252d`.
No timeout or owner changed.

The same exact commit passed a real Windows journey with source and store on
`D:` and generated TEMP on `C:`. Independent audit matched 38 declared plus 51
retained inventory entries, 10 manifests and receipts, all six ledger
commands, one generated and zero source no-argument verifies, a clean
three-commit bootstrap history, 9/9 generated stages, and 4/4 tests. The
substantive 122,990-byte Chrome screenshot has SHA-256
`da927d28bc0d2132d4f4e5fe347059d5fb11586452c38c5b40fc9fc808bf0c21`.
The normal push created only Exact runtime run `32673246286`.

**Hosted Linux cleanup defect.** Run `32673246286` proves both fresh-adopter
jobs and the real trusted-container job green. Linux controller invariants and
all orchestrator tests pass. Unit then reports 180/182 suites and 613/615 tests
passed, with one declared POSIX skip and one failure after the adopter-package
assertions: recursive removal of its owned temporary Git repository raises
transient `ENOTEMPTY` inside `.git/objects/pack`. The test took only about 315
milliseconds, so this is teardown rather than production package generation.
The 79,019-byte signed artifact archive has matching server/local SHA-256
`c6f53d0ebe926e8b7ffcf0438cdf60e561b776695f6cd020e7e55682008dc6a4`
and is safely extracted under `artifacts/hosted/run-32673246286/`. No rerun of
the unchanged SHA occurred.

**Owned-fixture cleanup correction.** A deterministic injected `ENOTEMPTY`
first failed on the old single-attempt teardown. Its 3,704-byte red report has
SHA-256
`5952ead2374fbd25e5cf6fabb11db73c67e554345a74cb6cf1ca6b55bfe71208`.
Only `adopter-package.test.ts` teardown now retries its owned temporary roots
for the named transient recursive-removal codes with five bounded retries and
linear delay. Permanent failures rethrow on the first attempt, and persistent
transient failures rethrow after six total attempts. Package generation, Git
semantics, production cleanup, workflow commands, timeouts, and receipt rules
remain unchanged. Receipt-owning focused evidence passes 7/7 tests with report
SHA-256 `782ba5b08e94fd762396703340d955e5337892ba85659a6a6a6d6f342e9a6506`
under `artifacts/manual/wp5-session3-linux-cleanup-focused-v2/`. This is test
harness hygiene under the existing bounded-transient-retry policy, so it adds
no durable product or architecture decision. After the final regression and
records, exact Node/pnpm typecheck, lint, and format each pass with report
SHA-256 values
`4d838f11875a69cc73cbd612cc55c10ab3ea562c3276c5da904cf43cbc387c40`,
`a92393f74448ab5af8f4bf30a674d182d5295856c510471ba2b5d2d331d2b53c`,
and `239e8fcea2cca53dd3c05f314590bb64ceb24fc78600d452d1d2f669fb8b1dba`.

**Final candidate and hosted closure.** Cleanup-repair commit
`0c67ac062693369345bd1efa0435ec3d70d9b476` / tree
`5fee03becf6a43024fb3de71fec0cf8c91d9c77a` passed the exact clean
adopter-package owner 7/7 plus receipt-owning typecheck, lint, and format under
Node `24.18.0` / pnpm `11.15.1`. Its real Windows cross-volume adopter journey
passed the ordered six-command ledger, sole generated no-argument verify, all
9 stages, 10 receipts, 18 declared artifacts, 4 tests, clean three-commit
bootstrap history, substantive browser inspection, and independent inventory
audit. Source no-argument verify count remained zero.

The sole normal push created Exact runtime CI run `32676400762`, attempt 1.
Controller Linux/Windows, fresh-adopter Linux/Windows, and trusted-container
Linux all completed successfully on that exact SHA. Every required step and
unconditional upload succeeded; all five check runs had zero annotations and
no Node 20 warning. The five archives match their server SHA-256 values and
were safely extracted under `artifacts/hosted/run-32676400762/`. Both
controllers prove the complete invariant/controller/unit/typecheck/lint/format
sequence with zero failures and only their declared platform skips. Both
generated adopters prove the clean three-commit bootstrap journey, exact
receipt/artifact inventories, substantive screenshots, and clean browser
diagnostics. The trusted-container artifact proves a real Docker daemon, no
host fallback or mock, the passing normal/boundary cases, and all four expected
adversarial dispositions with zero managed residue.

Independent audit
`artifacts/manual/wp5-session3-final-audit/audit-result.json` is `PASS` and
records `wp5HostedCiQuickstartClosed: true`. At audit time,
`HEAD == origin/master == 0c67ac0`, tracked bytes were clean, the protected
human plan was the only untracked entry at its expected SHA-256, readiness and
CAL-1 state were unchanged, and every immutable baseline/active/actual hash
matched. WP5 hosted CI and documented fresh-adopter quickstart validation are
therefore closed. This is not autonomous readiness or product completion; no
source no-argument verify, template proof, CAL-1, hidden validation, WP6, or
product/readiness expansion occurred. The separately identified omitted
`candidate-prepare` recovery boundary belongs to a new bounded increment.

## 2026-08-22 — WP5 Session 2 frozen-candidate isolation correction

**Passing adopter journey.** Separator-repair candidate
`731965fc65b1359ee77dc999b0e90abe3bbe2c9f` / tree
`8f9021647a7f854f827a5646f0c26b0554de6725` passed its only real Windows
journey at `artifacts/manual/wp5-session2-windows-adopter-final-2/`. The exact
six-command ledger created the package, performed the offline frozen copy
install, commissioned and deterministically committed the sole manifest, and
ran literal generated-repository `pnpm verify` once. The generated candidate
`005a04729e014a8751f49f91c77a3f9b5f54e699` / tree
`8eb55ffa048900984aa8a08a09113e87fa344bab` is clean on `main` with exactly
three commits, bootstrap default, and no readiness marker in its tree or
history. Source no-argument verify invocation count remained zero.

The generated verifier passed 9 stages, 10 receipts, 18 declared artifacts /
136,233 bytes, and 4 tests. The retained copy contains 51 files / 210,556
bytes. Independent recomputation matched all 38 audit inventory entries and
all 51 retained inventory entries. The 5,346-byte smoke result and 20,965-byte
shared audit have SHA-256
`3381aa812e4e9eab494a0711e848a0ba9ec8e01190cead58477b1c1ec30a6d54` and
`1d014fd9e02c4bc5f2659c8e24f150950477a95b7cc9d6b41e40b1fb45bd4ca0`.
The 122,990-byte screenshot has SHA-256
`da927d28bc0d2132d4f4e5fe347059d5fb11586452c38c5b40fc9fc808bf0c21`,
visibly reports three worker ticks and four extracted units, and its browser
diagnostics contain no console errors, page errors, or request failures. This
is bootstrap completion only and is explicitly not autonomous readiness.

**Non-passing broader launch.** The candidate's only
`pnpm test:invariants` invocation, from a clean no-local/no-hardlink exact
clone, retained a truthful failure under
`artifacts/manual/wp5-session2-final-invariants/evidence/`. Its first
protected-integrity entry passed all 13 contract checks with a valid receipt.
The next schema entry stopped before Vitest because the clone's dependencies
had been installed against
`C:\wp5tsr1\pnpm-home\store\v11`, while the trusted nested child correctly
removed the outer `npm_config_store_dir` and `CI` overrides; pnpm therefore
refused to purge the mismatched modules directory without a TTY. The
3,243-byte FAIL invariant report and 8,736-byte ERROR manifest have SHA-256
`bdcbba261dced4f8fb542a0e2f4b4caac377ba229068e452376f87e716d4c8ab`
and `4974498b41e7946981789bf0825ebf5fe7d5330747b464a3634d2322af453c78`.
The other five broader commands were not launched. The failure is neither
rerun nor relabeled.

**Preparation correction.** A new disposable no-local/no-hardlink exact clone
installed directly against pnpm's default
`C:\Users\duncan\AppData\Local\pnpm\store\v11` with copy imports and no
downloads. With both `CI` and `npm_config_store_dir` then absent, its exact
pinned pnpm successfully crossed the dependency-status boundary and reported
`vitest/4.1.10 win32-x64 node-v24.18.0`. This proves the preparation correction
without changing product, verifier, or invariant code to accommodate an
operator-created store mismatch.

**Commit and remaining gates.** Assigned by this causal record commit, which
becomes the second replacement candidate without rewriting prior commits. It
still requires one fresh retained Windows adopter journey and all six broader
commands exactly once from newly prepared default-store clones. WSL still has
no exact Linux Node/pnpm/browser boundary, the hosted matrix remains Session 3,
and no autonomous-readiness claim is made.

## 2026-08-22 — WP5 Session 2 documented pnpm separator repair

**Causal failure.** The first and only real journey on candidate
`d16bab91e8e1405c9b97aa572dc8fe9a168ea65d` / tree
`55dcc993ada05d17914313a50d0838326d9b0cec` failed before generated-repository
creation. Pnpm correctly invoked the documented creator form as
`tsx .../adopter-package-cli.ts "--" "--definition" ...`, but the CLI parser
treated that leading script-argument separator as an unknown option. The same
parser shape existed in commissioning, so merely changing the smoke's creator
argv would have hidden the documented commission defect and would not execute
the advertised quickstart. The failed candidate is non-passing; no broader
command ran.

Retained nonqualifying evidence is
`artifacts/manual/wp5-session2-windows-adopter-final/logs/`. Its 688-byte
creator stderr and 46-byte lifecycle stdout have SHA-256
`dc856729ce4c01e2742eb345555c8bc94164bf3739f15bbade8ba8e1cf29ec2f` and
`70691ee46df8bffd84dd117eb9297af7108f7fc0b6be5f63d6cb30aef0d605b5`.
The coordinator removed its temporary root and preserved source identity; no
smoke result, bootstrap receipt, or completion claim was emitted.

**Correction.** `parseAdopterPackageCliArguments` and
`parseCommissioningCliArguments` now strip exactly one leading `--` before
their unchanged strict option loops. Invocation without a separator remains
accepted for internal callers. A duplicate or later separator still reaches
the existing unknown-option failure; missing values, duplicate options, and
unknown flags retain their prior failures. Production package generation and
commissioning logic are byte-identical. This is the smallest repair that makes
the exact documented `pnpm <script> -- --option` forms executable rather than
rewriting the smoke ledger or weakening arbitrary option handling.

**Focused verification.** Under pinned Node `24.18.0` and pnpm `11.15.1`, one
receipt-owning serial invocation covered the fresh-smoke plan, shared bootstrap
audit, adopter package, and commissioning files. All 10 reported suites / 28
tests passed with zero failures or skips. The 10,499-byte report, 819-byte PASS
receipt, and 9,320-byte PASS manifest at
`artifacts/manual/wp5-session2-separator-repair-focused-1/evidence/` have
SHA-256
`85eb1fda55296ac0121a2f87e19c485bdba0abad2ba5cca3218a02f9ef352a53`,
`98fd9728bfc9287fddda881ce574e09662c6cc50c3910577413af0cf004e991a`,
and `612e6ee1719e00ab1f9cffce7fe2e18e5fde955e8b5e1ed7db1a51ba79c24fa6`.
Direct targeted ESLint and Prettier checks passed. Direct telemetry again
degraded honestly to null at the source `.js` projection boundary; receipt and
artifact evidence remain valid and independently inspectable.

**Commit.** Assigned by the cohesive separator-repair commit containing this
entry; no push. It supersedes the failed candidate without rewriting either of
the two primary Session 2 increment commits.

**Known final-session gates.** The replacement committed tree still requires
one successful Windows adopter/browser journey and the six once-only broader
checks. WSL inspection found no Linux Node, pnpm, or Chrome/Chromium boundary,
so local Linux parity is unavailable and remains an explicit Session 3 hosted
matrix obligation. No autonomous-readiness claim is made.

## 2026-08-22 — WP5 Session 2 Node 24 official action pins

**Objective and provenance.** Replace all nine repeated Node 20-metadata
action pins without changing application Node `24.18.0`, pnpm `11.15.1`,
workflow trust, scheduling, command, or evidence boundaries. Official GitHub
`releases/latest`, Git tag objects, exact commit metadata, and release migration
notes were inspected for `actions/checkout`, `actions/setup-node`, and
`actions/upload-artifact`. Each selected tag currently resolves directly to a
commit rather than an annotated tag object; the resolver procedure explicitly
dereferences annotated tags when present. Exact `action.yml` at every selected
commit declares `runs.using: node24`.

**Outcome.** All three jobs now use checkout `v7.0.1` at
`3d3c42e5aac5ba805825da76410c181273ba90b1`, setup-node `v7.0.0` at
`820762786026740c76f36085b0efc47a31fe5020`, and upload-artifact `v7.0.1`
at `043fb46d1a93c77aae656e7c1c64a875d1fc6a0a`. The executable contract has
one central release/repository/SHA allowlist, requires each exact reference and
comment three times globally and once per job, requires nine full-SHA action
references total, and rejects the three old SHAs, mutable tags, short SHAs,
mixed full-SHA versions, missing occurrences, wrong comments, and any action
outside the allowlist. It also now explicitly counts three
`persist-credentials: false` settings, unconditional uploads, and
`if-no-files-found: error` settings while preserving the existing history,
runner, toolchain, command, root, independence, and real-Docker checks.

The durable migration record in `docs/decision-log.md` links only official
GitHub releases and exact repository metadata. It records the Node 24 minimum
Runner `v2.327.1`, checkout credential/fork-trigger changes, setup-node cache
and ESM changes, and upload-artifact's optional direct-upload behavior. None is
selected in a way that changes this workflow: credentials remain disabled,
the affected checkout event types are absent, no setup-node cache input is
used, and evidence directories retain default archived upload.

**Focused verification.** Under pinned Node `24.18.0` and pnpm `11.15.1`, one
receipt-owning serial invocation passed the workflow contract's 2 reported
suites / 5 tests with zero failures or skips. The 2,454-byte report, 640-byte
PASS receipt, and 9,137-byte PASS manifest at
`artifacts/manual/wp5-session2-step5-focused-1/evidence/` have SHA-256
`c5a90eeefa4889bf80c9c97797156aedf861229f676f010d05fe773ba13f3dee`,
`18aef769fcd5037ec59211679ecbc7c4ddef38a03c025b40981bae15411095bb`,
and `fd5e0d74e99596cab8d2aa3a521190d10fe8e994b0d7ae3e367a23bbddecfa62`.
Direct targeted ESLint and Prettier checks passed. As in Increment 4, direct
telemetry initialization was honestly non-semantic/unavailable at the source
`.js` projection boundary and the command-owned manifest records null
telemetry; receipt and artifact validation are unaffected.

**Commit.** Assigned by the cohesive action-migration commit containing this
entry; no push.

**Known final-session gates.** Step 4 is committed at
`4cab466851160c0adba155032724c28f08ba99c3` / tree
`e830ef8331191f26bc7a2d4597fbd743f45dcccd`. After this action increment is
committed, that exact combined tree becomes the Session 2 candidate for one
real Windows adopter journey and the six once-only broader checks. No hosted
workflow is triggered here; Session 3 owns final Linux/Windows/Docker hosted
validation. No autonomous-readiness claim is made.

## 2026-08-22 — WP5 Session 2 full-quickstart adopter smoke

**Objective and baseline.** Close WP5's documented-quickstart coverage gap
without rerunning the retained WP4d package proof, invoking source no-argument
verification, or duplicating generated typecheck/unit execution. Fresh fetch
confirmed `HEAD == origin/master ==`
`dbf70e9b730f4e44f81862e159e127c252f64fd6`, tree
`266f9b23432bd297cc027395b490db9ad82f39c4`, and zero divergence. The latest
public starting-state Exact runtime CI run `32616522784` passed all five jobs
on that exact commit. The existing `fresh-adopter-ci-smoke.v1` stopped at a
clean two-commit repository and separately audited only generated typecheck and
unit receipts, while the README additionally required commission, manifest
add/commit, and literal no-argument verification.

**Outcome.** `fresh-adopter-ci-smoke.v2` has one pure, exact six-command plan
and one versioned ordered execution ledger: documented public creator from the
source checkout; generated offline/frozen/copy-mode install bound to the
source-cwd store; one generated commission; exact manifest add; deterministic
manifest commit; and one literal generated-repository `pnpm verify`. The plan
rejects wrong order/count/argv/scope and any source-level no-argument verify.
Commissioning must report only `.agent/verification-manifest.json`, and its
bytes/SHA-256 plus the complete untracked/tracked/staged surface are checked
before the commit. Fixture Git identity and the definition-derived third
timestamp are verified with the requested branch, exactly three commits, a
clean tree, bootstrap default, and no readiness marker in tree or history.

The coordinator copies the complete verifier run before temporary cleanup,
byte/hash-compares the source and retained inventories, then calls the existing
`auditBootstrapVerification` owner on the retained copy. That shared audit
requires bootstrap status/profile/claim, both candidate captures, all nine
ordered stages, every command receipt/manifest/artifact identity, at least four
passing unit tests, a substantive screenshot, and clean browser diagnostics.
The old standalone typecheck/unit launches and their weaker two-receipt audit
are removed because those same production boundaries are now mandatory within
the shared aggregate audit. README and repository-contract prose describe the
new bootstrap/non-readiness distinction accurately.

**Focused verification.** Under pinned Node `24.18.0` and pnpm `11.15.1`, one
receipt-owning serial invocation of `invariant-vitest` passed all 4 reported
suites / 11 tests with zero failures or skips across
`fresh-adopter-ci-smoke.test.ts` and `adopter-package-proof.test.ts`. The
4,204-byte report, 693-byte PASS receipt, and 9,259-byte PASS manifest at
`artifacts/manual/wp5-session2-step4-focused-1/evidence/` have SHA-256
`07beb77c334e0951a60a2acd6dd4cf39ab1f6170a92481f7ae51761f97c713ec`,
`2c7e8b2da78f592f219eafc1480f1d06fc71011017f8626c74a3003a06be68b6`,
and `428050b562b6a795dfa6ddc6dea1e68c6b19e1bcaa38055450d547f1a46ea59f`.
Mutations cover wrong command order/count, ledger drift, source verify, dirty or
two-commit repositories, readiness history, missing/tampered receipts,
tampered artifacts, wrong candidate identity, and absent screenshots. Direct
targeted ESLint and Prettier checks also passed. Telemetry initialization was
honestly non-semantic/unavailable because the direct loader could not resolve
the source `.js` projection for `path-safety.ts`; the valid command-owned
manifest records null telemetry rather than claiming a telemetry receipt.

**Commit.** Assigned by the cohesive Step 4 commit containing this entry; no
push.

**Known final-session gates.** Per the frozen Session 2 cadence, the expensive
real Windows create/install/commission/commit/verify/browser journey runs once
only after the action-pin increment and all tracked records are committed. The
Node 24 action migration, final broader checks, ignored final audit, and hosted
Session 3 matrix remain open. POSIX supervision, CAL-1, hidden validation,
product breadth, autonomous readiness, and human verification remain out of
scope; no readiness claim is made.

## 2026-08-22 — WP5af canonical verification-clone fixture roots

**Objective and cause.** From exact clean WP5ae, reproduce the two remaining
historical verification-clone failures while preserving production clone/Git
and strict path behavior. Unchanged source reproduced one pass/two failures:
the first two cases passed shared `repository()`'s raw
`milestone-loop-clone-source-*` spelling to strict candidate inspection; the
derived-junction case correctly stopped earlier at the linked-root guard and
passed.

**Baseline and source-root proof.** Exact no-local/no-hardlink clone
`C:/wp5af1b/repo` at WP5ae
`37f5be3a4d97c77878dbcae03b3739cbb74b61fd` / tree
`cb099e63a733e5ccff98a3f0937e232bb00c6852`, pinned Node `24.18.0`, pnpm
`11.15.1`, no alternates, isolated store, and distinct
`WP5AFB~1`/expanded TEMP reproduced 1/3. Its 2,998-byte report, 8,615-byte
ERROR/no-receipt manifest, and 1,153-byte telemetry manifest have SHA-256
`199cafc444d3287e59afc58e389502bdd82c5852e262e7599f69ec31bfab4bf1`,
`b30c8978348d5a2939acbcfb94d94e64a87df2f85ed93c010c35205749309150`,
and `7ea9ea7979308803e5d7215c92c754dc3e0ff13bd3de52c7b92ee1cf51e81c1d`.
Assertion-only tree `3d2c8e1c76d132710aaf207a78ede21a7666aa0b` imported promise
`realpath` and asserted `expect(await realpath(root)).toBe(root)` immediately
after shared creation. All three cases failed there before registration or Git
setup; the third is explicitly proof-only localization because its baseline
production input is the derived junction. Its 3,081-byte report, 8,626-byte
ERROR manifest, and 1,159-byte telemetry manifest have SHA-256
`30e076b314f484c74e3be29857e573a7c1b2a72571c6298620af85b85e835696`,
`83245135417ea6e4acfa7c8c80f0851ba380a6e7844e463ebba6ad3d14970168`,
and `f7d9cdafb336f95d86e082c6cc941a9500500af6f9db4b3c7ad98d81536dbccc`.
Initial red roots are
`artifacts/manual/wp5af-verification-clone-{red,owner-red}/`.

**Downstream proof and disposition.** Canonical source-root tree
`5357fd6b9283465f113d6557fa05f3838679d771` reached 2/3. The cloning case
then rejected the omitted option's pre-existing default `tmpdir()` spelling as
an unstable `Verification temporary parent`; dirty/mismatch and junction
controls passed. Its 2,202-byte report, 8,618-byte ERROR manifest, and
1,155-byte telemetry manifest have SHA-256
`bb882d3118125953bfcbc89d0408df98f159f0b79fd468bf3af6a9ff76831223`,
`3f8a2d16b9e45a24aa8c02e915cea695b18ca7fcdc8bd7d1452f71bcefafa3b9`,
and `55fbd9ed32515cda2585cc59a5be506d0a3c2123d97b154ea5efb0736679ffaa`.
Production does not create that parent, so its strict guard and the
caller/environment path remain unchanged. Instead, assertion-only tree
`58c8a713fbe5d8b641c5af9975e505f7b3db810c` supplied an explicit raw
fixture-owned `milestone-loop-clone-parent-*` to the first case and asserted
its equality before registration or the production call. Exactly that case
failed; both controls passed. Its 2,027-byte report, 8,628-byte ERROR manifest,
and 1,160-byte telemetry manifest have SHA-256
`e1ab5b4f0ebd66f6a11d586cfd71556a217e81a3a2443a8e168b87d5186b545c`,
`8304c8902f1541b47534212a49c611a25cd5aa0b0777974fab931637baec7653`,
and `4465020f4f93e45cf68cbc3beae60ddf86ab6accf028ca3d07780d7495454b77`.
These roots are
`artifacts/manual/wp5af-verification-clone-{temporary-parent-red,temporary-parent-owner-red}/`.

**Correction and verification.** Shared `repository()` now canonicalizes only
its just-created source root and retains its assertion. The first cloning case
creates, canonicalizes, asserts, registers, and explicitly passes its own fresh
temporary parent. Production `verification-clone.ts`, default/caller paths,
Git checks, cloning, cleanup, and link guards are byte-identical. Corrected
tree `15355fb65128893074d86ed489a8add59a9e69f3` passed Windows 3/3,
zero skips. Its report/receipt/manifest are 1,647/603/8,865 bytes with SHA-256
`ab8371d0f502fc62cf6badeebed09faac16a69f8a478e156a8d22886e311d9d0`,
`bb23ce4ed10fe4c5e65be2d9a333e48727e7859b05bb0e7f233e438d6cd27800`,
and `0966f8794dc3dfc571bd584df4036dc36f3fd719ac7e02db320895b343d9dd11`.
The identical full file passed WSL2 ext4 3/3; its report/receipt/manifest are
1,661/603/8,825 bytes with SHA-256
`73f570df5b2e1321d30ff3709f0b102190f19bf6f5e7627e3292bd97a890b332`,
`d6b4caee4eb3ce6cbb11b2550e7c8c48221d4aa50ac468c88f630d34f3b6a22e`,
and `e1d14e1f78834a577605d9a0cf1a212c9dc2a5611aa20bcf1cccb1d0f50655ad`.
Green roots are
`artifacts/manual/wp5af-verification-clone-{windows,linux}-green/`; bindings
and source blobs match. No decision record is needed.

The retained hosted-Windows focused inventory is now exhausted. The next step
is to commit this owner, freeze all tracked Session 1 records, and run the six
required broader commands exactly once from isolated identical Windows clones.
Focused Linux ext4 parity exists for every changed owner.

**Commit.** Assigned by the cohesive WP5af commit containing this entry; local
and unpushed.

**Known gaps.** Frozen broader checks, POSIX `setsid`, CAL-1, hidden
validation, product breadth, readiness, and human verification remain open.
No completion or readiness claim is made.

## 2026-08-22 — WP5ae canonical container-artifact fixture roots

**Objective and cause.** From exact clean WP5ad, reproduce the four historical
container-artifact failures, prove shared `root(prefix)` before changing it,
and preserve publication, inventories, strict link/containment guards, and
independent/combined quotas. The complete file reproduced one pass/four
failures: all filesystem cases used raw `milestone-loop-export-*` roots whose
NTFS 8.3 spelling disagreed with promise `realpath`; the path-free combined
quota case passed.

**Evidence.** Exact no-local/no-hardlink clone `C:/wp5ae1b/repo` at WP5ad
`b6aad15fb5d2f32471503092a2b5d375e9076a3b` / tree
`0c30ff54851e12d824454a71e84472a58f8050ec`, pinned Node `24.18.0`, pnpm
`11.15.1`, no alternates, isolated store, and distinct
`WP5AEB~1`/expanded TEMP reproduced 1/5. Its 5,159-byte report, 8,617-byte
ERROR/no-receipt manifest, and 1,154-byte telemetry manifest have SHA-256
`0430857911ff3d037b0a0bba9690a4e80438072e0340a400286a8b71c49250ae`,
`d25b6c5857e6cfcb49772c97d79c6c8cd84749bb90aea3cd69054360689586d9`,
and `2b2d29a526222bd39690ec67ee18444509f0af81e8c25844971c385601684482`.
Assertion-only tree `66ad885c9cfdc19f5b3a44996275ca61ebc6304c` imported promise
`realpath` and asserted `expect(await realpath(value)).toBe(value)` immediately
after creation. All four filesystem cases failed directly there before root
registration or artifact inventory/publication; the path-free case remained
passing. Its 4,133-byte report, 8,629-byte ERROR manifest, and 1,160-byte
telemetry manifest have SHA-256
`cfc4a82e96b0c5e7bcfeadd5fe6701d03ed761c36fbbc8462c28cb476ac511e9`,
`dc716573f1f566d77aa7a2170290582e5125e067db1720301a142e806a9826b9`,
and `e37520a4e00378f95c64d67c267de4c9f07fc85e6b370e4081adfc2e5b3a60e2`.
Red roots are `artifacts/manual/wp5ae-container-artifacts-{red,owner-red}/`.

**Correction and verification.** Only shared `root(prefix)`'s fresh value now
uses `realpath(await mkdtemp(...))`; the assertion remains. Production
artifact inventory/publication, stable-root and link guards, containment,
quotas, and caller paths are byte-identical. Corrected tree
`d377ae2cca1620fbd42293d606f81f8f44e9521d` passed Windows 5/5, zero
skips, including symbolic-link/junction, hard-link, substituted-parent,
linked-ancestor, and quota behavior. Its report/receipt/manifest are
2,262/604/8,868 bytes with SHA-256
`573be220bd552b2a9e4cfd7b6f0c10fdbd29bc94b8e4441bba1bab5f227c4eff`,
`54f644d0a3b5173f17bf9e1584bcb6a7b9131dde6a45f7ed6bbcb5638653c2bb`,
and `3e2d7fdcf41fb26c14af34cd5537fc5eec7467128a2970a15b7762693cc4ec8a`.
The identical full file passed WSL2 ext4 5/5; its report/receipt/manifest are
2,269/604/8,828 bytes with SHA-256
`ccbefd998c8fce17fb64b646bbdc75c07574268f39f016d7e954f929041d91bd`,
`6911219ee6ef3879c56a80bf3a20c80b1ab8e552fd57746a284ff030aec8c133`,
and `cbc72fed967065d7a2cee8437b6508b34c68ff180f8e35e947c3c49c59b6a66f`.
Green roots are
`artifacts/manual/wp5ae-container-artifacts-{windows,linux}-green/`; bindings
and source blobs match. One nonqualifying baseline setup install inherited the
source cwd; it ran no test, wrote no evidence, changed no tracked byte, and
left source dependencies bound to the established store. One owner-clone
setup process could not start because its not-yet-created cwd was selected;
it made no filesystem change. No decision record is needed.

Next is historical `verification-clone.test.ts` at `1786995311714`: one pass
and two failures. The first two cases pass shared `repository()`'s raw
`milestone-loop-clone-source-*` root to strict candidate inspection. The third
creates the same source but passes a derived junction to the linked-root guard
and historically passes. It remains open for exact current reproduction and
direct proof.

**Commit.** Assigned by the cohesive WP5ae commit containing this entry; local
and unpushed.

**Known gaps.** The verification-clone file, frozen Windows aggregate and
broader checks, POSIX `setsid`, CAL-1, hidden validation, product breadth,
readiness, and human verification remain open. No completion claim is made.

## 2026-08-22 — WP5ad canonical deterministic-operations fixture root

**Objective and cause.** From exact clean WP5ac, reproduce both historical
deterministic controller-operation failures, prove `deterministicFixture()`
before changing it, and preserve status/dry-run inspection, lease exclusion,
Git setup, configuration, state, and reconciliation semantics. Both cases were
0/2 because the raw `milestone-loop-deterministic-*` root retained its NTFS
8.3 spelling while strict orchestrator Git-root inspection resolved the
expanded identity and rejected the mismatch as an unsafe Git root.

**Evidence.** Exact no-local/no-hardlink clone `C:/wp5ad1b/repo` at WP5ac
`1836a5da5a3e0c287aa5b874bf4fa2c6fd299013` / tree
`283c6f1155841cd71df3797eb3fb79bb58a0005a`, pinned Node `24.18.0`, pnpm
`11.15.1`, no alternates, isolated store, and distinct
`WP5ADB~1`/expanded TEMP reproduced 0/2. Its 2,781-byte report, 9,030-byte
ERROR/no-receipt manifest, and 1,157-byte telemetry manifest have SHA-256
`2e78078b357f2a0cb9c9312523f7e18759f50175709e9bde632e15fd9ad4562f`,
`3e52627db6557139afac4a58f02227d2988758d9f03e2ecdeeda10f7cecf2765`,
and `b8f6ee2a43a343971fe9c33f45eb61f5b97909b8029e095e2fcf060973ca0e3f`.
Assertion-only tree `dd32c85d060fee56c07f3cccde69e70ae53e0707` imported promise
`realpath` and asserted `expect(await realpath(root)).toBe(root)` immediately
after creation. Both cases failed directly there before root registration,
protected/config file creation, Git initialization, or orchestrator open. Its
2,334-byte report, 9,022-byte ERROR manifest, and 1,154-byte telemetry
manifest have SHA-256
`2514398330fb0f4035bdec19bf285a757c843a288e83abd08000fbd80370ebb3`,
`5e1a40a73d5dd0194e4f9fd83a899f07ff10e9283a2f66f93adffac61777f9bb`,
and `3513d07fa755ce43e7debae80e39a0f9488c28f0610df19c7800cae5c44ce73b`.
Red roots are
`artifacts/manual/wp5ad-deterministic-operations-{red,owner-red}/`.

**Correction and verification.** Only `deterministicFixture()`'s fresh root
now uses `realpath(await mkdtemp(...))`; the assertion remains. Production
orchestrator/Git/lease/state/reconciliation code and caller paths are
byte-identical. Corrected tree
`7e75d91da01463701f7a7f5bd5025e0edc544581` passed Windows 2/2, zero
skips. Its report/receipt/manifest are 1,331/609/8,861 bytes with SHA-256
`4f0c982c0272683ebf91f8d3fa5864395ec26a9179341acb34f710a0964dbf55`,
`abe4e112ba74c13a09cc1e9b1c1654f889850cafc3a3e14da4f3573fa2248bfa`,
and `bee4de455f9fa74fe5f49495fdf1ab4cb13eb415d4dd63beeda1ba8d3c26eccf`.
The identical full file passed WSL2 ext4 2/2; its report/receipt/manifest are
1,353/609/8,821 bytes with SHA-256
`f4c52e9170c11de1f98bc2c6c7dca70b375ea2d7fb13ad1fd316787769543ead`,
`32e1d56c98e9d4ea2f42b54e368f273f49d454952c6d399a3a652afd04cf09b4`,
and `b8b97bbec5e4553c6cec7dd32d124836052f23371f597d9a1fcc07da94972fa4`.
Green roots are
`artifacts/manual/wp5ad-deterministic-operations-{windows,linux}-green/`;
bindings and source blobs match. The Linux setup had three nonqualifying
wrapper exits before the test: one quoting loss created no clone, one pnpm
install stopped for missing `CI=true`, and one post-install version probe
received a carriage-return option. The exact clone remained clean, the CI
install completed, and none of those setup attempts created command evidence.
No decision record is needed.

Next is historical `container-artifacts.test.ts` at `1786995304153`: one pass
and four failures. The first four cases share raw `root(prefix)` fresh
directories that cross strict artifact path checks; the fifth combined-limit
case creates no filesystem root and passed. It remains open for exact current
reproduction and direct proof.

**Commit.** Assigned by the cohesive WP5ad commit containing this entry; local
and unpushed.

**Known gaps.** Remaining artifact/verification-clone files, the Windows
aggregate, final broader frozen-candidate checks, POSIX `setsid`, CAL-1,
hidden validation, product breadth, readiness, and human verification remain
open. No completion claim is made.

## 2026-08-22 — WP5ac canonical retention-apply recovery fixture directory

**Objective and cause.** From exact clean WP5ab, reproduce both historical
retention hard-loss failures, prove `preparedFixture()` before changing it,
and preserve the crash worker plus production retention/state/schema/lease
semantics. Both cases were 0/2 because the raw
`milestone-loop-retention-<label>-*` directory fed short metadata and derived
repository paths to the worker; its first retention persistence rejected the
pending operation as schema-invalid.

**Evidence.** Exact no-local/no-hardlink clone `C:/wp5ac1b/repo` at WP5ab
`2dcca3ad78394ba01d1a410587383ceabf2cb87b` / tree
`c17c5f0a6b3af174d8ad7b919e2aef135feb775f`, pinned Node `24.18.0`, pnpm
`11.15.1`, no alternates, isolated store, and distinct
`WP5ACB~1`/expanded TEMP reproduced 0/2. Its 4,099-byte report, 9,034-byte
ERROR/no-receipt manifest, and 1,159-byte telemetry manifest have SHA-256
`06284483e4e3d19a7b5254424b8caa40d018f3e3f492a6c46e0d783e224f6fbd`,
`b9e2aa46cc7f9d03f204b12237184242543c26fbc4eacf7a26e76f176df3425f`,
and `d4a99c6c99768dd034c7d8db7d1d967fac376573db067ac091f2d4819b2740ef`.
Assertion-only tree `1853c6787addcb9cadc39c94f935f368810826fb` imported promise
`realpath` and asserted `expect(await realpath(directory)).toBe(directory)`
immediately after creation. Both cases failed there before registration,
metadata derivation, or worker launch. Its 2,337-byte report, 9,026-byte ERROR
manifest, and 1,156-byte telemetry manifest have SHA-256
`30db1aa209e7aa0cd47c203dc6fab92f8157a59e9af1c6131002d7fae3675f91`,
`c4545c0bbfc4d2ef2c76dd0f122d5b756edb0058ccd871ac51b17ea6ba99031a`,
and `38e1f2b6e99d89b74f201dc126e4648e22a61bcea941fab3d0fba77f29a3cb14`.
Red roots are
`artifacts/manual/wp5ac-retention-apply-recovery-{red,owner-red}/`.

**Correction and verification.** Only `preparedFixture()`'s fresh directory
now uses `realpath(await mkdtemp(...))`; the assertion remains. The worker,
nine declared fault points and exit 86, recovery operation, state/schema,
leases, and caller paths are byte-identical. Corrected tree
`92c4b1a6d30083dbcd4987d75340fd23394368da` passed Windows 2/2, zero
skips, after executing the complete nine-fault matrix and synchronized
contenders. Its report/receipt/manifest are 1,350/609/9,266 bytes with SHA-256
`976c1528e3d9cc567dd0df891fae598263b956c394d150fb154558005688bb75`,
`8d920cb8129fbfaee7a326ca4d3ba85e84f78631d4de211e19165b251ebb1c6d`,
and `161944372f695155e93d497d8e77a5e830c1e07ef4f5bffa14372bfb0e6fce5a`.
The identical full matrix passed WSL2 ext4 2/2; its report/receipt/manifest are
1,356/609/9,226 bytes with SHA-256
`837d10424a05bc8dcf69be891a4dc0611f06a54170ec9d2b15739cc7e5257241`,
`469765880868e0ad1cf644a0bcf89e6c80471ef79fede35e09af2e073932a9e7`,
and `505fb9e93b2a6e9d11c82a6bf9812d520f406b5163fc0dc5c16f1a0021847bef`.
Green roots are
`artifacts/manual/wp5ac-retention-apply-recovery-{windows,linux}-green/`;
bindings and source blobs match. No decision record is needed.

Next is historical `deterministic-operations.test.ts` at `1786995301890`:
0/2. Its shared `deterministicFixture()` owns a raw
`milestone-loop-deterministic-*` root that crosses strict orchestrator Git
inspection. It remains open for exact reproduction/direct proof.

**Commit.** Assigned by the cohesive WP5ac commit containing this entry; local
and unpushed.

**Known gaps.** Remaining deterministic/artifact/clone files, the Windows
aggregate, final broader frozen-candidate checks, POSIX `setsid`, CAL-1,
hidden validation, product breadth, readiness, and human verification remain
open. No completion claim is made.

## 2026-08-22 — WP5ab canonical scoped Git-isolation workspace parents

**Objective and cause.** From exact clean WP5aa, reproduce historical
`git-isolation.test.ts`, prove and repair only its two failing
workspace-creating parents, and leave two historically passing direct-Git
roots untouched. Baseline was and remains two passes/two failures. Only the
first two cases derive `source` repositories from raw `milestone-loop-git-*`
parents and cross strict workspace Git inspection; those short spellings
conflicted with expanded realpaths.

**Evidence.** Exact no-local/no-hardlink clone `C:/wp5ab1b/repo` at WP5aa
`0de6fea0796c33341560699334ac7ef2867d329e` / tree
`708af19aec17e39d3c548f29d01c87643e071a88`, pinned Node `24.18.0`, pnpm
`11.15.1`, no alternates, isolated store, and distinct
`WP5ABB~1`/expanded TEMP reproduced 2/4. Its 3,208-byte report, 9,018-byte
ERROR/no-receipt manifest, and 1,157-byte telemetry manifest have SHA-256
`7c220f4834662bda974b0f39e517572a294acfc1475dc479256219a53f4cb2a3`,
`318f20cd8eb0d8f086bf0852ecad720dfb599e16fe2b26ae868d08193b0b8363`,
and `b6acbb20671bd96d0fa22d6ee22b7293472bd33eb74a084c40a5efdae083d6db`.
Assertion-only tree `da8a74f84d8c705e29c97a35991d906926da38fd` imported promise
`realpath` and added direct parent assertions only at the first two sites.
Those two cases failed at the new lines before repository creation; the later
two raw-parent cases stayed byte-identical and passed. Its 2,522-byte report,
9,011-byte ERROR manifest, and 1,154-byte telemetry manifest have SHA-256
`78c638e85f7f0bdd06c7c11e58e5e0429a3d96df7df3df339a8828a4e23f97c1`,
`98b0f9052e97a591386a63df9ca56aac66e98684adab3c94827861757becf4cd`,
and `a73ecd13f971425c28e9524e0a0b4a02450b7422f2b3d1d9ea87d8d0fcadb556`.
Red roots are `artifacts/manual/wp5ab-git-isolation-{red,owner-red}/`.

**Correction and verification.** Only the first two fresh parents now use
`realpath(await mkdtemp(...))`, retaining assertions. The later two parents,
all production Git identity/integration and workspace code, and all
caller/pre-existing paths are unchanged. Corrected tree
`6c14d7c450df1613beeff3d6b767f5c1eb8e03f5` passed Windows 4/4, zero
skips. Its report/receipt/manifest are 1,794/598/9,251 bytes with SHA-256
`11b99ff6e9ec9db86d94f6d5e74aafaacb7e95d5151be9a47b20a9523f327e9f`,
`38452d8eaf8ffa13dac3122c1d5cbcc915bf979c1ea88a4bdde06f8d31f67ec7`,
and `b649f518b6b9e13788d4ee4414e67a7bb9c554a1763cce5569a268e3e033d08c`.
The identical tree passed WSL2 ext4 4/4; its report/receipt/manifest are
1,793/598/9,211 bytes with SHA-256
`ab4c2be77f49b4403ea99388e6c63a5188119d08082da51f5255459ef1deb7cf`,
`c9465f7ae2fc12bd36415a65130b044b0040be9656ff2126a39f470b0bb5108e`,
and `c038f93f62199690331e3f862fb30167a86418e120a636fe0456ea482132936a`.
Green roots are `artifacts/manual/wp5ab-git-isolation-{windows,linux}-green/`;
bindings and source blobs match. No decision record is needed.

Next is historical `retention-apply-recovery.test.ts` at `1786995292928`:
0/2. Its `preparedFixture()` owns a raw
`milestone-loop-retention-<label>-*` directory. The subprocess derives its
repository and metadata from that spelling, then strict realpath-backed
retention state rejects the pending operation. The worker and production
retention code remain out of scope pending exact reproduction/direct proof.

**Commit.** Assigned by the cohesive WP5ab commit containing this entry; local
and unpushed.

**Known gaps.** Remaining retention/deterministic/artifact/clone files, the
Windows aggregate, final broader frozen-candidate checks, POSIX `setsid`,
CAL-1, hidden validation, product breadth, readiness, and human verification
remain open. No completion claim is made.

## 2026-08-22 — WP5aa canonical retention-startup fixture root

**Objective and cause.** From exact clean WP5z, reproduce the next historical
Windows file, directly prove its test-owned fresh root, and preserve all
retention/state/schema/orchestrator semantics while applying one narrow
fixture correction. Historical and current
`orchestrator-retention-recovery.test.ts` were 0/1: the pending retention
operation became schema-invalid before the intended `after-run-deleted` fault
could produce the expected simulated startup handoff. The raw
`milestone-loop-retention-startup-*` root retained its short spelling while
strict realpath-backed operation fields observed the expanded identity.

**Evidence.** Exact clean no-local/no-hardlink clone `C:/wp5aa1b/repo` at WP5z
`7984d1ac9b9b41e2ad42a485d847245085ea26ee` / tree
`8a71d2dcf7605a89c3bbff0a4e4eeee18cc8f5b3`, pinned Node `24.18.0`, pnpm
`11.15.1`, no alternates, isolated store, and distinct
`WP5AAB~1`/expanded TEMP reproduced 0/1. Its 1,837-byte report, 9,044-byte
ERROR/no-receipt manifest, and 1,161-byte telemetry manifest have SHA-256
`f66544c2a78a743219c5f7257b6fcff3247697755bbdee0387f91cda254e7ff3`,
`1de9a918c8cb80badcde9e10cd63e11acb895fe11ea19f79a4e4962b64782a44`,
and `4972e099ccf619f874932e91010166d38607eb1d95a091a2b80e4adb0e1ee3d9`.
Assertion-only tree `e65c1dd9c462694b34b0ee94714d12190926b123` imported promise
`realpath` and asserted `expect(await realpath(root)).toBe(root)` immediately
after creation. The sole case failed directly there before temporary-root
registration, config, Git, state, or retention setup. Its 1,418-byte report,
9,038-byte ERROR manifest, and 1,158-byte telemetry manifest have SHA-256
`d2cd7eea0d8639134570ae93f48d509fa667bcffd1f108cb63b28683c1f5f6b5`,
`6cdc8853412442ad75c399f39164803aa027cfd3e2defbfc1ef2c2f7f841d36d`,
and `34813a605e8ac205cbc1f7a619c561523590ed00dd05a8261949178335b11ce8`.
Red roots are
`artifacts/manual/wp5aa-orchestrator-retention-recovery-{red,owner-red}/`.

**Correction and verification.** Only the fresh fixture root now uses
`realpath(await mkdtemp(...))`; the assertion remains before all consumers.
Production retention operation/recovery, state, schema, lease, orchestrator,
strict path checks, and the intentional fault are byte-identical. Corrected
tree `719d6ebc6e564eb5d394945214efbafff5704553` passed Windows 1/1, zero
skips. Its report/receipt/manifest are 1,029/616/9,277 bytes with SHA-256
`3de986ada7d2ca8c13e31a236456464bfc4f16b37f93601bdf7e1e02668d357b`,
`d98a428e7866400102d3dbb4b779ed82f4a50d373aa222b6a3c12ae3194b7561`,
and `c951af1d022b44849ede607e13efaf8a8f75705149a9ef7492cecdda0efa7e83`.
The identical tree passed WSL2 ext4 1/1; its report/receipt/manifest are
1,035/616/9,237 bytes with SHA-256
`0fad0767b394f5bc5d5e598417e8185522827ed7ceb4598741836dc7cd99f606`,
`1a2ca8b6d3666c567abefe6afb9b200d1dba1f30ffe78656cfa13051a1cf4033`,
and `9be9e06ae668657119267121400d5ea9e125aa247d97d922ee2b8f830106325c`.
Green roots are
`artifacts/manual/wp5aa-orchestrator-retention-recovery-{windows,linux}-green/`;
bindings and source blobs match. No decision record is needed.

Next is historical `git-isolation.test.ts` at `1786995290362`: two passes and
two failures. Only its first two raw `milestone-loop-git-*` parents derive
repositories that cross strict workspace creation; its later two raw parents
serve direct Git inspection and already passed. The later sites are explicitly
out of scope absent their own red proof, preventing bulk canonicalization.

**Commit.** Assigned by the cohesive WP5aa commit containing this entry; local
and unpushed.

**Known gaps.** Remaining Git/retention/deterministic/artifact/clone files,
the Windows aggregate, final broader frozen-candidate checks, POSIX `setsid`,
CAL-1, hidden validation, product breadth, readiness, and human verification
remain open. No completion claim is made.

## 2026-08-22 — WP5z canonical contract-integrity clone parent

**Objective and cause.** From exact clean WP5y, reproduce historical
`contract-integrity.test.ts`, prove its separate fresh parent owner, preserve
the corruption semantics and strict evidence-context consumer, and verify one
narrow test-only correction on Windows-short and Linux ext4. Historical and
current baseline were one pass/one failure: the corrupt adapter exited 3
instead of its expected failure exit 1 because `commissionedClone()` derived
the evaluated repository from a noncanonical `contract-integrity-*` parent.

**Evidence.** Exact no-local/no-hardlink clone `C:/wp5z1b/repo` at WP5y
`56dc9efbff64fa14e6d2787564b49b4284e74a96` / tree
`56842641f182a009a4861b0b8d4036edfee5c82e`, pinned Node `24.18.0`, pnpm
`11.15.1`, no alternates, an isolated store, and distinct
`WP5ZBA~1`/expanded TEMP reproduced 1/2. Its 2,478-byte report, 9,030-byte
ERROR/no-receipt manifest, and 1,161-byte telemetry manifest have SHA-256
`037366c351af5fcb9d87fc2532ba2439bb3acd5930328021fa3b4466e5db2944`,
`774bcac2373e364a1d31da1a991c68f7a030c86520216f7845d9a1beb2fac173`,
and `b697bfc52ea9e54984b79b4711314d39ceb780a1ab84768aedd07ad2e2b57131`.
Assertion-only tree `f7b31495eaa92d038d268f4b50279739799b13c4` imported promise
`realpath` and asserted `expect(await realpath(parent)).toBe(parent)` directly
after creation. Both cases failed at `commissionedClone()` before temporary
registration or Git clone setup. Its 2,348-byte report, 9,024-byte ERROR
manifest, and 1,158-byte telemetry manifest have SHA-256
`d411673ff536e02f7283dd0dea495f534f97a693565ecb4f2d2285b6285f284c`,
`f8e0359ea748f15366dd0a7a8ce39eca5be180e3cb1428e183092834db443186`,
and `8290973862ef8b097a7eee7ae7901d2e0bf2db61a9e5b42459f33c93c9a8a279`.
Red roots are `artifacts/manual/wp5z-contract-integrity-{red,owner-red}/`.

**Correction and verification.** Only the fresh parent now uses
`realpath(await mkdtemp(...))`; the assertion remains before clone derivation.
The contract evaluator, verifier/invariant adapter, strict evidence-context
check, intentionally corrupted manifest, and expected exit behavior are
byte-identical. Corrected tree
`d9c72bfcf2796796cc4468f2f1be1326f1440ee5` passed Windows 2/2, zero
skips. Its report/receipt/manifest are 1,386/603/9,262 bytes with SHA-256
`8bfc62c77e06f0e283479f97cecc6eadcfd2a5d6b15fa8347cee392a12c554ef`,
`3916469e7e22907ce2ef8524348c7b0762eb8f5f42811443b3ea005102e295cb`,
and `6859e79a6398e35e403c3f4afa5b6710225e01ff565899caedaba92fac1fbf92`.
The identical tree passed WSL2 ext4 2/2; its report/receipt/manifest are
1,392/603/9,223 bytes with SHA-256
`d8eea9d51fd7ef936596b469d8b9f7794547e7100b91a51643381b21a1c336b8`,
`037538f5e8b38bf8140e9f637e32579bd3c99c69bd010dd27577f5ac7a19b9a9`,
and `f8c5180617004ed468be6966d4abb0a033d51034c4dc50507b401bf598b1e97b`.
Green roots are
`artifacts/manual/wp5z-contract-integrity-{windows,linux}-green/`; bindings and
source blobs match. This is a test fixture correction, so no decision record
is needed.

Next is historical `orchestrator-retention-recovery.test.ts` at
`1786995288202`: 0/1. Its pending retention operation became schema-invalid
before the expected simulated handoff. Current source owns a raw
`milestone-loop-retention-startup-*` root; operation planning resolves that
short spelling while strict realpath-backed artifact fields use the expanded
root. It remains open for exact reproduction and direct proof.

**Commit.** Assigned by the cohesive WP5z commit containing this entry; local
and unpushed.

**Known gaps.** Remaining retention/Git/deterministic/artifact/clone files,
the Windows aggregate, final broader frozen-candidate checks, POSIX `setsid`,
CAL-1, hidden validation, product breadth, readiness, and human verification
remain open. No completion claim is made.

## 2026-08-22 — WP5y canonical Windows workspace-cleanup fixture root

**Objective and cause.** From exact clean WP5x, reproduce and repair only the
next retained fixture owner under genuine NTFS 8.3 TEMP, prove the owner before
changing it, verify both controller platforms, and commit narrowly without
pushing. Historical `workspace-cleanup.test.ts` was 0/6 at `1786995278951`.
Its `fixture()` retained raw `milestone-loop-cleanup-unit-*` spelling before
Git initialization and strict workspace inspection.

**Evidence.** Exact no-local/no-hardlink clone `C:/wp5y1b/repo` at WP5x
`b58184a5572f64f35a748871090544a9c0f26c42` / tree
`d0bd256a6d98fcd1b2d9797f5ef06838df06131c`, no alternates, pinned Node
`24.18.0` and pnpm `11.15.1`, an isolated store, and distinct
`WP5YBA~1`/expanded TEMP reproduced 0/6. Every failure was the same strict Git
root mismatch. Its report and ERROR/no-receipt manifest are 7,611/9,042 bytes
with SHA-256
`690912fd9335a28b026f226a46acba328fee52617b7e8167ba2a0416808b56bf`
and `02380db3a68a778eb77df7f7333402011119366fbe17f3d218c873bd6b5f2248`.
The 1,167-byte telemetry manifest is
`f79ab313700a12e0fb83852a5de0b124a47b1353dd348801ce782e7f82c76bff`.
Assertion-only tree `9c91525b39bbc61f1f893b45961d8c9fd34b11f4` imported promise
`realpath` and added `expect(await realpath(root)).toBe(root)` immediately
after `mkdtemp`. All six cases failed directly at that line before Git or
workspace creation. Its 5,590-byte report, 9,020-byte ERROR manifest, and
1,157-byte telemetry manifest are
`9323d80fdd1b48a16dc70ffc03579c33c803afbd57306304b80a952fcf291ae2`,
`1407d0339787d1bb87eef9477ae1c6f1fb2dcdfe521b7ab3018648b384582f52`,
and `93b96095141a022e4a8ef4188e46cc9ae08bdf81ff5909198573d97ca9424959`.
Red roots are `artifacts/manual/wp5y-workspace-cleanup-{red,owner-red}/`.

**Correction and verification.** Only the fresh root now uses
`realpath(await mkdtemp(...))`; the assertion remains before registration and
Git setup. Production Git, workspace creation/cleanup/archive, state/schema,
and caller-controlled paths remain byte-identical. Corrected tree
`74c712b5ac177e33e9578063909f0422272c8128` passed Windows 6/6, zero
skips. Its report/receipt/manifest are 2,778/602/9,259 bytes with SHA-256
`96cebd7ff36eded1e27e5a8633b00e53592ee86dbe9e14505d3801474ed02eb8`,
`46144ff0ac5c78e9aaa5461067ea0b987012cad730d9b1b33deb11504e3c5e4c`,
and `90503aa191c8da42739a0939e0434183835f60397031b9f9c61a9d3bb3a2addd`.
The identical tree passed WSL2 ext4 6/6, zero skips; its
report/receipt/manifest are 2,793/602/9,220 bytes with SHA-256
`ed83d52a867fd097afa101c1dbde6dab5568ab82103031358ee85a80b5ede907`,
`6aada8dc726a4ab74f65f9c91877e4f6811d92afe3396f993365c215b6161078`,
and `7c0f97af14f99743ffa276a5f62d27b3797242cab5df2fdc294792081b6b4c7f`.
Green roots are
`artifacts/manual/wp5y-workspace-cleanup-{windows,linux}-green/`. Bindings and
the corrected source blob match exactly; no decision record is needed.

**Nonqualifying setup diagnostics.** The first install wrapper inherited the
source working directory. It ran no test, changed no tracked bytes, and the
source dependency tree was immediately restored to its pinned store before
the clone was installed with an explicit CWD guard. A later direct-Node red
run bypassed `tsx`; its tests reproduced 0/6, but telemetry initialization
could not resolve a TypeScript-side `.js` specifier. It is excluded from the
qualifying record and retained under
`artifacts/manual/wp5y-workspace-cleanup-telemetry-loader-red/` (7,630-byte
report SHA
`c46bef048286b1d953fe875f308c3f3a84dabb26b7897d9e32148119ce34e018`,
8,880-byte ERROR manifest SHA
`943c6c1da8a06e4498bd9ddac9efcd001294feb4ab667452479b0c00f731d2ef`).

Next is historical `contract-integrity.test.ts` at `1786995282986`: one pass
and one failure. The corruption adapter exited 3 because the evidence context
used the short derived clone root while evaluation observed its expanded
identity. Its separate `commissionedClone()` owns a raw
`contract-integrity-*` parent and remains open rather than bundled.

**Commit.** Assigned by the cohesive WP5y commit containing this entry; local
and unpushed.

**Known gaps.** Remaining contract/retention/Git/deterministic/artifact/clone
files, the Windows aggregate, final broader frozen-candidate checks, POSIX
`setsid`, CAL-1, hidden validation, product breadth, readiness, and human
verification remain open. No completion claim is made.

## 2026-08-22 — WP5x canonical Windows workspace-create fixture parent

**Objective and cause.** From exact clean WP5w, reproduce and repair only the
next retained fresh fixture owner, verify both controller platforms, and commit
narrowly without pushing. `workspace-create.test.ts` was 0/5 at
`1786995272196`. Its `fixture()` retained raw `milestone-loop-workspace-*`
parent spelling and derived `source` from it; strict Git inspection correctly
rejected the expanded source identity.

**Evidence.** Exact no-local/no-hardlink WP5w clone `C:/wp5x1b/repo` at commit
`e292d411bd6c3b18c8bba284eeed83132a351047` / tree
`6d273ab902cf5dd47b72f1813a02a3dbaf2739ea`, pinned tools, no alternates/
drift, and genuine `WP5XLO~1` TEMP reproduced 0/5. Report/ERROR manifest are
5,676/9,025 bytes with SHA-256
`5650beeae2750953e0dc30ad57674755d347c75516010bb563bc89f8aba8c537`
and `5218316239d59f539c25503d80d3d929ab84aaf1a8eab203003e3872ca2b30b0`;
no receipt exists. Assertion-only tree
`84c028cdd7efd4ed187dee4c743aea93d64fe820` added promise `realpath` and
`expect(await realpath(parent)).toBe(parent)` beside the creator. All five
cases reported that equality failure directly or through their expected-error
matcher before source derivation. Its 4,616-byte report and 9,018-byte ERROR
manifest have SHA-256
`00e453121d195d428ca673e9d9cd43723476b3ff8c754a7574e560e8e6af713d`
and `07fe454a7b91aed0eddc3e3833022a5bf9dcf88d42ca88516edb334aa92afd03`.
Red roots are `artifacts/manual/wp5x-workspace-create-{red,owner-red}/`.

**Correction and verification.** Only the fresh parent now uses
`realpath(await mkdtemp(...))`; the assertion remains before registration and
source derivation. Production workspace/Git code and caller paths are
unchanged. Tree `9e2438f1cb28798ce63e84e150601b00545d2587` passed Windows 5/5,
zero skips. Its report/receipt/manifest are 2,287/601/9,241 bytes with SHA-256
`590b64a536d0ea972a35ba14113f5dc2f6032a45b4481a89c80ba9e9dcdedbbe`,
`f05d7fd9674e0c2cdfe99c8d4a91d9b775f38225bfb1bd30b518fc3c87acf829`,
and `f53614222d855bf98614c9ae4cae5c9645430cd8fe918d2a29139bcb84174e29`.
Linux ext4 PASS had four passes and the existing explicit Windows-only
`it.runIf(process.platform === "win32")` junction test skipped. Its
report/receipt/manifest are 2,267/601/9,205 bytes with SHA-256
`a5023c4704220c0e9685ee4bce95f9715cb6f16af23222dde723a261f052dfdd`,
`b293dcae208a0b4acf6738d76adc948492878f0c17b57d4dec57da13cee12624`,
and `563685d7b8ae9ac0f21596c28ce1a1e7be7c23784989b738871a97e858cc6401`.
Bindings match; no test/platform guard changed and no decision record is
needed.

A post-verification formatting attempt selected system Node `25.9.0`; pnpm
stopped at its noninteractive module-reconciliation guard before formatting.
Direct Prettier then confirmed all three commit paths were already formatted;
the qualifying evidence above remains exclusively pinned Node `24.18.0`.

Next is `workspace-cleanup.test.ts` at `1786995278951`: 0/6. Its separate
`fixture()` retains raw `milestone-loop-cleanup-unit-*` before workspace/Git
inspection. It remains open rather than bundled.

**Commit.** Assigned by the cohesive WP5x commit containing this entry; local
and unpushed.

**Known gaps.** Later workspace/Git/retention/artifact/verification-clone
clusters, POSIX `setsid`, CAL-1, hidden validation, product breadth, readiness,
and human verification remain open. No completion claim is made.

## 2026-08-22 — WP5w canonical Windows target-integration fixture root

**Objective and cause.** From exact clean WP5v, reproduce the next retained
Windows failure, prove and correct only its fresh fixture root, verify Windows
and Linux ext4, and commit narrowly without pushing. The historical report
places `target-integration.test.ts` at `1786995254903`: 0/4. Its `fixture()`
retained raw `milestone-loop-target-action-*` beneath short TEMP and passed it
through workspace creation; strict `inspectTarget()` correctly rejected the
expanded Git-root identity before intended integration behavior.

**Red evidence.** Clean no-local/no-hardlink clone `C:/wp5w1b/repo` at WP5v
commit `05afdba36b53d5e1e71237b26b6209c2136f22b4` / tree
`60d104aff7d56d5fa27f6e0ecbe4cf9a700ae863`, pinned tools, no alternates or
status drift, and genuine `WP5WLO~1` TEMP reproduced 0/4. The 5,896-byte
report and 9,031-byte ERROR manifest at
`artifacts/manual/wp5w-target-integration-red/evidence/` have SHA-256
`59797688b7eb78ae3d6e0799b6aa30ff8ab511ce6d36b415d8f32ac400ea37e8`
and `2c9e22d1dbccbb61af1ce8c0e1678f30f3f967ceaf0eb00a2da8bff8ec5700b4`;
no receipt exists.

Assertion-only tree `cdb6312878cf7739af5e028995e2228236e0d365`
added promise `realpath` and an equality check beside the creator. Three cases
failed directly at that check; the first surfaced the same assertion through
its expected-rejection matcher. Its 4,876-byte report and 9,024-byte ERROR
manifest under `artifacts/manual/wp5w-target-integration-owner-red/evidence/`
have SHA-256
`9596a6ecb385d570c6c66377936237b5936a8e9d8ca2138cbe4dc7542bb1e213`
and `1875af2bba50a8f4b7661aef98bc00271ff4fba0608843c8384fec9b87b4b342`;
again no receipt exists.

**Correction and verification.** `fixture()` now uses
`realpath(await mkdtemp(...))` only for its just-created root and retains the
direct assertion before registration or Git use. Production Git/workspace/
target integration, state/schema, and caller paths remain byte-identical.
Test-only tree `a81692822dde9520ac3268aced3dce2af87796ff` passed 4/4 with zero
skips on Windows-short and WSL2 ext4. Windows report/receipt/manifest are
2,202/603/9,246 bytes with SHA-256
`a7ac36cfe2d755e06200700b917d0d3191b76aa7827ef486ae2ef4514b591819`,
`74cb2f4fef352ed6669f5becd3a7c90ef36f292968928d84e1c1d3013fc75709`,
and `37873d89f8a45079024249fd78bc24f9053d0475f7eae6a11f903aa85944c6f7`.
Linux report/receipt/manifest are 2,224/603/9,211 bytes with SHA-256
`b8512d709da3d04836aa00aa521da7e74c20a86ab5ad012fbd3f988c54597049`,
`6e28ebcc29fe337cea28204e633cbb0337c4600b4125457ac876b4fd35637886`,
and `785be6eed1ac0a5d3490af4edb1dca1612f579640bd8e4f12a95585be2a67a32`.
Bindings match independently. This is test-only and needs no decision record.

Next is `workspace-create.test.ts` at `1786995272196`: 0/5. Its separate
`fixture()` retains a raw `milestone-loop-workspace-*` parent before deriving
the `source` Git root. It remains open rather than bundled.

**Commit.** Assigned by the cohesive WP5w commit containing this entry; it is
local and unpushed.

**Known gaps.** Later workspace/Git/retention/artifact/verification-clone
clusters, POSIX `setsid`, CAL-1, hidden validation, product breadth, readiness,
and human verification remain open. No completion claim is made.

## 2026-08-22 — WP5v canonical Windows workspace-create recovery fixture root

**Objective.** Reproduce the next retained hosted-Windows controller file from
the exact clean WP5u commit under pinned tools and genuine NTFS 8.3 TEMP, prove
its fixture-owned root precondition, canonicalize only that fresh root, verify
the complete file on Windows and Linux ext4, and commit one narrow owner
without pushing. Preserve strict Git/workspace-create recovery consumers,
fault points/timeouts, state and reducer semantics, later clusters, immutable
authority, lifecycle/CAL-1, and the protected human file.

**Cause and red proof.** The historical report places
`workspace-create-recovery.test.ts` at `1786995226842`: 0/5. Its `fixture()`
retained raw `milestone-loop-recover-create-*` beneath short TEMP and passed it
to `MilestoneOrchestrator.open()`; strict `inspectTarget()` correctly rejected
the expanded Git-root identity. Exact clean no-local/no-hardlink WP5u clone
`C:/wp5v1b/repo` at commit
`5653a345d1c3cbb35e2962c0de7c171e97ba794f` / tree
`8fba32c639c8f8c79869a760a09e5d07e04fd948`, pinned tools, no alternates or
status drift, and genuine `C:/wp5v1b/WP5VLO~1` TEMP reproduced 0/5. Its
6,566-byte report and 9,051-byte ERROR manifest under
`artifacts/manual/wp5v-workspace-create-recovery-red/evidence/` have SHA-256
`e1f0e160b786fc7bdf7a084ae96393feafb6f34630ae3fd95fdb3531464601aa`
and `9c57edc736bb583dd61b205e0b9a8178588d35ed0a153cb01eabeafd811c7e84`;
no receipt exists.

Assertion-only tree `74daa61698513eb017dbc0aeae2b9e1559785a9b`
added promise `realpath` and
`expect(await realpath(root)).toBe(root)` immediately beside the creator. It
remained 0/5, with every case stopping directly at that assertion before Git
or orchestrator setup. Its 4,796-byte report and 9,045-byte ERROR manifest
under `artifacts/manual/wp5v-workspace-create-recovery-owner-red/evidence/`
have SHA-256
`25f9b2efe74945c0accb8e3212f77169732eceaeeab934d81460f29e0c04ec78`
and `95c90b465ce3d944fe03bf15a75855b2f938c18689312fa793e998ce35a2e710`;
again no receipt exists.

**Correction and verification.** `fixture()` now resolves only its just-created
root through `realpath(await mkdtemp(...))`; the assertion remains before the
root is registered or used. Production Git, workspace-create/recovery,
orchestrator/reducer, state/schema, fault hooks/timeouts, and caller-controlled
paths remain byte-identical. Test-only tree
`e9f3789866865ed0ef7f54332d08f3f6655b8ba7` passed 5/5 with zero skips on
genuine-short Windows and clean WSL2 ext4. Windows's 2,387-byte report,
610-byte receipt, and 9,292-byte manifest have SHA-256
`59538333a1be9b10c73e519d0327842b7fb1e464337f962e9da9194fc7e6f866`,
`58d0eaf0dc94a07436c38b1edcc3f9cd1b6795913a764c168f1f5934a3b95784`,
and `3a29b9c90359ee3f7010adc1759f9b01558f6ca16ef9b18bd4c84377f1599606`.
Linux's 2,394-byte report, 610-byte receipt, and 9,232-byte manifest have
SHA-256 `5f1400d7a8343572720c84acf2e96adc356a94f6c1db04fdfa2d7a9d3f4fd328`,
`ad28ad8087b310e44dee225d71de0db91eb9a2d130d0036e31385294303280d3`,
and `d9e9b4964114256301334ce621f1a7809e74cc296ad2faf5c071ec7fd344002b`.
All receipt and artifact bindings matched independently. This is a test
fixture correction and requires no decision-log entry.

The next retained failure is `target-integration.test.ts` at
`1786995254903`: 0/4. Its separate `fixture()` retains raw
`milestone-loop-target-action-*` and passes it through workspace creation and
strict Git inspection. It remains open rather than being bundled.

**Commit.** Assigned by the single cohesive WP5v commit containing this entry;
identify it as the newest commit touching the entry. It is not pushed.

**Known gaps.** Target-integration and later workspace/Git/retention/artifact/
verification-clone fixture clusters, the documented POSIX `setsid` escape,
CAL-1, hidden validation, product breadth, autonomous readiness, and human
verification remain open. No readiness or product-completion claim is made.

## 2026-08-22 — WP5u canonical Windows workspace-cleanup crash-worker root

**Objective.** Select the earliest unresolved hosted-Windows controller file
after WP5t, reproduce it from the exact clean WP5t commit under pinned tools
and genuine NTFS 8.3 TEMP, prove its controlled subprocess root precondition,
canonicalize only that fresh worker root, verify the complete recovery file on
Windows and Linux ext4, and create one narrow local commit without pushing.
Preserve strict Git/workspace/cleanup inspection, all 15 recovery fault points
and timeouts, cleanup/archive/state semantics, later fixture clusters,
immutable authority, lifecycle/CAL-1 state, and the protected human file.

**Cause and ordering.** The historical hosted report places
`workspace-cleanup-recovery.test.ts` immediately after WP5t at
`1786995222359`: all three cases failed before their intended cleanup crash
boundaries. `test/workspace-cleanup-crash-worker.ts::main()` retained the raw
`milestone-loop-cleanup-crash-*` spelling returned beneath short TEMP and
passed it to `createIsolatedWorkspaceFixture()`. Strict `inspectTarget()`
correctly observed the expanded realpath and rejected the mismatched Git root.

**Red evidence.** Exact clean no-local/no-hardlink WP5t clone
`C:/wp5u1b/repo` at commit
`69c10b3b6e00e0e7bf044115d3bb9e040541e484` / tree
`f8191c7947e41573cf2cb612e6df089b61a84513`, with no alternates or status
drift, pinned tools, isolated writable roots, and a genuine
`C:/wp5u1b/WP5ULO~1` TEMP whose promise realpath expands, reproduced 0/3. The
5,229-byte report and 9,035-byte ERROR manifest at
`artifacts/manual/wp5u-workspace-cleanup-recovery-red/evidence/` have SHA-256
`3469873e155d80a455d047ed517eb1e0218ad33da1ecf0bc686c32feb393c795`
and `e46948956ce23a27303042a8d29e1c5cdb3c8f6acd910dfe2c011276f8d189ed`;
no receipt exists.

Assertion-only tree `5c1c95faed99490fb88b109e8f30af419ab6e9ed`
imported promise `realpath` and Node `strictEqual`, then required the freshly
created worker root to equal its realpath before Git/workspace setup. It
remained 0/3, with every case stopping directly at that assertion. Its
5,183-byte report and 9,028-byte ERROR manifest at
`artifacts/manual/wp5u-workspace-cleanup-recovery-owner-red/evidence/` have
SHA-256 `995284003f38d642f5d3a7d0d0bac46dbe77858642297a0f631160d985b50114`
and `c1728c30ec0f0b49a6fdd2af363238ae2e1d2f3dcadb1229b8a456b46dce55d4`;
again no receipt exists.

**Correction.** The cleanup crash worker now resolves only its freshly created
root through `realpath(await mkdtemp(...))` before deriving Git, workspace,
configuration, state, archive, or evidence paths. The direct assertion remains
beside the creator. Production `git-isolation.ts`, workspace create/cleanup,
orchestrator/reducer, state/schema, archive policy, fault points/timeouts, and
all caller-controlled or pre-existing paths remain byte-identical. This is a
test subprocess fixture correction and requires no decision-log entry.

**Focused verification.** Corrected test-only tree
`d588906184f78bc5eccfcdd0edda64891ef2670d` passed 3/3 with zero skips on
genuine-short-path Windows and a clean WSL2 ext4 clone. Windows's 1,646-byte
report, 611-byte receipt, and 9,275-byte manifest have SHA-256
`c77e82aeb9a54cd91b5e95fb4507b88016b27a11d03e5db2e5ffebfaca5f7ba4`,
`96c86a0d5b246de4c9c04ed74c17cde98079e226a8fae6076853c5f21f2b11b0`,
and `569b6dd76a95675f973944b2525ce74a4389b7249b5f0e147db4cfb158ad6a30`.
Linux's 1,655-byte report, 611-byte receipt, and 9,239-byte manifest have
SHA-256 `c238ad89d5d37a75a4e9df88c9304365aba2c201dc98afd7603966908aaf0aff`,
`7b7251eadfa3400151bba8fbc55848904fedd428ca0dcc58c835f5ceac86f30b`,
and `7502a06a4be3f77fc5de2ca6aed99e316f11d77df941ca017c5748172ed976ac`.
Every receipt and artifact declaration matched independently.

The next retained failed file is `workspace-create-recovery.test.ts` at
`1786995226842`: 0/5. Its directly owned `fixture()` retains the raw
`milestone-loop-recover-create-*` root and passes it to
`MilestoneOrchestrator.open()`, where strict `inspectTarget()` expands and
rejects it. It remains open rather than being bundled.

**Commit.** Assigned by the single cohesive WP5u commit containing this entry;
identify it as the newest commit touching the entry. It is not pushed.

**Known gaps.** The workspace-create recovery fixture and later Windows
workspace/Git/retention/artifact/verification-clone clusters, the documented
POSIX `setsid` escape, CAL-1, hidden validation, product breadth, autonomous
readiness, and human verification remain open. No readiness or product-
completion claim is made.

## 2026-08-22 — WP5t canonical Windows target-integration crash-worker root

**Objective.** Select the earliest unresolved hosted-Windows controller file
after WP5s, reproduce it from the exact clean WP5s commit under pinned tools
and a genuine NTFS 8.3 TEMP spelling, prove its controlled subprocess root
precondition, canonicalize only that fresh worker-owned root, verify Windows
and Linux ext4, and create one narrow local commit without pushing. Preserve
strict Git/workspace/target-integration inspection, recovery fault points and
timeouts, target/state/outcome semantics, later fixture clusters, immutable
authority, lifecycle/CAL-1 state, and the protected human file.

**Cause and ordering.** The historical hosted report places
`target-integration-recovery.test.ts` immediately after WP5s at
`1786995207495`: all three cases failed before their intended crash/recovery
boundaries. `test/target-integration-crash-worker.ts::main()` retained the raw
`milestone-loop-target-crash-*` spelling returned beneath short TEMP and
passed it to `createIsolatedWorkspaceFixture()`. Strict `inspectTarget()`
correctly observed the expanded realpath and rejected the mismatched Git root.

**Red evidence.** Exact clean no-local/no-hardlink WP5s clone
`C:/wp5t1b/repo` at commit
`e8aa6d5c379c59b88ee10b4ea12add6d16ae040c` / tree
`d4039f16b6464ec743b0de761a0ea974bfaff85a`, with no alternates or status
drift, pinned tools, isolated writable roots, and a genuine
`C:/wp5t1b/WP5TTA~1` TEMP whose promise realpath expands, reproduced 0/3. The
5,421-byte report and 9,034-byte ERROR manifest at
`artifacts/manual/wp5t-target-integration-recovery-red/evidence/` have SHA-256
`542760aa5199480b39b2feaf30415f6d032fdbbaf2a8fceac1b995ebb386000b`
and `a81d65ddd8727930cbb87a150452d5bdda2e54c7206c4473cae6c6bcab11e104`;
no receipt exists.

Assertion-only tree `545d44141ed2e0dc88412d71d07b40066a57b579`
imported promise `realpath` and Node `strictEqual`, then required the freshly
created worker root to equal its realpath before Git/workspace setup. It
remained 0/3, but all three subprocesses stopped directly at that assertion.
Its 5,438-byte report and 9,027-byte ERROR manifest at
`artifacts/manual/wp5t-target-integration-recovery-owner-red/evidence/` have
SHA-256 `ae178950d13df56bc380cfce1fb260b01f658cf318570237e6a5c7b5b41b8615`
and `e80730c8313504e612293dfb3faea2878610c73dfe122effb39706b00bdc655a`;
again no receipt exists.

**Correction.** The crash worker now resolves only its freshly created root
through `realpath(await mkdtemp(...))` before deriving Git, workspace,
configuration, state, verification, or outcome paths. The direct assertion
remains beside the creator. Production `git-isolation.ts`,
`workspace-create.ts`, `target-integration.ts`, the orchestrator/reducer,
state/schema, crash fault points/timeouts, and every caller-controlled or
pre-existing path remain byte-identical. This is a test subprocess fixture
correction and requires no decision-log entry.

**Path-budget diagnostic.** The first corrected-tree probe used an
unnecessarily long expanded TEMP and reached a different 0/3 failure. The
published workspace and ref files existed; its symbolic `HEAD` named a valid
41-byte ref containing the same commit as `refs/heads/main`. The nested target
branch ref's absolute path was 266 characters, however, and Git reported
`Filename too long` with `core.longpaths` unset. The 5,402-byte report and
1,331-byte ERROR manifest are retained under
`artifacts/manual/wp5t-target-integration-recovery-path-budget-red/`. An
identical tree passed with a shorter expanded TEMP that still had a distinct
8.3 alias, so this is retained as nonqualifying environment evidence rather
than misattributed to workspace publication. No production change followed.

**Focused diagnostics.** Corrected test-only tree
`2b4ce32834cfb51d280897d4d17c9bed21bb65c9` passed 3/3 with zero skips on
genuine-short-path Windows and a clean WSL2 ext4 clone. Windows's 1,708-byte
report, 612-byte receipt, and 1,564-byte manifest have SHA-256
`4471430537a25f5b052d8cbc9f3601d01d75df1857eaede6fb50e163061c41fa`,
`fd70dd741ef23ce5d1e145a6fe0ef777da8c06f8d89c08b472b79e7148df2c95`,
and `8ec5d682b19dee0e2cdb06570cde0467841ebc0928680baf2839d6431126aa06`.
Linux's 1,721-byte report, 612-byte receipt, and 1,528-byte manifest have
SHA-256 `0b82b9be79aab2e3180d4f47cba85364e25b3d021f19cb402e5f9b67611271c3`,
`08fd44b8c767372bb51119c5783e3cccfeadb74e6338af61cdb4aadded66deb5`,
and `5508412d0756949d192051c785c58598b0dcf0cd035e14e54bd5784d37e20069`.
Every receipt and artifact declaration matched independently.

Two setup attempts created no qualifying evidence. A Windows wrapper invoked
pnpm with a fresh store identity and stopped before evidence creation when it
refused a noninteractive module reconciliation; a later direct-Node attempt
was interrupted after live inspection showed Vitest's worker resolving the
system Node instead of pinned 24.18.0. The successful fresh clone prefixed the
pinned runtime and live inspection confirmed every Node process used it. A
WSL install command omitted `cd`, rebuilt only the source checkout's ignored
`node_modules`, and ran no test; a pinned Windows reinstall immediately
restored that ignored dependency tree without tracked or protected-file drift.

The next retained failed file is
`workspace-cleanup-recovery.test.ts` at `1786995222359`: 0/3. Its failures
originate in the separately owned subprocess fixture
`test/workspace-cleanup-crash-worker.ts`, whose raw
`milestone-loop-cleanup-crash-*` root crosses strict workspace Git inspection.
It remains open rather than being bundled.

**Stable-tree protocol.** The corrected worker, this log, and the next active
plan freeze before final commands. Independent exact candidate clones rerun
the complete Windows-short and Linux-ext4 file with fresh evidence. Exact final
outcomes remain in ignored artifacts and the handoff so tracked bytes do not
change afterward.

**Commit.** Assigned by the single cohesive WP5t commit containing this entry;
identify it as the newest commit touching the entry. It is not pushed.

**Known gaps.** The workspace-cleanup crash-worker and later Windows
workspace/Git/retention/artifact/verification-clone clusters, the documented
POSIX `setsid` escape, CAL-1, hidden validation, product breadth, autonomous
readiness, and human verification remain open. No readiness or product-
completion claim is made.

## 2026-08-22 — WP5s canonical Windows orchestrator-identity fixture root

**Objective.** Select the earliest unresolved hosted-Windows controller file
after WP5r, reproduce it from the exact clean WP5r commit under pinned tools
and a genuine NTFS 8.3 TEMP spelling, prove its controlled root precondition,
canonicalize only that fresh fixture root, verify Windows and Linux ext4, and
create one narrow local commit without pushing. Preserve strict Git/workspace/
orchestrator identity, state/schema, containment, later fixture clusters,
immutable authority, lifecycle/CAL-1 state, and the protected human file.

**Cause and ordering.** The historical hosted report places
`orchestrator-identity.test.ts` immediately after the WP5r cleanup file at
`1786995203341`: all eight cases failed before their intended candidate-
identity/reviewer/integration outcomes. `reviewingFixture()` retained the raw
`milestone-loop-identity-orch-*` spelling returned beneath short TEMP, then
passed it to `createIsolatedWorkspaceFixture()`. Strict `inspectTarget()`
correctly observed the expanded realpath and rejected the mismatched Git root.

**Red evidence.** Exact clean no-local/no-hardlink WP5r clone
`C:/wp5s1b/repo` at commit
`1b51a8bc671a19fab2b82e27a46cca87a333bcba` / tree
`1751b260806c3d10dd4784b133307a7058405fd7`, with no alternates or status
drift, pinned tools, isolated dependency roots, and a genuine distinct short
TEMP, reproduced 0/8. The 10,399-byte report and 9,013-byte ERROR manifest at
`artifacts/manual/wp5s-orchestrator-identity-red/evidence/` have SHA-256
`641348b18375f025f96b8cc0f978863d8673ab3c3acb42ad984338ddcd420dff`
and `bd2f9ea2339fb72c91a8bc9c3b0dc60927bf39c31e79526e8740615130cc4bfe`;
no receipt exists.

Assertion-only tree `d615fb639f4d84356b2f1a2b059a8b4b13c43b5c`
imported `realpath` and required the just-created root to equal it before Git
or workspace setup. It remained 0/8, but every case stopped directly at that
assertion. Its 7,424-byte report and 9,006-byte ERROR manifest at
`artifacts/manual/wp5s-orchestrator-identity-owner-red/evidence/` have SHA-256
`44c9169e1ddf51efbcc3a478657af96805efe50829e0696783b0cf48ca6e1756`
and `e6ba491f6e15fe97b09f930e04342364d719aa4e3f95964c5c6479a943c00503`;
no receipt exists.

**Correction.** `reviewingFixture()` now resolves only its freshly created
root through `realpath(await mkdtemp(...))` before deriving Git, workspace,
configuration, state, or artifact paths. The direct assertion remains beside
the creator. Production `git-isolation.ts`, `workspace-create.ts`,
`orchestrator.ts`, candidate identity, review/integration, state/schema,
containment, and all caller-controlled paths remain byte-identical. This is a
test fixture correction and requires no decision-log entry.

**Focused diagnostics.** Test-only tree
`5108a323a78edf70cdd320a6f85f37c7c0d0d286` passed 8/8 with zero skips on
genuine-short-path Windows and a clean Linux-ext4 clone. Windows's 3,549-byte
report, 606-byte receipt, and 1,558-byte manifest have SHA-256
`c6e537b133eee81388235b4840667c61a18df1e0f322d53b8330b5fbd9877376`,
`797c88cafe5b085b5936bfafcdcaf5220a27f8d8ec43dae3e695793d30b9c3f1`,
and `910e0ae17ffd80ffac73e5388d0830a04855e3ee1cdf689a64683280a8ecb98e`.
Linux's 3,572-byte report, 606-byte receipt, and 9,212-byte manifest have
SHA-256 `6405a8fe0782c285135b4ba8ae3394ec189929cff06685f5b6c64aaa675c0ca3`,
`d57381e97c93017e4988763a84394a7b02e189f76993cedd09d7415904fe4615`,
and `c7a499f8dc8ec9c209ab1e2f9c478829958dab751f523f0bdb4f27d1831ad553`.
Every receipt and artifact declaration matched independently.

Two reporting/setup mistakes created no false evidence: one audit wrapper
parsed `$rp-Raw` after the owner-red command had already written valid ERROR
evidence, and a preliminary-green wrapper attempted to assign PowerShell's
reserved `$HOME` before creating an evidence root or running a test. The
successful evidence was audited in separate read-only commands.

The next retained failed file is `target-integration-recovery.test.ts` at
`1786995207495`: 0/3. Its failures originate in the separately owned subprocess
fixture `test/target-integration-crash-worker.ts`, whose raw
`milestone-loop-target-crash-*` root crosses strict workspace Git inspection.
It remains open rather than being bundled.

**Stable-tree protocol.** The identity test, this log, and the next active
plan freeze before final commands. Independent exact candidate clones rerun
the complete Windows-short and Linux-ext4 file with fresh evidence. Exact final
outcomes remain in ignored artifacts and the handoff so tracked bytes do not
change afterward.

**Commit.** Assigned by the single cohesive WP5s commit containing this entry;
identify it as the newest commit touching the entry. It is not pushed.

**Known gaps.** The target-integration crash-worker root and later Windows
workspace/Git/retention/artifact/verification-clone clusters, the documented
POSIX `setsid` escape, CAL-1, hidden validation, product breadth, autonomous
readiness, and human verification remain open. No readiness or product-
completion claim is made.

## 2026-08-22 — WP5r canonical Windows orchestrator-cleanup fixture root

**Objective.** Reconcile published WP5q and exact runtime CI run
`32598203192`, then select the earliest unresolved hosted-Windows controller
failure, reproduce it from an exact clean source under Node `24.18.0` and pnpm
`11.15.1`, correct only its controlled fixture root, retain a direct
precondition assertion, verify Windows and Linux ext4, and create one narrow
local commit without pushing. Preserve strict Git identity, containment,
workspace cleanup, state/schema, later fixture clusters, immutable authority,
readiness/CAL-1, the protected human file, and ignored residue.

**Hosted reconciliation and ordering.** `HEAD` and `origin/master` both equal
WP5q commit `3113c13182951814459628cebe252fe97fd93d9a` / tree
`bb678f5a30e1a7f3bcd102ebb6d625b0b0ad350e`. Public GitHub metadata binds run
`32598203192` to that commit and records Linux controller, both fresh-adopter
jobs, and real Linux-Docker successful. Windows frozen installation and
invariants passed; `test:orchestrator` failed; later unit/type/lint/format steps
were skipped. The Windows artifact is 52,419 bytes with digest
`sha256:9ae84a84150d7a58389c5e452d03263968c37d01b0b9e74fc0c9dce52466a9f2`.
GitHub CLI has no authenticated session and the archive endpoint returns HTTP
401, so exact run #9 file contents/counts are not claimed. Public metadata is
retained at `artifacts/hosted/run-32598203192/public-metadata.json`.

The historical hosted report retained at
`artifacts/hosted/run-32060615125/controller-windows-87bd41e/orchestrator/orchestrator-report.json`
places `orchestrator-cleanup.test.ts` next after the WP5o/p/q closures: 1/9
passed and eight failed. Its controlled `repositoryFixture()` retained the
8.3 spelling from `mkdtemp(tmpdir())`; strict `inspectTarget()` correctly
expanded and rejected the mismatched Git-root identity before the intended
open/workspace/retention boundaries.

**Red evidence.** Exact clean no-local/no-hardlink clone `C:/wp5r1b/repo`,
with no alternates or status drift, pinned tools, isolated dependency roots,
and a genuine `C:/wp5r1b/WP5RWI~1` TEMP whose promise realpath expands, exactly
reproduced 1/9 passed and eight failed. The 10,010-byte report and 9,011-byte
ERROR manifest under
`artifacts/manual/wp5r-orchestrator-cleanup-red/evidence/` have SHA-256
`4ea9c7aa96e6c014efb215cbd98fd865f80f14fd6528d96f5b0acb64bfd248c0`
and `d3985a35e5d3cd8d5a71a2a58ac6133b7a0075b85ac690ed5d3e286dd4af75b9`;
no receipt exists.

An assertion-only second clone/tree
`fccbc84fcfe43d13b44ccd72b1cca08c83f98402` added only
`expect(await realpath(fixture.root)).toBe(fixture.root)` after the first
fixture return. It remained 1/9, but the first failure moved directly to that
assertion. Its 9,602-byte report and 9,004-byte ERROR manifest under
`artifacts/manual/wp5r-orchestrator-cleanup-owner-red/evidence/` have SHA-256
`0848bc0419fe36a46cee411075f9eddd109950460abc33fea6880ff427f0dd19`
and `4c9a3b20820a730fdbd4c9ac4331346f78b0c8db6cff9ccf5d52bcd4ac489772`;
again no receipt exists.

One rejected setup probe used `fs.realpathSync`, which on this Windows build
preserved the short spelling even though the production-relevant
`fs.promises.realpath` expands it. Clone/install had succeeded, but no test or
evidence root existed. The promise API then proved the intended precondition
before either cited red command ran.

**Correction.** `repositoryFixture()` now resolves only its freshly created
root through `realpath(await mkdtemp(...))` before deriving repository,
configuration, state, artifact, or workspace paths. The direct assertion
remains. Production `git-isolation.ts`, `orchestrator.ts`, workspace creation
and cleanup, containment, state/schema, artifacts, and every caller-controlled
or pre-existing path remain byte-identical. This is a test fixture correction,
not a durable production decision, so no decision-log entry is required.

**Focused diagnostics.** Test-only candidate tree
`0bb0fa80fa2f3c0095460273d5f34f49c1276c0b` passed 9/9 with zero skips on
genuine-short-path Windows and a clean Linux-ext4 clone. Windows's 3,984-byte
report, 605-byte receipt, and 9,256-byte manifest have SHA-256
`86047ac2f1455022b669e216de4fd347beaea9714cc3aae641dac9343e3fb949`,
`cf8b4d5a4a4f14ba05b5a5cbf905c436cfd44b30876f09702f5cf3d988e2db98`,
and `2d5c94f6325d88c6e41a99e98a8c2aa551ba3cc5e12660eef72368128d4bb4b5`.
Linux's 4,016-byte report, 605-byte receipt, and 1,539-byte manifest have
SHA-256 `f66d7c18e12cda18543592866f7fc728b78f47c9f9898318d9c205417f567832`,
`7bc6f467d924ee996cf8e15e78c1350842eaf7d91fb1309e3cc1d7ef70f4b7d5`,
and `3a239a1693935b9b9e56bd679536dd7c77d7fd6cf4266ed96ea9406e0981fc93`.
Every declared artifact and receipt binding was independently recomputed.

The next retained failed file is separately owned
`orchestrator-identity.test.ts` at `1786995203341`: 0/8 passed, with its own
raw `milestone-loop-identity-orch-*` reviewing fixture. It remains open rather
than being bundled.

**Stable-tree protocol.** The corrected test, this log, and the next active
plan freeze before final commands. Independent exact candidate clones rerun
the complete Windows-short and Linux-ext4 file with fresh command-owned
evidence. Exact final outcomes remain in ignored evidence and the handoff so
the candidate tree does not change afterward.

**Commit.** Assigned by the single cohesive WP5r commit containing this entry;
identify it as the newest commit touching the entry. It is not pushed.

**Known gaps.** The separately owned orchestrator-identity fixture and later
Windows workspace/Git/retention/artifact/verification-clone clusters, the
documented POSIX `setsid` escape, CAL-1, hidden validation, product breadth,
autonomous readiness, and human verification remain open. This increment
makes no readiness or product-completion claim.

## 2026-08-22 — WP5q canonical Windows container-executor roots

**Objective.** Select the earliest unresolved retained controller failure after
WP5p, reproduce it from a clean exact source under Node `24.18.0` and pnpm
`11.15.1`, repair only causally proved producer-owned path identities, verify
both supported controller platforms with command-owned evidence, and create one
narrow local commit without pushing. Preserve strict mount/artifact identity,
OCI containment, cleanup, process supervision, Git isolation, later retained
clusters, immutable authority, readiness/CAL-1, package/lock/workflow, the
protected human file, and ignored setup residue.

**Cause and ordering.** The retained hosted Windows report begins its failed
suites with Doctor at `1786995045207`, evidence retention at `1786995083268`,
then container executor at `1786995151895`. WP5o and WP5p close the first two;
worked-example was independently closed by WP5m. Container executor passed 2/10
and failed eight lifecycle cases. Six retained assertions received
`Controller pnpm store must be an ordinary directory with stable realpath
identity.`; the normal and timeout cases also returned ERROR before their
expected PASS/TIMEOUT boundaries. The policy-only and pre-store image-
attestation cases passed.

The controlled `fixture()` retained the valid 8.3 spelling returned by
`mkdtemp(tmpdir())`, then derived the mocked pnpm store and clone paths. The
strict production mount guard correctly observed a different expanded realpath
and stopped before clone/container lifecycle. Once that fixture root was
canonical, six cases passed and the only two paths reaching artifact export
exposed an independent production producer: the executor also retained raw
`mkdtemp(tmpdir())` for its export staging root. A direct observation proved the
evidence staging child noncanonical before strict artifact inventory rejected
it. Neither failure authorizes normalizing caller-controlled paths or relaxing
consumers.

**Red evidence.** A fresh no-local/no-hardlink exact-HEAD Windows clone at
commit `51d6eb8d039f31e0c9d4018508048bb74e11a3f9` / tree
`3a6d6b385c4d8beedca38d01cd36bfa44aa06bb4`, with no alternates, clean status,
pinned tools, and a genuine distinct 8.3 TEMP spelling, reproduced 2/10. The
7,082-byte report and 8,993-byte ERROR manifest under
`artifacts/manual/wp5q-windows-container-red/evidence/` have SHA-256
`c2250155c93ad27737ded2dbd9f9ca19544f269eaca523b99e0523ac219dd5d1`
and `36f47cce9fcacd926d78b0f4fdc57ca563b1bc6dfdaeffc6701b86fbbd025ccb`;
no receipt exists. Its 5,090-byte reproduction record has SHA-256
`c0ee7d7e803a763aa83630ea72c4a6103b0441e02e7973e492a432afe7636357`.

An assertion-only test tree `d18f965b05a73aeb83e895e0933d70942d074b10`
remained 2/10 but moved the first failure directly to
`realpath(data.root) === data.root`. Its 6,668-byte report and 9,004-byte ERROR
manifest under `artifacts/manual/wp5q-windows-container-owner-red/evidence/`
have SHA-256
`31c73bd18431036cb118e84b1ced75c26f0cec480bd656e2382278f1365d9ac7`
and `af7172ae067aca7253fb7125b55a2ace9fd62b85589b6a98b8e0d7adf19e725f`;
no receipt exists. Its 3,489-byte record has SHA-256
`acf8cf332560ac06a5e5e52aa1a92c3d5f4fd1a68bb09cd9fab4b37e223da0f4`.

With only the fixture canonicalized and production byte-identical, tree
`a8f7934b8ae92fb86b1caee20f14d051f005422f` passed 8/10. The normal case
failed a direct `evidenceStagingRootIsCanonical` assertion; the timeout case
remained ERROR at the same downstream inventory boundary. Its 4,634-byte report
and 9,007-byte ERROR manifest under
`artifacts/manual/wp5q-windows-container-staging-red/evidence/` have SHA-256
`b6a4903efcf94be945a1d12b9e76ba0a86f297939ea4d3ce2dc7850b6837e1ea`
and `1ec1fca2c809b8382cf89852efc9002466fe8d89946794870cb1b97e3900ff76`;
no receipt exists. Its 4,227-byte record has SHA-256
`dafff84a11c494d885deabf76ea2cb9958cb2d524d290fb3dde77b5c5c454baf`.

**Correction.** `fixture()` now resolves only its just-created root before any
derived mocked path. Production `createContainerCommandExecutor()` likewise
resolves only its own just-created export staging root before deriving artifact
paths. The direct fixture and staging observations remain in the focused test.
`assertOrdinaryMountSource`, `container-artifacts.ts`, caller-provided paths,
verification clone, artifact limits/publication, OCI policy/attestation,
container/volume cleanup, Git isolation, state/schema, and process supervision
remain unchanged. The production producer rule is recorded in the decision
log.

**Focused diagnostics.** The exact two-path implementation tree
`36fd561a80ed6436cab8d56a130cae53ab02591c` passed 10/10 with zero skips and
valid command-owned receipts on Windows under another genuine short TEMP and
Linux from an ext4 clone. Windows's 4,064-byte report, 603-byte receipt, and
9,243-byte manifest have SHA-256
`d20e446992916259bbaf9da86e6cd23f7dc374575f5e2fcb17584aec158faa8f`,
`68906740233e7ccc282f10403c7581809a21b3b78af7c972c13ccadce06b09a5`,
and `388e62f3002ee161a004fb1d15eb7d25522a958c0a698d4be12fb9800eefdab7`.
Linux's 4,086-byte report, 603-byte receipt, and 9,218-byte manifest have SHA-256
`96e4fd0aeb971ec7c96e9060013e15ffa0c30ea6acae09df090470267b4e4cff`,
`b41475bb9aff3a795d074553a23ec147ff79f5af151337da0e2a2e2cc863d7f7`,
and `5de11d6fb46fc6d65e5dafc66b96c22da907a6e921127506dff397d78790c26c`.

The next retained failed file, `orchestrator-cleanup.test.ts` at
`1786995191701`, passes 1/9 and has eight failures from its own raw
`milestone-loop-recovery-cleanup-*` Git fixture crossing strict
`inspectTarget()`. It imports neither changed owner, so it remains explicitly
open rather than being bundled.

**Stable-tree protocol.** The source, test, plan, autonomy log, and decision log
freeze before final commands. Independent no-local/no-hardlink clones
materialize the exact staged tree and run fresh Linux focused, Windows-short
focused, invariant, orchestrator, unit, typecheck, lint, and format commands in
distinct roots beneath `artifacts/manual/wp5q-*-final/`. Final outcomes and
independent hashes remain in ignored evidence and the final handoff rather than
changing the candidate.

**Setup incidents.** One Windows red setup wrapper called `.Trim()` on empty
clean-status output after clone/install and exited 1; no test or evidence root
existed yet. An initial WSL toolchain probe allowed host PATH expansion, and a
later WSL setup wrapper allowed host expansion of shell substitutions; neither
ran a test or created command evidence. Exact read-only checks recovered the
intended clone and the cited Linux command ran only after identity/toolchain
validation. External diagnostic roots `C:/w5qr`, `C:/w5qo`, `C:/w5qs`,
`C:/w5qg`, `/home/duncan/wp5q-linux-diagnostic`, and isolated Corepack probe
`/home/duncan/wp5q-linux-store-probe` remain retained for audit. The unrelated
repository residue `.tools/corepack-home-readonly-probe` remains untouched.

**Publication and hosted reconciliation.** The cohesive WP5q commit is
`3113c13182951814459628cebe252fe97fd93d9a` (tree
`bb678f5a30e1a7f3bcd102ebb6d625b0b0ad350e`) and is published at
`origin/master`. Exact runtime CI run `32598203192` executed that commit.
Public GitHub job metadata records Linux controller, Linux and Windows fresh
adopter, and the real Linux-Docker matrix successful. Windows controller
installation and invariants passed, `test:orchestrator` failed, and unit,
typecheck, lint, and format were skipped. Its retained artifact metadata names
`controller-windows-3113c13182951814459628cebe252fe97fd93d9a`, size 52,419
bytes, digest
`sha256:9ae84a84150d7a58389c5e452d03263968c37d01b0b9e74fc0c9dce52466a9f2`.
GitHub CLI is unauthenticated and the unauthenticated archive endpoint returns
HTTP 401, so the archive's file-level results and counts remain unaudited and
are not claimed. Public metadata is retained at
`artifacts/hosted/run-32598203192/public-metadata.json`.

**Commit.** `3113c13182951814459628cebe252fe97fd93d9a`; published at
`origin/master` by exact runtime CI run `32598203192` before WP5r began.

**Known gaps.** The separately owned orchestrator-cleanup fixture cluster,
later Windows workspace/Git/artifact/verification-clone cascades, the documented
POSIX `setsid` escape, CAL-1, hidden validation, product breadth, autonomous
readiness, and human verification remain open. This increment makes no
readiness or product-completion claim.

## 2026-08-22 — WP5p canonical Windows retention-apply fixture root

**Objective.** Select the earliest unresolved retained controller failure after
WP5o, reproduce it from a clean exact source under Node `24.18.0` and pnpm
`11.15.1`, correct only its causal real-filesystem fixture precondition, verify
both supported controller platforms with command-owned evidence, and create one
narrow local commit without pushing. Preserve production retention apply,
state/schema, containment, path and Git identity, later Windows fixture/path
clusters, immutable authority, lifecycle/CAL-1 state, package/lock/workflow,
retained evidence, and the protected human plan.

**Cause and ordering.** The retained hosted Windows report starts its unresolved
post-WP5o suites with evidence retention at `1786995083268`, then container
executor at `1786995151895` and later workspace, Git, artifact, and clone
cascades. Evidence retention passed 15/19; its four failures were exactly the
state-first cases for normal apply, forged-journal conflict, result conflict,
and torn-journal recovery. The first failed at `StateStore.save` with
`Invalid orchestrator state: State pending operation is invalid.`; the other
three received that same earlier error instead of their intended boundary.

The controlled `applyFixture()` retained `mkdtemp()`'s valid NTFS 8.3 spelling.
`validState(root)` only resolved it, while evidence planning correctly recorded
long artifact-root realpaths. Retention intent construction therefore combined
a short `repositoryRoot` with long realpath fields. Strict state containment
correctly rejected that mixed identity before publication. The other apply
tests stop at preflight and masked the helper defect; the four retained failures
are the only cases that cross publication. Production owners and the test are
byte-identical from hosted commit `87bd41e` through WP5o.

**Red evidence.** A fresh no-local/no-hardlink exact-WP5o Windows clone at
commit `70fb23538d6664d4fd3c7e59397398cde702dd4b` / tree
`1610ca8714a43850b7ec423c7e0119e7bf0d9930`, under a genuine 8.3 temp spelling,
reproduced 15/19 with the exact four failures, an `ERROR` manifest, no receipt,
clean clone, and exact toolchain. The 11,865-byte report and 9,137-byte manifest
under `artifacts/manual/wp5p-windows-evidence-retention-red/evidence/` have
SHA-256 `d8f5f27f39f5cbad8114742addfc6d19948de35eb0400d75f6f56c08cf33dd5c`
and `43ea06ac5aea4109a50de97eae3c346c3c483edde83bfac0d6540f218e06d216`.
The 2,939-byte reproduction record has SHA-256
`90e011417c9f6e50111dc6d430aceb8bea9e302d7f9a239a53e1190df3955f4d`.
A first dependency setup selected host Node 25 and was rejected before any test
or evidence command; it is not cited.

An assertion-only patch required `realpath(fixture.root) === fixture.root` in
the first state-first case. Staged alone in a second exact clone, it produced
tree `e4e17f3d4a0348a3b2d3eca2bc39d6c49e9cc4a4` and remained 15/19, but the
first failure moved directly to that assertion. Its 10,809-byte report and
9,114-byte `ERROR` manifest under
`artifacts/manual/wp5p-windows-owner-red/evidence/` have SHA-256
`1568e376fab1a73044df2c34ca9439bb58e27a5609148d6463f1cced2a66dd52`
and `40edd8e396916c1df641ab979fe364d94159f0f1eb8d65eb5f0f8a364658f6df`;
no receipt exists. Its 2,110-byte record has SHA-256
`cbba27231112e59ba4bbd5e27dba711909e7fd5dd8b916577e060409128fd803`.

**Correction.** `applyFixture()` now resolves only its freshly created root
through `realpath(await mkdtemp(...))`; the direct root-identity assertion
remains. Every repository, plan, artifact, apply, journal, result, and deletion
path is consequently derived from one controlled spelling. Production
`evidence-retention.ts`, `retention-apply-operation.ts`, `schema.ts`,
`state-store.ts`, `path-safety.ts`, `git-isolation.ts`, strict containment,
authorization, recovery, and controller policy remain byte-identical. This is
a controlled fixture correction, not a durable production decision, so no
decision-log entry is required.

**Focused diagnostics.** Windows under another genuine short temp alias and a
fresh Linux ext4 clone staged only the corrected test at tree
`35f950dba9f41675493817f3a442c9a32f35694f`; both passed 19/19 with zero skips
and valid receipts. Windows's 6,769-byte report, 603-byte receipt, and
9,373-byte manifest have SHA-256
`d31a144ec0602813a1120a8092937349ddb20bdb1f65eef5b94b096535ad56f1`,
`9b11469a60398720b5884781c2b4fade2ff724fef42cdd4dbe31e898487f52f6`,
and `99fb91ea3122c8e7898867630e91b9149dc9b404a1631da0df23b78659905ebc`.
Linux's 6,713-byte report, 603-byte receipt, and 9,278-byte manifest have
SHA-256 `178a653ba74b520f89e708a3340a0e3f8fc10e15e4799cc6087d364b37c830b0`,
`a934d99a1dfeb0d4628f839f495519a7090847441cca44814e7702e450e941cb`,
and `40e4af3ce9a17135841806878d8f746d13da28a0ab5a9d17109d40a5ebe8bbc0`.
The next retained container-executor suite has its own test fixture and imports
no changed owner; this test-only correction cannot repair it, so it remains
open rather than being bundled.

**Stable-tree protocol.** The test, this log, and execution plan freeze before
final commands. Independent no-local/no-hardlink clones materialize the exact
staged tree and run fresh Linux focused, Windows-short focused, invariant,
orchestrator, unit, typecheck, lint, and format commands in distinct roots under
`artifacts/manual/wp5p-*-final/`. Outcomes and independent hashes stay in
ignored evidence and the final handoff rather than changing the candidate.

**Commit.** Assigned by the single cohesive WP5p commit containing this entry;
identify it as the newest commit touching the entry. It is not pushed.

**Known gaps.** The separately owned container-executor cluster, later Windows
workspace/Git/artifact/verification-clone cascades, the documented POSIX
`setsid` escape, CAL-1, hidden validation, product breadth, autonomous
readiness, and human verification remain open. This increment makes no
readiness or product-completion claim.

## 2026-08-22 — WP5o canonical Windows Doctor fixture root

**Objective.** Select the earliest unresolved retained controller failure after
WP5n, reproduce it from a clean exact source under Node `24.18.0` and pnpm
`11.15.1`, correct only its causal real-filesystem fixture precondition,
verify both controller platforms with command-owned evidence, and create one
narrow local commit without pushing. Preserve production Doctor, schema,
retention, path-safety, and Git identity policy; later Windows path clusters;
immutable authority; lifecycle/CAL-1 state; packages/lock/workflow; retained
evidence; and the protected human plan.

**Cause and ordering.** WP5n closes the last retained Linux failure cluster.
The retained hosted Windows report starts its remaining failed suites with the
Doctor retention-apply case at `1786995045207`, followed by evidence retention
at `1786995083268`, container execution at `1786995151895`, and later
workspace, Git, artifact, and clone cascades. The first Doctor test and its
strict schema/retention/path inputs remain unchanged from hosted commit
`87bd41e` through current HEAD except for WP5k's unrelated Doctor production
portability correction.

On the hosted Windows runner, Node's temp root uses the valid NTFS 8.3 spelling
`C:\Users\RUNNER~1\...`. The controlled fixture preserves that spelling
through `mkdtemp()`, but `realpath()` returns the long
`C:\Users\runneradmin\...` spelling. The fixture therefore persisted a
short-form `repositoryRoot` with long-form artifact-root realpaths. Strict
containment correctly rejected that mixed identity, so Doctor observed invalid
state before it could classify the pending retention operation. This is a
fixture precondition defect, not permission to relax production identity or
containment.

**Red evidence.** A clean no-hardlink Windows clone of exact WP5n commit
`b86083b97f82128061d0aa40bc1b539e5cffb323` / tree
`31ff3c8144d4e8f1991d075a78fc0857f1595289`, with `%TEMP%` and `%TMP%`
set to a genuine local 8.3 alias whose realpath has a different long spelling,
reproduced 18/19 passed, one failed, zero skipped at the exact retained Doctor
assertion. The command exited 1 with an ERROR manifest, no receipt, clean clone,
and exact toolchain. The 8,215-byte report and 9,111-byte manifest under
`artifacts/manual/wp5o-windows-doctor-pre-fix/evidence/` have SHA-256
`15ac9e70503a71228ab2c0540262efbf4b900f45cf8983fb3acc96b5824c978c`
and `493532d0bff5c955293fc500b2829ccbc0eafccfe22dc8d11cbced6c074b3fec`.

An assertion-only patch then required
`realpath(fixture.root) === fixture.root` before state construction. Applied
and staged alone in the disposable clone, it produced tree
`fa3395b684f18a264b33ab58d68327db044534a7` and failed directly at that new
owner precondition: 18/19 passed, one failed, zero skipped, ERROR/no receipt,
and exact one-path staged scope. Its 7,563-byte report and 9,110-byte manifest
under `artifacts/manual/wp5o-windows-doctor-owner-red/evidence/` have SHA-256
`15d413e7a4ddcc7a33dc20c1069bf28f55e78664176653df5ba3e22941836cfc`
and `5423dc27530648f7d4d4a74b908c66941a3483468e7070f2654fbbe55c43b605`.

**Correction.** `repositoryFixture()` now resolves the newly created temp
directory once through `realpath(await mkdtemp(...))` and retains the direct
root-identity assertion in the affected retention test. Every derived
repository/artifact/apply/deletion path therefore uses one spelling. Production
`doctor.ts`, `schema.ts`, `retention-apply-operation.ts`,
`path-safety.ts`, `git-isolation.ts`, strict containment, alias rejection,
and controller policy remain byte-identical. This is a controlled fixture
correction, not a durable production-contract decision, so no decision-log
entry is required.

**Focused diagnostics.** Windows with the same genuine short temp alias and a
clean Linux ext4 clone both staged only the corrected Doctor test at tree
`c57589de1ed26e90700c6e1b1142a17b1fb986bc` and passed 19/19 with zero
skips. Every manifest/receipt/artifact binding independently matched.
Windows's 6,999-byte report, 591-byte receipt, and 9,299-byte manifest have
SHA-256
`5c8bdd3ab9d0d649221e5acaa78f278c986cab7dd9019a4e7177b734af299b63`,
`4125c2944a8062d587775f864e56cb140e4e9b96d8605889503f0fa50713b8bd`,
and `e9523d080ab5351eed1197583e28ee3a6158b0c6c264ae8e9c310c056246d401`.
Linux's 6,989-byte report, 591-byte receipt, and 9,250-byte manifest have
SHA-256
`3001f8bcdfcf3cf34826f2da391f6ab00509a8a7ee4b032fa55e0c0abdbd0180`,
`d0150d3f360209b58fdf711523874ef87c5e3929a959c0480892a08d5a3698f8`,
and `cb31f1a8a7950e955d53aa84756db2daaa514c0931375433fb79f0d321cb1f2a`.
Two earlier disposable Linux setup attempts never reached Vitest or created an
evidence root: one retained-script line-continuation defect and one incomplete
offline store. Both clones cleaned successfully; the exact locked closure was
then hydrated and the cited diagnostic passed.

**Stable-tree milestone protocol.** The test, this log, and execution plan
freeze before final commands. The exact staged tree runs a fresh Linux focused
shard and receipt-owning Windows-short-temp focused, invariant, orchestrator,
unit, typecheck, lint, and format commands separately and serially in fresh
roots beneath `artifacts/manual/wp5o-*-final/`. Outcomes and independent
hashes stay in ignored command evidence and the final handoff rather than being
backfilled into tracked files and changing the candidate.

**Commit.** Assigned by the single cohesive WP5o commit containing this entry;
identify it as the newest commit touching the entry. It is not pushed.
`origin/master` remained at WP5n's grandparent before this increment; no
remote mutation occurs here.

**Known gaps.** The next Windows evidence-retention fixture cluster, larger
Windows Git/path-spelling and identity cascades, container path fixtures, the
documented POSIX `setsid` escape, CAL-1, hidden validation, product breadth,
autonomous readiness, and human verification remain open. This increment makes
no readiness or product-completion claim.

## 2026-08-21 — WP5n POSIX candidate-identity fixture materialization

**Objective.** Select the earliest unresolved retained Linux controller
failure after WP5m, reproduce it from a clean exact source under Node
`24.18.0` and pnpm `11.15.1`, correct only its causal real-Git fixture
precondition, verify both controller platforms with command-owned evidence,
and create one narrow local commit without pushing. Preserve production
candidate identity and Git inspection policy, later path-portability clusters,
immutable authority, lifecycle/CAL-1 state, packages/locks/workflow, retained
evidence, and the protected human plan.

**Cause and ordering.** Retained hosted Linux run `32060615125` starts its
failed suites at Doctor `1786995000003`, process supervisor `1786995022223`,
worked example `1786995133398`, and candidate identity `1786995183453`. WP5k,
WP5l, and WP5m close the first three, making `candidate-identity.test.ts` the
next cluster. Its production owner, test, shared Git-inspection owner, and
ignore file are byte-identical from hosted commit `87bd41e` through WP5m.

The candidate fixture uses `git update-index --chmod=+x` and commits the
mode-only tree change. On POSIX with `core.filemode=true`, Git records `100755`
in the index/tree but does not mutate the existing worktree file from
`100644`. The fixture therefore sampled its supposed clean `modeIdentity` while
Git already reported `.M change.txt`; adding `dirty.txt` left both identities
at `clean:false`, so the expected differing field disappeared. Windows uses
`core.filemode=false`, which masked the incomplete fixture precondition. Exact
cross-platform probes confirmed `dirty.txt` is not ignored and that
materializing only mode `0755` removes the Linux `.M` while retaining the
untracked-file status.

**Red evidence.** A clean no-hardlink Ubuntu WSL2 clone of exact WP5m commit
`69e92fc3e6d44ffa329ffd94c23c60f1bcfba0d3` / tree
`8b8cde4728fbe0f186efed117a77a7cd8ead6324` reproduced 2/3 passed, one
failed, zero skipped with the exact hosted `expected [] to deeply equal
[ 'clean' ]` assertion, an ERROR manifest, no receipt, clean clone, exact
toolchain, and confirmed cleanup. The shard ran once. Its post-run shell
predicate had an unmatched-quote defect after evidence production; the
existing evidence was finalized independently, and the attempted second
invocation refused the existing root before running a shard. The 3,309-byte
record at
`artifacts/manual/wp5n-linux-candidate-identity-pre-fix/reproduction.json` has
SHA-256
`ee2a85dcbe34537e292f6d3291721a8ad4e8bf70aa758573af579168b0e6a8b2`;
its 1,960-byte report, 8,871-byte manifest, and 340-byte toolchain record have
SHA-256
`669710c3fc0ea3cf65f84015e2e1c46ca5476e3c280044262414da9cdcd8188a`,
`cf3e2d2ea2c018358c755c4733ab8c08dd34b8c1c62cc4849150d8f56a189906`,
and `d521e219427b86398e6d610bd984c2ad9813d2b43e02c66f3d3a8b79aa46e548`.

An assertion-only direct owner patch then required `modeIdentity.clean` before
the later untracked write. Applied and staged alone in a second clean exact-
HEAD Linux clone, it produced tree
`4ad410fa0082ae02f238ad052f84167db0bd7bcd` and failed directly at that
new assertion: 2/3 passed, one failed, zero skipped, ERROR/no receipt, exact
one-path staged scope, and confirmed cleanup. Its 2,068-byte record at
`artifacts/manual/wp5n-linux-owner-assertion-red/reproduction.json` has
SHA-256
`cdcf6795ab468f27686b4eb91049189fc0e8165e860e553ee888c4a3fa7b76c6`;
the 1,967-byte report and 8,870-byte manifest have SHA-256
`f39e292386628ad15686bbe66e3eb0a135c2c306462dda9794b50ec3a36d6509`
and `7708772af4d6deb12dc011e2ff98577ed643952abbc23666c08511d617e48545`.

**Correction.** The controlled test file is now set to mode `0755` after the
mode-only commit and before shared-owner inspection. On POSIX this materializes
the exact committed mode; on Windows `chmod` is harmless while
`core.filemode=false`. The direct clean assertion remains, followed by the
existing distinct tree/digest checks and later exact `clean`-only difference.
Production `candidate-identity.ts`, `git-isolation.ts`, status argv, identity
fields, digest framing, dirty-candidate rejection, and every controller policy
boundary remain byte-identical. This is a fixture correction, not a durable
production-contract decision, so no decision-log entry is required.

**Focused diagnostics.** A clean exact-Linux clone and the Windows source
checkout both staged only the corrected test at tree
`28b8e7e61e02f1ae5e9771c66f4c9df0d9b821f3` and passed 3/3 with zero
skips. Every manifest/receipt/artifact binding independently matched. Linux's
1,609-byte report, 603-byte receipt, and 9,119-byte manifest have SHA-256
`830fc046e5337a439ac1d3338aaeac806631e2fb2b2af9fabff56bc3bcecf951`,
`5b5a5bdfa2d5083b6237f7a5bfc4e57b26a1c657e5058ddc61ec9adbf10e28d4`,
and `0ef1269d76d176b7b892c882ab5425481fedaf6b30859ac22d5d5c9c7aa0faa9`.
Windows's 1,612-byte report, 603-byte receipt, and 9,159-byte manifest have
SHA-256
`fb23027e2ebc2ba611ef567c7cceb0fa9fa8d65bb4655f6e30dd31e6cfce16aa`,
`6341d2543ab31370d2698a1d54dc5e1d1d8e0a834827e745101cd1c566c13563`,
and `7c8d3b33b06b8f601c0b5dbea70d933d27830fad08798a39327d523473e1137c`.

**Stable-tree milestone protocol.** The test, this log, and execution plan
freeze before final commands. The exact staged tree runs a fresh Linux focused
shard and receipt-owning Windows focused, invariant, orchestrator, unit,
typecheck, lint, and format commands separately and serially in fresh roots
beneath `artifacts/manual/wp5n-*-final/`. Outcomes and independent hashes stay
in ignored command evidence and the final handoff rather than being backfilled
into tracked files and changing the candidate.

**Commit.** Assigned by the single cohesive WP5n commit containing this entry;
identify it as the newest commit touching the entry. It is not pushed.
`origin/master` remained at WP5m's parent before this increment; no remote
mutation occurs here.

**Known gaps.** Larger Windows path-spelling/identity cascades, the documented
POSIX `setsid` escape, CAL-1, hidden validation, product breadth, autonomous
readiness, and human verification remain open. This increment makes no
readiness or product-completion claim.

## 2026-08-21 — WP5m canonical worked-example payload identities

**Objective.** Select the earliest unresolved hosted Linux controller failure
after WP5k and WP5l, reproduce it from clean exact source under Node `24.18.0`
and pnpm `11.15.1`, repair only its causal historical-package identity facts,
verify both controller platforms with command-owned evidence, and create one
narrow local commit without pushing. Preserve every historical payload blob,
strict validation and cross-links, later candidate-identity and path-portability
clusters, immutable authority, lifecycle/CAL-1 state, packages/locks/workflow,
retained evidence, and the protected human plan.

**Cause and ordering.** Retained hosted Linux run `32060615125` starts its
failed suites at Doctor `1786995000003`, process supervisor `1786995022223`,
worked example `1786995133398`, and candidate identity `1786995183453`. WP5k
and WP5l close the first two, making `worked-example.test.ts` the next causal
cluster. Its owner/test bytes are unchanged from hosted commit `87bd41e`
through WP5l.

WP4c generated three descriptor identities from stale Windows worktree copies:
`invariant-suite.json` recorded 4,476 CRLF bytes instead of its 4,333-byte LF
Git blob; `loop-recommissioning-verification.json` recorded 7,013 instead of
6,821; and `slow-suite-registry.json` recorded 463 instead of 452. The global
`* text=auto eol=lf` attribute predates WP4c, but those local copies survived
from earlier checkout/edit history while Git committed canonical LF. All three
staged blobs are unchanged from the WP4c base, parse to the same JSON as the
stale copies, and retain every schema and cross-link. The other four descriptor
entries already match Git exactly. Linux correctly materialized LF and rejected
the first impossible descriptor identity; four negative cases then cascaded at
that earlier boundary instead of reaching their intended assertions.

**Red evidence.** A single clean no-hardlink Ubuntu WSL2 clone of exact WP5l
commit `31a9e53ab2491ead0a3c88fac0860fdab9641f3a` / tree
`1136baa31cbafbce2fbad27846395eebd6f903f9` reproduced 4/9 passed and the
exact five hosted worked-example failures with an ERROR manifest, no receipt,
clean source, exact toolchain, and confirmed clone cleanup. The first post-run
parser rejected its own overly broad expectation because Vitest elides the
causal error inside four downstream matcher messages; the shard was not rerun.
A separate fail-closed finalizer accepted only the exact direct identity error
and those four exact elided cascades. The 8,014-byte record at
`artifacts/manual/wp5m-linux-worked-example-pre-fix/reproduction.json` has
SHA-256
`7093b891545acacdfc9e1828bff3c9b4d2224c4decd758f42d367783044fc023`;
its 8,281-byte report and 9,022-byte ERROR manifest have SHA-256
`3ba2d7f230d807b0ff1180c44206218074a50afbfe3daf87e96028401601ba08`
and `45a106ffbb776a4ccbe32a7ebc2343b18749e64043452b14e831f26ffed1bd22`.

The direct regression hashes every exact staged payload blob and compares the
complete ordered inventory with the descriptor. A second clean exact-WP5l
Linux clone applied and staged only its 1,812-byte patch (SHA-256
`fef63f0953481edaa20f047444d441dd1a1bea89c38fb1e97c2a709e9630bb63`)
at tree `e92e6e455388aaa919d0ed6633ff2bb7876e656b` and proved it red: 4/10
passed, six failed, ERROR/no receipt, staged-only test scope, and confirmed
cleanup. Vitest elided the array contents from the owner failure, so the first
post-run predicate again rejected only its own message assumption; the shard
was not rerun, and a separate finalizer bound the exact test patch and manifest
candidate tree to the failed owner assertion plus the direct mismatch and four
cascades. Its 8,906-byte record has SHA-256
`fd98168fa70a2c894569456f214e1a56edee9e48ac247633c47bea6895e42ded`;
the 8,883-byte report and 9,016-byte ERROR manifest have SHA-256
`ed0a300277880e6c5f2d576622fe47dfee216425fc1efff88f89e7f9d4c2c69c`
and `7fbb24e87ce3cc4ebe18ac8dfa012e8cb760831bdbcb6144405d6a2b06a108ef`.

**Executable semantic audit and correction.** Before source implementation, a
third clean Linux clone proposed only the owner test and three descriptor
metadata pairs. The first audit predicate overreached by requiring the WP4c
README change to predate WP4c, and the next invocation forwarded a literal
separator rejected by the strict CLI; neither reached or altered source
implementation. The corrected audit proved all seven candidate payload blobs
equal HEAD, all three mismatched blobs equal the WP4c base, zero payload paths
changed, and exactly three descriptor byte/hash pairs differed. The real
explicit validator then passed the complete regular/tracked file inventory,
strict schemas, legacy identities, registry/check catalogue, protected paths,
and historical/inactive/non-executable semantics. The complete focused suite
passed 10/10 with a valid receipt at candidate tree
`f5f18bd8ba06c2b19c5c7874410905a4f23f55b5`.

The 10,752-byte audit at
`artifacts/manual/wp5m-semantic-audit-pre-implementation/audit-result.json`
has SHA-256
`5f5562f6c5228de6b59228fd4a6c5aa56289bae925b1f03105d8c0f57d616baf`.
Its 4,025-byte report, 9,271-byte manifest, and 599-byte receipt have SHA-256
`54607d5d380460e1394a42d1eb233c3bd5e549bab6ffb19308e5fcd8e551e745`,
`005cd1ba3c9d46b96c5ae6e7cdad6d4dbf2b716cf6ced35ebaf6a88cca217633`,
and `f0aa9e7e4e402047d8838e0069057ff1b854b1bb30494cbb9385e656be22f0de`.

Source now changes only those audited descriptor pairs and the staged-blob
regression. Runtime validation remains byte-exact and fail closed; it does not
normalize newlines or accept alternate identities. No payload, role,
provenance, schema, link, registry, check, protection, or legacy semantic
changes. Pinned Prettier materialized the three stale local Windows copies as
LF; it also reformatted one unrelated legacy-manifest array, which was
immediately restored with `apply_patch`. Independent raw-byte comparison shows
all three working copies exactly equal their pre-existing index blobs, and no
payload path is changed or staged. This restores the already-recorded WP4c
exact-tracked-byte decision, so no new decision record is required.

**Focused diagnostics.** Exact Windows focused verification passed 10/10 with
no skips against the same two-file tree already proved on Linux. The 3,999-byte
report at
`artifacts/manual/wp5m-windows-focused-diagnostic-1/evidence/invariant-vitest-report.json`
has SHA-256
`0607acdb81ee1a047ae36f820909dfd992763382ab741d19ea6a8be20140e5ee`;
its 9,307-byte PASS manifest and 599-byte receipt have SHA-256
`dd3ca6972c9183850f6e79f59d4a6652b1b3919b39d1c5e3bd8baae975cb715e`
and `e4282c26575d0ab12238f92d9d6cd11250366fd71bc63c484d51cedd613bfdf3`.
Independent inspection matched the receipt and artifact bindings with zero
mismatches. The exact Windows explicit validator also returned PASS for the
2,948-byte corrected descriptor at SHA-256
`be37c29dbe123d2da4eba93b525794f17b76143f88ec34bda9fcf830fb9a8354`
and all seven audited file identities.

**Stable-tree milestone protocol.** Descriptor, owner regression, this log,
and the execution plan freeze before final commands. The exact staged tree runs
a fresh Linux focused shard and receipt-owning Windows focused, invariant,
orchestrator, unit, typecheck, lint, and format commands separately and
serially in fresh roots beneath `artifacts/manual/wp5m-*-final/`. Outcomes and
independent hashes remain in ignored command evidence and the final handoff
rather than being backfilled into tracked files and changing the candidate.

**Commit.** Assigned by the single cohesive WP5m commit containing this entry;
identify it as the newest commit touching the entry. It is not pushed. A later
external publication had already advanced `origin/master` to WP5l before this
increment began; no remote mutation occurs here.

**Known gaps.** Candidate identity is the next retained Linux controller
cluster. The larger Windows path-spelling/identity cascades, documented POSIX
`setsid` escape, CAL-1, hidden validation, product breadth, autonomous
readiness, and human verification remain open. This increment makes no
readiness or product-completion claim.

## 2026-08-18 — WP5l POSIX process-group supervision portability

**Objective.** Select the earliest unresolved hosted Linux controller failure
after WP5k's Doctor correction, reproduce it from clean exact source under Node
`24.18.0` and pnpm `11.15.1`, correct only its causal process-group
portability facts, verify both supported controller platforms with
command-owned evidence, and create one narrow local commit without pushing.
Preserve the documented `setsid` escape residual, shared supervision policy,
all later controller clusters, immutable authority, lifecycle/CAL-1 state,
packages/locks/workflow, retained evidence, and the protected human plan.

**Cause and ordering.** The retained Linux orchestrator report from exact
runtime run `32060615125` is 214,181 bytes with SHA-256
`a6e7cc9d098dc52327b10ffdf33067c06dbf8eb18a73cae8033b0d902339e188`.
Failed-suite starts are Doctor `1786995000003`, process supervisor
`1786995022223`, worked example `1786995133398`, and candidate identity
`1786995183453`; process supervision is therefore the first unresolved suite
after WP5k. Its owner and test are byte-unchanged from hosted commit `87bd41e`
through current WP5k `HEAD`.

The suite had two POSIX failures. The intact-tree output-limit fixture spawned
its grandchild with `detached: true` on every platform. That topology is needed
on Windows to escape libuv's job object and prove force-first `taskkill /T`,
but on POSIX it creates a new session outside the supervised root's process
group—exactly the explicitly recorded WP3a `setsid` escape residual—so the
group strike correctly could not reap it. Separately, after a root exited and
left no process group, the drain sweep's `kill(-pgid, SIGKILL)` returned
`ESRCH`; the owner mislabeled that already-absent target as
`posix-group-sigkill-failed:ESRCH`.

**Red evidence.** A clean no-hardlink Ubuntu WSL2 clone of exact WP5k commit
`6bfe4a84a8d616725e5c41eaa9c29ad12a1f747a` / tree
`7f93ea058e627b1840a88c400e08a4f45bc2bd7b` reproduced exactly 18/20
passed and those two failures, with an ERROR manifest, no receipt, clean source
identity, exact Linux toolchain, and confirmed clone cleanup. The 2,781-byte
record at
`artifacts/manual/wp5l-linux-process-supervisor-pre-fix/reproduction.json` has
SHA-256
`19d72bd76613df98bccba6d3928523cabeee4be955e49fb2dcbc1282c75effc2`;
its 7,948-byte report has SHA-256
`b5bfeb2b45233d2bb13bbbe8dc18e1dec8dd44a3b3e69ff1c9a40258a2dbe497`.

A direct owner-level regression then used the existing impossible fake PID to
produce real Linux `ESRCH` and injected `EACCES` to require every other signal
failure to remain explicit. A second clean exact-HEAD clone applied only the
2,294-byte test patch (SHA-256
`97aac7f482eaa39bdc067855067b30a66061d9c736ec88fcde74657d049c04cf`)
and proved the regression red at 18/21 passed, three failed, zero skipped, with
ERROR/no receipt and staged-only source scope. Its 3,719-byte record has
SHA-256
`97247b00acd78a3913ce43e0ce1d27881234f1ad2f1826bd10b2597a8250769d`;
the 8,732-byte report has SHA-256
`1e96e4e43e2218296082dd11d80c3e15b485f228f036b6534b3a785651d27266`.

**Correction.** The intact-tree fixture now detaches its grandchild only on
Windows; POSIX keeps it in the supervisor-created process group and therefore
tests the contract the owner actually provides. Production drain-sweep
classification retains `posix-group-sigkill` when the signal reports only
`ESRCH`, because there is no remaining group to kill; every other error keeps
`posix-group-sigkill-failed:<code>`. Spawn topology, group SIGTERM/SIGKILL
escalation, timeout/output cap, redaction, drain bounds, exactly-once settle,
and shared controller/verifier/evidence ownership do not change. The recorded
`setsid`-detached daemon residual remains open and is not relabeled as solved.

**Focused diagnostics.** A clean exact-Linux clone with only the owner/test
correction passed 21/21 with zero skips and a valid receipt; its patch tree is
`ab13cdb58d7d3c378822d94466960ad1ee553155`. The 7,605-byte report at
`artifacts/manual/wp5l-linux-focused-diagnostic-1/evidence/invariant-vitest-report.json`
has SHA-256
`160772885fcf18fac26d03bf3780bed16a9a2b6faf2d22675a49791b33a5ed33`,
and the independently matched 603-byte receipt has SHA-256
`4f7bad05cb7de782bf9ea1fba1e744cd7584a863000a838dd958e91cb512efe5`.
Exact Windows focused verification passed 19/21 with zero failures and only
the two existing POSIX-only skips; its 7,504-byte report has SHA-256
`3250f8104f6874b135b7acc65bc0bb28f1a0e402f75c0a8f47754ea78bc5c11b`
and its independently matched 603-byte receipt has SHA-256
`7796162fec6aa510063c790c2c14404fd1a78d9f6a83aae1277177465c3ac2ae`.

The pre-freeze receipt-owning format diagnostic then correctly rejected style
in both changed TypeScript files. Its 8,953-byte ERROR manifest has SHA-256
`c57322e39f00f063dc2ad2f7ac2ba808439ab7196c50c0d23e36d92d094a51c4`
and no receipt. Pinned Prettier changed only those two bounded paths; no
diagnostic PASS is reused after formatting, and every frozen-tree final command
runs again.

**Stable-tree milestone protocol.** Source, regression, this log, and the
execution plan freeze before final commands. The exact staged tree runs a fresh
Linux focused shard and receipt-owning Windows focused, invariant,
orchestrator, unit, typecheck, lint, and format commands separately and
serially in fresh roots beneath `artifacts/manual/wp5l-*-final/`. Outcomes and
independent hashes remain in ignored command evidence and the final handoff
rather than being backfilled into tracked files and changing the candidate.

**Commit.** Assigned by the single cohesive WP5l commit containing this entry;
identify it as the newest commit touching the entry. It is not pushed. A later
external publication had already advanced `origin/master` to WP5k before this
increment began; no remote mutation occurs here.

**Known gaps.** Worked-example payload identity and candidate identity are the
next retained Linux controller clusters. The larger Windows controller
path-spelling/identity cascades, documented POSIX `setsid` process escape,
CAL-1, hidden validation, product breadth, autonomous readiness, and human
verification remain open. This increment makes no readiness or product-
completion claim.

## 2026-08-18 — WP5k POSIX Doctor ENOTDIR portability closure

**Objective.** Select one causal Linux controller failure from retained Exact
runtime CI run `32060615125`, reproduce it locally under the exact Linux
toolchain, correct its root cause without weakening configured-path or lease
mutation fences, verify both supported controller platforms with command-owned
evidence, and create one narrow local commit without pushing. Preserve all
later controller clusters, immutable authority, lifecycle/CAL-1 state,
packages/locks/workflow, completed evidence, and the protected human plan.

**Cause and reproduction.** The retained controller report recorded failed
suite starts in this order: Doctor `1786995000003`, process supervisor
`1786995022223`, worked example `1786995133398`, and candidate identity
`1786995183453`. The Doctor suite was therefore the first causal boundary. On
POSIX, `lstat` of `state/controller.lease` beneath a regular-file
`artifacts/orchestrator` ancestor raises `ENOTDIR`; Windows reports the same
unreachable leaf as `ENOENT`. `readLegacyPath` propagated the POSIX error and
crashed read-only Doctor before its configured-path block could be returned.

An exact clean-`b04d33a` Ubuntu WSL2 clone under Node `v24.18.0` and pnpm
`11.15.1` reproduced 18/19 Doctor tests with the exact hosted ENOTDIR stack,
an ERROR manifest, no receipt, clean source identity, and confirmed clone
cleanup. Its 2,532-byte structured record at
`artifacts/manual/wp5k-linux-enotdir-pre-fix/reproduction.json` has SHA-256
`b3c37c446d154b63562f3df140e26486a612269c02b0fd756a29aaf7a0913017`.
The new direct lease-owner regression was then applied alone to another exact
clone and proved red: 34/36 passed, with exactly the owner and Doctor cases
failing at the same ENOTDIR stack, and no passing receipt. Its 3,571-byte
record at
`artifacts/manual/wp5k-linux-owner-regression-red/reproduction.json` has
SHA-256
`40d928bf18be9cd7caaf8c74a5633c29005e97945ffa6fdbaab9aa4bced68a99`.

**Correction.** The two read-only observers involved in the same case now
classify only `ENOENT` and `ENOTDIR` as an unreachable leaf. Doctor's
configured-path walker continues upward to the actual regular-file ancestor
and retains its `configured-path-unsafe` block with exact nearest-path/kind
facts; the retired legacy-guard reader reports no leaf. All other errors retain
their prior fail-closed behavior. `ControllerLease.acquire` still runs
`ensureContainedDirectory`, rejects the obstructing ancestor with ENOTDIR,
preserves its bytes, and publishes no private lease ref. The new regression
asserts that complete inspection/mutation boundary.

The first Linux diagnostic after only the lease-reader correction intentionally
remained non-passing at 35/36: it exposed the same POSIX code in Doctor's own
ancestor walker rather than concealing the incomplete fix. Its 13,463-byte
ERROR report is retained at
`artifacts/manual/wp5k-linux-focused-diagnostic-1/failure-evidence/invariant-vitest-report.json`
with SHA-256
`a28f8e7e359b496b93aeff2398dbcf39fddb5705d2c15db33ef68f6e8b28a5f1`.

**Implementation diagnostics.** After correcting both read-only observers,
the exact Linux affected shard passed 36/36 across four reported suites and an
independent audit matched one receipt, one artifact, and one manifest binding
with zero mismatches. Its 1,525-byte summary at
`artifacts/manual/wp5k-linux-focused-diagnostic-1/result-summary.json` has
SHA-256
`49030803e8868a26f859b4585890b29fcda89b1b1c1b33941286a44f8a22df7d`;
the 12,523-byte report has SHA-256
`3ad67c4082e65ce5ca3200f4bc6617bec9dc246bf49fb51e5c6b47d3f03cf46c`.
The post-change Windows affected shard independently passed 36/36; its
12,498-byte report has SHA-256
`35a2326793e320608282c1692c8c659ab7956f4cea8c63a8f61a41d5b03338f3`,
and its receipt/artifact/manifest bindings all matched.

**Rejected first freeze.** The first staged candidate tree
`f1d4eea454acfe614ef5001503940df40f4328ba` passed exact Linux focused 36/36,
Windows focused 36/36, all four invariant commands, orchestrator 589/591 with
only the two declared skips, unit 602/604 with the same skips, typecheck, and
lint. Final format then correctly rejected one style issue in the new lease
regression. Its ERROR manifest retained no receipt and has SHA-256
`9f99fc2c7eef6e0fac56428349e3a9bc72131c4141fef649f28f87f4ea25022f`.
Pinned Prettier is applied only to that test before the second freeze; because
the tracked tree changes, none of the first-tree PASS receipts are reused as
final evidence.

**Recurring harness timeout.** The formatted second tree
`f8219ed79d5327ebe528d2015839eb83e16db012` passed format, exact Linux and
Windows focused 36/36, invariants, typecheck, and lint. Its full orchestrator
rerun then rejected the tree at 588/591 passed, one failed, and the same two
declared skips. The unchanged real workspace-diagnostics cleanup assertion hit
its explicit 30-second test timeout at 30,173.705 ms. The 207,946-byte ERROR
report at
`artifacts/manual/wp5k-orchestrator-final-r2/orchestrator-report.json` has
SHA-256
`ca753467c212df610fca2f061a19eac0394060d6e22ea21ca28035fb22f035b3`;
its manifest retained no receipt.

An audit of 98 retained reports for that exact assertion found four timeout
failures at 30,173.705, 30,263.47, 30,516.37, and 31,512.311 ms. Identical
semantic runs pass as high as 27,170.63 ms; the first WP5k tree passed in
22,352.244 ms and WP5j passed in 23,009.979 ms. The test performs real
clone/archive/delete work, and the 30-second harness budget is therefore a
known recurring Windows filesystem/scheduling flake rather than a cleanup or
ENOTDIR semantic regression. Under the regression rule, finalization stops and
only that test timeout advances to a still-bounded 60 seconds. No production
code, assertion, retry, skip, conditional, mock, or acceptance performance
threshold changes. Three serial receipt-owning focused-file runs and every
frozen-tree final command run again afterward; no second-tree PASS is reused.

The timeout-only correction then passed three serial receipt-owning focused
executions of the complete real cleanup file: 9/9 each with zero skips, while
the target assertion completed in 24,159.078, 25,845.774, and 25,979.5 ms.
Every receipt, artifact, and manifest binding independently matched with zero
mismatches. The three report SHA-256 values are
`acb46cc8680cbe123c741642001c8e71bebb6f0c07347dfe7eb7ee02e0856343`,
`495d2da11ed8e89898b79dfdabd2f6745eebb6c6516059ebeda10c6b159c6b8a`,
and `c5a30820806734925b1f1a102f53103ec867cd754b37dd468df0edbcf830c6df`.
These focused results are diagnostic; a new frozen tree still runs every final
gate serially.

**Stable-tree milestone protocol.** Source, regression, this log, and the
execution plan freeze before final commands. The exact staged tree runs a fresh
Linux focused shard and receipt-owning Windows focused, invariant,
orchestrator, unit, typecheck, lint, and format commands in distinct ignored
roots beneath `artifacts/manual/wp5k-*-final/`. Outcomes and independent hashes
remain in those command-owned artifacts and the final handoff rather than being
backfilled into tracked files and changing the candidate they verify.

**Commit.** Assigned by the single cohesive WP5k commit containing this entry;
identify it as the newest commit touching the entry. It is not pushed.

**Known gaps.** Process-supervision, worked-example payload identity,
candidate identity, and the larger Windows controller portability clusters
remain open, as do CAL-1, hidden validation, product breadth, autonomous
readiness, and human verification. This increment makes no readiness or
product-completion claim.

## 2026-08-17 — WP5j Windows fresh-adopter shared-store closure

**Objective.** Reconcile pushed WP5i commit
`87bd41e072a9e49baf212dc803ead83acbdabb92` against its exact hosted run,
prove the trusted-container correction under real GitHub Docker, and fix only
the independent Windows fresh-adopter store-visibility failure. Preserve exact
tooling, offline/frozen/copy install policy, generated bootstrap history and
completion ineligibility, package/lock bytes, OCI behavior, controller
failures, immutable authority, commissioning/readiness/verifier meanings, and
the protected human plan. Create one local commit and do not push.

**Hosted audit.** Exact push run
`https://github.com/mclaurin10/milestone-loop-template/actions/runs/32060615125`
(run 5, attempt 1) executed the exact commit/tree from
`2026-08-17T19:29:21Z` through `19:35:24Z` and concluded `failure`. All five
jobs, every step, complete logs, eight annotations, and all five artifact ZIPs
were retrieved and inspected. Jobs were: fresh-adopter Windows
`95480834015` failure; controller Windows `95480834038` failure;
fresh-adopter Linux `95480834051` success; controller Linux `95480834113`
failure; trusted-container Linux `95480834183` success. The annotations were
five action-runtime Node 20 deprecation warnings and three exit-code failures,
not causal substitutes.

Artifact IDs / ZIP bytes / SHA-256 are: controller Windows `9298180337` /
52,794 / `7c58a84f11475d46a15e15f5cee430f938b866f6b17d20a7b18e1203f14f2c38`;
controller Linux `9298111032` / 49,146 /
`42e3c9d8325b818188c65ee2c9a1bbf8caa8d5d1c0bae2cb3125c81a3179f131`;
trusted container `9298026972` / 21,902 /
`9ca49490907fec39b280dc1d715478ee5798085719e55a2e8a11baaf43deca1c`;
adopter Windows `9298008310` / 8,736 /
`f210504bdb7850c7c046f5fcfdcfc6ee29c3ebc92ace7ed55d89c766c09ba22e`;
and adopter Linux `9298000229` / 15,191 /
`cbcfcffbec09c4bd39b1a28ab289440edb8de64c8cab8383aee0cabef1b0bdd5`.
Raw API responses, full logs, ZIPs, and extracted artifacts are retained under
ignored `artifacts/hosted/run-32060615125/`.

The independent 23,471-byte hosted audit has SHA-256
`54b50a40334ca8efab5aa291aa341b9516e4504783557d44d524feebb93060bf`
and zero mismatches: 13 PASS receipts, 13 rehashed artifacts totaling 81,253
bytes, 12 manifest bindings plus the OCI containment binding, and two honest
ERROR/no-receipt controller manifests. Both controllers passed invariant
totals 13/13, 7/7, 15/15, and 61/61. Linux then reported 578/588 tests passed,
9 failed, 1 skipped; Windows 512/588 passed, 74 failed, 2 skipped. Linux
fresh-adopter passed 4/4 with two audited receipts.

WP5i's hosted boundary is now proved: Docker `28.0.4` accepted exact
`committed-head` source identity, fixture hydration completed, and normal /
boundary / artifact-link / artifact-quota / output-flood / hang produced
PASS / PASS / ERROR / ERROR / ERROR / TIMEOUT as required. Every containment
report matched bytes/hash, network remained denied, root/store host mounts were
non-writable, every container/exporter/bounded volume was removed, and managed
resource inventories were empty before and after.

**Cause and correction.** Windows source install downloaded all 138 packages,
including `@eslint/js@10.0.1`, on GitHub's `D:` checkout drive. The generated
repository under `C:` then selected a different empty default store, reused and
downloaded zero packages, and failed offline for that exact tarball. Linux's
single-filesystem job passed. A logical `subst` control correctly reused one
physical store and was rejected as a reproduction; two project-config controls
also passed because pnpm propagated or copied the configured store. The
accepted invocation-shim control exposed a hydrated source store and distinct
empty child store without changing production commands. The unchanged smoke
then reproduced the exact failure while preserving source status and both lock
hashes. Its 3,696-byte structured record at
`artifacts/hosted/run-32060615125/reproduction/windows-store-split-wrapper-pre-fix/result.json`
has SHA-256
`a63005aee099fc03640d16b44f38b57dd97194b978d0edd7053c51888ab0aae2`.

The coordinator now resolves exactly one absolute existing `pnpm store path`
through the pinned invocation from the source cwd and passes it explicitly to
the generated install while retaining `--offline --frozen-lockfile
--package-import-method=copy`. Unsafe/failed store identity is fail-closed. The
smoke result records an `explicit-source-store` disposition and path hash, not
the host path. The workflow command, generated package, dependencies, locks,
and OCI boundary do not change.

The focused regression first failed 2/4 because the new owner did not exist,
then passed 4/4. Receipt-owning focused, typecheck, lint, and corrected format
diagnostics passed under Node `24.18.0` / pnpm `11.15.1`. A real isolated-store
corrected smoke passed install, typecheck, and 4/4 tests; independently matched
two receipts, two artifacts totaling 3,256 bytes, and two manifest bindings;
retained clean two-commit bootstrap history with no readiness marker/tree
history; removed its generated temporary root; and preserved source identity.
Its 3,606-byte result at
`artifacts/manual/wp5j-fresh-adopter-smoke-diagnostic-1/smoke-result.json` has
SHA-256
`9a3b76ba44b1255dcd644c1141ae4795fc6ba7e0082bb321bfbdd086bf1e791b`.

**Stable-tree milestone protocol.** Coordinator, regression, decision record,
this log, and the execution plan freeze before final commands. The exact staged
tree runs a fresh isolated-store smoke and receipt-owning focused, invariant,
orchestrator, unit, typecheck, lint, and format commands in separate fresh
roots beneath `artifacts/manual/wp5j-*-final/`. Outcomes and independent hashes
remain in ignored command evidence and the final handoff rather than being
backfilled into tracked files and changing the candidate they verify.

**Commit.** `b04d33a6869645ea4d847af7991831b249e2f882` (tree
`25f0c9d16c4160758161aa3aea96af0bd2e7b5a6`, parent
`87bd41e072a9e49baf212dc803ead83acbdabb92`). It was created locally without a
push during WP5j. A later human-side publication advanced `origin/master` to
that commit; exact hosted run `32073770072` then passed both fresh-adopter jobs
and trusted-container Linux while both controller jobs remained failed.

**Known gaps.** Only a later pushed native `windows-2022` run can close hosted
Windows fresh-adopter status. Linux/Windows controller portability clusters,
product placeholders, CAL-1, hidden validation, autonomous readiness, and
human verification remain open. This increment makes no readiness or product
completion claim.

## 2026-08-17 — WP5i exact OCI fixture-store closure

**Objective.** Reconcile pushed WP5h commit
`a868d9d92227cb95b17db93b14038ae2d24ec026` against its exact hosted run,
inspect every job/log/annotation/artifact, reproduce the first causal failure
after the corrected controller-source identity, and fix only that failure.
Preserve the candidate's offline/network-denied/read-only-store policy, all six
normal/adversarial cases, package and lock bytes, immutable authority,
commissioning/readiness/verifier meanings, and unrelated WP5 failures. Create
one local commit and do not push.

**Hosted audit and first cause.** Exact push run
`https://github.com/mclaurin10/milestone-loop-template/actions/runs/32047579881`
(run 4, attempt 1) executed commit
`a868d9d92227cb95b17db93b14038ae2d24ec026`, tree
`24954859be765bd893b5a3cfd41e2634a22578af`, from
`2026-08-17T16:51:24Z` through `16:57:56Z` and concluded `failure`. All five
independently scheduled full-history jobs, every step, complete log, all nine
annotations, and all five retained artifacts were inspected. The annotations
were five action-runtime Node 20 deprecation warnings and four process-failure
annotations; the warnings were not mislabeled as causes.

Linux fresh-adopter passed both receipt-owning commands and 4/4 tests. Windows
fresh-adopter failed its generated frozen offline install because the selected
Windows store lacked `@eslint/js@10.0.1`; that remains separate. Both
controllers passed contract 13/13, schema 7/7, policy 15/15, and verifier
fail-closed 61/61 before their independently retained orchestrator failures.
Linux reported 577/587 passed, 9 failed, 1 skipped across 180 suites. Windows
reported 509/587 passed, 76 failed, 2 skipped; its dominant cluster remains
GitHub's `RUNNER~1` versus `runneradmin` realpath spelling, with separate
worked-example/retention/schema cascades.

WP5h's intended Docker correction succeeded: real Docker client/server
`28.0.4` recorded `committed-head`, exact HEAD/tree, zero staged paths, and the
deterministic empty-path digest. The image built, the normal container started,
and cleanup removed the candidate/exporter/volumes with empty managed-resource
inventories before and after. The first new cause was then exact and narrow:
the root lock/store contained Vite `8.2.0`, while the protected OCI fixture lock
required Vite `8.2.1`; the unchanged offline candidate install failed with
`ERR_PNPM_NO_OFFLINE_TARBALL` for that tarball. Its 2,004-byte result has
SHA-256 `c36e504e25978aae4b8cc96a1f4d12c11228ad9d0bad4452bd23a8e669c042c4`.

The five downloaded ZIPs under ignored `artifacts/hosted/run-32047579881/`
match their retained bytes/SHA-256: controller Windows 52,900 /
`30700153ff0b4a7fce6dfb598d28defdc42113dc8dedcfb6e1dd962fd4b107af`;
controller Linux 49,138 /
`329883c4a35953718d0af13345c8a8aa6151bd1d236b2949fd3b97f501d1f126`;
adopter Windows 8,733 /
`5917c3c7768d423bb2d1c2dd907865bec1eee56864b63f7852bd562b2aaf80f9`;
adopter Linux 15,189 /
`fdcd3ff4d78fdc4fe5d3aa1c4af48501850540c8f53358c645cb731ed7764f96`;
and trusted container 5,481 /
`3b66cd202d706dbb0c00f99683083beada5bcab6d2d21a9f9793bbb828d5c32d`.
Independent extraction audit matched 12/12 PASS receipts, 12/12 declared
artifacts totaling 80,482 bytes, and 12/12 manifest bindings with zero
mismatches while preserving every ERROR/no-receipt boundary.

**Reproduction and correction.** A no-local/no-hardlinks clone of the exact
commit under Linux Node `v24.18.0`, pnpm `11.15.1`, and Git `2.43.0` populated
a new store only from the root frozen install. An exact fixture archive outside
workspace discovery then reproduced the missing `vite@8.2.1` tarball. The
2,836-byte structured record at
`artifacts/hosted/run-32047579881/reproduction/oci-store-closure/result.json`
has SHA-256
`29ad277635fcf1e3f713ad71c0d4b856834afd929dc297da4452674d720ce94d`.
The root lock remained 60,467 bytes / Vite `8.2.0` /
`154f9b86ae26bf839a51c2de1eed204397f7c54cf9dcf870320c881c3aa5c181`;
the fixture lock remained 24,385 bytes / Vite `8.2.1` /
`8623b26cc48086c4149d3d9a564ae3879072bf5a11da3a2ba3945fe3f7f9beca`.

A direct fixture-directory `pnpm fetch --frozen-lockfile` hydrated the missing
graph but also normalized the checked-out fixture lock's YAML formatting. That
is semantically harmless in a disposable copy but violates tracked-source byte
identity. The workflow therefore archives exact
`HEAD:fixtures/oci-candidate` bytes into a `mktemp` scratch directory, fetches
there with explicit `--ignore-workspace` and `--frozen-lockfile`, and removes
the scratch directory on exit. It runs after the root install and before Docker,
so both controller operations populate the same default store while the
candidate still receives only a read-only store mount and no network.

The second fresh explicit-store control downloaded the fixture closure, kept
the tracked fixture lock and package hashes exactly
`8623b26cc48086c4149d3d9a564ae3879072bf5a11da3a2ba3945fe3f7f9beca`
and `962c5d88ea243d7ca6b79982bf64a9928f8d27334f2aec084f87cc494e864cb5`,
and made the unchanged isolated offline/frozen/store-integrity install pass
with 47/47 packages reused. The executable workflow contract binds the exact
archive/fetch/cleanup block once and enforces its position between source
install and the real matrix; mutation coverage rejects removal, reordering,
wrong archive root, root-directory substitution, missing workspace isolation,
or missing frozen-lock enforcement. No package, lock, fixture, OCI provider,
case, containment, or candidate command changed.

**Implementation diagnostics.** Under pinned Windows Node `24.18.0` and pnpm
`11.15.1`, the corrected receipt-owning workflow-contract shard passed 4/4
tests across 2/2 reported suites at
`artifacts/manual/wp5i-workflow-focused-diagnostic-2/` (2,104-byte report,
SHA-256
`bd94ba142ab100c81283bd72339761acb4313cd26767f1aa127396cb2afe8910`).
Receipt-owning typecheck and lint diagnostics passed at
`artifacts/manual/wp5i-typecheck-diagnostic-1/typecheck-report.json` (1,066
bytes, SHA-256
`d28d2480608f18f5fe0732702e4dbc11d4d9c56b70469b8c29c01642bdbbba16`)
and `artifacts/manual/wp5i-lint-diagnostic-1/lint-report.json` (1,599 bytes,
SHA-256
`ab6d8e78791a0146d94bf724bce7396963735d0552de3f33059a3e82a96ca645`).
These are iteration diagnostics, not substitutes for the final frozen-tree
commands.

**Stable-tree milestone protocol.** Workflow, contract/tests, decision record,
this log, and the execution plan freeze before final evidence. The exact staged
tree is compiled into ignored `artifacts/manual/wp5i-oci-final-build-1/`. A
disposable Linux clone receives that exact staged diff, a new default store,
the root frozen install, and the exact scratch-fixture fetch before the emitted
entry runs all six real Docker cases into
`artifacts/wp5i-oci-final-20260817/`. Receipt-owning focused, invariant,
orchestrator, unit, typecheck, lint, and format commands write fresh evidence
beneath `artifacts/manual/wp5i-*-final/`. Outcomes and independent artifact
hash audits remain in command-owned ignored artifacts and the final handoff
rather than being backfilled into tracked files and changing the tree they
verify. Long suites run separately and serially.

**Commit.** Assigned by the single cohesive WP5i commit containing this entry;
identify it as the newest commit touching the entry. It is not pushed.

**Known gaps.** A complete local fresh-store real-Docker matrix cannot
substitute for a later hosted Ubuntu run of the committed revision. The
Linux/Windows controller portability clusters and Windows fresh-adopter
cross-drive offline-store failure remain separate WP5 work. Product
placeholders, CAL-1, hidden validation, autonomous readiness, and human
verification remain open; this increment makes no product-completion claim.

## 2026-08-17 — WP5h generic OCI controller-source identity

**Objective.** Reconcile the pushed WP5g candidate against its exact hosted
run, inspect every job/log/annotation/artifact, reproduce the next first causal
trusted-container failure under exact pinned Linux tooling and real Docker, and
fix only that failure. Preserve the six-case OCI policy and every immutable,
commissioning, readiness, invariant, workflow, dependency, and unrelated WP5
meaning; create one local commit and do not push.

**Hosted audit and first cause.** Exact push run
`https://github.com/mclaurin10/milestone-loop-template/actions/runs/32039150245`
(run 3, attempt 1) executed commit
`a0e9af205b7c6dff1155a087dfe56c7786da2b79`, tree
`f998fb50c9ab249b7e07a6d70eebed8ea1513ae9`, from
`2026-08-17T14:28:20Z` through `14:34:40Z` and concluded `failure`. The five
independently scheduled full-history jobs all installed exact Node `24.18.0`
and pnpm `11.15.1`. Their complete logs were inspected: Linux adopter 247
lines / 21,094 characters; Windows controller 263 / 22,873; trusted container
259 / 21,779; Windows adopter 237 / 21,722; Linux controller 282 / 23,749. The
public annotation API contained five action-runtime warnings and four
exit-code failures, nine annotations total.

Both controllers passed the four-command invariant suite (contract 13/13,
schema 7/7, policy 15/15, fail-closed 61/61) and then failed their independently
retained orchestrator boundaries. Linux reported 574/584 passed, 9 failed, 1
skipped across 178 suites; Windows reported 508/584 passed, 74 failed, 2
skipped. Both retained ERROR manifests with no passing receipt, and later
controller commands correctly skipped. Linux fresh-adopter passed both
receipt-owning checks and 4/4 tests. Windows fresh-adopter again failed its
generated frozen offline install because the Windows pnpm store lacked the
`@eslint/js@10.0.1` tarball.

The WP5g argv repair worked exactly. Trusted-container confirmed real hosted
Docker client/server `28.0.4`, invoked
`pnpm test:oci-container --output artifacts/ci/trusted-container/matrix`, and
entered the strict current TypeScript with no extra separator. It then exposed
the next earlier-than-cases defect: the WP3d milestone harness required a
non-empty staged index and rejected GitHub's exact clean committed checkout as
`The WP3d candidate index is empty.` The 1,061-byte FAIL result has SHA-256
`c428400f08be282d144bb2e844f5970e31908911b3732671591ec3bd24871ea7`,
zero cases, and empty before/after managed-resource inventories.

All five authenticated artifacts are retained under ignored
`artifacts/hosted/run-32039150245/` and match GitHub metadata: controller
Windows 52,557 bytes / SHA-256
`304aefbb270c78477bd2bff791b13aa216882a3dbf8c2c26b4fa6194726e1ed6`;
controller Linux 49,000 /
`c8d5935bf9492395ef22fdf6978785f148dd33c2e80fd92a3f6943c92dbc08f4`;
adopter Windows 8,674 /
`753fc7cf1918e59a208e3e03e7877a66af589fd4e143525311eeacd906c7c5f0`;
adopter Linux 15,137 /
`ed0cf0db4b98e2205f260bc41f8778d0876d8aeb8114c6bda62609801f841c65`;
and trusted container 2,488 /
`0b86f79331f255a4fbd4674daa60ec1bae49497d1a5d2d8a07c93cddb7b9c561`.
Independent audit matched 12 hosted PASS receipts to 12 artifacts totaling
80,484 bytes with zero mismatches and preserved every ERROR/no-receipt
boundary.

**Reproduction and correction.** The exact current TypeScript source (35,259
bytes, SHA-256
`c5d2bf4e472c158c67b085c4b6bb31a576fc44362cac18944d6bb25f119bd7ff`)
was compiled into ignored diagnostic output, then run under Ubuntu WSL with
Linux Node `v24.18.0`, pnpm `11.15.1`, and real Docker `29.1.3`. It reproduced
the same empty-index failure at
`artifacts/hosted/run-32039150245/reproduction/clean-index-current/result.json`
(1,062 bytes, SHA-256
`c86b21780d44da208835804824bfbc55845868eb9677e708c5ea5c618c459278`)
before image or case execution and left no managed resource. A historical
compiled runner reached a different policy diagnostic and is retained but
explicitly rejected as current-source evidence.

The OCI entry now delegates tracked-source capture to one small owner. A clean
Git checkout is explicitly `committed-head` and binds candidate tree to
`HEAD^{tree}`. A pre-commit frozen candidate is explicitly `frozen-index` and
binds candidate tree to `git write-tree`, staged path count, and staged-path
digest. Both modes retain exact HEAD and HEAD-tree identity and reject any
unstaged tracked change. Result schema advances to `1.1.0` and records
`controllerSource`; the distributed OCI harness no longer requires, names, or
hashes the local protected human plan. No CI environment branch, fabricated
change, parser relaxation, provider/case/policy change, or workflow change was
introduced.

**Implementation diagnostics.** Under pinned Windows Node `24.18.0` and pnpm
`11.15.1`, the receipt-owning real-Git/workflow shard passed 6/6 tests with zero
failures or skips across 4/4 suites at
`artifacts/manual/wp5h-source-identity-focused-1/invariant-vitest-report.json`
(2,860 bytes, SHA-256
`2b0778a2ac5ce95bdbec86a92709617c9cb9568e0ef0b900e34c9d716565e2c5`).
Receipt-owning typecheck and lint diagnostics passed at
`artifacts/manual/wp5h-typecheck-diagnostic-1/typecheck-report.json` (1,075
bytes, SHA-256
`3a3e7ad14c73a68dbc7095618a790d17384438c14e97680b00d4ef95b81cfe63`)
and `artifacts/manual/wp5h-lint-diagnostic-1/lint-report.json` (1,608 bytes,
SHA-256
`73085a2ff0df3c500c68ea2b7c1234692ab773fdb7ec604babba767ac6bbe9e6`).
These are iteration diagnostics, not substitutes for the final frozen-tree
commands.

The first staged-tree matrix attempt correctly captured `frozen-index` source
identity and reached the real normal container, then exposed a narrow
implementation regression: the initial global schema-version bump also made
the validator expect containment report `1.1.0`, although the unchanged
containment report remains `1.0.0`. The rejected result is retained at
`artifacts/wp5h-oci-final-20260817/result.json` (1,957 bytes, SHA-256
`29bcbcf150055641b51a4be0bcc9eb78592fdc5dd82286abec15d05ca1105752`)
with zero accepted cases and empty before/after managed-resource inventories.
The matrix and containment schema constants are now separate; no containment
validation, case expectation, or cleanup rule was weakened.

**Stable-tree milestone protocol.** Source, tests, decision record, this log,
and the execution plan freeze before the final commands. The exact staged tree
is compiled to ignored `artifacts/manual/wp5h-oci-final-build-r2/` and the
complete real six-case matrix writes
`artifacts/wp5h-oci-final-20260817-r2/result.json`. Receipt-owning focused,
invariant, orchestrator, unit, typecheck, lint, and format commands write fresh
evidence beneath `artifacts/manual/wp5h-*-final/`. Their outcomes, hashes, and
receipt audit remain in those command-owned ignored artifacts and the final
handoff rather than being backfilled into tracked files and changing the tree
they verify. Long suites run separately and serially.

**Commit.** Assigned by the single cohesive WP5h commit containing this entry;
identify it as the newest commit touching the entry. It is not pushed.

**Known gaps.** A complete local real-Docker matrix cannot substitute for a
later hosted Ubuntu run of the new committed revision. Controller Linux/Windows
portability and Windows fresh-adopter offline-store failures remain separate
WP5 gaps. Product placeholders, calibration, hidden validation, autonomous
readiness, and human verification remain open; this increment makes no product
completion claim.

## 2026-08-17 — WP5g hosted CI audit and OCI argv correction

**Objective.** Reconcile the pushed WP5f candidate against actual hosted
execution, inspect every job/log/annotation/artifact rather than the aggregate
badge, reproduce the first causal failure under exact pinned tooling, and fix
that one defect without hiding the other independently exposed WP5 failures.
Preserve all authority, commissioning, readiness, invariant, provider/matrix,
package, and completed-evidence meanings; create one local commit and do not
push.

**Hosted audit and first cause.** Exact push run
`https://github.com/mclaurin10/milestone-loop-template/actions/runs/32029510422`
(run 2, attempt 1) executed commit
`8ffdbcd83b3d07c1f49b91a057ffe5f8e1ec7d30` from
`2026-08-17T12:22:11Z` through `12:28:41Z` and concluded `failure`. Public
run/job metadata, authenticated GitHub connector logs and artifact downloads,
the public annotation API, and the visible run summary agreed on five
independently scheduled jobs, four exit-code errors, and five action-runtime
Node 20 deprecation warnings. Every job used `fetch-depth: 0`, exact Node
`24.18.0`, and pnpm `11.15.1`; the warnings occurred outside the causal
commands and are not mislabeled as their cause.

Controller Linux and Windows both reached the commissioned base and passed all
four invariant commands, including contract integrity 13/13. Linux then
failed the orchestrator aggregate at 574/584 passed, 9 failed, 1 skipped: one
candidate-identity case, one Doctor ENOTDIR case, two POSIX supervisor cases,
and five worked-example byte-identity cases. Windows failed at 508/584 passed,
74 failed, 2 skipped across 19 files; the dominant shared cluster was strict
realpath comparison of GitHub's `RUNNER~1` spelling against the long
`runneradmin` identity, with additional worked-example byte drift and
retention/schema cascades. Both retained ERROR manifests with no PASS receipt;
later controller commands were correctly skipped.

Fresh-adopter Linux ran independently and passed its generated repository,
two receipt-owning checks, and 4/4 tests. Fresh-adopter Windows also ran
independently but its generated frozen offline install failed with
`ERR_PNPM_NO_OFFLINE_TARBALL` for `@eslint/js@10.0.1`, so it produced no smoke
PASS result. Trusted-container independently reached Ubuntu 24.04's real
Docker Engine and retained `docker version`/`docker info`, then became the
earliest causal failure at `12:22:31Z`: pinned pnpm forwarded the workflow's
extra separator, the package script launched as
`container-executor.oci.ts -- --output ...`, and the unchanged strict parser
rejected `Unknown argument --.` before any normal/adversarial case ran.

All five authenticated ZIP downloads matched GitHub metadata exactly:
controller Linux 48,953 bytes / SHA-256
`ec6a89c22e1299bf23d3278b9544eeab652aca18379d185ccdef49113bf1a6aa`;
controller Windows 52,528 /
`cad946551db47d05bb374ada84fe84f73faaffe21d9522e16a8229445e6ac467`;
adopter Linux 15,137 /
`73b4f34fa67367076a39c23334e8519e2ce121a88ee2edb2d66ba1a5b2b9c070`;
adopter Windows 8,685 /
`c730cc1866b570dc6b98ea2eb27459ffd3959775398a205b32e04a2502fedb90`;
and trusted-container 1,889 /
`a3bdaad59fda3d336dc1d1820367702e213503faec6643526f814f5bc7885eea`.
They are extracted under ignored
`artifacts/hosted/run-32029510422/`. Independent inspection matched 12 hosted
PASS receipts to 12 artifacts totaling 80,446 bytes with zero mismatches, and
confirmed both controller ERROR manifests declared zero artifacts and no
receipt.

**Correction.** A retained exact-toolchain argv fixture first ran the hosted
shape and observed
`['--','--output','artifacts/ci/trusted-container/matrix']`, exit 1. Its
119-byte observation has SHA-256
`8446064855500a29db5b697c8c3aad8d6228aa0e9054b8da55969b4d363505be`.
A regression mutation was added before the fix and correctly produced one
focused failure because the malformed separator remained accepted. The
workflow, its executable contract/test, and current README guidance now use
`pnpm test:oci-container --output artifacts/ci/trusted-container/matrix`.
The corrected pinned probe passed exit 0 and observed exactly
`['--output','artifacts/ci/trusted-container/matrix']`; its 109-byte record has
SHA-256
`df1809ca54bb241a1b12755f38290b539b69c8c9c92e9a759ff511e276561793`.
The OCI parser, package script, matrix cases, real engine probes,
provider/containment implementation, schedules, histories, and evidence roots
did not change. The workflow contract now rejects restoration of the literal
separator as well as its existing mock/platform/history/scheduling/evidence
mutations.

**Verification.** Under pinned Windows Node `24.18.0` and pnpm `11.15.1`, the
receipt-owning focused workflow shard passed 3/3 tests with zero failures or
skips across 2/2 suites at
`artifacts/manual/wp5g-ci-focused-final/invariant-vitest-report.json` (1,768
bytes, SHA-256
`edea3fd5acbbe6bb32cddaa48d8f90854424f6c5848854798802e1071f21a5e1`).
Direct invariants passed all four commands in 27,223 ms at
`artifacts/manual/wp5g-invariants-final/invariant-suite-report.json` (7,232
bytes, SHA-256
`7a4c8a73503b77137bd39891cfc0d4eaccd2fe4bedc19db14d04b4923f318bc7`):
contract 13/13, schema 7/7, policy 15/15, and fail-closed 61/61.

The orchestrator aggregate passed 582/584 tests with zero failures and exactly
the two declared Windows POSIX skips across 178/178 suites at
`artifacts/manual/wp5g-orchestrator-final/orchestrator-report.json` (203,902
bytes, SHA-256
`cfbac35a2baa1662f04af5a0559480b89b8ccab5d7edab57874046a363da5186`).
The complete unit aggregate passed 595/597 with zero failures and the same two
skips across 180/180 suites at
`artifacts/manual/wp5g-unit-final/test-report.json` (207,962 bytes, SHA-256
`9ca5dc68aee9ab8d42d43b70319532d66305db1309953855f3c256a7b91c4eea`).
Both long serial commands completed under their unchanged one-hour limits;
their delayed output was observed, not normalized by increasing a limit or
enabling parallelism.

Receipt-owning typecheck, lint, and format passed at
`artifacts/manual/wp5g-typecheck-final`, `wp5g-lint-final`, and
`wp5g-format-final`; their report hashes are respectively
`705e409f6a1032257dc65370aa35aa546b8b639c76253e54dfd2ad4a4b480f14`,
`11b960b7f380f4eca66185de8b367b3b4d12713b37573279b5afa7acb675c99e`,
and `73e68162c1874321c7e23051186edaf95330a68cd45e201477024390ac3e8b95`.
Independent audit matched 11 PASS receipts to 11 declared artifacts totaling
456,720 bytes and recomputed every receipt/artifact count, byte size, SHA-256,
status, and stage/command identity with zero mismatches.

Independent workflow audit found three full-history checkouts, zero dependency
keys/references, nine full-SHA actions, one corrected OCI command, zero
malformed commands, both real Docker probes, no `continue-on-error`, and no
source no-argument verification. Immutable baseline/active/actual hashes,
CAL-1 open/not-started state, commissioned readiness base/profile, permanent
marker history, Doctor `2.0.0`, Status `1.0.0`, all four invariant IDs,
package/lock/parser/matrix/example identities, retained WP4d evidence, private
ref/path absence, and all protected-plan identities passed. No source
no-argument verifier, local OCI substitute, completed WP4d proof, mutating loop
command, dependency change, recommissioning, workflow rerun/dispatch, push, or
remote/ref mutation occurred. Correcting malformed argv did not create a new
durable decision, so the decision log is unchanged.

**Commit.** Assigned by the single cohesive WP5g commit containing this entry;
identify it as the newest commit touching the entry. It is not pushed.

**Known gaps.** The corrected OCI invocation still requires a later pushed
hosted run before any real matrix PASS can be credited. The Linux/Windows
controller portability failures and Windows fresh-adopter offline-store
failure remain first-class WP5 gaps and must be addressed from their retained
reports, beginning with the next highest-impact shared cause. The five action
runtime deprecation warnings also remain observable but were not causal here.
WP6 and all product/readiness placeholders remain later; this increment is not
an autonomous-readiness or source-completion claim.

## 2026-08-16 — WP5f hosted CI history and scheduling correction

**Objective.** Correct the failed hosted Exact runtime CI candidate without
rewriting WP5e: establish the exact first failing invariant from authenticated
job logs and artifacts, reproduce it under the exact runtime and checkout
model, restore the commissioned Git authority base to every job, and make the
fresh-adopter and real-OCI boundaries independently schedulable. Preserve all
WP4d/WP5a-e meanings, pins, commands, evidence ownership, and completed
evidence; create one local commit and do not push.

**Hosted diagnosis and outcome before commit.** Authenticated GitHub inspection
of run `31988139046` showed both controller jobs passing checkout, exact Node
`24.18.0`/pnpm `11.15.1` assertion, and frozen install before first failing at
`Run invariant suite`. Both checkouts used the action default `fetch-depth: 1`.
The commissioned base
`0f4ab3e5ef39bda07d6e77356ad53fca9136cdd5` is eight commits behind the
candidate, so neither runner could resolve the Git-owned authority anchor.

Both authenticated artifact downloads matched GitHub metadata exactly: Linux
5,357-byte ZIP / SHA-256
`3261585491f05b279615372cc7917c12e026b222f4dc910fda9eebafcc51e677`;
Windows 5,380-byte ZIP / SHA-256
`77c8412c4550bf36d133ce839117e14a721e6a0b72200915cf4166848bb050c1`.
Each archive contained seven files. The Linux/Windows contract reports were
respectively 2,982 bytes / SHA-256
`22ad84643f817b7376ee30451873a8907361e08ba7a875df62bbaa9f321e441d`
and 2,983 bytes / SHA-256
`981ffbdd653730bdd067022bd34020bf5a7c5ed6c248ca31cec0d820a5694d1a`.
Both stopped at the first `protected-integrity` command, ran 11 expected-identity
checks, and recorded 9 PASS / 2 FAIL: first
`immutable-contract-lock-hash` because the commissioned base was missing, then
`acceptance-prose-bot-aggregation` because base prose was unavailable. Both
outer reports retained exit 1 and no receipt. The runner warning that pinned
actions target Node 20 but are forced onto Node 24 is separate from this
evidence-backed step failure.

A disposable exact-candidate `--depth 1 --no-local` clone with `CI=true`, the
hosted GitHub variables, the workflow evidence root, frozen offline copy-mode
install, and pinned Windows Node/pnpm reproduced one reachable commit, exit 1,
and the identical 11/9/2 report. After `git fetch --unshallow`, the same clone
had 54 reachable commits plus the exact base; the unchanged invariant suite
passed all four commands in 31,058 ms. Independent control audit matched five
PASS receipts to five artifacts totaling 39,420 bytes and contract integrity
passed 13/13 with valid check identity. This establishes missing checkout
history—not changed authority or action-runtime warnings—as the shared cause.

The workflow now supplies `fetch-depth: 0` to all three pinned checkout actions.
The two `needs: controller` edges were removed, so the Linux/Windows
fresh-adopter matrix and Linux Docker job expand and run independently of a
controller conclusion. No replacement condition or `continue-on-error` was
added. The existing workflow contract now binds one full-history checkout to
each job and rejects any `needs` key/reference on the adopter or container
boundary. Focused mutations cover depth-one/omitted history and restored
controller dependencies, in addition to the existing runtime, platform,
command, evidence, and real-OCI mutations. This enforces the already committed
WP5e decision that controller, distributor smoke, and privileged Docker are
separate diagnostic boundaries; no new durable decision was required.

**Verification.** Under pinned Windows Node `24.18.0` and pnpm `11.15.1`, the
accepted receipt-owning focused shard passed 14/14 tests with zero failures or
skips across 9/9 suites at
`artifacts/manual/wp5f-ci-focused-final-2/invariant-vitest-report.json` (5,754
bytes, SHA-256
`bd7854ec353527ca66a067cf5d7f93c5277e3c91153882bc70ea008e6c95c4d3`).
It covers the exact-runtime workflow contract plus invariant/contract receipt
behavior. Direct `pnpm test:invariants` passed all four commands at
`artifacts/manual/wp5f-invariants-final-2/invariant-suite-report.json` (7,264
bytes, SHA-256
`622c48f57302cd8249558ae17c2250433d97d06e4dc52827b6287d1b69ac5902`):
contract integrity 13/13, schema 7/7, policy 15/15, and fail-closed evidence
61/61.

The exact-tree orchestrator aggregate passed 582/584 tests with zero failures
and exactly the two declared Windows POSIX process-group skips across 178/178
suites at
`artifacts/manual/wp5f-orchestrator-final-2/orchestrator-report.json` (203,947
bytes, SHA-256
`4d0a1a238b3351a1feae880fc5591ab07845a50cacc02aef4a4a468a3075db52`).
The exact-tree unit aggregate passed 595/597 with zero failures and the same two
skips across 180/180 suites at
`artifacts/manual/wp5f-unit-final-2/test-report.json` (207,877 bytes, SHA-256
`51c493547a05a699648f88af735a83f873b9c100991ac99a5df2ad93e237bedc`).
Receipt-owning typecheck, lint, and format passed at
`artifacts/manual/wp5f-typecheck-final-2`, `wp5f-lint-final-2`, and
`wp5f-format-final-2`; their report hashes are respectively
`cfaf581b00707ddaddda60898154724c65a2fdada04a8eb9c7bb2895a3c2fc81`,
`c4c0d2c804877c04844ffbaabc9dff16534d8e70bd97ab390e568a1665ee971a`,
and `c7c61b29b84c6ffa610400b6b7f8c903f73814d162bf3ce702187c38bf145204`.
An independent audit matched 11 PASS receipts to 11 declared artifacts totaling
460,616 bytes and recomputed every receipt/artifact byte count and SHA-256 with
zero mismatches.

The first lint gate correctly rejected a literal-four-space scheduling regex
under `no-regex-spaces` and produced no passing receipt. Replacing it with the
exactly equivalent `{4}` form changed one source byte sequence; all focused,
invariant, orchestrator, unit, typecheck, lint, and format gates were therefore
rerun into the cited `final-2` roots on the frozen accepted tree. Earlier green
broad reports are diagnostic only and are not credited.

The independent scope/identity audit matched 46 critical tracked authority,
commissioning, readiness, verifier, Doctor `2.0.0`, Status `1.0.0`, invariant,
config/schema, example, fresh-adopter, and package/lock files to entry HEAD.
All four immutable-lock baseline/active/actual hashes matched with CAL-1 still
open/not started; the commissioned base remained a strict ancestor; the
readiness marker remained permanent in history with no deletion; the four
invariant IDs and 13 contract-check IDs remained exact. Both private state and
lease refs/paths were absent. Both retained WP4d artifacts and all three
protected-plan identities matched. Independent workflow inspection found three
full-history checkouts, zero dependency keys/references, nine full-SHA actions,
all six controller commands exactly once, one real OCI matrix command, and no
completion shortcut.

No source no-argument verifier, completed WP4d proof, local OCI substitution,
mutating loop command, dependency change, recommissioning, workflow rerun,
dispatch, push, or remote/ref mutation occurred. Local OCI was not applicable:
this correction changes scheduling/history, not the OCI executor, and only a
real hosted Docker run can close that boundary.

**Commit.** Assigned by the single cohesive WP5f commit containing this entry;
identify it as the newest commit touching the entry. It is not pushed.

**Known gaps.** Hosted validation of the correction remains pending until the
user pushes the WP5f commit. Consequently Linux/Windows controller completion,
POSIX supervisor execution, hosted fresh-adopter smoke, artifact upload, and
real Docker matrix PASS remain unverified for the corrected candidate. After a
push, inspect the new run/logs/artifacts and reconcile canonical documentation
only from actual evidence. WP6 performance work and all product/readiness gaps
remain later and unchanged; WP5f makes no autonomous-readiness claim.

## 2026-08-16 — WP5e exact-runtime cross-platform CI

**Objective.** Complete one bounded WP5 CI increment by adding exact Node
`24.18.0` and pnpm `11.15.1` Linux/Windows controller coverage, a distinct
fresh-adopter smoke, and an applicable Linux-only real trusted-container job.
Preserve every WP4d/WP5a-d contract and evidence boundary, and distinguish
locally verified workflow structure from hosted execution that did not occur.

**Outcome before commit.** The reproduced baseline had no `.github/workflows`
directory. The new least-privilege workflow has pull-request, `master` push,
and manual triggers; full-SHA checkout/setup/upload actions; and three separate
boundaries. The Linux/Windows controller matrix installs and asserts the exact
toolchain, performs a frozen copy-mode install, then runs the existing
receipt-owning invariant, orchestrator, unit, typecheck, lint, and format
commands serially into unique uploaded evidence roots. The separate
Linux/Windows adopter matrix invokes a new CI smoke coordinator, and the
Linux-only Docker job probes a real engine before invoking the unchanged
complete `test:oci-container` normal/adversarial matrix.

The fresh-adopter coordinator uses bundled Corepack and the public
`loop:template:create` command in a disposable directory. It performs a frozen
offline copy-mode install, runs generated typecheck and unit commands, checks
both command-owned receipts and every declared artifact byte/hash, and proves
a clean two-commit bootstrap history, both copied configuration schemas, and
no readiness marker in tree or history. Its versioned result is explicitly
completion-ineligible and autonomous-readiness-ineligible. It does not
commission, launch a browser, run source or generated no-argument verification,
or replace the retained WP4d proof. A dependency-free workflow contract parses
the YAML and rejects mutated runtime pins, platforms, command routing, evidence
root reuse, mock/non-Linux OCI, source no-argument verification, and WP4d proof
invocation.

**Verification.** Under pinned Windows Node `24.18.0` and pnpm `11.15.1`, the
final receipt-owning focused shard passed 45/45 tests with zero failures/skips
across 18/18 suites at
`artifacts/manual/wp5e-ci-focused-final-2/invariant-vitest-report.json` (16,253
bytes, SHA-256
`b19807a8132225bb8fefdb2014fa47a4ea97b5b5310454805dd8119296865bf4`).
It covers the workflow/smoke mutation tests, real adopter generation, and the
package-graph, affected-scope, verification-tier, and benchmark regressions.

The final Windows fresh-adopter smoke passed two receipt-owning generated
commands and 4/4 unit tests with zero failures/skips. Its two declared artifacts
total 2,981 bytes, and
`artifacts/manual/wp5e-fresh-adopter-smoke-final-2/smoke-result.json` is 3,443
bytes with SHA-256
`6dfdcf08814f9a4bd6cb9235b8354bded4196b1702c1aa69b08a2407da04b5cd`.
The generated repository remained clean at its deterministic two-commit
bootstrap identity and the source status/HEAD/tree remained unchanged.

Direct `pnpm test:invariants` passed all four commands in 37,587 ms at
`artifacts/manual/wp5e-invariants-final-2/invariant-suite-report.json` (7,264
bytes, SHA-256
`f3c865fb8bd79667a93d6f8ce432a454cbd88637be5aa34c2710e9187430cf9d`).
The outer result remained completion-ineligible; its children passed contract
integrity 13/13, schema 7/7, policy 15/15, and fail-closed evidence 61/61.

The orchestrator aggregate passed 581/583 tests with zero failures and exactly
the two declared Windows POSIX process-group skips across 178/178 suites at
`artifacts/manual/wp5e-orchestrator-final-2/orchestrator-report.json` (203,606
bytes, SHA-256
`d4e49a4a0b05e418bc7719f4e26a078d4e80f9905bcca097f2a41ce2b4d31449`).
The complete unit aggregate passed 594/596 with the same two skips and zero
failures across 180/180 suites at
`artifacts/manual/wp5e-unit-final-2/test-report.json` (207,491 bytes, SHA-256
`0256c15a321c2f2d9e267e6e1afbd337707e6d82cd2a5a703a6a074d6e95ca66`).
Receipt-owning typecheck, lint, and format passed at
`artifacts/manual/wp5e-typecheck-final-2`, `wp5e-lint-final-2`, and
`wp5e-format-final-2`; their report hashes are respectively
`e29ffb9c49f6d01f4298c7cad28412b770587056affa5f4a5e708753a50d9776`,
`2f4d96280a0514d12897ddae7f68f17dd40803c491baaa546d7e20339dca36f0`,
and `f3d86c5ce55b473847d0de351867009393a89d6bef77c7d1b502e0627a0c820a`.
An independent audit matched 13 PASS receipts to 13 declared artifacts totaling
474,113 bytes and independently confirmed all test, failure, and skip counts.

The first broad attempt is retained but not credited: 565/583 passed, 16
failed, and two skipped because a new top-level `tools/ci` directory matched
the existing `tools/*` workspace pattern and therefore correctly lacked the
required package manifest. Its 217,558-byte report (SHA-256
`352a6e226586c5cfee9b99fa67542951bd853f904985589d60dfea2fa1deff4d`)
identified one shared package-graph cause. Moving helpers inside the existing
orchestrator package preserved package/lock/script identities; the six affected
files then passed 41/41 before the accepted broad retry.

The frozen authority, immutable lock, active/historical commissioning,
readiness marker, exact verifier, Doctor `2.0.0`, Status `1.0.0`, invariant
registry, current config/schema/migrations, examples, package/lock files,
private state/lease absence, retained WP4d evidence, and all three protected-
plan identities are audited separately before commit. No source no-argument
verifier, completed WP4d proof, safety demonstration, mutating loop command,
dependency change, recommissioning, push, or ref mutation occurred.

**Commit.** Assigned by the single cohesive WP5e commit containing this entry;
identify it as the newest commit touching the entry. No push is authorized.

**Known gaps.** Local Windows execution proves workflow structure and the
generated-adopter smoke, not hosted behavior. GitHub has not yet run the Linux
or Windows matrices, artifact upload, POSIX supervisor cases, or the real
Linux Docker job; no hosted or local OCI PASS is claimed. Those actual hosted
runs and any evidence-driven final WP5 documentation reconciliation remain
outstanding. WP6 performance work remains later. The source is still honestly
blocked from autonomous readiness by its adopting-product placeholders and
other existing Doctor blockers; WP5e is not autonomous readiness or a push.

## 2026-08-16 — WP5d strict configuration schema parity

**Objective.** Complete one bounded WP5 strict-config increment by publishing
the missing current `OrchestratorConfig` JSON Schema and proving one shared
acceptance/rejection corpus through both real runtime parsing and the schema.
Preserve the earlier runtime rejection of unknown root fields, every supported
legacy migration, and all WP4d/WP5a-c contracts and evidence.

**Outcome before commit.** The runtime was already strict at the root; the
reproduced gap was the absence of
`schemas/orchestrator-config.schema.json` and any executable runtime/schema
parity corpus. The new strict `1.6.0` schema closes every root and nested object,
references the existing model-policy schema, expresses the mandatory protected
floor, and is copied with its reference into generated adopter packages. The
model-policy schema now matches existing runtime rejection of whitespace-only
override reasons and duplicate override roles; runtime policy behavior did not
change.

A dependency-free test-only JSON Schema 2020-12 evaluator resolves local and
external references, enforces the exact keyword subset used by both schemas,
and throws on unsupported keywords. Forty named cases each assert the expected
disposition independently under `loadConfigForInspection` and schema
evaluation, then assert differential equality. They cover maintained valid
source/example configurations, valid boundary variants, the intentionally
invalid raw placeholder template, unknown root and closed nested keys, missing
keys, and representative value/path/list failures. Structural assertions bind
all closed property/required sets and the schema's protected floor to runtime
fixtures/constants. Legacy `1.0.0` through `1.5.0` inputs remain owned by the
unchanged migration path; repository-dependent cross-field checks remain
strict runtime-only semantics.

**Verification.** Under pinned Node `24.18.0` and pnpm `11.15.1`, the
receipt-owning affected shard passed 69/69 tests with zero skips across 11/11
suites at
`artifacts/manual/wp5d-config-schema-focused-final/invariant-vitest-report.json`
(23,154 bytes, SHA-256
`77b344f481a412b94810943b7cf4985d861e481a0133fcadeffab3f7b55b64f5`).
This includes 42/42 parity/structure/evaluator tests and a real generated
adopter whose config validates against its copied schemas. The wrapper's
optional direct-telemetry begin hook could not load the TypeScript-only
`path-safety.js` import under plain Node, so telemetry is null; the semantic
report and PASS receipt are complete.

Direct `pnpm test:invariants` passed all four serial commands in 29,059 ms,
below its 60-second warm target, at
`artifacts/manual/wp5d-invariants-final/invariant-suite-report.json` (7,232
bytes, SHA-256
`7cd9a4cce21063a09430d0c3226d2eca9caa5756820f2823af331e6a4d833693`).
The outer report remained explicitly completion-ineligible. Its children
passed contract integrity 13/13, schema 7/7, policy 15/15, and fail-closed
evidence 61/61. The direct contract report remained completion-ineligible at
`entries/protected-integrity/contract-integrity-report.json` (3,531 bytes,
SHA-256
`18a7c2029615685dbb349a65db07486e939d96474497910282847cbb8850d6d7`).

The orchestrator aggregate passed 577/579 tests with zero failures and only the
two declared Windows POSIX process-group skips across 174/174 suites at
`artifacts/manual/wp5d-test-orchestrator-final/orchestrator-report.json`
(201,850 bytes, SHA-256
`6ea09b0d6431166ea88030159e77b3e9a33de019bfe6cfd5056d3e7afd217c20`).
The unit aggregate passed 590/592 with the same two skips across 176/176 suites
at `artifacts/manual/wp5d-test-unit-final/test-report.json` (206,052 bytes,
SHA-256
`a23980c4376548dc247cd8e3d5eab35ccf1d5fe2cba135f8132704b29891de23`).
Receipt-owning typecheck, lint, and format passed at
`artifacts/manual/wp5d-typecheck-final`, `wp5d-lint-final`, and
`wp5d-format-final`; their report hashes are respectively
`2540e3c6155ab20c1971bb940ebbb4eb6cd784e787e0de4ad4b6e15fb1c6fe53`,
`012193e1acb18740e236708f9f394cf589285030adb1d06ec4a0c613724d10ec`,
and `53633d763f14ac37272fd7801634c524fa7658e42a348edd7bfa7009314f08ca`.
An independent audit matched all 11 PASS receipts to all 11 declared artifacts
(474,994 artifact bytes) and independently confirmed every reported test total,
failure, and skip.

The frozen authority, immutable lock, active/historical commissioning,
readiness marker, exact verifier, invariant registry, Doctor `2.0.0`, Status
`1.0.0`, default readiness profile, package/lock files, maintained configs,
worked example, private ref/path absence, and both retained WP4d artifacts all
matched their entry identities. The protected human plan retained all three
required identities and remained the sole user-owned untracked path. No source
no-argument verifier, OCI matrix, safety demonstration, completed fresh-adopter
proof rerun, mutating loop command, dependency install, recommissioning, push,
or ref mutation occurred. OCI/safety evidence was not applicable because this
increment changes neither provider execution nor controller mutation/recovery.

**Commit.** Assigned by the single cohesive WP5d commit containing this entry;
identify it as the newest commit touching the entry. No push is authorized.

**Known gaps.** Remaining WP5 work is exact-runtime Linux and Windows CI with
fresh-adopter smoke plus an applicable real trusted-container CI job, followed
by any final canonical-documentation reconciliation supported by those runs.
WP6 verification-efficiency work remains later and separately gated. The
source remains honestly blocked from autonomous readiness by its placeholder
product/build/runtime/state conditions. WP5d is not full WP5, cross-platform
proof, readiness repair, product implementation, autonomous readiness, or a
push.

## 2026-08-16 — WP5c shared contract-integrity invariant

**Objective.** Complete one bounded WP5 independent-invariant increment by
extracting the existing 13-check contract-integrity evaluation into one
controller-owned module consumed by both the authoritative verifier and a
completion-ineligible invariant adapter. Preserve ordinary focused verifier
semantics while removing the invariant suite's unrelated dependency on the
environment stage.

**Outcome before commit.** `src/contract-integrity.ts` now owns the exact
ordered contract checks and accepts the existing commissioned-authority
validator as an explicit dependency, which keeps it directly loadable from
plain Node. `scripts/verify.mjs` delegates its unchanged contract stage to that
module. The source and generated-adopter `protected-integrity` registry entries
invoke `verification-cli.ts contract-integrity` directly and require a
`contract-integrity-report`; no package command, registry ID, profile/stage
selection, or completion path changed. The adapter requires the exact healthy
check identity, retains a failing diagnostic without a receipt, and marks both
its `contract-integrity-report.v1` and the outer invariant-suite `1.1.0` report
`completionEligible:false`. Tier implementation loading is deferred until a
tier mode is selected, so the narrow contract command does not load unrelated
SDK/tier dependencies.

**Verification.** Under pinned Node `24.18.0` and pnpm `11.15.1`, the accepted
receipt-owning contract/routing/package/verifier shard passed 28/28 tests with
zero skips across 14/14 suites at
`artifacts/manual/wp5c-contract-focused-final-3/invariant-vitest-report.json`
(10,135 bytes, SHA-256
`7042cb4b802d2b42ea0424142dfa2ba5f479258ed03c100c7e83e51ac8e380f8`).
It proves exact healthy check ordering, authoritative-verifier parity with the
unchanged `environment,contract-integrity` focused selection, generated-adopter
routing, and a real commissioned-contract corruption that exits 1, retains an
ineligible failing report, and writes no PASS receipt.

Direct `pnpm test:invariants` passed all four serial commands in 27,751 ms,
below its 60-second warm target, at
`artifacts/manual/wp5c-invariants-final/invariant-suite-report.json` (7,232
bytes, SHA-256
`2b65afaf50a8e8ab5b8f8f76389c61f8fdd1ba34db0ff3f6cc68934a8161798a`).
Its first argv is the direct adapter, not `pnpm verify`; the child report is
completion-ineligible and passed all 13 checks at
`entries/protected-integrity/contract-integrity-report.json` (3,531 bytes,
SHA-256
`9e6b1eeb8ada30e398745bcc0d690f967ebb24293a3db2e6f04435f1d5bc8945`).
The other receipt-owning children passed schema 7/7, policy 15/15, and
fail-closed verifier 61/61, with no environment or aggregate verifier result.

The orchestrator aggregate passed 535/537 tests with zero failures and only
the two declared Windows POSIX process-group skips across 172/172 suites at
`artifacts/manual/wp5c-test-orchestrator-final/orchestrator-report.json`
(188,743 bytes, SHA-256
`489c1c570ded68a41c628ca2ab1acf5e4e4ab8a41aeff32d0cb4bd8bff2a0341`).
The unit aggregate passed 548/550 with the same two skips across 174/174 suites
at `artifacts/manual/test-unit-3532/test-report.json` (192,753 bytes, SHA-256
`f6e05cf9e111d163e874ace11682bff36ce5826e296452c5bf6229612f167e9c`).
Receipt-owning typecheck, lint, and format passed at
`artifacts/manual/wp5c-typecheck-final`,
`artifacts/manual/wp5c-lint-final`, and
`artifacts/manual/wp5c-format-final`; their report hashes are respectively
`a864a46d8fbda1d2056ea61073b815a9551bb42da37936ff35f460dfff5f71e0`,
`2f759e5b623a519e4cd9333dbfb5c124953093fa5e2fb86b3b5255940066ecb3`,
and `63128dac587b1252fbab116839b9a7a4fd1c318f1bf68a35bd10958b9a8b8c5d`.
Every cited receipt, nested receipt, and declared artifact byte count/SHA-256
independently matched.

Two earlier affected-shard attempts correctly retained no PASS receipt at
27/28: the disposable corruption process first inherited an evidence context
for the source repository, then exposed that the source-installed evidence
runtime could not own a receipt for a different clone. The accepted fixture
copies the current adapter/evaluator/CLI into the commissioned clone so its
evaluation and receipt authority agree. The focused wrapper's optional direct
telemetry begin hook remained unavailable because its plain-Node path resolved
a TypeScript-only transitive module as a missing `.js`; this was non-semantic,
and the command-owned PASS receipt/report are complete. No source no-argument
verifier, OCI matrix, safety demonstration, fresh-adopter proof rerun, mutating
loop command, recommissioning, readiness repair, or push occurred.

The immutable authority, active/historical commissioning, readiness marker,
default/scope/slow/benchmark registries, package/lock files, worked example,
fresh-adopter fixture, private ref/path absence, and both retained WP4d
artifacts remained unchanged. The protected human plan remains the sole
user-owned untracked path after the intended WP5c files are staged and retains
its required byte/hash/blob identities.

**Commit.** Assigned by the single cohesive WP5c commit containing this entry;
identify it as the newest commit touching the entry. No push is authorized.

**Known gaps.** Remaining WP5 work owns strict rejection of unknown config
fields plus its differential schema corpus, exact-runtime Linux and Windows CI
including fresh-adopter smoke, and an applicable real trusted-container CI
job. The source remains honestly blocked by the protected human plan, absent
production build, active product placeholders, unavailable trusted runtime/
image, and absent exact canonical state. WP5c is not full WP5, readiness
repair, autonomous readiness, product implementation, or a push.

## 2026-08-16 — WP5b canonical lifecycle status

**Objective.** Complete the bounded Status slice of WP5 by making
`pnpm loop:status -- --json` the single versioned, read-only resume surface for
uninitialized, ordinary initialized, pending-operation, target-drift, and
active-reconciliation states. Preserve the accepted WP5a Doctor authority and
all WP4d evidence while closing the roadmap gap for commissioning/profile,
target relation, lease, pending side effect, recovery disposition, latest
milestone/exact verification, integration eligibility, deferred work, and the
next safe command.

**Outcome before commit.** Status schema `1.0.0` composes accepted Doctor
schema `2.0.0` facts with validated canonical state and the existing read-only
operation inspectors; it does not search artifacts or derive completion from
logs. Target relation is explicitly target-oriented and distinguishes
`current`, `ahead`, `behind`, `divergent`, `uninitialized`, and fail-closed
`unavailable`. Recovery is normalized as `automatic`, `blocked`, `external`,
or `none`. Ordinary status now routes before reconciliation-controller opening,
so active reconciliation retains the common status contract without acquiring
a mutation capability. `reconcile-status`, Doctor, dry-run, mutation,
commissioning, provider, state, and verifier behavior are unchanged.

Doctor and detailed state are fenced to one canonical generation. When valid
commissioning aligns the branch sources, the Doctor observation, checkout,
and target-ref HEAD must also agree. Status retries movement once and then
returns `changed-during-inspection`, suppresses detailed state and integration
eligibility, and directs the operator to rerun status. Ancestry probes suppress
optional Git locks. CLI recursive redaction remains in force, and real child
process tests prove both active-state and missing-state paths leave status,
refs, state storage, and repository files unchanged.

**Verification.** Under pinned Node `24.18.0` and pnpm `11.15.1`, the
receipt-owning status/CLI/deterministic-operation shard passed 20/20 with zero
skips at
`artifacts/manual/wp5b-status-focused-final/invariant-vitest-report.json`
(7,566 bytes, SHA-256
`622931a8a34c2395f9d9af886c96dba7e48eec8b58a63e7ac6c2e393ecc48fd5`).
Its direct-telemetry begin hook was unavailable because the planned plain-Node
wrapper could not import a TypeScript module; this was reported as non-semantic,
while the command-owned PASS receipt and declared report remained complete.
The orchestrator aggregate passed 532/534 with zero failures and only the two
declared Windows POSIX skips across 170/170 suites at
`artifacts/manual/wp5b-test-orchestrator-final/orchestrator-report.json`
(187,483 bytes, SHA-256
`3a24a9905d4386a5c7c2de29d564313143ab9af0b49c83bd6d427e565f9e7236`).
The unit aggregate passed 545/547 with zero failures and the same two skips
across 172/172 suites at
`artifacts/manual/wp5b-test-unit-final/test-report.json` (191,507 bytes,
SHA-256
`adf81a781c1b9770b5d17984a204d1f7c8fe93b8a64604b20524322e33e9b06f`).

Receipt-owning typecheck, lint, and format all passed at
`artifacts/manual/wp5b-typecheck-final`,
`artifacts/manual/wp5b-lint-final`, and
`artifacts/manual/wp5b-format-final`; their report hashes are respectively
`69848e5391d2f1cdd5b12f10cc0960a231caa32b6872d79108ff4b863a0fc469`,
`12ceeddbeabb60e14088a18cd895ac120eca6433c112485a917eb1b9eaa90d84`,
and `ad28882c2184f6d2a73ccb80cbed5e49239604b1f950079a514c6efa1b15387b`.
Every receipt, manifest, declared report byte count, and SHA-256 independently
matched. `pnpm loop:demo-safety` passed all six scenarios at
`artifacts/orchestrator/runs/safety-demonstration/safety-demonstration-20260816171558718-6e19b0f2.json`
(14,968 bytes, SHA-256
`07fbaec742fe438634fa22e72ed4111926e13a4699ed422eae6f69c9ef3dac5d`).

Final source status emitted schema `1.0.0` with a stable snapshot, valid
readiness commissioning, target `master`, uninitialized canonical relation,
no lease or pending side effect, recovery `none`, no completed milestone or
exact verification, unavailable trusted execution, ineligible autonomous
integration, the accepted 9 passes / 3 warnings / 4 blockers, and
`git status --short --branch` as the next safe command. The state path and
private state/lease refs remained absent. HEAD/tree, tracked and staged bytes,
protected-plan identities, and both retained WP4d artifact identities remained
unchanged. No no-argument source verifier, OCI matrix, Doctor evidence rerun,
fresh-adopter proof, mutating loop command, push, or WP6/product/readiness work
occurred.

**Commit.** Assigned by the single cohesive WP5b commit containing this entry;
identify it as the newest commit touching the entry. No push is authorized.

**Known gaps.** The next dependency-ordered WP5 area is independent invariant
extraction. Later WP5 work still owns the strict-config corpus, Linux/CI race
coverage, and remaining operator documentation. The source remains honestly
blocked by the protected human plan, absent production build, active
placeholders, unavailable trusted runtime/image, and absent exact canonical
state. WP5b is not full WP5, readiness repair, autonomous readiness, product
implementation, or a push.

## 2026-08-16 — WP5a strict operational Doctor

**Objective.** Complete the bounded Doctor slice of WP5 by turning
`pnpm loop:doctor` into a complete read-only operational diagnostic and adding
a Doctor-only strict blocker exit, without changing source readiness,
commissioning, provider policy, product placeholders, or WP4d evidence.

**Outcome before commit.** Doctor schema `2.0.0` gives every check a stable
`pass`, `warning`, or `block` result with code, message, remediation, and safe
command where one exists. It emits complete ordered issues, counts, current
autonomous-integration eligibility, and the earliest safe next action. Ordinary
Doctor exits zero after an honest `ready` or `blocked` result; `--strict` emits
the same diagnostic and exits 2 only when a block exists. Structural config and
the installed SDK are independent facts, while normal config loading retains
its exact installed-SDK assertion.

The diagnostic reuses active commissioning and all four tier plans, the
production-build contract, provider capability/identity, canonical state,
operation recovery, protected-root, protected-identity, and lease authorities.
Configured paths are checked lexically and through the nearest existing
ancestor/realpath without creation. Exact verification is accepted only from
validated canonical state, a current intact copied result, readiness profile,
and the matching active completion-eligible provider identity. Pending
operations and simultaneous protected drift remain independently visible.
Doctor makes no network call and launches no build, verifier, container,
candidate command, or Codex turn; it writes no path, state, ref, mirror,
evidence, lease, or configuration.

**Verification.** Under pinned Node `24.18.0` and pnpm `11.15.1`, the accepted
receipt-owning Doctor/CLI/config shard passed 38/38 at
`artifacts/manual/invariant-vitest-7236/invariant-vitest-report.json` (13,426
bytes, SHA-256
`b7d62bb9cfbfe6b8b489e9802ddee2b77a2a0739e6c131042a0f2e7aafd7358f`).
The full orchestrator aggregate passed 523/525 with zero failures and only the
two declared Windows POSIX process-group skips at
`artifacts/manual/test-orchestrator-19716/orchestrator-report.json` (184,077
bytes, SHA-256
`fcc44893f0922bb3006cb6e16114d45e14b5fa89c6f78c9648fcf96232e8aad6`).
The unit aggregate passed 536/538 with the same two skips at
`artifacts/manual/test-unit-23304/test-report.json` (188,245 bytes, SHA-256
`9ab63d42d3ed2f01082799cf016ade0b69ba32125b73ab4018b7b7c41d6f5446`).
Every report hash/size matched its PASS receipt. Typecheck, lint, and format
passed with independently matched receipts at
`artifacts/manual/typecheck-7452`, `artifacts/manual/lint-22044`, and
`artifacts/manual/format-check-8972`. `pnpm loop:demo-safety` passed every
scenario at
`artifacts/orchestrator/runs/safety-demonstration/safety-demonstration-20260816150722143-fe2a229a.json`.
No source no-argument verifier, OCI matrix, fresh-adopter proof, or mutating
loop command ran. Final ordinary and strict source Doctor emitted byte-equivalent
schema `2.0.0` diagnostics with 9 passes, 3 warnings, and the honest 4 blockers
(dirty protected plan, missing production build, active placeholders, missing
trusted runtime). Ordinary exited 0, strict exited 2, integration remained
ineligible, and `git status --short --branch` was the next command. Git status,
absent state/lease refs, and absent state-path facts were unchanged.

**Commit.** Assigned only after the frozen WP5a candidate passes its final
Doctor, diff, staged-scope, and protected-identity audits; identify it as the
newest commit touching this entry.

**Known gaps.** Later WP5 increments still own status expansion, independent
invariant extraction, strict-config corpus, Linux/CI race coverage, and
operator documentation beyond Doctor. The source remains deliberately blocked
by the protected human plan, placeholder scripts, absent production-build
declaration, unavailable trusted runtime/image, and absent exact state. WP5a is
not full WP5, autonomous readiness, product implementation, or a push.

## 2026-08-15 — WP4d fresh-adopter bootstrap packaging

**Objective.** Complete one bounded WP4d distributable-template increment that
creates a fresh adopter-owned Git history without verifier source edits and
proves the generated technical scaffold can reach a truthful package-default
bootstrap PASS without changing or reinterpreting source readiness.

**Outcome before final milestone verification.** A strict versioned definition
and public no-clobber package command now generate the authority lock, generic
active configuration and registries, package metadata, real bootstrap app, two
deterministic commits, and a strict-ancestor commissioning input. A shared
Git-base anchor replaces the source-specific verifier hash literal and requires
the current lock and all four authority files to match the exact commissioned
base. The scaffold uses one kernel for Node, replay, Worker, persistence, and
rendering; every bootstrap stage exercises a real boundary and owns hashed
evidence. A separate retained proof runner adds offline copy-mode installation,
explicit one-shot commissioning, the manifest commit, one no-argument verifier,
independent receipt/artifact matching, marker/history checks, source-identity
scanning, and compact retained browser evidence.

**Implementation diagnostics.** No source aggregate, source no-argument
verifier, or OCI matrix was used for orientation. Under pinned Node `24.18.0`
and pnpm `11.15.1`, the authority/commissioning/package files passed 21/21
focused tests, direct tool TypeScript passed, and the proof auditor passed 3/3
including post-receipt artifact drift and asserted-PASS rejection. In a newly
generated commissioned fixture, dependency, format, lint, architecture,
typecheck, clean-clone build, four Vitest tests, two invariants, persistence,
Node/replay/Worker simulation, and real Chromium browser commands all passed.
The single budgeted diagnostic literal no-argument fixture run passed all 9
bootstrap stages in 40,944 ms with 10 valid command receipts and 18 declared
artifacts. Its result is 45,280 bytes / SHA-256
`21621834eaf1999de6034483ae9210a44c0ade1b1d2437ef0d4c3db2bc0a0177` at
`artifacts/wp4d-package-diagnostic-8/repository/artifacts/verify-2026-08-16T045227-338Z-8888/result.json`.
It reports `bootstrap_complete`, `autonomousReadinessEquivalent:false`, clean
candidate identity, and honest provider-based completion ineligibility. The
122,990-byte screenshot has SHA-256
`da927d28bc0d2132d4f4e5fe347059d5fb11586452c38c5b40fc9fc808bf0c21`.
Independent in-app browser inspection observed the readable production layout,
public Worker action, canonical extracted-4/tick-3 consequence, and no warning
or error diagnostics.

**Stable-tree milestone protocol.** Source, tests, template assets, definition,
documentation, this log, and the execution plan freeze before one exact
receipt-owning affected shard, one retained fresh-adopter proof, serial
orchestrator and unit aggregates, and receipt-owning typecheck/lint/format
gates. No OCI matrix or safety demonstration is applicable because no
executor/provider owner or canonical safety primitive changed. Every source and
fixture receipt, artifact, count, skip, duration, identity, protected/example
hash, and package inventory is independently checked before one cohesive
commit. Literal no-argument source `pnpm verify` runs exactly once afterward
and its known product/provider/dirty-file/deadline gaps remain honest.
The first final lint gate exposed and rejected an empty JSON/Markdown-only
fixture directory passed as an ESLint target. A tested fixture-local definition
entry point now supplies a real lintable boundary while leaving the package-
copied evidence runtime byte-identical to the retained proof.

**Audited pre-commit evidence.** The accepted affected shard passed 57/57 at
`artifacts/manual/invariant-vitest-20152/invariant-vitest-report.json`.
The retained proof at
`artifacts/wp4d-fresh-adopter-proof-final-3/proof-result.json` is 2,424 bytes /
SHA-256 `1561bbf47a910a3a2d54f35b1114ff51b79395d007e35fea8b093af8e27c37ff`;
its clean fresh repository passed 9/9 bootstrap stages with 10 valid receipts,
18 matched artifacts (136,506 bytes), 4/4 tests, and verifier result SHA-256
`1ea5cc51597047eecd6054701989d2096484a7e9162f3cb93afbd3a749b8ff9c`.
A package-only post-fix regeneration matched all 114 initial retained paths,
bytes, hashes, commits, and pre-commission tree without another verifier run.
The exact-tree orchestrator aggregate passed 514/516 at
`artifacts/manual/test-orchestrator-1576/orchestrator-report.json`; unit passed
527/529 at `artifacts/manual/test-unit-18672/test-report.json`. Both have zero
failures/todos and only the two declared Windows skips for POSIX process-group
termination. All receipt/artifact hashes and sizes, durations, and five slowest
tests were independently audited. Typecheck, lint, and format passed at
`artifacts/manual/typecheck-13140`, `artifacts/manual/lint-19384`, and
`artifacts/manual/format-check-21068`. Immutable/config/example diffs are zero,
all protected-plan identities match, and the source remains readiness with its
permanent marker. No OCI matrix applies because no provider/executor owner
changed.

**Commit.** Assigned only after the frozen WP4d candidate passes the applicable
checks; identify it as the newest commit touching this entry.

**Known gaps.** Bootstrap is only a technical scaffold. Product-domain breadth,
CAL-1, trusted default-Windows completion eligibility, hidden validation,
autonomous readiness, and human verification remain open. A later plan must
perform the permanent one-way readiness transition before substantive product
implementation. WP4d makes no readiness claim and does not push.

## 2026-08-15 — WP4c explicit historical worked-example boundary

**Objective.** Complete one bounded WP4c packaging increment by making the
already-placed Ski Tycoon configuration self-validating and explicitly
legacy-only, without moving or rewriting its historical JSON payloads or
allowing any example identity into active source commissioning.

**Outcome before final milestone verification.** A strict
`worked-example.v1` descriptor pins the complete package, source provenance,
legacy/inactive/no-fallback semantics, per-file provenance, roles, byte counts,
hashes, paths, and identities. The read-only
`pnpm loop:example:validate -- --descriptor <file>` route requires exact
contained regular tracked files, validates all six JSON schemas plus manifest/
registry/check/protected cross-links, and deterministically reports every
payload. It never runs the historical benchmark, requires its unavailable
commits, commissions the v1 manifest, or mutates repository state. The three
unchanged source snapshots are distinguished from the three maintained
compatibility adapters. All six example JSON payloads remain byte-identical to
entry. The active slow-suite ID is now generic, the reusable benchmark template
no longer defaults to D-032, and active manifest/input/config registries remain
free of D-031/D-032 and Ski Tycoon identity.

**Implementation diagnostics.** No broad suite or verifier was used for
orientation. Under pinned Node `24.18.0` and pnpm `11.15.1`, the new focused
file passed 9/9 cases covering exact/deterministic validation, descriptor and
CLI strictness, containment, regular/tracked/exact file sets, byte/hash drift,
JSON/schema drift, cross-links, and active/legacy isolation. The seven-file
affected diagnostic passed 66/66, including the unchanged commissioning,
config, invariant, manifest, schema, and protected-root boundaries. Direct
TypeScript and new-file lint diagnostics passed. The explicit source command
reported the 2,948-byte descriptor at SHA-256
`e4f3c1496603ae5dbd3189f02177cd5e200693cf42ff5a8f6e683712920faa70`
and all seven pinned package files with no mutation. These are iteration
diagnostics, not final receipts.

**Stable-tree milestone protocol.** Source, tests, descriptor, documentation,
this log, and the execution plan freeze before one receipt-owning focused
shard, serial orchestrator and unit aggregates, and receipt-owning typecheck,
lint, and format gates. No OCI matrix or safety demonstration is applicable
because no executor/provider or canonical protected-catalogue owner changes.
Every receipt, artifact, count, skip, duration, candidate identity, and
immutable/protected/example hash is independently checked before the cohesive
commit. Literal no-argument `pnpm verify` runs exactly once afterward and any
unrelated product, provider, dirty-tree, or deadline gaps remain honest.

**Commit.** Assigned only after the frozen candidate passes the applicable
WP4c checks; identify it as the newest commit touching this entry.

**Known gaps.** A later WP4 increment must prove a fresh distributable adopter
reaches a truthful bootstrap PASS. Product placeholders, calibration, trusted
default-Windows execution, autonomous readiness, hidden validation, and human
verification remain open. WP4c makes no readiness claim.

## 2026-08-15 — WP4b deterministic source commissioning

**Objective.** Add one deterministic, fail-closed commissioning workflow and
use it to publish the source repository's active generic v2 manifest, without
rewriting historical evidence, frozen authority, readiness history, product
placeholders, provider boundaries, or verifier policy.

**Outcome before final milestone verification.** The standalone
`pnpm loop:commission -- --input <file>` command validates an absent active
path; completely clean tracked and untracked state; attached configured target
branch; exact strict-ancestor base; explicit bootstrap/readiness lifecycle;
authority, immutable-lock, and verifier-anchor agreement; generic registry and
protected-root identities; package-owned focused commands; exact and
reconciliation policy; and all four tier plans. Its canonical timestamp comes
from the base commit. It stages exclusive deterministic bytes, detects
identity/status drift, publishes no-clobber, performs a read-only post-generation
doctor, reports path/bytes/SHA-256, and cleans or exactly rolls back its owned
output on injected faults.

The source target is corrected from `main` to its real `master` branch and the
active invariant/scope ids are generic. Historical v1 records and adapters
remain explicit legacy contexts. In a clean clone of the exact candidate, the
tracked source input (6,561 bytes, SHA-256
`59f053d0b4ed195e2fda8746f8ee018ea3c97706c07f53a37908c40ef41b8629`)
commissioned `.agent/verification-manifest.json` at 7,124 bytes and SHA-256
`f765765d8082280282151253e616f87a460dbe8c38f17909aa22d7dcb7930dd9`.
The manifest binds WP4a base
`0f4ab3e5ef39bda07d6e77356ad53fca9136cdd5`, `master`, package-default
readiness, the base's real `2026-08-15T20:50:19.000Z` timestamp, the current
generic registries and complete catalogue, and no D-031/D-032 or Ski Tycoon
identity. The commissioning doctor passed and constructed iteration,
candidate, milestone, and periodic plans; exact verification appears only in
milestone and periodic.

**Implementation diagnostics.** No broad suite or full verifier was used for
orientation. Under pinned Node `24.18.0` and pnpm `11.15.1`, the commissioning
fixture file passed 13/13 cases, including fresh bootstrap/readiness adopters,
twin-clone determinism, dirty trees, bases/branches/profiles/marker history,
authority/lock/registry/catalogue drift, unsafe input, partial writes, races,
rollback, reporting, and read-only doctor behavior. Six manifest, schema,
config, tier, doctor, and protected-root files passed 66/66, and the tools
TypeScript diagnostic passed. These are iteration diagnostics, not final
receipts.

**Stable-tree milestone protocol.** Source, tests, this log, the execution
plan, schema, generated input/manifest, and documentation freeze before the
final commands. Two receipt-owning focused shards, the live safety
demonstration, serial orchestrator and unit aggregates, and receipt-owning
typecheck/lint/format gates write fresh ignored evidence. Their outcomes remain
in machine-owned artifacts and the final handoff rather than being backfilled
into tracked files. Every receipt, declared artifact, count, skip, duration,
candidate identity, and immutable/protected hash is independently checked
before the cohesive commit. Literal no-argument `pnpm verify` runs exactly once
afterward and its unrelated product/infrastructure gaps remain honest.

**Commit.** Assigned only after the frozen candidate passes the applicable
WP4b checks; identify it as the newest commit touching this entry.

**Known gaps.** WP4c may relocate or modernize the Ski Tycoon worked example.
Product placeholders, calibration, trusted default-Windows execution,
autonomous readiness, hidden validation, and human verification remain open.
WP4b makes no readiness claim.

## 2026-08-15 — WP4a generic verification-manifest foundations

**Objective.** Replace the active D-031/D-032-specific commissioning contract
with a generic manifest and make configuration/tier runtime paths resolve exact
verification from the package-default profile, without migrating the retained
source record or weakening readiness, reconciliation, provider, or protected
authority gates.

**Outcome before final milestone verification.** Active manifests now use
strict `verification-manifest.v2` at `.agent/verification-manifest.json`, with
generic commissioning, objective, focused command, protected-path, invariant,
scope, exact, and reconciliation policy fields. Config loading proves the
commissioned profile equals the package default; all four tier plans consume a
source-independent generic fixture. Bootstrap exact indexes are representable
but remain non-authoritative and are explicitly rejected by readiness
reconciliation. The frozen v1 source and Ski Tycoon records are accepted only
by closed historical contexts; the source reconciliation adapter strengthens
their protected set with the current floor and cannot act as a general active
loader. Its required v2 timestamp comes from the retained record's real Git
commit timestamp. Both active and retained source paths remain automatically
protected while present. The source repository intentionally has no active v2
manifest until WP4b.

**Implementation diagnostics.** Read-only entry inspection confirmed synced
HEAD `2b65ddc860e5c8387de57aa6f2f624f4a734f167`, tree
`30e787d81c5faee1ae7080f2ffaf845fb8eab268`, zero branch divergence, a clean
tracked tree, and the protected human file's four expected identities. No
orientation aggregate or OCI case was run. Under pinned Node `24.18.0` and pnpm
`11.15.1`, the first five-file diagnostic ran 50 tests: 49 passed and the
historical adapter exposed one missing-current-trust-floor defect. After the
one-way protected-root union, the focused manifest file passed 6/6. A direct
stabilized-interface TypeScript diagnostic then passed. These are iteration
diagnostics, not final receipts.

**Stable-tree milestone protocol.** Source, tests, this log, the execution plan,
schema, and documentation freeze before the final commands. Two exact
receipt-owning focused shards, the live safety demonstration, serial
orchestrator and unit aggregates, and receipt-owning typecheck/lint/format gates
write fresh ignored evidence. Their outcomes remain in machine-owned artifacts
and the final handoff rather than being backfilled into tracked files. Every
receipt, declared artifact, count, skip, duration, candidate identity, and
immutable/protected hash is independently checked before the cohesive commit.
The required no-argument verifier runs exactly once afterward and its known
unrelated non-passing conditions remain honest.

**Commit.** Assigned only after the frozen candidate passes the applicable
WP4a checks; identify it as the newest commit touching this entry.

**Known gaps.** WP4b must commission the active source manifest and its
workflow without changing the historical record. Product placeholders,
calibration, trusted default-Windows execution, autonomous readiness, hidden
validation, and human verification remain open. WP4a makes no readiness claim.

## 2026-08-14 — WP3d disposable Docker execution candidate

**Objective.** Implement the OCI data plane behind WP3c's fail-closed provider:
an exact disposable verification clone, immutable image/input identity, fixed
runtime policy with independent inspection, bounded daemon-owned lifecycle and
storage, safe artifact export, real normal/adversarial containment coverage,
and no local or WSL fallback.

**Outcome before final milestone verification.** Docker-only executor version
1.0.0 is wired into `trusted-container`; Podman remains an explicit policy
mismatch. Every command uses a fresh exact clone, candidate container, read-only
exporter, and bounded workspace/evidence tmpfs volumes. Source and the pnpm v11
store are the only host binds and are read-only. The image, interpreted mount,
network, privilege, namespace, resource, and volume policies are inspected
before launch. Timeouts and output breaches stop/kill at the daemon, and every
container/volume removal must be confirmed. Export accepts only regular
single-link files, enforces combined file/byte limits, writes through an
exclusive open inode, and repeats source/destination size/hash checks. The
controller-owned report binds the daemon version, image ID/input hash,
provider capability, candidate commit/tree, lifecycle, policy, cleanup, and
artifact inventory.

**Implementation evidence.** The committed WP3c handoff evidence and hashes,
tree status, plan/logs, audit CD-01/P0.2, provider call sites, and
`pnpm loop:doctor` were inspected without a full-verifier baseline. With the
user's authorization, Ubuntu Docker Engine/client `29.1.3`, containerd `2.2.1`,
runc `1.3.4`, exact Linux Node `24.18.0`, and pnpm `11.15.1` were commissioned
inside the existing WSL2 distribution. The pinned base is
`node:24.18.0-bookworm@sha256:5711a0d445a1af54af9589066c646df387d1831a608226f4cd694fc59e745059`.
Image input SHA-256
`0392ec049d9c168fdefb9ab22fe38f9127953639aa96701a6369fa10ed9556a3`
was built once to immutable local image
`sha256:e405e2790e743243dd669f8e58eeaff6c585df3cbc77e9a4316a7f07b4e2eaad`;
subsequent unchanged-input probes reused the image and never a candidate
container.

A focused real normal-path diagnostic passed at
`artifacts/wp3d-oci-normal-policy-repro-20260814-r14/result.json` (2,401 bytes,
SHA-256 `6b08bf27811432831e84a84ff620c73dccc8f700a8b5de0049d5356603b01503`),
covering offline install, build, typecheck, Vitest, read-only Git, a valid
command receipt, artifact export, and confirmed cleanup. It predates the final
stable candidate and is diagnostic only, not reused as milestone evidence.
During hardening, the combined focused shard correctly exposed two 5-second
artifact-copy stalls at
`artifacts/manual/invariant-vitest-4604/`; after replacing the stream-close
dependency with bounded handle-based copying, the artifact suite passed 5/5 at
`artifacts/manual/invariant-vitest-428/`. After adding the strict environment
allowlist, pre-copy artifact preflight, and malformed-volume cleanup regression,
the affected executor suite passed 10/10 in 5,729 ms at
`artifacts/manual/invariant-vitest-13336/` and typecheck passed in 8,122 ms at
`artifacts/manual/typecheck-22284/`. The final regression proves cleanup is
attempted when a daemon may have accepted a create whose client response timed
out. Both command-owned receipts and their declared artifacts were independently
byte/hash checked. Earlier runtime-backed failures were
diagnosed one case at a time (Linux/Windows tool binary mismatch, emitted
module resolution, Docker option normalization, unsupported `docker start`
flag, stopped-container tmpfs lifetime, pnpm store selection, offline trust
revalidation, and fixture discovery); no failed run is counted as containment
evidence. A WSL-created Linux symlink dependency tree that Windows could not
read was moved intact to ignored
`artifacts/wp3d-wsl-node-modules-quarantine/`; a clean pinned Windows install
was materialized before continuing.

Independent inspection rejected the first nominal all-case result at
`artifacts/wp3d-oci-milestone-20260815/`: although its harness status was PASS,
the 1,500 ms hang deadline expired during offline installation and both its
artifact preflight and published-command inventories contained zero files. It
therefore did not exercise the claimed stubborn descendant and is not counted
as evidence. The focused repair changed only that real-case deadline to 12,000
ms and required a retained valid `child.json` PID marker. The focused
reproduction passed at
`artifacts/wp3d-oci-hang-repro-20260815-r1/result.json` (2,867 bytes, SHA-256
`a80f3554c8e63e942ee9878170d814545a8967328aead5c74d6a23c6cfd09e9a`):
the case timed out after 14,948 ms, published one descendant marker, reused the
unchanged image with zero builds, and left no managed container or volume. Its
10,076-byte containment report independently matched SHA-256
`263ff5cee4f93b1b8fde61980f7df757ca809ba923642089059538971d454b31`.
This focused result remains diagnostic because recording it changes the final
staged tree.

The corrected all-case matrix then passed on its frozen staged tree at
`artifacts/wp3d-oci-milestone-20260815-r2/result.json` (6,923 bytes, SHA-256
`a70ddbf431068ad28b4619579c9149ab12d29a3986739752dc1ae65485d88560`):
all six expected dispositions, the retained hang marker, unique disposable
container IDs, zero image builds, and zero remaining managed resources were
independently validated. It is no longer final evidence because the first
serial orchestrator aggregate subsequently exposed one stale test expectation.
That aggregate ran 2,303,297 ms and wrote
`artifacts/manual/test-orchestrator-24192/orchestrator-report.json`: 460 tests,
457 passed, one failed, and the same two explicit WP5 skips; the failed command
correctly produced no passing receipt. The sole failure was a WP3c-era
`missing-implementation` expectation in `verification-tier.test.ts`. A focused
reproduction failed at `artifacts/manual/invariant-vitest-19880/`; the repair
now injects a missing runtime deterministically and preserves the exact
NOT_READY/no-local-fallback meaning under WP3d's real implementation. The
focused file passed 14/14 in 7,024 ms at
`artifacts/manual/invariant-vitest-5736/`; its 5,269-byte declared report
independently matched SHA-256
`9da5c71e5eca1e4ff0f8b70054469c7e3d4ca6dd287df08536c8db6df22bfa0c`.

The next exact-tree matrix passed at
`artifacts/wp3d-oci-milestone-20260815-r3/result.json` (6,923 bytes, SHA-256
`2d8c428b3b07c9bc8ce4cde169cbd687df3432de19e6bb992cb0a8346302c06e`),
with all report/artifact identities and cleanup independently checked. The
required orchestrator rerun passed 458/460 with the two unchanged WP5 skips in
2,254,714 ms at `artifacts/manual/test-orchestrator-14780/`; its 161,116-byte
report independently matched SHA-256
`ad4346de23a05e526742510e44894202c905b63e9d685f3d12b5b02342ad746b`.
The unit aggregate passed 471/473 with the same skips in 2,291,871 ms at
`artifacts/manual/test-unit-15604/`; its 165,029-byte report matched SHA-256
`f1f7f96dd75931132dacf552c560856c65dbd4d979e401cd384dc9de7371c0a3`.
The safety demonstration passed in 3,406 ms; its 11,931-byte artifact matched
SHA-256
`8cbd2787aa81681204aaa729bdc6b1fd053abfe60ac7d171a69ebbfa1cb7eaf6`.
Typecheck passed in 11,807 ms at `artifacts/manual/typecheck-1752/`.

Static inspection then found two harness-only useless initial assignments in
the OCI result accumulator. Removing those initializers passed lint in 10,409
ms at `artifacts/manual/lint-14612/` and typecheck in 7,617 ms at
`artifacts/manual/typecheck-11464/`. Format inspection separately caught the
new fixture lockfile before the freeze; formatting only that lockfile passed in
10,718 ms at `artifacts/manual/format-check-7128/`. Those source/fixture changes
invalidate the otherwise-passing r3 and aggregate receipts for a final-tree
claim; none will be reused. The final commands below run again only because
exact-tree evidence is mandatory.

Report-span comparison attributes only 6,239 ms (0.28%) of orchestrator wall
time and 5,882 ms (0.26%) of unit wall time to wrapper overhead. The long stage
times are overwhelmingly the crash-boundary assertions themselves, not a
recurring launch/receipt harness tax. No separate harness optimization is
justified in WP3d; changing those tests would risk coverage for negligible
wrapper savings.

**Stable-tree milestone protocol.** Source, tests, this log, the execution plan,
and documentation freeze before the final commands. The serial OCI matrix will
write `artifacts/wp3d-oci-milestone-20260815-r4/result.json`; receipt-owning
orchestrator, unit, typecheck, lint, and format gates will write fresh ignored
evidence, and their reports provide stage/test durations. Outcomes are retained
in those machine-owned artifacts and the final handoff rather than backfilled
into tracked files, so the verified candidate tree does not change underneath
its evidence. The required no-argument verifier runs only after the same tree
is committed and clean; its expected product-placeholder failures are not
suppressed or relabeled.

**Commit.** Assigned only after the frozen candidate passes the applicable
WP3d checks; identify it as the newest commit touching this entry.

**Known gaps.** The real matrix is Docker/WSL2 Linux evidence, not native
Windows, Podman, or native Linux CI evidence. The default image ID remains
uncommissioned by design, so the shipped template doctor is `NOT_READY`.
Product placeholders, calibration, autonomous readiness, hidden validation,
and human verification remain open; this increment makes no product or
readiness claim and is not pushed.

## 2026-08-14 — WP3c fail-closed execution provider control plane

**Objective.** Add the controller-owned provider selection and evidence
identity required before candidate-authored verification can be moved into a
pinned OCI environment, without claiming that WP3d containment already exists
or weakening the existing supervisor, receipt, integration, and readiness
gates.

**Outcome.** Config schema `1.6.0` defaults and migrates every prior version to
`trusted-container`; the absent WP3d executor fails closed before candidate
spawn and never falls back. Explicit `unsafe-local-diagnostic` execution uses
the bounded shared supervisor and stays completion-ineligible. A strict
provider identity is propagated through command/tier/aggregate/state/target/
reconciliation evidence and is validated for presence, eligibility, and exact
semantic equality wherever evidence could support adoption. Candidate-returned
identity is not trusted. State migrations preserve old evidence as
unattested/ineligible and block legacy pending target operations safely. Doctor
now distinguishes implementation, runtime, pinned-image, and policy failures.

**Verification.** All commands used Node `24.18.0` and pnpm `11.15.1`.
The complete focused matrix passed 46/46 suites and 205 tests with 0 failures
and exactly the two explicit WP5 POSIX skips at
`artifacts/manual/invariant-vitest-520/`; its 71,507-byte report matches
SHA-256 `4634557d8296a2e4d3cddc0a606bb71fc1f47cbc8fd37ea80722cfac4b8ddf1b`.
The later hardening subset passed 65/65 at
`artifacts/manual/invariant-vitest-7812/`. The final isolated orchestrator
aggregate passed 137/137 suites, 436 tests, 0 failures, and the same two skips
at `artifacts/manual/test-orchestrator-10220/`; its 152,919-byte report matches
SHA-256 `fcb4d768222acc67427da7fcf4175d3fe6b3d45c1db5d336699e6cbc0de60cd3`.
The earlier unit aggregate passed 446 tests, 0 failures, and the same two skips
at `artifacts/manual/test-unit-21396/`. A user-directed stop of a redundant
pre-freeze rerun left `artifacts/manual/test-unit-1420/` with no receipt, so it
is not cited as evidence.

Receipt-owning typecheck, lint, and format gates passed at
`artifacts/manual/typecheck-3064/`, `artifacts/manual/lint-25080/`, and
`artifacts/manual/format-check-13384/`; every receipt and declared artifact
byte count/SHA-256 was independently recomputed and matched. Safety demo passed
all six scenarios at
`artifacts/orchestrator/runs/safety-demonstration/safety-demonstration-20260815010034386-d9e187ef.json`.
The immutable lock remains
`d1166088b00c54af65e8654188adc58a3cabd9d7908820809fe66af28c933050`,
all governed baseline/active hashes remain equal, and the protected human file
remains outside the commit at blob
`d0abdd24f404d9dc335818c355e39f7cfc531300`. A single post-freeze consolidated
verification is the final handoff check; no process-supervision suites are run
concurrently and already-valid focused/orchestrator evidence is reused.

**Commit.** `cc17d8e5f22beb3eb3be9871bb6fed5efa9c031b` (tree
`44050eba6c69bdf9ced6cc388a18c51b72348576`).

**Known gaps.** WP3d must implement the pinned OCI executor, disposable clone,
mount/network/resource containment, and adversarial escape matrix. The two
POSIX-only process-tree tests remain explicit WP5 skips; no unsupported-platform
coverage is claimed. Product placeholders, calibration, autonomous-readiness,
and human-verification gates remain open. This increment makes no product
completion or readiness claim and is not pushed.

## 2026-08-08 — WP3b verifier and evidence trust-root supervision

**Objective.** Convert every process launch owned directly by the protected
authoritative verifier and shared evidence helpers to the WP3a bounded
supervisor while preserving verifier contract semantics, exact toolchain
identity, WP2 retention/workspace-cleanup behavior, and all WP3a review fixes.

**Outcome.** `scripts/verify.mjs` and `tools/evidence.mjs` now use the shared
plain-Node-loadable supervisor for identity probes, package scripts, citation
queries, and evidence commands. Each launch has a finite timeout, per-stream
cap, shared kill grace, redact-before-write behavior, and the complete WP3a
supervision disposition; timeout and output-limit outcomes fail closed.
Verifier schema `2.1.0`, stage/profile meanings, immutable-lock and receipt
validation, identity drift, exit/status weighting, and completion eligibility
are unchanged. Evidence callers await the asynchronous boundary, execute the
exact pnpm JavaScript entry under pinned Node, and retain their prior result
contracts. New regressions cover plain Node loading, default ownership,
redaction, output breach, timeout, verifier identity/supervision, and absence
of direct production spawn paths. Isolated verifier and production-build
fixtures now copy the exact transitive supervisor dependency and pinned
package-manager state.

**Verification.** All commands used Node `24.18.0` and pnpm `11.15.1`. The
requested serial cleanup/reconciliation reproduction initially retained only
the cleanup deadline while an unrelated host Vitest/Git workload was active;
with that workload clear, the identical command passed 24/24 (cleanup
26.264 s, rejected-review reconciliation 32.065 s) without a source or timeout
change. Contended aggregates at
`artifacts/manual/test-orchestrator-3512/` and
`artifacts/manual/test-orchestrator-7220/` correctly produced no PASS receipt;
the clean corrected-tree orchestrator aggregate passed 419 tests (417 passed,
2 explicit WP5 POSIX skips, 0 failed) at
`artifacts/manual/test-orchestrator-1444/`. The clean unit aggregate exposed
one deterministic isolated-fixture dependency defect at
`artifacts/manual/test-unit-22236/`; after the fixture repair, the focused
production-build suite passed 13/13 and the complete unit aggregate passed 432
tests (430 passed, the same 2 WP5 skips, 0 failed) at
`artifacts/manual/test-unit-21692/`. The earlier one-hour unit supervision
timeout remains honestly recorded at `artifacts/manual/test-unit-24196/`; no
bound or test deadline was raised.

Final receipt-owning gates passed at `artifacts/manual/typecheck-6956/`,
`artifacts/manual/lint-5448/`, and
`artifacts/manual/format-check-3044/`; the pre-format attempt at
`artifacts/manual/format-check-13128/` correctly contains only an ERROR
manifest. Every final orchestrator, unit, typecheck, lint, and format report
and receipt byte count/SHA-256 was independently recomputed and matches its
manifest. `pnpm loop:demo-safety` passed all six scenarios at
`artifacts/orchestrator/runs/safety-demonstration/safety-demonstration-20260809002843117-741e4c73.json`.
The final focused verifier at
`artifacts/wp3b-final-contract-20260808/result.json` has all exact-runtime/pin
checks and all 13 contract-integrity checks PASS; overall FAIL is expected
only from the honest dependency placeholder, its command supervision is
bounded/closed-stream, and completion is ineligible. The immutable lock and
all four governed hashes remain exact, `git diff --check` passed, and the
unrelated human file remained outside the commit at blob
`d0abdd24f404d9dc335818c355e39f7cfc531300`.

**Commit.** `3efa3ed77b46abdea61e4b867a5998e92f54d6c3` (tree
`8cb1bd29486f643830ff19e39ede38945ed7ea73`).

**Known gaps.** The two POSIX group/process-tree tests remain explicit WP5
skips; no unsupported-platform coverage is claimed. OCI containment,
execution-provider identity, unrelated launch sites, and the previously
recorded WP3a process-escape residuals remain future WP3 work. Product-domain
verification placeholders, calibration, and every autonomous-readiness and
human-verification gate remain open. This increment makes no completion or
autonomous-readiness claim.

## 2026-08-07 — WP3a review fix: drain cutoff, spawn resolve, honest termination

**Objective.** Close three independent review findings against the WP3a
supervisor at `e06baf4`: an inert post-exit output-limit breach (high), a
synchronous spawn throw rejecting past the never-rejects contract (medium),
and `termination.succeeded` overstating what root exit proves (medium).

**Outcome.** A cap breach during the post-exit drain now cuts the drain off
at the breach: the straggler sweep runs immediately (POSIX group SIGKILL;
recorded unavailable on Windows behind a dead root), streams are destroyed,
and the command settles with `drainCutoff: "output-limit"` — a breaching
writer that then closes its pipes can no longer skip the sweep, and the
runner reports the post-exit breach without claiming tree termination.
Synchronous spawn throws resolve an ERROR-shaped result with `spawnError`
set. The termination report now records `rootExitObserved` plus per-attempt
detail and never claims tree-wide success. Findings 1 and 2 were reproduced
by deterministic probes against the prior commit before fixing; all three
have regressions (scripted-child drain cutoff, scripted-child spawn throw,
fallback-root-kill semantics, and a real detached holder that polls for
parent death and floods the inherited pipe strictly after exit through
`runCommand`).

**Verification.** Under Node `24.18.0` and pnpm `11.15.1`: focused
supervisor/runner suites 27 passed / 2 skipped (WP5 POSIX). One first-run
aggregate failure was the new fixture's own cleanup racing Windows
asynchronous handle release (EBUSY removing the killed holder's working
directory); both process-test suites now poll killed fixtures to death and
retry the same transient removal codes the production stores retry, and only
the subsequent complete green aggregates are cited. Final-tree receipts:
typecheck `artifacts/manual/typecheck-17492/`, lint
`artifacts/manual/lint-20652/`, format `artifacts/manual/format-check-24620/`,
orchestrator aggregate 414 tests (412 passed, 2 skipped WP5, 0 failed) at
`artifacts/manual/test-orchestrator-10784/orchestrator-report.json`, unit
aggregate 427 tests (425 passed, 2 skipped WP5, 0 failed) at
`artifacts/manual/test-unit-7280/`, `pnpm loop:demo-safety` PASS at
`artifacts/orchestrator/runs/safety-demonstration/safety-demonstration-20260807190106966-4c6cc48e.json`,
clean `git diff --check`. The unrelated untracked human file remained at
blob `d0abdd24f404d9dc335818c355e39f7cfc531300` and outside the commit.

**Commit.** `eab0cd6` (tree `11e115cf0188929afb1c5e6357b616541c4fc75d`).

**Known gaps.** Unchanged from WP3a: POSIX supervision paths first execute
in WP5 Linux CI; reparented-descendant/PID-reuse escapes, Windows post-exit
stragglers behind a dead root, and setsid-detached POSIX daemons remain
recorded residuals owned by the WP3 container slice, alongside contained
candidate execution and the `scripts/verify.mjs`/`tools/evidence.mjs` spawn
conversion. No product-completion or autonomous-readiness claim.

## 2026-08-07 — WP3a bounded process supervisor

**Objective.** Give every controller-spawned verification command a bounded,
deterministic supervision boundary: capped and redacted output, complete
process-tree termination on timeout or cap breach, a bounded post-exit
stream-drain window, and an exactly-once settle with a hard upper bound —
the first bounded WP3 process-containment slice (audit CR-02,
improvement-plan §WP3.5, P0 sweep P1.1/R-01).

**Outcome.** New `process-supervisor.ts` owns spawn, bounded per-stream
capture, termination, drain, and settle; `runCommand` keeps its public API,
policy, redaction, artifact, hashing, telemetry, and status semantics and
adopts the supervisor, so all orchestrator call sites inherit supervision.
Output beyond `limits.commandOutputLimitBytes` (default 64 MiB per stream)
is counted but never retained; a breach tree-kills and fails in the existing
infrastructure lane with newline-boundary truncation and a marker covered by
the recorded hash. Windows termination is force-first
`taskkill /pid <pid> /T /F` while the tree is intact with `child.kill()`
fallback; POSIX uses detached process-group SIGTERM escalating to SIGKILL
after `limits.commandKillGraceMs` (default 5000 ms). Settle is exactly-once
with an abandonment backstop bounding it by `timeoutMs + 2 x killGraceMs`.
Config schema is `1.5.0` with in-memory migration injecting the two new
limits; summaries carry a full `supervision` record. Probed platform facts
(recorded in the decision log): non-detached Node grandchildren die with
their parent via libuv's kill-on-close job object, while detached ones
escape it, survive, and hold inherited pipes open — the reproduced CR-02
hang, which now settles through the drain window; the tree-kill proof
therefore uses a detached (job-object-escaping) grandchild reaped by the
intact-tree taskkill.

**Verification.** Under Node `24.18.0` and pnpm `11.15.1`: focused
supervisor/runner/config suites passed 29 with 2 skipped (POSIX-only,
flagged WP5); affected verifier/reconciliation/tier suites passed 86/86.
Receipt-owning gates: typecheck `artifacts/manual/typecheck-21180/`, lint
`artifacts/manual/lint-22928/`, format `artifacts/manual/format-check-13364/`,
complete orchestrator aggregate 410 tests (408 passed, 2 skipped WP5,
0 failed) at `artifacts/manual/test-orchestrator-3096/orchestrator-report.json`,
complete unit aggregate 423 tests (421 passed, 2 skipped WP5, 0 failed) at
`artifacts/manual/test-unit-10224/result.json`, `pnpm loop:demo-safety` PASS
at
`artifacts/orchestrator/runs/safety-demonstration/safety-demonstration-20260807154534494-b6b8565c.json`,
and a clean `git diff --check`. Two earlier complete aggregates failed only
on the pre-existing `target-integration-recovery` post-fast-forward test
exceeding its 120s budget (90.9s at the 2026-08-06 baseline; 102.3s isolated
and 120.2s/122.4s in-suite on 2026-08-07; its code paths do not touch this
increment); its duration budget was raised to 300s with measurements
recorded in-file and no assertion changed, and only the subsequent complete
green aggregates are cited. The unrelated untracked human file remained at
blob `d0abdd24f404d9dc335818c355e39f7cfc531300` and outside the commit.

**Commit.** `e06baf4b658713961825edc7996884308bc8c582` (tree
`6d8307b9e9923eafff13fa734931fde1e88b47b5`).

**Known gaps.** POSIX supervision paths (group kill, escalation, drain
sweep) are written but first execute in WP5 Linux CI — no unsupported-
platform claim is made. Descendants reparented before the kill, PID reuse,
Windows post-exit stragglers behind a dead root, and setsid-detached POSIX
daemons remain recorded escape residuals owned by the WP3 container slice,
which also still owns contained candidate execution, execution-provider
identity, and `scripts/verify.mjs`/`tools/evidence.mjs` spawn conversion.
Product-domain verification placeholders, calibration, and every frozen
autonomous-readiness and human-verification gate remain open; nothing here
claims product completion or autonomous readiness.

## 2026-08-06 — WP2d recoverable approval-bound retention apply

**Objective.** Authenticate the complete operator-approved retention plan,
publish one canonical deletion intent before any apply artifact or evidence
removal, and make interrupted application converge without transferring
authority to journal text or changing terminal workspace-cleanup semantics.

**Outcome.** State schema `1.8.0` adds a strict global `retention-apply`
operation bound to the full plan hash, exact input generation/revision,
repository/controller/retention identity, complete dirty-worktree fingerprint,
configured and real roots, observed inventories, ordered target manifest
identities, canonical full-hash apply paths, progress, and deterministic
timestamps. Strict plan schema `1.2.0` and a fresh preflight reject partial or
non-canonical envelopes, changed bytes, configuration/root/citation/recency/
suspension drift, and target identity changes before deletion. Each target
enters durable delete-started state before the unchanged contained removal
primitive. The synced JSONL journal and exact result are derived evidence only:
recovery completes canonical prefixes and torn appends, adopts absence only
from state authorization, preserves conflicting paths with a durable blocked
diagnostic, and completes through one reducer. Explicit apply and leased
orchestrator startup share this recovery path before other state mutation.
Status and doctor schema `1.6.0` classify progress without recovery or
mutation. Terminal workspace-cleanup production code and policy are unchanged.

**Verification.** Under Node `24.18.0` and pnpm `11.15.1`, focused retention
apply passed 19/19, operation/schema/store/doctor passed 48/48, leased startup
recovery passed, and synchronized recovery contenders serialized through the
controller lease. Hard process loss at all nine declared boundaries converged
to identical normalized state, journal, and result digests in
`artifacts/manual/wp2d-retention-apply/fault-matrix.json`. Final receipt-owning
typecheck, lint, and format checks passed at
`artifacts/manual/typecheck-21684/`, `artifacts/manual/lint-21048/`, and
`artifacts/manual/format-check-22956/`. The complete orchestrator aggregate
passed 390/390 at `artifacts/manual/test-orchestrator-11316/result.json`; the
full unit aggregate passed 403/403 at
`artifacts/manual/test-unit-19776/result.json`; and `pnpm loop:demo-safety`
passed at
`artifacts/orchestrator/runs/safety-demonstration/safety-demonstration-20260807050845281-8bd6533b.json`.
Two broad attempts exceeded undersized outer shell wrappers and were treated as
invalid. A later complete attempt correctly exposed one stale plan-schema
assertion plus a Windows test-fixture `ENOTEMPTY`; both were fixed without
changing production cleanup, the focused lifecycle file passed 9/9, and only
the subsequent complete green aggregates are cited.

**Commit.** `c556e112113da4b565f13a9a5337aeb9df2dd344` (tree
`3365a5aa21057b2337c921f02d0cccad4a531a49`).

**Known gaps.** WP3 still owns process containment, and WP5 owns Linux
publication/race evidence. Product-domain verification placeholders,
calibration, and every frozen autonomous-readiness and human-verification gate
remain open. These Windows controller results do not claim unsupported-platform
coverage, product completion, or autonomous readiness.

## 2026-08-06 — WP2c recoverable terminal workspace cleanup

**Objective.** Publish one exact terminal workspace-cleanup intent before
dependency removal, failed-run diagnostic publication, or recursive workspace
deletion, then make uninterrupted and restarted cleanup converge through one
canonical completion reducer without changing evidence-retention semantics.

**Outcome.** State schema `1.7.0` extends the exclusive pending-operation union
with `workspace-cleanup`, bound to the exact canonical generation/revision,
run/milestone/attempt, repository/target identity, standalone workspace and
creation marker, recorded and observed commits, cleanup policy, pinned
timestamps, and exact diagnostic hashes/sizes. Startup recovery runs under the
controller lease before ordinary terminal cleanup and advances through explicit
dependency, archive, and workspace-delete phases. Preserve policy never adopts
a missing workspace; delete policy adopts one only after durable authorization;
and failed deletion requires an exact complete archive. Failed cleanup pins the
actual observed descendant independently from the last recorded candidate,
because candidate drift may be the failure being archived. Ambiguous roots,
links, substitutions, Git or diagnostic drift, premature disappearance, and
partial/conflicting archives remain preserved with a durable blocked
diagnostic. Status and doctor schema `1.5.0` classify the operation and next
safe action without recovery or mutation. Approval-bound evidence retention is
unchanged.

**Verification.** Under Node `24.18.0` and pnpm `11.15.1`, synchronized
post-delete recovery produced zero semantic differences and hard process loss
converged at all 15 declared boundaries across completed deletion, completed
preservation, and failed diagnostic deletion. Structured records are
`artifacts/manual/wp2c-workspace-cleanup/post-delete-convergence.json` and
`artifacts/manual/wp2c-workspace-cleanup/fault-matrix.json`. Blocked-state,
candidate-drift, diagnostic-drift, archive-conflict, concurrent lease, and
status/doctor byte-digest cases passed. Receipt-owning typecheck, lint, and
format passed at `artifacts/manual/typecheck-18532/`,
`artifacts/manual/lint-4720/`, and
`artifacts/manual/format-check-23228/`. The complete orchestrator aggregate
passed 379/379 at `artifacts/manual/test-orchestrator-19060/result.json`; the
full unit aggregate passed 392/392 at
`artifacts/manual/test-unit-14056/result.json`; and `pnpm loop:demo-safety`
passed at
`artifacts/orchestrator/runs/safety-demonstration/safety-demonstration-20260807005440748-4cc540e4.json`.
One broad attempt was invalidated by an outer shell timeout and a later complete
attempt correctly exposed a failed-workspace HEAD-policy defect; neither is
cited as passing evidence, and the successful aggregates ran after the fix
under a temporary OS keep-awake guard with repository test limits unchanged.

**Commit.** `0557e66a5fa0763896fee9c4319d6d8939ed8254` (tree
`0508a5f4c759c327d60714c5295f77d13fbd2fc1`).

**Known gaps.** WP2d still owns approval-bound evidence-retention application
intent/authentication and interrupted deletion convergence. Linux cleanup
publication/race evidence remains a WP5 CI deliverable. This Windows result
does not claim unsupported-platform coverage or autonomous readiness, and the
adopting product verification placeholders remain honestly non-passing.

## 2026-08-06 — WP2b recoverable target integration

**Objective.** Publish one exact approved target-integration intent before any
outcome, fetch, ref, index, or worktree side effect, recover it under the
controller lease, and make uninterrupted and restarted completion use one pure
semantic reducer.

**Outcome.** State schema `1.6.0` extends the exclusive pending-operation union
with `target-integrate`, bound to the exact canonical generation/revision,
run/milestone/attempt, repository/target/workspace identity, approved candidate
and commit list, verification-result digest, deterministic outcome paths,
phases, timestamps, and validate/adopt-or-preserve policy. Normal integration
persists intent before its first external side effect. Startup recovers before
ordinary target drift, revalidates protected files and the standalone
remote-free candidate, resumes only from the exact clean base, and adopts only
the exact clean candidate. Pending and integrated outcome bytes are exactly
regenerable. Dirty, locked, in-progress, unexpected, drifted, linked,
substituted, and conflicting states are preserved with durable diagnostics.
Reviewer approval without intent now requires explicit reconciliation. One
completion reducer owns target/milestone/queue/vertical-consumer/processed-count
and human-verification-stop state. Status and doctor schema `1.4.0` classify the
operation and exact next action without mutation.

**Verification.** Under Node `24.18.0` and pnpm `11.15.1`, hard child-process
loss at all 12 declared boundaries converged to canonical completion; the
structured records are
`artifacts/manual/wp2b-target-integration/fault-matrix.json` and
`artifacts/manual/wp2b-target-integration/post-fast-forward-convergence.json`.
The latter also barrier-synchronized two restart contenders and found no normal
versus recovered semantic difference. Target classification/action/outcome,
migration, lifecycle, identity, reconciliation, cleanup, status, doctor, and
CLI focused checks passed. Receipt-owning typecheck, lint, and format passed at
`artifacts/manual/typecheck-15628/`, `artifacts/manual/lint-904/`, and
`artifacts/manual/format-check-13872/`. The complete orchestrator aggregate
passed 372/372 at `artifacts/manual/test-orchestrator-20588/result.json`; the
full unit aggregate passed 385/385 at
`artifacts/manual/test-unit-11116/result.json`; and `pnpm loop:demo-safety`
passed at
`artifacts/orchestrator/runs/safety-demonstration/safety-demonstration-20260806215546754-eb6dd114.json`.
Two earlier broad attempts were invalidated by machine suspend, which produced
impossible multi-thousand-second durations for unchanged 60-second tests; every
affected case passed awake under its original limit, and the successful broad
runs used only a temporary OS awake guard, not altered repository timeouts.

**Commit.** `057f16bc14ec28bda36e762d503ee1d4252a898d` (tree
`55b6e7a8b97c941663228246617998743589f3b9`).

**Known gaps.** Later WP2 increments still own terminal cleanup and retention
side-effect journaling; this change uses but does not make those subsystems
recoverable. Linux ref/index/worktree race evidence remains a WP5 CI
deliverable. This Windows result does not claim unsupported-platform coverage
or autonomous readiness, and the adopting product verification placeholders
remain honestly non-passing.

## 2026-08-06 — WP2a recoverable workspace creation

**Objective.** Persist a strict workspace-create operation before any clone
side effect, publish through a unique contained temporary path, and make every
creation boundary deterministic and recoverable under the controller lease.

**Outcome.** State schema `1.5.0` adds one exclusive, exact-generation-bound
`workspace-create` intent with pure set/advance/block/complete transitions and
a global unrelated-mutation fence. Canonical `1.4.0` generations migrate
virtually on read and durably on their next CAS successor. Attempt startup now
persists intent before creating directories, clones without hardlinks into a
short unique temporary entry, establishes standalone remote-free identity,
and publishes with no-clobber semantics. Leased startup classifies missing,
source-clone, ready-temporary, exact-final, ambiguous, substituted, and unsafe
paths; it resumes or adopts only exact identity and otherwise preserves the
entries in place with a durable blocked diagnostic. Validation covers lexical
and realpath containment, symlinks/junctions/gitfiles, repository ownership,
alternates/shallow state, exact base/branch, cleanliness, canonical config,
controller markers, and remote facts. Status and doctor schema `1.3.0` expose
the pending operation and next safe action using read-only Git inspection.

**Verification.** Under Node `24.18.0` and pnpm `11.15.1`, a real-clone matrix
injected process loss at all eight declared durable/filesystem boundaries and
converged every restart to the same normalized revision-9 state. The complete
orchestrator suite passed 363/363 at
`artifacts/manual/test-orchestrator-13136/result.json`; the full unit aggregate
passed 376/376 at `artifacts/manual/test-unit-17720/result.json`. Receipt-owning
typecheck, lint, and format passed at `artifacts/manual/typecheck-21940/`,
`artifacts/manual/lint-7288/`, and `artifacts/manual/format-check-25136/`.
`pnpm loop:demo-safety` passed with its report at
`artifacts/orchestrator/runs/safety-demonstration/safety-demonstration-20260806175034510-a6ecc318.json`.

**Commit.** `3f6d8e916a7139c71d7aa1e6b99e2bfe10ff1844` (tree
`55858b14eff61c7b4348719604ebf1357bdfb2fe`).

**Known gaps.** WP2b must journal target integration and converge interrupted
integration through one canonical completion reducer; later WP2 increments
still own cleanup and retention side effects. Linux path and publication-race
evidence remains a WP5 CI deliverable. This Windows result does not claim
unsupported-platform coverage or autonomous readiness, and the adopting
product verification placeholders remain honestly non-passing.

## 2026-08-05 — WP1b atomic canonical state generations

**Objective.** Replace mirror-revision read/check/write with a canonical,
recoverable state-generation primitive that permits exactly one publication
from a shared starting generation and preserves read-only command semantics.

**Outcome.** `refs/milestone-loop/state` now points to a strict Git commit
generation containing canonical state JSON and exact revision/hash metadata.
The single parent is the prior generation; current and immediately previous
commits are validated for type, exact tree, schema, hashes, revision successor,
parent, fixed controller identity/timestamp, and canonical message. Saves use
expected-old `git update-ref`. The configured `state.json` is a derived mirror
repaired only on mutation-capable opens. Valid legacy bytes import exactly once
and remain available for reconciliation provenance; malformed, linked, or
ambiguous input fails closed. `load()` cannot authorize `save()`. Status and
doctor schema `1.2.0` expose canonical-generation and mirror facts without
mutating either store. The safety demonstration uses an isolated Git fixture.

**Verification.** Under Node `24.18.0` and pnpm `11.15.1`, the synchronized
multiprocess same-generation race passed five consecutive runs at
`artifacts/manual/wp1b-state-races/run-{1..5}.json`. Receipt-owning typecheck,
lint, and format passed at `artifacts/manual/typecheck-7476/`,
`artifacts/manual/lint-21564/`, and
`artifacts/manual/format-check-22368/`. The complete orchestrator suite passed
349/349 at `artifacts/manual/test-orchestrator-20856/result.json`; the full
unit aggregate passed 362/362 before commit and again from the clean committed
tree at `artifacts/manual/test-unit-24644/result.json`. The live safety
demonstration passed at
`artifacts/orchestrator/runs/safety-demonstration/safety-demonstration-20260806045354446-4e64d4e5.json`.

**Commit.** `987ce005a410470d078b8dd57802abbffc2d0356` (tree
`0b9c1719ebc9f7accac4d64e872c6878b753eed2`).

**Known gaps.** WP2 must journal workspace, integration, cleanup, and retention
side effects and converge interrupted integration through the same canonical
completion reducer. Linux race evidence remains a WP5 CI deliverable; this
Windows proof does not claim unsupported-platform coverage. Uncommissioned
readiness placeholders remain honestly non-passing and WP1 is not an
autonomous-readiness claim.

## 2026-08-05 — WP1a atomic controller ownership

**Objective.** Replace stale-file quarantine takeover with a real
expected-owner primitive so a losing first-owner or stale-owner contender can
never remove, replace, or release the live winner.

**Outcome.** The canonical lease is now
`refs/milestone-loop/controller-lease`, pointing to a strictly validated owner
JSON blob. Acquisition, stale takeover, and release use expected-old
`git update-ref`; inspection is read-only. A permanent file-protocol guard
blocks older file-lease binaries and conflicting legacy files fail closed.
Doctor schema `1.1.0` and status expose the canonical ref and guard state.
Normal `git push --all` excludes the private namespace.

**Verification.** Under Node `24.18.0` and pnpm `11.15.1`: the focused lease
suite passed 16/16; the three synchronized first-owner/stale-owner/winner-life
race cases passed in five consecutive repetitions; the complete orchestrator
suite passed 328/328 at
`artifacts/manual/test-orchestrator-20228/orchestrator-report.json`. From the
clean implementation commit, `pnpm test:unit` passed 341/341 with receipt at
`artifacts/manual/test-unit-15140/result.json`; typecheck, lint, and format
receipts are `artifacts/manual/typecheck-3040/`,
`artifacts/manual/lint-16032/`, and
`artifacts/manual/format-check-15788/`; `pnpm loop:demo-safety` passed with its
report under `artifacts/orchestrator/runs/safety-demonstration/`. A direct
`loop:status` probe left both the ref and legacy guard absent, proving the
read-only path does not initialize ownership state.

**Commit.** `fa1ef6f80c1dd089f8f78133d0aa2344f40a2174` (tree
`0be6b70c386cf58b076f7d3b33cc8f82545cb2a0`).

**Known gaps.** The JSON state mirror still uses a non-atomic revision
read/check/write sequence. WP1b must make `refs/milestone-loop/state`
canonical, migrate legacy state exactly once, and demote `state.json` to a
repairable mirror before WP1 is complete. Linux race evidence remains a WP5 CI
deliverable; no unsupported platform result is claimed here.

## 2026-08-05 — WP0 truthful production-build evidence

**Objective.** Eliminate the zero-command production-build PASS and require an
explicit project-owned build contract, a clean disposable clone, fresh outputs,
output-root containment, and retained path/size/SHA-256 evidence.

**Outcome.** `pnpm build` now exits 2/`NOT_READY` without a receipt when
`package.json#milestoneLoop.productionBuild` is absent. A configured fixture
runs the declared non-recursive script after a frozen offline install, rejects
stale, empty, outside-root, linked, and post-report-mutated outputs, and issues a
PASS receipt only after a second inventory check.

**Verification.** Under Node `24.18.0` and pnpm `11.15.1`: 13/13 focused build
fixtures passed; `pnpm test:unit` passed 336/336 with receipt at
`artifacts/manual/test-unit-11968/result.json`; `pnpm typecheck`, `pnpm lint`,
and `pnpm format:check` passed with receipts at
`artifacts/manual/typecheck-23840/`, `artifacts/manual/lint-23020/`, and
`artifacts/manual/format-check-19280/`; `pnpm loop:demo-safety` passed. Focused
aggregate evidence is
`artifacts/verify-2026-08-06T025915-819Z-12324/result.json`: production-build is
correctly `NOT_READY` with no receipt, while the aggregate remains FAIL because
the unrelated adopting-project dependency check is still a placeholder.

**Commit.** `66c564c3c2142cde7b5d31d82a18213fdcde525a` (tree
`d9ffd30151c9fac86c5f8c15f1aecd181e10a641`).

**Known gaps.** The template remains deliberately uncommissioned. Candidate
build execution is still local-host execution until WP3 containment. This
increment does not alter readiness meaning or claim autonomous completion.

## 2026-08-05 — Supported-runtime state replacement retry

**Objective.** Remove an intermittent Windows `EPERM` state-file replacement
failure that blocked broad supported-runtime verification, without disguising
or claiming to solve the WP1 atomic-CAS defect.

**Outcome.** State JSON replacement retries only bounded transient filesystem
codes with linear backoff, then fails closed and preserves the prior durable
file. Deterministic hooks cover eventual success and persistent failure.

**Verification.** Under Node `24.18.0`: 13/13 state-store tests, typecheck, lint,
format, and 323/323 orchestrator tests passed. The broad receipt is retained at
`.tools/state-rename-retry/artifacts/manual/test-orchestrator-21932/result.json`.

**Commit.** `235ea2bcb2c32850a9e9e3f4aec24058c4aab546` (tree
`f35a056b5a7ba71e5607c381e6885aa41c60a017`).

**Known gaps.** Read/compare/rename state publication is still not an atomic
CAS, and stale lease takeover is still vulnerable. Both remain WP1 blockers.
