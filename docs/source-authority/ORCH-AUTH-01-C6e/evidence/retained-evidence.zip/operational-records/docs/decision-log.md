# Decision Log

## 2026-09-07 04:46 UTC — Archive operational records while preserving executable verification pins

The user's rolling-handoff requirement exposed a retention-draft defect: pinning the live plan and append-only logs as current implementation files would invalidate retained source verification every time continuity was refreshed. C6e curation now copies exactly `.agent/current-exec-plan.md`, `docs/autonomy-log.md` and `docs/decision-log.md` into its sealed `operational-records/` inventory. The manifest binds each original path to the copied byte length and SHA256; the auditor requires that exact three-path set and checks the archived copies. Only these operational records leave the live implementation-pin set. Source, tests, configuration, retention procedures and README remain pinned; all 331 executing inputs and the complete original 650-file frozen reconstruction remain checked. Frozen authorities, acceptance meanings and verification gates are unchanged. This permits honest later handoff/log updates without rewriting the original seal. Final behavioral curation/audit is still required.

## 2026-09-07 UTC — Preserve unborn legacy state and combine typed Git object reads

The new rollback fence must admit a real unborn legacy branch while still inspecting source publication reachable through any ref or reflog. An explicit HEAD commit peel plus rejection of any Git error/diagnostic closes the observed blob-HEAD gap; missing or corrupt branch/detached objects remain rejected. Observations stay local to each boundary, with no cached authority proof. Repeated native Git startup also caused original state deadlines to fail. Combine only the private commit type/content queries into one bounded batch response, checking exact object ID, type, byte length and framing before the existing commit/tree/lineage validation. Preserve every state entry, publication, mirror and hook fence and every original test/deadline. Real Git coverage includes Unicode contents and rejection of trees, tags and absent objects. The six-file 130-case run passes; broader verification remains required.

## 2026-09-07 UTC — Keep source QA and Docker qualification separately bounded

The original C3 30-minute lifecycle cannot contain all nine serial source suites: the actual fourth run expired during the controller suite. Preserve that failure and all original C3 limits. As in the protected workflow, run the complete unchanged source commands in a separate fresh owned Linux checkout with private namespaces and an eight-hour finite service; keep Docker endpoints and external interfaces inaccessible. Run actual Docker/OCI qualification separately under unchanged C3 at the exact same commit. Retained audits must bind both runtimes explicitly and cannot label namespace source checks as Docker host qualification. A later actual candidate still requires its own qualified sufficiently long finite host so the full 3900000ms partition allowance reaches the actual provider. No command, test, original lifecycle limit or acceptance meaning changes.

## 2026-09-06 UTC — Check pristine store content separately from allowed build output

Actual pinned Linux runs showed that pnpm 11.15.1's store status compares installed files with the unbuilt package index. It rejects esbuild's legitimate postinstall replacement even when the actual native bytes exactly match a normal frozen offline replay. Keep the store command mandatory, but execute it against a separate frozen offline unbuilt reference with scripts and side-effect cache disabled; separately compare the working packages with a normal frozen offline built reference. No esbuild-specific exception, ignored store failure, source-package edit, hardlink allowance or weaker graph comparison is permitted. The owned prototype passed the actual store command and all 192 graph entries through the existing production byte comparator. Dependency report v2 will bind both reference paths, command cwd and raw logs. Strict v1 support is limited to the recorded immutable prior inspector hash; a new implementation cannot downgrade to the old proof. The original native focused result and failed VMs retain their exact inputs and meanings.

## 2026-09-06 UTC — Bind retries before active intent and retain export history

The real before-intent regressions showed that replacing the first attempted intent on retry breaks the retained event hash chain. Retain exact planned intent bytes in the fsynced first attempt record, validate the complete chain, original review/lease and exact prior files, then require a fresh private review permit and real lease before publication. This prepared record grants no mutation permission. If recovery observes an already-durable exclusive intent whose creation event was interrupted, record intent-observed-durable under the actual recovery owner rather than fabricating the missing creation event. Evidence export keeps its original complete packet and receipt, while the transaction retains fresh recovery review/owner/trace. Fault hooks reach actual before/after fixed-file copying and preserve foreign bytes. Focused native source verification carries candidate-support with no qualifier dispatch; full invocation retains its separate qualifier identity and non-passing missing gates.

## 2026-09-06 UTC — Keep the approved source dependency command in tier dispatch

Actual candidate and milestone regression calls found a catalogue collision between the source floor's dependencies command and the legacy auxiliary of the same name. Only after exact source identity and complete floor validation, omit that legacy auxiliary and retain the approved verify:source-dependencies argv and source-dependencies-report requirement. All legacy auxiliary insertion and duplicate rejection remain intact; this is not generic command deduplication. The native integration harness now separates full/focused actual invocations, uses the production process supervisor and emits exact nested diagnostic bytes into retained test stdout. Its new test-only limits do not alter public verification or original publication deadlines. An unavailable invariant child remains non-passing even when the source authority checks pass.

## 2026-09-06 UTC — Validate implementation audit meanings through committed raw evidence

Nested receipt hashes establish byte bindings but cannot substitute for child report meaning. Before an actual source migration request, require the eight fixed producer executions and their raw argv, clean implementation identity, supervision, log sizes and ordered timing. Inspect static/graph/test/invariant/build reports against actual audited Git objects, including every root test file, original integrity IDs, complete nested receipts and a consumed archive matching the implementation payload. The eight-command audit's existing 90-minute supervisor deadline is distinct from the four candidate partitions' required 65-minute execution-provider limit. Neither supporting audit evidence nor synthetic fixtures confer qualification, approval or state adoption. Keep the reader pure and operation-local; the actual independent gateway review remains the private capability boundary.

## 2026-09-06 UTC — Keep source observations local to each checked boundary

The integrated packet exporter exposed three real deadline failures. Batch immutable Git objects only within a newly created reader for each inspection, return copied buffers and continue reobserving live canonical bytes. Observe commit/tree/attached branch together through actual Git, retaining branch validation. Factor publisher input validation from its complete lease/permit/input/lease boundary so packet export performs that boundary once. No permit, reader capability, stale live observation, deadline relaxation or weaker assertion is introduced. Use a literal MJS-to-TS import edge rather than hiding a dynamic import from the unchanged architecture checker. The complete original cases and two added real-Git regressions must pass before broader work resumes.

## 2026-09-06 UTC — Retain committed source publication without granting state adoption

Normal source consumers require one actual activation commit immediately after its immutable request, with all twelve outputs and the independently inspectable command-owned packet committed together. Retain original and fresh review evidence, actual lease-owner Git blobs, raw append-chain events and runtime observations. Validate the packet's complete inventory and immutable introduction/history. Later code fixes may change implementation files while the source authority and generated schedule remain exact; rollback to legacy requires an explicitly approved appended revision. Current state formats do not carry the new epoch, so fence legacy state operations instead of initializing or adopting state during publication.

Keep full source qualification NOT_READY until its authenticated producer and complete required observations exist. A fresh nonce and explicit source/fixture scope bind dispatch but cannot confer host qualification or readiness. The separately scoped source candidate retains the eleven-command floor and four original owner partitions. An implementation audit must inspect real raw command results, report semantics and consumed build evidence, beyond nested receipt hashes; that remaining implementation work precedes an actual request or SDK review.

For manual evidence, register one process lifecycle handler pair over all owned contexts, including finalized contexts. A later nonzero exit must still revoke earlier PASS receipts; an unfinished context must still fail. The new real child-process regression demonstrated the prior listener growth and retained exit/receipt semantics after the repair. Do not suppress listener warnings or remove finalized contexts from revocation tracking.

## 2026-09-06 UTC — Bound disposal of exact source-transition fixture roots

The real bb312f3 Linux controller failed teardown with ENOTEMPTY in a newly owned Git clone, without evidence identifying a background writer. Disable automatic Git maintenance/GC only in each disposable clone as a precaution. Retain the original fixture and CLI test bodies, assertions and deadlines. Cleanup accepts only exact canonical system-temporary mkdtemp roots or the two original UUID-named CLI output patterns under canonical controller artifacts, then uses Node's documented five retries at 25ms linear backoff. Persistent failures remain fatal; no shared configuration or production contract changes.

The initial guard overlooked the existing CLI output roots and caused two actual cleanup failures; retain that 30 PASS/2 FAIL run and correct only the guard. Do not change the suite or normalize the failure. The retained auditor compares complete original suite syntax trees and validates raw reports and every command-owned receipt. The predecessor R1 clean post-commit audit/focused/dependency/consumed-build observations remain separate from hosted outcomes. Keep the running bb312f3 Windows cohort until complete before any same-ref successor push.


## 2026-09-06 UTC — bind the package-runtime fixture to the observed installation store

The runtime probe claims to consume the CI-installed graph. Its offline fixture must therefore use the store recorded by that actual installation, rather than an implicit location selected in a temporary directory. Read/validate pinned pnpm metadata, require a canonical absolute v11 store, and pass --config.store-dir to both install and exec. Force a fixture-local empty implicit store to keep the observed missing-store boundary covered. Preserve original assertions, deadlines, copy/offline/frozen/ignore-scripts flags and safeAgentEnvironment. No production verification or shared configuration change is warranted by this fixture defect; a drive-specific explanation remains unproven by local observations.

## 2026-09-06 UTC — Reproduce fixed transition outputs before admitting publication

Use a strict twelve-file output allowlist and a canonical request-subject digest linking the new epoch ledger to real audited implementation and strict-ancestor snapshots. The separately committed request binds those output hashes and a fixed implementation-evidence path. It cannot supply arbitrary output bytes, file paths, approval flags or a weaker command floor. Inspect actual Git objects and reconstruct the full proposal in an owned temporary view; do not fabricate commits or copy source controller state. The read-only inspector is an immediate receipt-owning consumer, with publication, audit-authentication, review-authentication and completion flags false.

Normal consumers continue refusing source generations until complete review/publication validation exists. Reserved source commissioning/policy IDs must not fall through as generic adopter schedules. Preserve every old command and commissioning/amendment prefix; new source candidates retain invariants first, the real dependency/static/architecture/build floor and four unchanged canonical owner commands with their existing 65-minute binding.

The original adopter text scan can accidentally match milestone labels inside a valid opaque Git ID. Preserve its regex and all ordinary text/field checks, and independently bind the one excluded baseCommit value to actual Git HEAD^ and the producer's base identity. Do not change generated hashes, search for a favorable commit or change production generation to appease the test. Preserve the observed failure and original test bytes.

## 2026-09-06 UTC — Pin workspace package layout across sanitized child environments

Make enableGlobalVirtualStore explicit in the versioned source workspace, which the existing adopter distribution copies. Pinned pnpm 11.15.1 otherwise changes its default under CI, while the production safe environment deliberately removes CI. The real regression demonstrated a strict dependency-verification rejection after a CI installation. Preserve that rejection when configuration differs; do not disable verification or expand the environment allowlist. Test actual dependency consumption and unchanged module metadata across both child environments.

Give the four later host-discovery table rows stable descriptive labels and retain their exact prior/new observation mapping. Preserve the original parameters and assertion, and keep the strict exactly-once comparator unchanged. A bounded whole-file transformation plus real raw report comparison prevents a rename from hiding lost or altered acceptance. Original historical IDs remain unaffected, and the final candidate must still reconcile the complete historical/later universe.

## 2026-09-06 UTC — Separate source evidence decoding from qualification authority

Use explicit source aggregate 3.0.0 and tier 2.0.0 envelopes with trusted dispatch scope and separate source, fixture and qualifier identities. Refuse unknown or foreign scope before reading status, including nested exact closure. Preserve legacy aggregate 2.1.0, tier 1.2.0, command artifact validation and original diagnostics. Partial source evidence can be inspected only as NOT_READY; a source PASS requires future actual full-qualification authentication. No reader inspection activates authority, supplies independent review or replaces a missing producer.

Keep the approved source integrity inspection in the typed source-anchor module. The first placement introduced a real native Node import-resolution failure through contract-integrity.ts; restore that legacy module byte for byte and retain the failed evidence. Native node scripts/verify.mjs and generated adopters must remain executable without a TypeScript loader. Share native scope/registry metadata through the explicit distributed MJS dependency. Do not solve import failures by changing the public verifier command, original assertions or runtime pins.

## 2026-09-06 UTC — Preserve original controller boundaries with valid legacy fixture metadata

The strict authority publication reader exposed plain-text package/lock seeds in ten original test fixtures. Keep the production refusal intact and change only those fixture writes to parseable legacy JSON before their original Git commits and protected hashes are captured. Preserve absent optional manifests, all assertions, fault loops and original deadlines. An independent whole-file transformation check must prove the exact edit; correcting incidental fixture encoding does not change acceptance meaning.

Retain the failed exact C6a cohort, all five provider artifacts and the native reproduction. Separate raw test FAIL from the command wrapper's ERROR and independently validate the successful child receipts. A selective diagnostic with skipped cases cannot emit a complete-file PASS. Use the existing finite, qualified C3 VM route for the full real unit check of the exact fixture projection while retaining native outcomes. Host limits, timestamp checks, authority scope and source state remain unchanged. Pause and preserve unfinished C6b rather than mixing feature work into this repair; restore it after the verified commit and continue the full authorized request.

The first VM's full unit check passed every affected fixture case but failed the original omission test before its expected reduction. A stricter pnpm diagnostic exposed a CI-dependent enableGlobalVirtualStore mismatch across the unchanged sanitized child boundary; an explicit isolated configuration restored the intended semantic rejection. Pin that setting only in the next disposable guest account's pnpm configuration and retain before-configuration diagnostics. Do not broaden the production environment allowlist, disable dependency verification, automate a modules-purge confirmation, modify shared user configuration or relabel the failed VM. The original missing child diagnostics limit direct attribution until the fresh VM observation is collected.

## 2026-09-06 UTC — Fence publication before admitting a new authority generation

Use one native-Node-compatible MJS scope/pending reader across both the unchanged node scripts/verify.mjs entry point and the TS controller. Presence of an intent is refusal, including malformed and linked entries; unknown/mixed source signals cannot fall back to legacy. Recheck before state/ref publication and around provider execution. Exact approved-anchor inspection is read-only and cannot authorize activation. Keep a complete source projection refused until every committed generation/request/review consumer and the recoverable publisher are implemented. Retain original downstream/bootstrap behavior and ship the common runtime dependency explicitly.

Keep production timestamp rejection when a runtime's epoch clock moves backward. Native deadline diagnostics and two raw-passing WSL runs did not supply passing command receipts. The separate Python observer established real clock discontinuities, so use the existing bounded disposable C3 VM route for the complete supporting selection. Preserve its original host limits, original test deadlines and original measurement semantics; add only the fixed reader command and independent guest clock observer after the real OCI probe. Retain all failed attempts and distinguish this development projection from a clean committed candidate, native Windows qualification or any performance interpretation.

## 2026-09-06 UTC — Transport actual supporting Git objects without source refs

A published branch-only clone cannot depend on unpushed side branches for its retained audit. Retain exact original commit bytes and verify their Git IDs against the sealed record; reconstruct their original trees from the existing sealed patches in a temporary object cache. Expose that cache only to the unchanged auditor, then delete it and assert the source bindings remain unchanged. Do not manufacture new commit metadata, publish supporting refs, rewrite the sealed archive or adopt controller state. The wrapper and its independent retained follow-up audit remain supporting evidence; fresh clean post-commit observations are separately required.

## 2026-09-06 UTC — Package committed runtime bytes and retain the real consumer

Use an explicit portable TS/tsx payload and deterministic regular-file ustar/gzip archive, keeping exact source provenance inside the payload and wall-clock consumer telemetry outside it. Parse actual imports and model the generated scaffold overlay; shipped code may not resolve through source-only checkers. Reuse the existing clean-clone production build and its twice-checked output inventory. The declared source build's afterReport consumer independently inspects and retains the real archive, manifest, child receipt and detached generation output before cleanup. Preserve generic adopter build behavior and its original safety assertions.

Compare installed dependency bytes against a fresh frozen offline copy-mode reference in addition to exact runtime/lock/store checks. Normalize only a pnpm workspace alias whose parent, relative target and installed identity are verified; do not ignore version disagreements or package contents. The independent standard tar reader checks the actual archive format outside the JavaScript encoder/parser. This supporting single-build path expressly leaves full native/repeated build and inaccessible-source generation/commissioning qualification incomplete.

Keep universal adopter AGENTS bytes in a dedicated template so later source authority activation cannot leak source scope into generated projects. Retarget only the old undeclared-root build test's fixture, preserving its original assertions and deadline, because the approved source build makes permanent absence incorrect. Every old public argv, authority/commissioning record and readiness marker stays unchanged until the approved migration. Never promote these supporting receipts or synthetic output-retention fixtures into candidate 5(a)/5(b), source readiness or historical WP6 completion.

## 2026-09-06 UTC — Canonicalize owned discovery fixtures while preserving refusal of arbitrary aliases

The launch-free scanner must continue rejecting noncanonical paths before reading a possible installer or binary. A test's newly created directory is owned and may be resolved with realpath before constructing the input; arbitrary discovered launcher paths may not. Preserve the original forty host-discovery assertions and the production scanner verbatim. A deliberately aliased/link input must still be refused. Native Windows TEMP aliases reproduce the actual hosted issue and support the narrow fixture fix; they do not qualify native Windows controller/container workflows.

Keep the failed 827ebbf cohort and all five artifacts separately from the local correction and its later exact hosted cohort. Pause C5 without mixing its staged implementation into this repair. Ordinary source-control integration must restore every preserved C5 byte and continue the authorized prerequisites; no source-state initialization, authority activation or historical reinterpretation is permitted.

Record durable or costly-to-reverse decisions: date, decision, alternatives
considered, rationale, and affected files. Newest first.

## 2026-09-06 UTC — Inspect exact inert epoch objects without granting activation

Bind source snapshot inspection to the actual known maintainer/control-plane approval record and fixed approved source/legacy prefixes. Read exact committed Git blobs with a complete regular-file allowlist and preserve original legacy ancestry/bytes. The inspector accepts same-commit inspection only as explicitly non-ancestor evidence, with activationAuthorized and completionEligible always false. The later migration must separately require strict ancestry, a clean separately committed request, independent review, the existing lease, durable exclusive intent and coherent recoverable publication. No repository-authored approval flag, matching working bytes or fabricated future commit can replace those boundaries.

The immediate consumer is the receipt-owning inert-snapshot CLI; its committed objects become the later migration's actual ancestor. Keep this supporting inspection separate from active authority selection, which remains legacy until all compatible consumers and the complete approved transition are implemented. This is a scoped prerequisite, not authority activation or a stopping point for the authorized WP6e continuation.

## 2026-09-06 UTC — Qualify the disposable host separately from its OCI children

Use one task-local Ubuntu guest launched through the inspected/pinned C2 QEMU payload. A narrowly scoped root coordinator creates a transient resource-constrained unit; QEMU itself is UID/GID 65534 with only KVM group access, zero capabilities, no-new-privileges and seccomp. Do not change shared services, accounts/groups or device permissions, expose workstation mounts/credentials, or reuse the unintended LXD installation. The guest owns its package installation and Docker daemon. Outer host enforcement and inner OCI policy are separate independently checked records.

Capture actual QMP, process/cgroup/mount and guest boot observations before the fixed provider dispatch. Six small real kernel fault probes establish mechanisms; the actual QEMU readbacks establish its configured 4 GiB/no-swap, 200% CPU, 64-task, 16 GiB virtual disk/17 GiB file, output and 30-minute bounds. Explicitly cap QEMU's I/O pool at sixteen after its default pool exhausted the whole-unit task bound. Increase the finite provisioning disk only after retained Docker ENOSPC evidence, remove duplicated store contents, and keep every original OCI case/container limit unchanged. These limits qualify this job and do not pre-authorize a longer candidate.

The task-owned guest runs its trusted job in a separate bounded service with partial-write-safe channel framing, command heartbeats, bounded host observations, error transmission before disk writes and explicit export-failure handling. Attempt fourteen's actual failure and manually interrupted crash snapshot remain failed. Cleanup requires exact ownership, precise allowed entries, recorded process identity and whole-cgroup disappearance, plus an independent native observation. Missing early program/PID observations are disclosed; kernel-source inference about PID zero is not promoted to direct observation.

Keep reusable payloads and crash disks outside Git; seal selected raw evidence, exact supporting source patches and nineteen validated receipts. Reconstruct and independently audit those artifacts before and after commit. Supporting staged executions remain dirty/completion-ineligible even though the guest runtime source is a clean old-epoch commit. Do not relabel historical WP6e, count evidence-tamper tests as candidate 5(a)/5(b), infer Windows from WSL, activate authority from approval, or adopt source controller state. The next increment consumes this qualified Linux route while implementing compatible source verification prerequisites.

## 2026-09-06 UTC — Prove a network-disabled task-local VM lifecycle before host admission

Choose QEMU TCG with a signed Ubuntu cloud image for C2's bounded trusted diagnostic. The existing WSL user cannot use KVM and no qualified provider was discovered. Extract verified Debian payloads in a fresh task prefix without maintainer scripts; do not install a global provider, reuse the shared LXD service, mount a Docker socket, expose workstation directories or dispatch a source controller. Native Windows and the frozen Server 2022 reference remain distinct unsolved requirements.

Pin launcher/image bytes and the complete extracted-provider inventory outside the guest report. Use fixed VM argv, no NIC, an immutable backing image, fresh owned overlay/read-only seed, QMP observations, kernel/process evidence and a direct nonce-bound guest serial diagnostic. The final guest probe runs during cloud-init's boot stage; the earlier prefixed late-stage output caused a real timeout and remains failed. Keep resource/deadline restrictions and label guest settings separately from future host admission/cgroup/quota guarantees. A diagnostic PASS and an upstream signature do not authorize or qualify Docker-controller execution.

Cleanup requires the recorded owner and exact allowed entries after process exit, removes individual owned files without recursive deletion, and refuses foreign/linked/changed ownership input. Actual Linux probes exercise these boundaries and a separate native observer verifies the completed cleanup. Keep immutable inputs, outside sentinels, unsuccessful attempts and their provenance limits. Do not turn missing historical stderr into a fabricated raw artifact.

Docker's client/VM support and remote bind-mount semantics constrain native Windows options. A suitable dedicated Windows client with a supported Linux backend still needs its own authorized lifecycle and real executor proof; an arbitrary remote daemon lacks the existing executor's local-path transport/mapping. Server container/LCOW or WSL substitution does not close the native Windows/Server 2022 row. Preserve all gates and settled r2 scope while the next increment provisions and qualifies an actual disposable guest with compatible Docker/OCI inputs.
## 2026-09-05 — Inspect host launchers as data before executing capability queries

C1 follows a concrete discovery failure: codex.lab's /usr/sbin/lxc version query
triggered the LXD installer. Treat newly discovered Docker/VM launchers as data
first. Read bounded metadata/prefixes without invoking --version, an interpreter,
a shell alias or an installer; preserve earlier PATH candidates and ambiguous
links/aliases instead of selecting a later apparently usable binary. Record
errors and missing prerequisites without promoting metadata into host support.

The standalone scanner is the smallest dependency-free unit that can run on the
native Windows process and both inspected Linux routes without copying a source
checkout or provisioning a provider. Its immediate consumer is an explicit
outer discovery command with a pinned scanner/source/run/nonce and independently
retained capture digest. Fixed-name PATH search is not universal shell command
resolution. A binary signature is only prefix evidence. The command's PASS
receipt attests completed observation/audit, while host qualification remains
NOT_READY and completion remains false. This does not implement the later
trusted disposable-host/admission protocol or grant maintainer approval.

Reject automatic provider installation, privileged nested Docker, socket mounts,
shared-workstation controller fallback, arbitrary remote context substitution
and WSL-as-Windows claims. Docker documents supported Windows client Desktop
routes but excludes Server 2022; a remote daemon's bind mounts address its own
filesystem. Native Windows routing and the frozen Server 2022 reference remain
real implementation/qualification work, not an authority reinterpretation.

Preserve the unintended remote installation and the failed concurrent partition
identity capture as actual events. Do not invent a configuration-unchanged claim
or delete remote package/service data to conceal the side effect. The serial
partition rerun resolves the check, but its initial cause remains unproven.
The full source gate, protected CI/candidate cadence, authority activation and
human gate are unchanged. A future increment must prove one disposable host
lifecycle/provenance route before expanding controller workflows.

## 2026-09-05 — Use contained planning and an externally pinned read-only input

The first B workflow uses public planning because that controller needs no Docker
control plane and can run within the qualified OCI restrictions. This conforms
to the approved contained-workflow route. It does not qualify a general host for
run/integration controllers, nor native Windows. Those prerequisites remain open.

Expose the existing CLI dispatch with a gateway dependency seam; keep the normal
CLI's real SDK default. A deterministic client supplies proposal responses
through the production SDK gateway adapter, while production code owns state,
policy and receipts. This supports reproducible mechanism qualification without
claiming live-agent/model resolution or token usage.

Authentication for this local dispatch is the trusted outer coordinator's
out-of-band envelope digest and complete expected binding. Neither a supplied
envelope nor candidate-authored files can grant coordinator/maintainer approval.
The coordinator obtains actual provider/container identity through its executor.
The contained consumer and independent outer auditor both inspect real
observations and producer-owned receipts. This does not establish a portable
signed remote-job protocol; remote host routing/identity remains future work.

Use one explicit /qualification-input read-only bind, limited to 256 files,
4 MiB, 512 entries and depth 16. Validate ordinary paths, links, content inventory
and external pins before and after execution; attest both intended and applied
mounts. Require trusted-controller dispatch and refuse local-runner fallback.
Commands without input retain exactly the original four mounts and unchanged
resource, network, user and privilege restrictions. Real EROFS and after-launch
mutation regressions exercise these boundaries.

Only finalized producer/input/consumer roots enter the immutable handoff
inventory. The first run's still-open stdout invalidated its broader snapshot;
the initial evidence and audit refusal remain retained. A fresh corrected run
proved the finalized boundary. The complete unchanged OCI matrix was rerun once
because the executor mount boundary changed. Source readiness and full-platform
qualification remain distinct, incomplete gates under the approved r2 scope.

## 2026-09-05 — Require retained raw OCI artifacts for the runtime foundation

The initial real WSL matrix reached all six required dispositions, yet its
normal aggregate's build and Vitest files disappeared during candidate
cleanup. A passing aggregate plus retained hashes cannot support independent
inspection of absent bytes. Keep that first run as incomplete evidence and
repair the matrix's retention boundary using the existing quota-enforcing,
link-rejecting, exclusive artifact publisher. Compare both source and retained
inventories to the executor's actual exported inventory before cleanup.

Preserve the fixture, cases, image recipe and production executor policy. The
repair changes only matrix evidence retention and adds three regressions in
the existing owner file. A second full OCI run is justified by the observed
defect; it is not an automatic full source/native-platform dispatch. Record
both costs, immutable image reuse, raw artifacts and negative audit outcomes.

Use the package-declared pnpm executable and a persistent task-local Linux
directory; /tmp setup evidence was unavailable after a WSL restart. Preserve
the existing engine and normally resolved Linux store, whose candidate mount
is read-only. A working local WSL runtime is not native Windows proof or an
authorization to run untrusted controllers on a personal host. Disposable
qualification-host suitability and authenticated read-only producer/consumer
evidence delivery still need their own real workflow increment.

The source build remains truthfully NOT_READY under the unchanged legacy
package declaration. Source release build implementation, authority activation,
exact readiness, independent reconciliation and the separate live human gate
remain outside this runtime foundation. Its frozen staged tree and actual
patch are retained explicitly; later documentation cannot promote it to an
exact committed no-argument source-readiness result.


## 2026-09-05 — Approve r2 scope and preserve a bounded implementation handoff

The maintainer explicitly approved the immediately preceding ORCH-AUTH-01 r2
review target with “Proposal approved.” Its normative digest is
`53d38a2c2038cd9c5ffc240275043709d23dd33a81237e3d12018a38a8378108`;
its reviewed package integrity digest is
`2db01416302e24f3bda9d1991f44a1ac05b8ef5fad70b09c18bc4f037d267a2c`.
The approval record binds the actual task/turn and exact inventory. The
agent transcribes supplied human authority; it does not invent approval,
assert a cryptographic signature or mark the separate human product gate
passed. The maintainer/control-plane validation and all approved transition
safeguards still apply to the later migration.

Keep the sealed proposal bytes unchanged and record approval separately so
historical hashes remain reproducible. Store the sealed packages as Git
binary assets to prevent text normalization and automatic merging; use their
exact manifests and supplied authority diff for review. The initial import
whitespace diagnostics are retained and all new editable files keep normal
checks. This changes no production formatting or acceptance rule. Conforming implementation notes can
evolve without renewed approval of unchanged normative outcomes, public
contracts and safety/cadence boundaries. This does not allow a plan or
candidate record to redefine authority. Root authority and commissioning
remain on their coherent legacy generation until compatible readers,
strict-ancestor inert snapshots and recoverable publication are implemented.

The user highlighted heavy verification costs and then steered to a fresh
session. First prove the existing WSL engine through the real OCI fixture;
next prove one public workflow/rejection and trusted evidence handoff before
expanding the full qualification matrix. Candidate-support evidence does not
replace required exact closure, native Windows qualification or live human
acceptance. No new per-commit full-release trigger or CI change is introduced.

Archive the old WP6e living plan byte-for-byte, preserve all historical logs
and evidence, and use the current plan plus the handoff guide as the next
session's operational entry point. The source remains e590e38 plus a
record-only handoff commit; no controller state is initialized/adopted. WP6e
and WP6f retain their original incomplete/provenance boundaries.

## 2026-09-05 — Preserve policy provenance in historical test fixtures

The active v2 suite exposed fourteen historical/generic tests that loaded a
legacy manifest with the live policy. Their setup now reads the original v1
policy from the same committed commissioning anchor used by generation
compatibility tests. Existing assertions, identities, and legacy meanings
remain intact; the active-source test keeps the actual live pair. This is a
fixture correction within the coherent activation, not a relaxation of the
production rule rejecting mixed source generations. The repaired active
generation passes the complete local broad suite and independent receipt
audit. The candidate execution and fail-closed tier gates remain separate
acceptance obligations; neither hosted controller success nor shadow
evidence may replace them. WP6f owns any later performance interpretation.

## 2026-09-04 — WP6e corrected source generation and audited reversal boundary

The formatted request was applied through the real CLI from clean repair
commit `b03a6cd`; both publication validation and the existing format
command passed. All three context comparisons retain their complete non-test
command definitions, and iteration/periodic projections remain identical.
The source v2 schedule and scope policy are published together with the
generated manifest and Git-anchored ledger. Generated adopters, exact
closure, existing scripts, the workflow, and all frozen measurement
identities remain unchanged.

The source request becomes stale after application. An interrupted
invocation resumes its exact committed request; reversal requires a new
request matching the current hashes and chain tip and containing the
original v1 input/policy bytes. Formatting alone cannot create another
generation. The first failed uncommitted application remains diagnostic
evidence outside this source history. No acceptance or readiness gate is
inferred from these successful publication, formatting, or projection
checks. Full-candidate prerequisites remain an explicit unresolved scope
conflict; WP6f interpretation is deferred.

## 2026-09-04 — WP6e source formatting follows the committed descriptor

An actual v2 publication passed semantic/provenance checks but failed the
existing format command because proposed input/policy text came from plain
`JSON.stringify`. Preserve that failed application. Prepare the descriptor
using the pinned repository JSON formatter; the tool continues to publish
its exact committed text. V2 approval compares every parsed input/policy field
to the reviewed transformation and requires the same canonical manifest.
Whitespace and key layout have no authority to alter a value. Hashes and
descriptor/provenance validation still bind exact stored text, including each
historical generation. Original v1 reversal remains byte-exact.

This keeps formatting out of the synchronous production audit and avoids a
second formatter implementation. No formatter rule, test, package script,
active file, protected authority, or acceptance criterion is relaxed. The
new regression applies formatted text, checks the real published files with
the installed formatter, compares parsed content, commits the coherent
generation, and invokes commissioning Doctor again. Publication and ledger validation also
reject semantically identical generations, so formatting-only requests cannot
create no-op entries. A separate regression exercises that rejected request.

## 2026-09-04 — WP6e compatible amendment generation and recovery implementation

The source amendment accepts only the original Git-anchored v1 bytes or the
reviewed deterministic v2 transformation. Its separately committed descriptor
supplies exact input and policy text, prior hashes, chain tip, and the approved
decision heading. The manifest always comes from `manifestFromInput`; there is
no descriptor field for an output manifest or arbitrary publication paths.
The original source commissioning is anchored to commit
`345591818b220964618dc4e80cce3c0e0213783c`. Every ledger entry binds its
descriptor in the invocation commit, prior/next bytes and hashes, ordered tier
projections, and the preceding entry. Validation checks all committed prefixes,
including deletion history. A reverse amendment restores the anchor's exact
input/policy bytes and extends the ledger.

Publication uses the existing controller mutation lease and an exclusive,
fsynced intent containing all staged bytes before any active replacement.
Each replacement rechecks HEAD, branch, index, descriptor, intent, and all
prior/new file states. Doctor, active manifest consumers, and ordinary
controller mutation leases reject a pending operation. Recovery preserves
foreign edits and accepts only the same committed request and invocation.
The lease does not adopt controller state or commit any Git work. Generated
adopters retain their separate commissioning input and bootstrap schedule.

The planner keeps v1 compatible, exposes absent legacy commands as auxiliary
checks, and validates v2's complete owner definitions before subsumption.
Partitions require the original invariant package entry point, canonical
invariant command, and production ownership registry child. Only those four
canonical owner commands receive 3,900,000 ms; unrelated focused commands
retain 1,200,000 ms. The selected bound is retained in tier records. Historical
records remain readable; partition records require the canonical timeout/argv
binding. The policy matrix remains shadow-only with graduation deferred.

Historical measurement revalidation now reproduces retained candidate/source
identity from all lane artifacts instead of binding those artifacts to the
validating checkout. An explicit source constraint still applies. Creation
continues to bind the current clean exact-runtime candidate, and the new
validation receipt identifies the checkout that performed the reproduction.
The measurement catalogue, lane deadlines, statistics implementation, and
measurement schemas are unchanged. The retained matrix still requires an
executed CLI revalidation after the compatible commit; no such outcome is
asserted here.

Focused regressions cover clean v1, v2 and reverse publication, every
publication boundary, concurrent starts, foreign edits, descriptor/Git drift,
ledger deletion/truncation, canonical prerequisites, schedule/policy mapping,
timeouts at the provider boundary, and historical statistics expectations.
The complete corrected broad cohort passed and its source-bound receipt audit
is recorded in the autonomy log. The actual source amendment remains pending. The candidate prerequisite conflict remains open:
the plan requires candidate PASS while retaining project-owned placeholder
scripts and an undeclared production build. This decision does not remove
those checks or amend that acceptance requirement.

## 2026-09-04 — WP6e canonical schedule projection and diagnostic compatibility

**Decision.** Expose a versioned, read-only projection of the existing
production tier planner before implementing the amendment operation.
`verification-schedule-projection.v1` includes the tier, ordered check IDs,
ordered command argv and expected artifact kinds, the existing focused
command count, and exact-closure inclusion. The exact closure is represented
as the final literal `pnpm verify` command, with no focused-command artifact
kinds, and is excluded from the focused count. Canonical comparisons preserve
array order and omit candidate, policy, and timestamp metadata. Callers must
compare projections from the same changed-path context.

The runtime validator rejects unknown fields, malformed definitions,
duplicates, inconsistent IDs/order/counts, and altered closure semantics.
The published Draft 2020-12 schema checks structural constraints; runtime
validation additionally checks relationships across arrays and counts. The
test-only schema evaluator now implements `prefixItems` and validates its
prefix/tail behavior, while continuing to reject unsupported keywords and
malformed schemas. This addresses an observed unsupported-keyword failure
without loosening the projection schema.

**Compatibility.** The commissioning diagnostic becomes
`loop-commissioning-doctor.v2`. Lifecycle Doctor and Status retain their
outer versions and propagate the richer, explicitly versioned nested
projections. Generated adopters receive the same projection schema through
the runtime-file allowlist; a packaging regression validates its exact bytes
and all four tier projections. The initial commissioning result and its
one-shot publication behavior remain intact. This diagnostic version does
not activate the proposed source schedule or scope-policy v2.

**Alternatives and scope.** Counts alone cannot prove an ordered schedule
diff. Comparing complete tier results would couple a schedule comparison to
unrelated candidate identity and policy metadata. Sorting command arrays
would erase execution-order changes. The separate projection avoids those
problems and follows the actual production planner. The 19 new regression
identities belong to the existing controller owner; the canonical file-count
assertions increase by one without changing the owner set. The active
commissioning input, policy, manifest, package scripts, protected workflow,
measurement identities, and frozen authorities are preserved. Descriptor,
anchored amendment history, recoverable publication, and schedule cutover
remain subsequent WP6e work.


## 2026-09-04 — WP6e recomposition direction and transition requirements approved

**Decision and authority.** The maintainer approved the reviewed WP6e
recommendation: commission the four canonical owner partitions in candidate
and milestone; retain the legacy scripts as diagnostic, shadow, measurement,
and hosted entry points; and apply the schedule through an audited amendment.
The active plan records the implementation requirements below. Its former
routine-confirmation pause is removed in accordance with the autonomous
decision boundary in `AGENTS.md`. This approval establishes direction; all
baseline, implementation, execution, and hosted acceptance evidence remains
to be produced.

The 2026-08-15 one-shot commissioning decision remains the rule for initial
creation. This decision adds a distinct, controlled amendment path for an
existing commissioning, superseding the earlier absence of such a path.
Commissioning identity, frozen authorities, the protected exact-runtime
workflow, exact no-argument verification, and measurement identities retain
their existing constraints. Historical decisions are preserved as written.

**Schedule and policy.** Candidate and milestone commission
`controller-runtime`, `repository-tooling`, `adopter-template`, and
`trusted-container-fixture` exactly once as focused partition commands. V2
has no tiered legacy test command. Legacy IDs remain resolvable as auxiliary
checks only when absent from the active manifest, preserving the existing
duplicate-ID rejection and valid v1/historical catalogues.

Scope-policy v2 uses explicit owner mappings: `test-unit` becomes controller,
repository, and adopter; `test-orchestrator` becomes controller and adopter;
fast becomes the three root owners; migrations becomes controller. The plan
enumerates every trigger and workspace row and requires a discovery-superset
proof. Current migration rows also require full unit, so their union does not
expand; the two fast-only direct mappings add the 32 baseline migration
tests. The OCI owner is a required commissioned command and is recommended by
existing broad/fail-broad augmentation; it is not silently added to every
direct legacy replacement. Source-v2 broad recommendation also replaces the
hard-coded `test-unit` addition with the three root owners. V1/historical
behavior and deferred shadow-only policy remain separately testable.

**Prerequisite and timeout.** Candidate/milestone partition schedules require
the canonical invariant command first and the production ownership child in
its registry. Check those premises before applying subsumption; then stop
execution on any prerequisite failure. Validate complete generation,
partition IDs, owner argv, artifact kinds, and tier tags rather than accepting
the presence of four arbitrary names. Each canonical partition receives a
65-minute outer tier timeout, containing its existing 60-minute inner limit
plus setup/publication. Other focused tier commands retain 20 minutes; exact,
measurement, and individual test/hook deadlines retain their existing values.
Test the timeout actually supplied to the execution provider.

**Publication and audit.** A separately committed, strict amendment
descriptor supplies proposed input/policy bytes, expected current hashes and
chain tip, and this decision heading. The active files remain valid v1 while
compatible infrastructure and v1/v2-aware guards land. A clean target-branch
invocation validates current and proposed generations, renders the manifest
through `manifestFromInput`, stages exact bytes, and records recovery intent
before replacing any active file. Input, policy, manifest, and amendment
record form one recoverable operation; incomplete generations are refused
by doctor and consumers. Resume only recorded prior/new states and preserve
foreign changes. Publish no broken intermediate commit and perform no
implicit Git or controller-state adoption.

The append-only amendment chain binds prior/new hashes for all three active
files, descriptor identity, previous entry hash, invocation HEAD/tree,
ordered tier plans/diff, and decision heading. Anchor its initial generation
to real commissioned Git blobs, validate its committed prefix, and compare
the live files with its tip. Tests cover individual/coordinated edits,
ledger deletion or truncation, publication crashes, concurrent attempts,
and recovery. Hashes establish repository consistency and audit continuity;
they do not independently authenticate an actor capable of rewriting all
repository history. Reversal restores prior input and policy, regenerates
the manifest, and appends another entry; it never truncates the ledger.

**Evidence corrections.** Current doctor tier summaries expose counts but
not ordered check IDs. Capture a baseline through the production planner
and extend the diagnostic before depending on exact per-tier diffs. Compare
identical changed-path contexts and command projections; metadata schemas
and broad recommendations can differ. Historical 708-root/709-with-OCI
counts are baseline observations. New WP6e regressions must be classified
and their added identities enumerated; final counts must not be forced back
to the baseline. Exactly-once evidence is scoped to the four partition
reports, with prerequisite invariant executions accounted separately.

The repository still has candidate-facing dependencies/architecture
placeholders and no production-build declaration. The readiness unit stage
is `unit-domain` and also requests `test:domain`. These inherited conditions
must be preflighted and reported accurately; a root-unit report or hosted
controller pass cannot establish a candidate or complete unit-domain PASS.
They do not authorize skipped checks, product implementation outside WP6e,
or any reduction of the frozen acceptance contract.

**Alternatives rejected.** A repeated maintainer-confirmation gate for
routine reversible engineering; an unconditional v2 ownership expectation
before v2 publication; an input-only commit that breaks doctor; coordinated
manual input/manifest edits validated only against each other; independent
file replacements described as a transaction without recovery; a blanket
four-owner policy replacement; widening all deadlines; and relying on a
possibly omitted invariant to establish its own presence. Each either
conflicts with the autonomous contract or leaves a concrete validation gap.

**Affected files and next action.** This decision updates only
`.agent/current-exec-plan.md`, this log, and `docs/autonomy-log.md`.
Implementation has not started. Pin Step 0 in a clean short-root clone of
`ac4e9a2`, beginning with candidate prerequisites and exact planner
projections, then implement the compatible amendment infrastructure.

## 2026-08-31 — WP6d closes on reproduced evidence without interpretation

**Decision.** Accept WP6d's hosted execution surface only after all ten
cold/warm pair jobs and both statistics jobs pass, every retained archive is
downloaded, every lane/receipt/summary/reduction and cold/warm binding is
revalidated, and each retained statistics record is reproduced with the
production validator from the workflow's exact merged
`platform/ordinal/...` artifact topology. Archive-name wrapper directories are
transport metadata, not part of the statistics input topology. The resulting
records remain descriptive and non-semantic; only intended WP6e may consume
them for manifest/tier/slow-registry recomposition, and only intended WP6f may
interpret them or make a go/no-go decision.

**Why.** Run `33402460152` supplied the required five pairs per platform and
passed its producing validators. Independent download validation additionally
proved exact candidate/source identity, dispositions, hashes, pair bindings,
and statistics reproduction. A first local assembly retained archive-name
wrappers and correctly failed canonical reproduction because relative input
paths no longer matched the producer's `merge-multiple: true` topology;
reconstructing that declared topology passed without changing evidence. The
alternatives were rejected: treating transport wrapper names as semantic,
editing a retained record to fit a new path, accepting workflow exit codes
without reproduction, interpreting timings inside WP6d, or allowing this lane
to authorize cutover/readiness.

**Affected files.** The active execution plan, autonomy and decision records,
and external retained evidence for runs `33397675209` and `33402460152`.
Production source, the protected exact-runtime workflow, the commissioned
benchmark, frozen authorities, and successor ownership remain unchanged.

## 2026-08-31 — Transaction recovery owns completed-worker identity, not OS liveness

**Decision.** The candidate-prepare hard-loss matrix may substitute a dead
process observation only for the exact PIDs of fault workers whose
point-specific crash marker and exit status 86 have both been verified in that
test. Platform-specific parsing recognizes only the production observer's
exact PowerShell or `ps` invocation; every unrelated command and every
unverified PID delegates to the real bounded-spawn implementation. The
dedicated controller-lease suite remains the authority for real live-owner,
unavailable-observation, matching-incarnation, and reused-PID behavior.

**Why.** The transaction matrix proves checkpoint convergence after a known
worker crash; marker plus exit-status evidence already proves that worker
incarnation completed. Asking the host to establish liveness again introduces
a separate timing race: Windows can retain or reuse the numeric PID within the
production ten-second start-time tolerance. Protected run `33370485616`
demonstrated that race while a direct rerun passed the same transaction rows.
Changing the production tolerance or fail-closed rule would weaken safety, and
raising test timeouts would not make PID identity deterministic. Limiting the
substitution to verified completed workers keeps both responsibilities explicit
and independently covered.

**Affected files.** `candidate-prepare-baseline.test.ts`, the active execution
plan, and autonomy evidence records. `controller-lease.ts`, production
liveness behavior, frozen authorities, and the protected exact-runtime
workflow are unchanged.

## 2026-08-31 — Lease verification separates probe availability from semantics

**Decision.** Keep the production process-incarnation observer, its five-second
bound, and its fail-closed `unavailable` result unchanged. The external-process
lease regression delegates its first observation to the real platform helper,
then controls only subsequent observer results at the existing bounded-spawn
boundary. It proves four distinct cases in one live process lifetime: the real
probe cannot permit theft, an unavailable observation blocks, an alive matching
start time blocks, and an alive mismatched start time alone permits exact-old
recovery. Separately, the candidate-prepare baseline's real recursive
`afterEach` cleanup has a 120-second hook budget so Vitest can contain the
already-bounded cleanup it invokes.

**Why.** Hosted measurement run `33353378514` showed that PowerShell process
identity can be unavailable in every Windows measured lane even though the
same integration succeeds outside the measurement preload. Unavailability is
an intentional safe production outcome, so requiring availability made test
success depend on host timing rather than lease semantics. Raising the
production timeout would change controller failure latency without guaranteeing
availability; treating unavailable as stale could steal a live lease; skipping
or conditionally weakening the test would remove required coverage. The broad
unit gate also proved that a default 10-second hook budget can expire while the
hard-loss matrix's repository deletion continues and completes successfully.
Giving that cleanup an explicit containing budget changes neither assertions
nor product behavior.

**Affected files.** `controller-lease.test.ts`,
`candidate-prepare-baseline.test.ts`, the active execution plan, and autonomy
evidence records. `controller-lease.ts`, production command behavior, frozen
authorities, and the protected exact-runtime workflow are unchanged.

## 2026-08-30 — Lane dependency identity uses the installed virtual-store lock

**Decision.** Measurement-lane schema `1.1.0` adds the regular-file identity
of `node_modules/.pnpm/lock.yaml` as `virtualStoreLockfile`. Cold and warm
pairing requires byte-equal root `pnpm-lock.yaml` and installed virtual-store
lock identities in the same repository path. The raw
`node_modules/.modules.yaml` identity remains in every lane record for audit,
but its full bytes are not a cold/warm equality operand. A changed
virtual-store lock fails pairing before warm child execution. The protocol ID,
command surface, classification definitions, receipt/summary/reduction
validation, and non-semantic authority flags are unchanged.

**Correction to the preceding lane decision.** The earlier decision called a
full modules-manifest hash part of the cold/warm dependency-tree binding.
Hosted matrix run 33326405457 proved that interpretation was not executable:
all seven Linux cold commands passed, then the warm runner rejected the same
workspace before running a child because ordinary pinned pnpm execution had
rewritten `.modules.yaml`. That file includes operational `prunedAt`, store
path, virtual-store path, and ignored-build bookkeeping; byte drift is not
installed graph drift. Historical `1.0.0` records remain unchanged evidence of
what they observed, but the repeated matrix accepts only the corrected `1.1.0`
shape.

**Why.** The root lock identifies the resolved graph and the virtual-store lock
proves that graph was materialized in the installed workspace. Those files are
stable across ordinary test-script invocations, while retaining the raw
modules manifest preserves useful environment metadata without turning
pnpm's volatile housekeeping into a false dependency mismatch. Alternatives
rejected: weakening all dependency checks to the root lock alone, stripping
undocumented keys from `.modules.yaml`, treating the failed warm start as a
flake, reinstalling between cold and warm, or allowing warm execution after a
virtual-store-lock mutation.

**Affected files.** Measurement-lane runtime, schema and regression fixtures;
statistics fixtures; active plan and evidence records. Frozen authorities, the
protected exact-runtime workflow, measured commands, and statistics semantics
are unchanged.

## 2026-08-30 — WP6 statistics are exact five-pair descriptive records

**Decision.** The hosted measurement workflow is manual-dispatch only and
shards one cold/warm pair into each of ten isolated jobs: five ordinals on
`ubuntu-24.04` and five on `windows-2022`. Each job checks out the exact
candidate, performs one fresh frozen copy-mode install, executes all seven
canonical measured commands in its cold lane, and then immediately executes
the same commands in the paired warm lane without changing workspace or
dependency state. Pair jobs may run concurrently; the two lanes within a pair
are strictly ordered. A separate per-platform job downloads all five pairs and
produces one statistics record.

The statistics producer recursively rejects symlinked inputs, independently
validates every lane, child receipt, compact summary, reduction, and copied
cold record, and requires exactly ten records: unique cold/warm ordinals 1–5,
unique lane-run IDs, five distinct declared job workspaces, equal clean
candidate and hosted source context, one operating system, the exact command
catalogue/selection, and valid cold/warm hash binding. For every command and
classification it reports exact integer minimum, maximum, range, median, and
median absolute deviation for wall/setup/Git/startup/test-body duration, total
CPU, peak RSS, and test counts. Missing required measurements fail the
statistics command; values never set thresholds, compare cold with warm, alter
test success, make a benchmark claim, or authorize cutover. The retained
statistics record is content-hashed and accepted only when a fresh validator
reproduces it byte-semantically from the lane artifacts.

**Why.** Isolating each pair gives every cold repetition a real hosted-job
checkout/install boundary while keeping its warm counterpart in the one
workspace it is permitted to reuse. Sharding keeps the long Windows command
surface within the six-hour job ceiling without weakening or omitting any
measured command. Integer medians and median absolute deviations over five
samples are deterministic and avoid floating-point or performance-judgment
semantics. Alternatives rejected: push/schedule triggers, reusing one checkout
for multiple cold ordinals, running warm in another job, relying on archive or
record hashes without revalidating children, averaging durations, comparing
cold/warm values, thresholds, changing `benchmark.ts`, or modifying the
protected exact-runtime workflow.

**Affected files.** The additive statistics producer, CLI, JSON Schema and
regressions; the manual-dispatch measurement workflow; root package script;
ownership catalogue/count; and adopter-package exclusions. The commissioned
manifest, tiers, slow registry, `benchmark.ts`, frozen authorities, and
`.github/workflows/exact-runtime-ci.yml` remain unchanged.

## 2026-08-30 — WP6 measurement lanes are paired, non-semantic evidence runs

**Decision.** A measurement-lane invocation executes a canonical selection
from seven existing measured commands and emits one strict
`milestone-loop-wp6-measurement-lane.v1` record plus the existing deterministic
test-run reduction. The record binds the clean commit/tree, exact Node and
pnpm versions, platform, hosted-job provenance, catalogue and selection
hashes, ordinal, child receipt/summary identities, reduction identity, and
the installed lockfile/modules-manifest hashes. Cold means the first measured
invocation in a fresh hosted-job checkout after the declared frozen install;
warm means the immediately following invocation in that same workspace and
dependency tree. OS caches are explicitly uncontrolled in both cases.

Warm execution independently revalidates the complete cold artifact root,
copies and hash-binds the cold record, and requires equal ordinal, workspace,
dependency state, command set, candidate, platform, and hosted-job context.
Every child must pass its existing command-owned receipt contract and emit
exactly one strict compact summary; the runner rereads clean candidate/runtime
identity after every command, reproduces its reduction, and fails before a
lane record or PASS receipt on missing, stale, contradictory, or drifted
evidence. The lane's permanent flags say it changes no test success,
authorizes no cutover, and makes no benchmark claim.

**Why.** The hosted matrix needs reproducible descriptive inputs without
creating a second test-success authority or implying cache states the runner
cannot prove. Pairing within one job gives the warm classification an
inspectable workspace boundary, while one fresh job per cold repetition makes
the cold declaration executable. Alternatives rejected: treating the OS
cache as cold/warm, comparing or thresholding in the runner, consuming raw
reports without receipt validation, trusting a cold record without its child
artifacts, permitting dirty candidates, or adding this WP6-only tooling to
the generated adopter runtime.

**Affected files.** The additive measurement-lane runner, CLI, JSON Schema,
tests, package script, ownership catalogue/count, and adopter-package source
exclusions. The active manifest, tiers, slow registry, `benchmark.ts`,
verification scripts, frozen authorities, and protected exact-runtime
workflow are unchanged.

## 2026-08-29 — Measurement v1.0.0 runtime acceptance is producer-coherent

**Decision.** Keep `milestone-loop-test-run-measurement.v1` summary and
reduction `schemaVersion: "1.0.0"` and their existing JSON shapes, while
tightening the authoritative runtime validators to reject values the genuine
producer cannot coherently emit. Measured wall/setup/startup/test-body
durations require a positive sample count. Measured Git time may have zero
samples only at zero nanoseconds. An unavailable preload probe has zero
synchronous launches and cannot support measured Git/startup/test-body/CPU/RSS
observations. Measured CPU and RSS process coverage equals the probe record
count. The producer now withholds those fine-grained observations when the
probe set is unavailable, and its boundary text states that completeness rule.

Reduction disposition rows must reconcile by availability with their declared
counters and `inputCount`. Zero-measured duration and CPU aggregates must be
zero, and only partition inputs have non-null owners. These relational checks
remain runtime acceptance because the unchanged JSON Schemas describe the
wire shape, not every cross-field invariant. The shared shadow finalizer owns
semantic comparison, final candidate check, summary validation, reduction,
proof publication, and the receipt decision for both production execution and
the test-only omission mutation.

**Why.** The prior validators admitted internally impossible combinations even
when artifact bytes and content hashes were self-consistent. That contradicted
the intended fail-closed claim. This is a validation bug fix, not a new wire
format: no field, enum, identifier, unit, artifact kind, or producer version
changes, and all eight retained candidate-Q summaries plus their retained
reduction validate and reproduce byte-semantically under the tighter rules.
Alternatives rejected: bumping the version for an unchanged shape, preserving
permissive acceptance for compatibility with impossible values, inferring
missing metrics as zero, weakening validation to preserve a bad artifact, or
letting the omission CLI maintain a second receipt-decision path.

**Affected files.** `test-run-summary.ts` and its contract regressions;
`test-partitions.ts` and its omission/finalization regressions; this decision,
the corrective autonomy record, and the active WP6d plan. Frozen authorities,
test-success meaning, the generic manifest/tiers/slow registry,
`benchmark.ts`, and `exact-runtime-ci.yml` are unchanged.

## 2026-08-29 — Same-host controller liveness is PID plus incarnation

**Decision.** A live PID is the recorded controller only when its observed
process start time matches the lease's `processStartedAt` within the existing
tolerance. This comparison applies to every same-host owner, not only a stale
owner whose PID happens to equal the acquiring process PID. Windows uses a
bounded, noninteractive Windows PowerShell `Get-Process` query; other supported
hosts use bounded `ps` under the C locale. If the occupant disappeared, the
lease is stale. If the start times differ, the PID was reused and the lease is
stale. If start-time observation is unavailable, ownership remains live and
acquisition fails closed. Git expected-old ref publication and exact-token
release remain the ownership authority.

**Why.** A hard-loss process leaves its owner blob by design. `kill(pid, 0)`
proves only that some current process has the number, and the clean WP6 shadow
captured frequent Windows PID reuse while exercising thousands of Git
processes. Treating a replacement process as the controller produced a false
live-owner block. The prior special case already recorded start time to handle
the acquiring process's own reused PID but failed to apply the discriminator
to every other PID. Alternatives rejected: retrying or sleeping around the
race, weakening live-owner exclusion, deleting a lease because it is old,
test-only serialization, or treating the failed shadow as flaky/pass. The
regression first refuses a genuine external live owner with a matching start
time, then reuses that still-live PID with an old recorded incarnation and
requires safe expected-old recovery.

**Affected files.** `controller-lease.ts`, its focused regression, and the
active plan. Lease schema, Git ref protocol, host-instance boundary, status/
doctor contracts, product scope, and immutable acceptance are unchanged.

## 2026-08-29 — Non-semantic compact summaries and summary-only reduction (intended WP6b)

**Decision.** Protocol `milestone-loop-test-run-measurement.v1` defines strict
version `1.0.0` per-run summaries and deterministic reductions. Each measured
legacy or owner command emits exactly one receipt-owned summary binding its
run/stage/command/role/owner, exact candidate identity, platform/runtime,
timestamps, report set, counts, units, boundary descriptions, and explicit
availability for wall, setup, Git-fixture, process-startup, test-body, CPU, and
peak-RSS measurements. A command-scoped preload probe observes Node processes;
Git time is summed child-call elapsed time, startup is measured through
`spawn` handle return (with synchronous launches counted separately), CPU is
summed over published process records, and peak RSS is the maximum individual
instrumented-process peak. None of these intervals is assumed additive.

The shadow reducer reads only validated receipt-bound summaries, never raw
reports or logs. It requires the exact expected identity set and candidate,
sorts by stage/command/run identity, rejects missing/unexpected/duplicate,
malformed, contradictory, stale, or mismatched inputs, and hash-binds both the
input set and canonical output. Missing observation is represented only by an
explicit `unavailable` or `not-applicable` disposition and reason; it is never
zero-filled. A persistent incomplete probe record makes the affected process
metrics unavailable after a bounded atomic-rename quiescence window but does
not rewrite a passing/failing test disposition. Summary and reduction flags
permanently state that the evidence changes no test success, authorizes no
cutover, and makes no benchmark claim.

The semantic shadow proof remains independently raw-report based. It now has
separate missing and unexpected semantic-ID mutations plus a real executed
fixture omission that must fail without a PASS receipt and retain the omitted
identity. Summary evidence supplements but cannot replace ownership,
disjoint-union, raw-disposition, or semantic-equivalence proof.

**Crosswalk and sequencing.** Historical repository “WP6b” is the
owner-derived partition/shadow package and maps to intended **WP6c**. Intended
WP6a is inventory, WP6b is this compact-summary/instrumentation package, WP6c
is ownership/shadow, WP6d is benchmark CI, WP6e is manifest/tier
recomposition, and WP6f is measurement go/no-go. Historical records and
evidence identities are not renamed. The commissioned legacy schedule remains
authoritative through WP6d; this decision does not edit the active manifest,
workflow commands, slow registry, tiers, or `benchmark.ts` semantics.

**Why.** Existing receipts proved execution but could not support comparable
phase/resource analysis, and consuming raw reports in a later benchmark lane
would couple measurement to large format-specific evidence. Strict compact
artifacts provide a small independently validated input while retaining raw
evidence for semantic truth. Alternatives rejected: wall-time-only records,
inferring setup/body/resource fields, process-tree RSS sums mislabeled as a
peak, silently dropping incomplete probes, reading raw reports in the reducer,
allowing summary absence to pass, changing test success from metrics, running
the Windows/Linux matrix in this increment, or recomposing tiers before WP6d
evidence exists.

**Affected files.** New summary/reduction runtime, preload probe, JSON schemas,
and regressions; evidence, invariant, process-supervision, owner/shadow, and
fixture-dependency integration; ownership catalogue; operator/contract docs;
and active plan/log records. Frozen authority and product behavior are
unchanged.

## 2026-08-26 — Exact durable citations and two-identity closeout evidence

**Decision.** A tracked durable citation exists only when tracked bytes contain
the exact unique evidence manifest ID or an exact normalized artifact path at a
token boundary. An external directory basename is never a citation needle.
Repository-relative variants are eligible only for evidence actually contained
by the repository. Citation class is fixed when the manifest is created;
documentation added later records provenance but never rewrites old evidence.

WP6b also establishes a transparent two-identity closeout convention. The
executable candidate X is committed first and all clean qualification binds its
commit/tree. A later Y may record those results only when its diff from X is
documentation/evidence-record-only. Y is never described as shadow-tested, and
the final handoff reports both identities. An exact path committed in X may
legitimately make the aggregate manifest `tracked`; dynamically created child
directories remain `uncited-at-creation` absent their own exact reference.

**Why.** Basename matching allowed incidental short strings in prose or hashes
to overstate evidence durability. Boundary-exact identities preserve real
citations without false positives. Separating executable and documentary
commits avoids the impossible self-reference of recording final evidence in
the already-tested commit while keeping the evidence identity unambiguous.
Alternatives rejected: basename heuristics, substring matching, retroactive
manifest rewrites, amending a qualified candidate, or claiming Y inherited X's
qualification.

**Affected files.** Durable-citation classification/regressions and the WP6b
plan, autonomy, and decision records. Frozen contracts, product behavior,
commissioning, verification tiers, and WP6c scope are unaffected.

## 2026-08-25 — Owner-derived executable shadow partitions (WP6b)

**Decision.** The four allowlisted WP6a ownership boundaries are also the four
WP6b executable shadow partitions. Each `test:partition:<owner>` command first
runs the complete independent ownership evaluation, selects files directly
from the validated canonical declaration, and assigns each selected file to a
Vitest config from repeated discovery provenance. Config selection prefers the
deepest containing config directory, then normalized lexical order. This keeps
controller/repository files under the root config while exercising adopter and
OCI files through their own config roots without a second owner-to-glob or
owner-to-config registry.

Every owner command writes its own `test-partition-report`, raw
`test-partition-vitest-report` artifact(s), and PASS receipt. The clean-only
`test:partitions:shadow` aggregate invokes the unchanged fast, migration, and
orchestrator commands with their existing evidence identities; it adds only the
independently discovered files outside their deduplicated union, validates all
child receipts, then invokes each owner command independently. Legacy overlap
is deduplicated by normalized repository file plus Vitest full test name. The
comparison retains only disposition and normalized failure output, excluding
absolute roots, ordering, timestamps, and durations. A child nonzero is
propagated exactly (or mapped to one when absent), later children do not start,
and no aggregate PASS receipt exists on failure.

**Why.** The owner taxonomy already records real execution responsibility and
passed WP6a's independent completeness gate; inventing timing-oriented groups
before measurement would add drift and prejudge WP6c. Discovery provenance is
the only current machine-verified config authority, so deriving config roots
from it preserves nested adopter/OCI semantics without owner special cases.
Keeping the aggregate shadow-only proves correctness before modifying the
commissioned schedule and leaves exact closure fresh and unchanged.

The first exact clean shadow exposed one directly blocking legacy defect before
any comparison ran: `runUnitPartition` still capped the serial fast selector at
20 minutes although the pinned-runtime suite requires roughly 49–51 minutes.
The fast/migration wrapper now uses the same one-hour bound as the existing full
unit/orchestrator commands. This changes no membership, test timeout,
parallelism, receipt, commissioned argv, or exact-runtime workflow command; a
regression pins the bound so it cannot silently contract again.

A second clean shadow exposed an evidence-environment constraint: placing the
aggregate beneath the repository's long `artifacts/manual/...` path left
insufficient Windows path headroom for the nested Git repositories created by
the legacy suite. The aggregate retained the failing report and issued no PASS
receipt. Final qualification therefore uses short external clean-clone and
evidence roots while retaining the same committed commands, runtime, config,
selection, and receipt rules. No Git behavior or test expectation is weakened
to accommodate the host path limit.

The first short-path shadow then passed completely, but the subsequent
standalone clean `test:unit` qualification was still producing fresh fixture
state when the generic one-hour receipt-wrapper supervisor terminated it. The
same commit's disjoint fast and migration children had already passed all 625
plus 29 unit tests with valid receipts. Full unit and orchestrator evidence
wrappers therefore share a finite 90-minute bound, giving measured host
headroom while remaining fail-closed. A regression pins the bound. Package
argv, Vitest selection, serial execution, per-test limits, workflow commands,
and receipt requirements remain unchanged. Alternatives rejected: treating the
timeout as passing, omitting the applicable broad check, removing supervision,
or weakening/parallelizing tests to fit the stale wrapper.

The next clean shadow exposed a separate Windows fixture-teardown race after
634/635 controller-partition tests passed: recursive removal of an owned
state-store Git fixture returned transient `ENOTEMPTY`. The state file left in
the directory predated teardown, so no product write was still active. That
test file now uses bounded linear-backoff cleanup for the transient filesystem
codes that recursive removal and Windows handle release can produce; permanent
errors fail on the first attempt and persistent transient failures remain
non-passing at the ceiling. Deterministic injected-remover tests pin all three
dispositions. Alternatives rejected: suppressing cleanup failures, globally
weakening teardown, deleting the failed result, or treating the otherwise-green
partition as passing.

**Affected files.** `test-partitions.ts`, its CLI/regressions, the new package
scripts, `evidence.mjs`, the full-suite evidence wrapper, the canonical
catalogue entry for the new regression owner, `state-store.test.ts`, and contract/operator
documentation. The active manifest and commissioning source, slow registry,
benchmark, default profile, legacy package argv, and exact-runtime workflow
remain unchanged.

## 2026-08-24 — Four-boundary canonical test ownership (WP6a)

**Decision.** The source test universe has four allowlisted ownership ids:
`controller-runtime`, `repository-tooling`, `adopter-template`, and
`trusted-container-fixture`. The tracked
`tools/milestone-orchestrator/config/test-ownership.json` catalogue lists every
test path explicitly under exactly one owner. Owner ids remain code-allowlisted
rather than self-declared by the catalogue, so a typo or invented partition
cannot become valid metadata.

Discovery is independently executable. The ownership gate enumerates every
tracked or unignored `vitest.config.*`, runs Vitest's own file-list operation
twice for each config, separately repeats the orchestrator command filter, and
normalizes absolute results to sorted forward-slash repository paths. It also
reconciles the root package scripts, active commissioned test commands,
existing fast/migration candidate discovery, direct invariant test selection,
the OCI fixture command, and the executable exact-runtime workflow contract.
Exact overlap between root and nested adopter-template discovery is retained as
provenance; duplicate entries, case-fold collisions, changed repeated sets, or
entry-point drift are ambiguous and fail closed.

The gate is a fifth receipt-owning child of the existing invariant suite. A
PASS owns `test-ownership-report`; a classification failure retains the report
and emits no receipt. WP6a does not feed the catalogue into fast, migration,
orchestrator, unit, OCI, generated-adopter, tier, or exact-closure execution.
Disjoint executors and shadow equivalence remain WP6b1 work, and a later
commissioned-manifest cutover remains separate.

**Why.** The prior slow-suite registry explicitly named one migration file but
assigned every other discovered file to fast by subtraction. A new test was
therefore automatically classified and could not fail closed. Four owners are
the smallest defensible current taxonomy: controller tests share one source
runtime; the production-build owner is the root-unit remainder excluded by the
orchestrator command; adopter tests are source templates also executed after
generation; and the OCI case runs under a separate config and trusted-container
boundary. Merging any of the latter three into the controller majority would
hide a current execution responsibility. Splitting controller tests by
speculative timing or future executor shape was rejected until WP6
measurements exist.

**Affected files.** The ownership catalogue and gate/CLI/tests, invariant
registry and owner expectation, `README.md`, `CONTRACT.md`, config guidance,
and WP6a plan/log records. Package scripts, exact-runtime workflow, active
verification manifest, commissioning identity, slow-suite executor registry,
and benchmark implementation are unchanged.

## 2026-08-24 — Canonical candidate recovery and reproducible derived evidence (WP2 Session 2, verified)

**Decision.** State schema `1.11.0` completes the intent-first
`candidate-prepare` boundary. An exact unchanged `intent-persisted` operation
may resume by publishing invocation-start before entering the Worker gateway.
Invocation-start, thread-recorded, and gateway-return interruptions are
deliberately non-replayable: they become a preserved
`worker-outcome-ambiguous` block. Canonical Worker completion now retains the
redacted final-response bytes and digest as well as the deterministic
Worker-turn digest. Missing Worker-turn and checkpoint evidence can therefore
be materialized from canonical state; conflicting bytes can never authorize
progress. Every evidence ancestor and file is revalidated as a real,
contained, non-linked canonical path before read or publication. Unowned
pre-intent evidence blocks candidate preparation with a retained diagnostic.
Legacy `1.10.0` candidate completion that lacks response bytes migrates to
`legacy-worker-evidence-unrecoverable` rather than trusting an artifact or
inventing content.

Normal and recovered paths use the same candidate reducers. Recovery runs
under the repository controller lease and state-generation CAS; synchronized
contenders may produce only one advancing hook sequence, controller commit,
artifact authority, verification transition, and intent completion. The
state mirror remains diagnostic: failure after canonical ref publication does
not roll back authority and is repaired only by a later mutation-capable open.
Status, Doctor, and static inspection expose the same phase,
classification/disposition, preserved paths, and next safe action without
repair or recovery.

An exact successor published by a mutation-capable state store after immutable-
field transition validation and canonical compare-and-swap is treated as an
inductively validated lineage step in that store. It is not re-read from the
object database immediately after publication. Fresh and read-only/mutation
opens still validate the complete pending-operation lineage from the current
generation to its recorded input generation. This preserves the same Git-ref
CAS authority and tamper checks while avoiding quadratic revalidation across
the candidate operation's explicit durable phases.

Verification owners remain substantive on every supported host. Process-tree
tests exercise Windows `taskkill` tree termination as well as POSIX process-
group SIGKILL rather than reporting platform skips. Expensive commissioning
negative cases may share one disposable repository only when they execute
sequentially and independently restore the exact base under test; both missing
and unrelated-base rejections remain required. Neither portability nor fixture
cost is a reason to increase timeouts, skip behavior, or weaken assertions.

The fail-closed workspace identity boundary is expressed as facts, not as a
required subprocess topology. Once a real contained standalone `.git`
directory is proven, top-level/Git/common directory and branch may be queried
together; the six exact local controller markers may be queried together only
with missing/duplicate detection; remote absence remains explicit; and active
operation markers are checked directly under that proven `.git` directory.
This preserves every recovery classification while avoiding dozens of Windows
process startups at each candidate phase.

**Why.** Hash-only Worker completion could detect a missing derived artifact
but could not reconstruct it, while replay after any possible gateway entry
could duplicate unobservable Worker effects. Retaining the already-redacted
canonical response closes the former gap; drawing the replay boundary before
invocation-start closes the latter. Exact path, Git, protected-file,
diff-policy, context, parent, tree, message, and artifact validation makes the
operation intent—not ancestry or evidence files—the only authority for
checkpoint adoption. Alternatives rejected: a generic workflow engine, a
second journal, trusting Worker events or artifacts, relaunching after an
ambiguous gateway boundary, silently adopting an existing candidate, resetting
or recommitting a suspicious tree, following linked evidence, and migrating
legacy hashes as if the missing response bytes were known. Also rejected:
removing durable phases, weakening fresh-open lineage validation, increasing
test timeouts, or treating a timed-out broad run as passing; the redundant
same-store post-CAS rewalk was the performance defect.

**Scope boundary.** The green Session 2 ledger and cohesive commit close only
the previously omitted WP2 candidate recovery boundary. They do not
change Planner/Worker/Reviewer roles, execution-provider eligibility,
verification, target integration, cleanup, retention, readiness, CAL-1,
hidden validation, product completion, or human-acceptance meaning, and it
does not begin WP6.

**Affected files.** Candidate contracts/runtime and shipped schemas, state
migration/store, operation reducers, Worker orchestration and fault hooks,
status/Doctor/static inspection projections, hard-loss/concurrency/path/Git/
context tests, `README.md`, `CONTRACT.md`, and Session 2 plan/autonomy records.

## 2026-08-23 — Intent-first candidate checkpoint authority (WP2 Session 1)

**Decision.** State schema `1.10.0` extends the one exclusive
`pendingOperation` union with a strict `candidate-prepare` intent. The
controller publishes it by canonical state CAS before the Worker gateway can
mutate the isolated candidate. It pins the exact input generation/revision,
run/milestone/attempt, repository and standalone workspace identity, starting
candidate, Worker assignment/policy/thread lineage, retry/proposal/protected
context, prompt, accounting baseline, evidence paths, phases, and recovery
policy. Invocation, thread, completion, checkpoint plan/result/evidence, block,
and completion transitions are pure bounded reducers guarded by the global
unrelated-mutation fence.

After durable Worker completion, the controller validates protected bytes and
diff policy, stages the exact worktree, and records the authorized parent,
tree, message, and path set before creating a checkpoint commit. Leased restart
adopts only the exact clean commit matching that authorization and completes
through the same reducer as the uninterrupted path. Worker events,
`worker-turn.json`, and `controller-checkpoint.json` are derived evidence, not
authority. A clean or dirty candidate without matching intent never enters
verification; it is classified external/ambiguous and the existing cleanup
operation is explicitly directed to preserve it even when ordinary failed-
workspace policy would delete it. Status and Doctor inspect the same operation
read-only.

**Why.** The previous controller committed candidate output before recording
checkpoint state and then treated any clean descendant with no retry feedback
as interrupted controller work. A crash and an otherwise valid out-of-band
commit were therefore observationally identical and both advanced directly to
verification. Intent-first ordering makes ownership durable before mutation,
while exact parent/tree/message and context validation distinguishes the one
authorized post-commit result without resetting or rewriting suspicious work.
Alternatives rejected: descendant ancestry as ownership, Worker/checkpoint
artifacts as authority, a second journal, publishing intent only immediately
before the Git commit, replaying the Worker after an ambiguous result,
recommitting an observed tree, deleting or quarantining unowned output, and
separate normal/recovery completion mutations.

**Scope boundary.** This decision establishes only the Session 1 central path
and two critical authority cases. The remaining crash/adversarial matrix starts
with loss immediately after intent publication and remains required before
`candidate-prepare` or WP2 can close. It does not begin WP6 or change
verification, integration, readiness, CAL-1, or human-acceptance meaning.

**Affected files.** State contracts/runtime and shipped schemas/store
migration, `operation-intent.ts`, `candidate-prepare.ts`, Git-isolation commit
helpers, orchestrator Worker/startup/cleanup routing, status and Doctor
projections, candidate and existing-operation recovery tests, `README.md`,
`CONTRACT.md`, and Session 1 plan/autonomy records.

## 2026-08-23 — Production-build unit fixtures own exact pnpm stores

**Decision.** Every production-build unit fixture creates an empty real
versioned pnpm store inside its disposable parent and supplies that exact path
through canonical `pnpm_config_store_dir` to both direct and spawned fixture
executions. Test helpers remove conflicting case variants before entry and
restore the complete prior environment afterward. Production store discovery,
existence validation, offline preparation, and reporting remain unchanged.

**Why.** Exact runtime run `32660428700` proves both real generated-adopter
production builds pass, but nine Windows unit fixtures fail before their owned
assertions because a new hosted runner has no ambient
`C:\Users\runneradmin\AppData\Local\pnpm\store\v11`. The same fixtures pass
locally only because that machine-default store already exists. A fixture must
own every filesystem precondition it exercises. Alternatives rejected: weaken
or remove the production existing-store guard, create an ambient user store,
skip the Windows assertions, seed a global CI-only path, or special-case GitHub
Actions.

**Affected files.** `tools/production-build.test.mjs` and the WP5 execution/
autonomy records.

## 2026-08-23 — Matrix-specific outer controller timebox

**Decision.** Exact runtime CI retains a 60-minute outer timeout for the Linux
controller and assigns 120 minutes to the Windows controller through an
explicit matrix field. All six controller commands, their order, evidence
roots, internal supervisor limits, per-test limits, unconditional upload, and
success criteria remain unchanged. The executable workflow contract requires
both platform-specific values and rejects collapsing Windows back to 60.

**Why.** In run `32651184672`, Windows invariants and the 597-test controller
suite passed, then the outer 60-minute job clock cancelled the complete unit
suite after only 28 minutes. The unit command retained an ERROR manifest with
no receipt and later static steps were skipped. The same unchanged complete
unit command passed 612 tests with two declared Windows-only POSIX skips under
exact Node/pnpm locally, but required about 57 minutes by itself. Setup,
invariants, controller, unit, and statics therefore cannot reliably fit the
old Windows outer bound. Alternatives rejected: weakening or removing either
test command, increasing per-test limits, splitting or conditionally skipping
coverage, accepting cancellation, giving Linux unnecessary extra time, or
rerunning the unchanged failing SHA as though cancellation were unexplained.

**Affected files.** `.github/workflows/exact-runtime-ci.yml`, the executable
workflow contract and its tests, `CONTRACT.md`, and `README.md`.

## 2026-08-23 — Source-store pinning across production-build clone volumes

**Decision.** Before creating its disposable clone, production-build evidence
asks the currently pinned pnpm for `store path` from the exact clean source
repository. Discovery must succeed and emit exactly one absolute path naming an
existing real directory. The wrapper then supplies that exact path through
`--store-dir` on the clone's frozen offline copy-mode install. The build report
records both store discovery and the explicitly pinned preparation command, and
bounded stdout/stderr is included when either subprocess fails. The
fresh-adopter coordinator carries its already validated source-store identity
through every generated-repository command as pnpm's
`pnpm_config_store_dir`; it removes conflicting case variants first and retains
the explicit install argv in the public command ledger.

**Why.** Windows Exact runtime CI checks out the source on `D:` while Node's
temporary directory is on `C:`. The generated adopter install correctly seeded
and used `D:\.pnpm-store\v11`, but the nested production-build install omitted
that identity and let pnpm select a different volume-local default store for
the `C:` clone. Offline preparation therefore failed despite the required
packages already existing in the proven source store. Store identity is an
input to an offline build and must cross the disposable-clone boundary
explicitly. Alternatives rejected: enabling network access, copying installed
`node_modules`, relying on ambient/global pnpm configuration, hydrating a
second implicit store, forcing the temporary root onto the checkout volume, or
relabeling the hosted failure as infrastructure.

**Affected files.** `tools/production-build.mjs`, its focused tests,
the fresh-adopter CI coordinator and tests, `CONTRACT.md`, and the
generated-adopter description in `README.md`.

## 2026-08-22 — Current Node 24 official actions with immutable pins (WP5 Session 2)

**Decision.** The Exact runtime workflow allowlists and uses these official
stable releases, each exactly once per controller, fresh-adopter, and
trusted-container job:

- [`actions/checkout` v7.0.1](https://github.com/actions/checkout/releases/tag/v7.0.1)
  at commit `3d3c42e5aac5ba805825da76410c181273ba90b1`; the exact
  [`action.yml`](https://github.com/actions/checkout/blob/3d3c42e5aac5ba805825da76410c181273ba90b1/action.yml)
  declares `runs.using: node24`.
- [`actions/setup-node` v7.0.0](https://github.com/actions/setup-node/releases/tag/v7.0.0)
  at commit `820762786026740c76f36085b0efc47a31fe5020`; the exact
  [`action.yml`](https://github.com/actions/setup-node/blob/820762786026740c76f36085b0efc47a31fe5020/action.yml)
  declares `runs.using: node24`.
- [`actions/upload-artifact` v7.0.1](https://github.com/actions/upload-artifact/releases/tag/v7.0.1)
  at commit `043fb46d1a93c77aae656e7c1c64a875d1fc6a0a`; the exact
  [`action.yml`](https://github.com/actions/upload-artifact/blob/043fb46d1a93c77aae656e7c1c64a875d1fc6a0a/action.yml)
  declares `runs.using: node24`.

The releases were selected from each official repository's `releases/latest`
record on 2026-08-22. Resolution then read the official `git/ref/tags/<tag>`
object and would follow a returned annotated `tag` object through
`git/tags/<sha>.object` until reaching the commit. All three selected refs
currently returned `type: commit`, so the listed 40-character values are their
direct commit targets rather than tag-object IDs. Runtime proof was read from
`action.yml` at those commits, not inferred from the release number or moving
major tag. The executable workflow contract owns this exact release/comment/
SHA allowlist, requires three global and one per-job occurrences, and rejects
every other action reference even if it is a full SHA.

**Migration facts and disposition.** Checkout first moved to Node 24 in the
official [v5.0.0 notes](https://github.com/actions/checkout/releases/tag/v5.0.0),
which require Actions Runner `v2.327.1` or newer. Checkout
[v6.0.0](https://github.com/actions/checkout/releases/tag/v6.0.0) moved
persisted credentials to a separate runner-temp file; this workflow retains
`persist-credentials: false`, so no credential persistence is adopted.
Checkout [v7.0.0](https://github.com/actions/checkout/releases/tag/v7.0.0)
migrated to ESM and blocks unsafe fork checkout for `pull_request_target` and
`workflow_run`; this workflow uses `pull_request`, `push`, and manual dispatch,
so its scheduling meaning is unchanged.

Setup-node's official
[v5.0.0 notes](https://github.com/actions/setup-node/releases/tag/v5.0.0)
likewise establish Node 24 and Runner `v2.327.1`, while adding automatic cache
detection. The [v6.0.0 notes](https://github.com/actions/setup-node/releases/tag/v6.0.0)
limit automatic caching to npm. This workflow supplies no cache input and its
package manager is pnpm, so no dependency cache or trust-boundary change is
introduced. v7 migrates the action to ESM, adds cache-key outputs, removes a
dummy `NODE_AUTH_TOKEN`, and updates dependencies; none alters the exact
`node-version: 24.18.0` / `check-latest: false` inputs used here.

Upload-artifact's official
[v6.0.0 notes](https://github.com/actions/upload-artifact/releases/tag/v6.0.0)
are the first to state that the action runs on Node 24 by default and requires
Runner `v2.327.1`; v5's preliminary support still defaulted to Node 20. The
[v7.0.0 notes](https://github.com/actions/upload-artifact/releases/tag/v7.0.0)
add optional direct single-file upload via `archive: false` and migrate to ESM.
This workflow retains default archive behavior for directory evidence,
`if: always()`, `if-no-files-found: error`, unique platform roots, and 14-day
retention, so the optional direct-upload behavior is not selected.

**Why.** The previous checkout v4.2.2, setup-node v4.4.0, and upload-artifact
v4.6.2 metadata declared Node 20; hosted logs warned that GitHub was forcing
those actions onto Node 24. Current official Node 24 metadata removes that
runtime ambiguity while immutable commit pins preserve the existing
supply-chain policy. Alternatives rejected: keeping Node 20 metadata and
depending on forced-runtime compatibility; pinning mutable major or release
tags; using short SHAs; selecting versions from third-party summaries;
assuming a major version implies Node 24; mixing releases across jobs; adding
an action outside the exact three-action inventory; or changing application
Node/pnpm pins, workflow permissions, checkout history/credentials, scheduling,
or evidence upload semantics as part of this migration.

**Affected files.** Exact-runtime workflow; executable workflow allowlist and
mutation tests; Session 2 execution plan, autonomy log, and this decision
record. Hosted execution of the frozen candidate remains Session 3 work.

## 2026-08-22 — Producer-owned canonical OCI export staging root (WP5q)

**Decision.** The trusted-container executor canonicalizes its own freshly
created artifact-export staging root exactly once with
`realpath(await mkdtemp(...))`, before deriving evidence/workspace staging
children or passing them to strict artifact inventory and publication. The
container-executor test fixture applies the same rule to its controlled fresh
root before deriving its mocked pnpm store and clone paths. Retained assertions
require both the fixture root and the executor-provided evidence staging path to
already have stable realpath identity.

Caller-provided pnpm stores, disposable clone paths, artifact destinations,
mount inputs, and pre-existing filesystem objects are not normalized. Existing
ordinary-directory, no-link, exact-realpath, containment, artifact-limit,
cleanup, OCI-policy, and process-supervision guards remain unchanged.

**Why.** Hosted Windows supplies a valid NTFS 8.3 spelling beneath TEMP while
`fs.promises.realpath()` expands it. The raw test fixture therefore stopped all
eight lifecycle cases at the strict pnpm-store mount guard. After that controlled
fixture was canonicalized, six cases reached their intended outcomes, while the
normal and timeout cases exposed the executor's independently created raw export
root at the strict artifact-inventory boundary. A direct observation recorded
that staging path as noncanonical. Canonicalizing each producer-owned fresh root
at creation preserves fail-closed consumer semantics and makes every derived
path use one identity on Windows and POSIX.

Alternatives rejected: normalizing arbitrary inputs inside the mount or artifact
guards; accepting equivalent NTFS aliases; comparing case-insensitively;
globally overriding or canonicalizing TEMP; changing container/artifact cleanup
or publication; special-casing Windows; and leaving the production staging root
dependent on the caller's temp spelling.

**Affected files.** `container-executor.ts`, its focused test, execution plan,
autonomy log, and this decision record. `container-artifacts.ts`, verification
clone, Git isolation, schema/state, process supervision, OCI policy, package,
lock, and workflow owners are unchanged.

## 2026-08-17 — Source-bound pnpm store for fresh-adopter smoke (WP5j)

**Decision.** The fresh-adopter coordinator resolves `pnpm store path` once
through its already pinned pnpm invocation with the source repository as the
working directory. It accepts exactly one non-empty absolute path, requires
that path to be an existing directory, and supplies it explicitly as
`--store-dir` to the generated repository's install. The child remains
`--offline --frozen-lockfile --package-import-method=copy`; no fallback or
network retry exists. The smoke result records only an
`explicit-source-store` disposition and SHA-256 of the host path, while the
command-owned ignored log retains the diagnostic path itself.

**Why.** On hosted Windows the source checkout is on `D:` and the generated
repository is created under the `C:` user temporary directory. pnpm selects a
drive-local store, so the source frozen install hydrated all 138 packages on
`D:` while the generated offline install selected an empty `C:` store and
failed on `@eslint/js@10.0.1`. Linux used one filesystem and passed. Resolving
from the exact source cwd binds the child to the dependency closure that the
preceding source install actually hydrated, independent of the generated
repository's volume, without weakening its offline boundary.

Alternatives rejected: enabling child network access or retry; duplicating
dependency hydration; adding/changing package or lock inputs; relying on a warm
runner cache; moving the generated repository merely to inherit a drive;
setting a second workflow-owned store path that could drift from coordinator
behavior; copying or linking the store; or retaining the host path in cleartext
inside the durable smoke result.

**Affected files.** Fresh-adopter CI smoke coordinator and focused regression
tests; execution plan, autonomy log, and this decision record. The workflow
command itself is unchanged.

## 2026-08-17 — Git-archived scratch hydration for OCI fixture closure (WP5i)

**Decision.** The trusted-container controller hydrates its existing pnpm store
from an exact `git archive HEAD:fixtures/oci-candidate` extracted into a
`mktemp` directory. The fetch runs there exactly once with
`--ignore-workspace` and `--frozen-lockfile`, after the root frozen install and
before the unchanged real Docker matrix, and the scratch directory is removed
on exit. The executable workflow contract pins the complete archive/fetch/
cleanup script and ordering, not merely the presence of a generic `pnpm fetch`.

The controller remains the only networked party. The candidate still runs an
offline/frozen/store-integrity install with denied networking and a read-only
store mount. Fixture/package/lock bytes, the candidate command, provider,
normal/adversarial cases, containment policy, and source-identity modes do not
change.

**Why.** A root frozen install populated Vite `8.2.0`, but the separately
locked OCI fixture required `8.2.1`, so hosted normal-case startup failed with
`ERR_PNPM_NO_OFFLINE_TARBALL`. Fetching from the fixture directory closes that
graph, but pnpm `11.15.1` also byte-normalizes the fixture YAML despite
`--frozen-lockfile`; doing so in the checkout would dirty the exact source that
the next step must attest. The Git archive supplies committed fixture bytes,
avoids parent-workspace discovery, confines normalization to disposable state,
and populates the same controller default store already selected by the root
install and OCI executor.

Alternatives rejected: adding Vite `8.2.1` or the entire fixture graph to the
root package/lock; changing the protected fixture lock to Vite `8.2.0`;
allowing candidate network access; making the store mount writable; restoring
the tracked lock after mutating it; accepting a dirty controller checkout;
using the root workspace graph; relying on a warm runner cache; or weakening
offline/frozen/store-integrity enforcement.

**Affected files.** Exact-runtime workflow; executable workflow contract and
mutation tests; execution plan, autonomy log, and this decision record.

## 2026-08-17 — Dual-mode OCI controller-source identity (WP5h)

**Decision.** The real OCI matrix accepts exactly two explicit tracked-source
states. A clean checkout is `committed-head` and binds its candidate tree to
`HEAD^{tree}`. A locally frozen implementation candidate is `frozen-index` and
binds its candidate tree to `git write-tree`, together with exact HEAD/tree,
staged path count, and a deterministic staged-path digest. Both modes reject
any unstaged tracked change before image creation. OCI result schema `1.1.0`
records this generic `controllerSource` identity instead of WP3d's
milestone-only `controllerCandidate` shape.

The OCI product harness no longer names, requires, or hashes the user-owned
`Implementation-ready improvement plan 8-5-26.txt`. That file remains guarded
by the outer autonomous-work protocol. Unrelated untracked content likewise
does not manufacture a candidate tree; the matrix identity is the exact Git
tracked source plus the installed lockfile-bound toolchain.

**Why.** GitHub Actions checks out the exact committed tree with an empty
index. Treating that valid state as `The WP3d candidate index is empty` stopped
the hosted job before every normal/adversarial case, while fabricating a staged
change would make the evidence dishonest. Retaining the staged mode is still
necessary for pre-commit real-container verification of an exact frozen
candidate. Making the modes explicit preserves both workflows without a CI
environment branch or a dirty-tree bypass. Alternatives rejected: staging a
sentinel in CI, weakening the parser, special-casing `GITHUB_ACTIONS`, requiring
the local human file in distributed/adopter repositories, silently placing a
committed tree in fields named as staged evidence, accepting unstaged tracked
content, or removing pre-commit OCI verification.

**Affected files.** OCI controller-source identity owner and real-Git tests;
real OCI matrix entry/report schema; execution plan and autonomy log.

## 2026-08-16 — Exact-runtime cross-platform CI boundaries (WP5e)

**Decision.** The source repository has one least-privilege GitHub Actions
workflow with three deliberately separate diagnostic boundaries. The controller
matrix runs the unchanged receipt-owning invariant, orchestrator, unit,
typecheck, lint, and format commands serially on `ubuntu-24.04` and
`windows-2022`. Every job installs and asserts exact Node `24.18.0` and pnpm
`11.15.1`; all external actions are pinned to full release commit SHAs, and
platform-specific evidence roots are uploaded.

The fresh-adopter matrix is a CI smoke, not another bootstrap proof. It invokes
the public creator, performs a frozen offline copy-mode install, runs the
generated typecheck and four-test unit boundary, independently validates both
command receipts plus every declared artifact size/hash, verifies clean
two-commit bootstrap history and absent readiness activation, and labels its
result completion-ineligible. It does not commission, launch a browser, run
source or generated no-argument verification, or supersede retained WP4d
evidence. The trusted-container job is Linux-only and must reach a real Docker
Engine before invoking the existing complete normal/adversarial OCI matrix; no
mock or structural assertion substitutes for execution.

The checked-in workflow contract parses the YAML and mutation-tests runtime,
platform, command, evidence-root, OCI, and completion boundaries. It proves
local structure only. Hosted Linux, Windows, artifact-upload, and Docker status
remain unverified until GitHub actually executes them, and even a green hosted
run is diagnostic rather than autonomous-readiness evidence.

**Why.** Prior Windows evidence left the two POSIX supervisor cases and the
Linux Git/filesystem/race paths unexecuted, while the repository contained no
workflow at all. Separate jobs make ordinary cross-platform regression,
distributor smoke, and privileged Docker prerequisites independently visible
and prevent an unavailable engine from being mislabeled as controller
coverage. Alternatives rejected: one opaque aggregate job, floating Node/pnpm
or action tags, changing package scripts/dependencies for CI, rerunning the
costly WP4d no-argument/browser proof on every change, treating YAML tests as
hosted evidence, mocking Docker, running the OCI owner from a Windows
controller, or allowing CI status to authorize integration.

**Affected files.** Exact-runtime workflow; CI toolchain assertion,
fresh-adopter coordinator, workflow/receipt regression tests; README,
repository contract, execution plan, and autonomy log.

## 2026-08-16 — Current-config schema and differential parity boundary (WP5d)

**Decision.** Publish the current `OrchestratorConfig` contract as strict JSON
Schema 2020-12 artifact `orchestrator-config.schema.json` at version `1.6.0`.
It references, rather than copies, the separately versioned strict
`model-policy.schema.json`; generated adopter packages carry both schemas and
must validate their generated config against them. The model-policy schema is
aligned with existing runtime semantics for non-whitespace override reasons
and at most one override per role.

One shared named corpus is the executable parity boundary. Each current-input
case is parsed through the real read-only runtime loader and independently
evaluated against the shipped schemas, with both expected disposition and
runtime/schema equality required. Closed property/required inventories and the
mandatory protected floor also receive structural equality assertions. A
test-only dependency-free evaluator implements only the 2020-12 keywords used
by these schemas, resolves local/external references, and fails on every
unsupported keyword. It is not runtime configuration authority and is not
packaged into adopters.

The JSON Schema is current-input-only. Existing runtime migration remains the
sole authority for legacy `1.0.0` through `1.5.0` input, and runtime validation
remains stricter for installation-, repository-, and cross-field-dependent
facts that portable JSON Schema cannot express, such as requiring the selected
authority path itself in `protectedPaths`. The raw placeholder template remains
invalid until generation/substitution; it is not mislabeled as a current valid
configuration.

**Why.** Unknown-root rejection already existed in runtime, but adopters had no
corresponding top-level schema and tests only proved selected schema files were
parseable. Duplicating the model-policy shape inside a new config schema would
create immediate drift, while replacing runtime parsing with JSON Schema would
lose migration and repository semantics. The frozen package graph exposes no
declared 2020-12 validator; its only Ajv is an undeclared ESLint transitive at
version 6, which demonstrably predates `minContains` and misinterprets the
duplicate-role constraints. Alternatives rejected: adding a dependency and
changing package/lock files, importing transitive Ajv internals, applying the
current schema directly to legacy bytes, loosening runtime checks for schema
equivalence, duplicating model policy, accepting boolean equality without
expected outcomes, silently ignoring unsupported schema keywords, or omitting
the schemas from generated adopters.

**Affected files.** Current config and model-policy schemas; dependency-free
schema test evaluator; differential corpus and schema/adopter tests; adopter
runtime inventory; configuration guide, repository contract, execution plan,
and autonomy log.

## 2026-08-16 — Shared contract-integrity owner and ineligible adapter (WP5c)

**Decision.** The 13 ordered `contract-integrity` checks have one
controller-owned implementation in `src/contract-integrity.ts`. The module is
plain-Node-loadable: it accepts the existing commissioned-authority-anchor
validator as an explicit dependency, so `scripts/verify.mjs` can import the
same evaluator directly under pinned Node while controller commands consume it
through `tsx`. The authoritative verifier still selects and aggregates stages
exactly as before; only its former inline check body moved.

The invariant registry's `protected-integrity` entry now calls a narrow
`verification-cli.ts contract-integrity` adapter instead of a focused
`pnpm verify`. The adapter requires the exact healthy check identity and all
PASS statuses, retains `contract-integrity-report.v1`, and writes a
command-owned receipt only after success. The report always states
`completionEligible:false`; the outer invariant-suite report advances to
`1.1.0` to state the same. Failure retains the diagnostic and no PASS receipt.
The verification CLI loads the full tier implementation only after selecting
a tier mode, so the contract adapter does not require the Codex SDK or other
unrelated tier dependencies merely to start.
Source and generated-adopter registries use the same argv, owner path, and
artifact kind without adding a package script or changing their commissioned
registry IDs.

**Why.** Focused verifier selection deliberately includes `environment`, so
using it as an invariant made correct contract checks depend on unrelated
dependency, placeholder, production, and runtime wiring. Duplicating the
checks in the controller would let invariant and exact verification meanings
drift. A shared evaluator preserves one authority, while the separate evidence
adapter gives fast corruption feedback without creating a second completion
path. Alternatives rejected: changing focused verifier stage selection,
special-casing environment success, retaining the aggregate wrapper, copying
the 13 checks into the invariant suite, accepting exit zero without a receipt,
making the adapter completion-eligible, adding a public package command, or
rerunning the completed WP4d adopter proof merely to refresh evidence.

**Affected files.** Shared contract evaluator/tests/export; authoritative
verifier import; invariant adapter/report/CLI/tests; source/template/generated
invariant registries; aggregate verifier fixture dependency; README,
configuration guide, repository contract, execution plan, and autonomy log.

## 2026-08-16 — Generation-bound canonical lifecycle status (WP5b)

**Decision.** `pnpm loop:status -- --json` emits one versioned
`orchestrator-status` schema `1.0.0` for uninitialized, ordinary initialized,
pending-operation, target-drift, and active-reconciliation states. CLI status
runs before reconciliation-controller opening, so an active reconciliation is
reported through the common observational contract rather than replacing it
with the narrower `reconcile-status` shape or creating a mutation capability.

Status composes two existing authorities. Accepted Doctor schema `2.0.0` owns
commissioning/profile, operational issues, provider identity, exact-result
integrity/currentness, eligibility, lease, and earliest safe next action.
Validated canonical state and existing operation inspectors own detailed
controller state, pending side effects/recovery, latest completed milestone,
exact-verification provenance, cleanup, and reconciliation. Status never
searches artifact directories or treats prose logs as state.

Target relation names target-branch HEAD as the subject: `ahead` means target
descends from the stored verified commit, `behind` means verified descends
from target, and `divergent` means neither; `current`, `uninitialized`, and
fail-closed `unavailable` are distinct. Recovery is normalized as `automatic`
for an inspector-owned resume, `blocked` for manual reconciliation,
`external` for reconciliation/history drift, and `none` when no recovery is
recorded. Git ancestry inspection is optional-lock-suppressed.

Doctor and detailed state must name the same canonical generation. When valid
commissioning aligns the branch sources, Doctor, checkout, and target-ref HEAD
must also agree. Status retries movement once, then reports
`changed-during-inspection`, suppresses the detailed state projection and
integration eligibility, and returns only a status-rerun action. This prevents
an individually valid Doctor observation and state generation from being
combined into a false current-integration claim.

**Why.** The prior status omitted commissioning, relation, exact evidence,
eligibility, recovery disposition, and a next command, while active
reconciliation silently changed schemas. Copying Doctor or reimplementing its
checks would create a competing readiness definition; relying only on raw
state would omit provider/evidence integrity; sampling both without a
generation/target fence could produce an internally inconsistent resume
surface. Alternatives rejected: expanding `ReconciliationStatusSummary`,
calling the mutation-capable reconciliation controller, artifact-directory
discovery, log-derived completion, a binary target-drift flag, inverted or
ambiguous ahead/behind labels, and presenting stale state after a race.

**Affected files.** New status contract/tests/export, CLI status routing,
README and contract guidance, active plan, autonomy/decision records.

## 2026-08-16 — Versioned read-only operational Doctor and strict blocker gate (WP5a)

**Decision.** Operational Doctor schema `2.0.0` uses only `pass`, `warning`,
and `block` check severities and derives top-level `ready` solely from the
absence of blocks. Every non-pass check becomes an ordered issue with a stable
code, remediation, and optional safe command. `nextAction` follows the earliest
block; if that block requires manual repair, it directs the operator back to
strict Doctor after repair instead of skipping ahead to a later executable
action. With no blocks, it selects the earliest actionable warning or the
canonical state's permitted action.

Ordinary Doctor remains an inspectable exit-zero command even when it reports
`blocked`. The Doctor-only `--strict` flag prints the identical complete JSON,
then exits 2 when any block exists; warnings alone exit zero but keep
autonomous integration ineligible. Other loop commands reject `--strict`
before repository mutation.

Doctor projects existing read-only authorities rather than creating parallel
success definitions: commissioning/tier construction, production-build
declaration, structural configuration, exact installed SDK, provider
capability and identity, canonical state and pending-operation recovery,
protected roots and stored identities, lease ownership, authentication, and
Git identity. The normal config loader still enforces installed-SDK
compatibility; a narrow inspection loader lets Doctor report structural config
and installed state separately. Exact evidence is state-owned, hash-checked,
realpath-contained, current, readiness-only, and bound to the active
completion-eligible provider identity. Protected drift is a separate blocker
so it cannot hide a simultaneous recovery operation.

**Why.** The prior coarse `pass/attention` output could not serve as an
operational gate, omitted material package/path/evidence facts, and rejected
strict mode before diagnosis. Running verification from Doctor would be slow,
mutating, and circular; guessing the latest artifact directory would bypass
canonical state; coupling structural config to installed dependencies would
hide the actual failure; and treating every first-run warning as a block would
prevent safe initialization. Alternatives rejected: warnings authorizing
integration, strict mode suppressing JSON, a generic strict flag for mutating
commands, following linked paths, probing an unconfigured container provider,
repairing state or paths, or choosing a later actionable blocker over an
earlier manual one.

**Affected files.** Doctor/CLI/config inspection source and tests, three
read-only recovery consumers, `README.md`, `CONTRACT.md`, the active execution
plan, and autonomy/decision logs.

## 2026-08-15 — Git-anchored fresh-adopter bootstrap package (WP4d)

**Decision.** Distribute the loop through a strict
`milestone-loop-adopter-package.v1` definition and the no-clobber
`pnpm loop:template:create -- --definition <file> --output <absent-directory>`
command. The creator copies only an allowlisted runtime plus a minimal real
bootstrap scaffold, generates adopter-owned authority lock/config/registries/
package metadata, initializes the requested attached branch with fixed local
Git identity and timestamps, commits the authority base, then commits a
commissioning input bound to that exact strict ancestor. It never copies or
deletes the source readiness lifecycle, active commissioning, history, or
historical example.

The verifier and commissioning now share one Git-base authority anchor. The
active v2 manifest's base must be a strict ancestor containing byte-identical
immutable-lock and four-authority-file content; the candidate lock must pass
its own schema, lifecycle, and hash checks. Adopter-specific acceptance shape
is derived from the frozen base while universal exact-command, bootstrap/
readiness, no-compensation, hidden-custody, and one-way lifecycle rules remain
in verifier code. No adopter edits a verifier hash constant or hard-coded
acceptance counts.

The generated bootstrap owns one deterministic kernel used by Node, replay,
the production Worker, persistence, and rendered UI. Real static checks,
Vitest, clean-clone production build, save/load continuation, Worker parity,
desktop Chromium interaction, diagnostics, screenshot, and command receipts
are required. The separate `loop:template:prove` command performs an offline
frozen copy-mode install, explicit commissioning and manifest commit, exactly
one literal no-argument verifier run, and an independent hash/receipt/identity
audit. Its PASS is fixed to `bootstrap_complete`, remains provider-ineligible,
and is never autonomous-readiness-equivalent.

**Why.** Copying the source tree leaked commissioned readiness history and
required manual removal and source edits. Pinning an adopter hash in verifier
source made a generic distributable impossible, while a mutable unanchored lock
would weaken authority. The already-required strict ancestor is a durable,
reviewable trust root that preserves fail-closed calibration behavior without a
new protected file. Alternatives rejected: whole-repository copying, deleting
the readiness marker in copied history, regenerating the lock without a Git
anchor, embedding fixture hashes or project ids in verifier source, automatic
commissioning, no-op bootstrap scripts, DOM-only browser evidence, and treating
bootstrap as readiness.

**Affected files.** Shared authority anchor and commissioning/verifier tests;
adopter package/proof commands and tests; fresh-adopter definition/authority;
bootstrap scaffold and evidence tools; package/lockfile/static coverage;
adoption, contract, config, plan, and autonomy documentation.

## 2026-08-15 — Self-validating legacy worked-example package (WP4c)

**Decision.** Keep the Ski Tycoon files at their existing
`examples/ski-tycoon/` location and preserve all six JSON payloads byte-for-byte.
A sibling `worked-example.v1` descriptor now names the exact package file set,
source and template-introduction commits, legacy-only/inactive semantics,
per-file provenance disposition, roles, byte counts, SHA-256 values, paths, and
cross-file identities. `pnpm loop:example:validate -- --descriptor <file>` is
the only supported inspection route. It requires an explicitly supplied,
contained, regular, tracked descriptor; rejects missing, extra, linked,
untracked, drifted, malformed, or incoherent payloads; validates every strict
schema and legacy registry/check/protected link; and emits deterministic static
results without executing, migrating, commissioning, or rewriting the example.

The benchmark matrix, slow-suite registry, and scope policy remain labeled as
unchanged source snapshots. The orchestrator config, invariant suite, and
legacy manifest are labeled maintained compatibility adapters because they
received post-extraction trust-boundary updates. Active configuration keeps no
example identity: the source slow-suite registry is renamed to
`milestone-loop-explicit-migration-suites.v1`, while the example retains its
historical D-032 ID and the benchmark template uses an adopter placeholder.

**Why.** The WP4 source plan already requires the historical configuration at
the location it occupies, so a move or rewrite would add risk without closing a
gap. The actual gap was that the directory's README misstated provenance and
schema age, and only one file had a purpose-limited loader test; no boundary
proved the package as a coherent, non-active whole. A separate pinned
descriptor preserves recoverability and makes later drift explicit without
turning legacy v1 into an active fallback. Alternatives rejected: moving the
directory, converting its manifest to v2 (would erase historical semantics),
loading it through active config, executing unavailable historical commits,
or relying on documentation and ad hoc tests without byte identities.

**Affected files.** Worked-example descriptor/validator/CLI/tests and export,
package command, active slow-suite ID, benchmark template, example/root/config
documentation, `CONTRACT.md`, and WP4c plan/logs.

## 2026-08-15 — Deterministic one-shot commissioning (WP4b)

**Decision.** A repository creates its active generic v2 verification manifest
only through `pnpm loop:commission -- --input <file>`. The strict, explicit
input binds the target branch, strict-ancestor base, package-default profile,
current config/registry paths and identities, immutable-lock hash, canonical
protected floor, focused catalogue, literal exact command, and generic
reconciliation minimum. Commissioning is deliberately one-shot: the active
path must be absent and the attached target-branch checkout must be clean of
both tracked and untracked changes. Readiness additionally requires the
permanent marker to exist at or before the base and at the candidate;
bootstrap rejects any marker tree or history.

Generated `createdAt` is the base commit's canonical Git timestamp. The command
validates existing authority hashes, immutable-lock lifecycle and verifier
anchor, package scripts, all registry identities, protected coverage, and all
four tier plans; it never creates or repairs authority. It writes an exclusive
temporary file, verifies exact bytes and SHA-256, rechecks Git identity and
status, creates the absent destination with a no-clobber filesystem link, and
runs a strict read-only commissioning doctor. Failure cleans the owned stage;
after publication it may remove only the exact inode and hash it just created.
Every generated path, byte count, and SHA-256 is printed.

The source repository is commissioned on `master` from WP4a commit
`0f4ab3e5ef39bda07d6e77356ad53fca9136cdd5` with its existing readiness
lifecycle. Only the active registry ids become generic
`milestone-loop-core-invariants.v1` and
`milestone-loop-shadow-scope-policy.v1`; explicit historical v1 records retain
their legacy identity. Because the protected human plan intentionally makes
the source checkout unclean, the workflow ran in a clean temporary clone of
the exact candidate and only its independently matched deterministic manifest
bytes returned to the source tree.

**Why.** Commissioning is a trust transition, so accepting hand-authored
output, wall-clock metadata, a dirty-tree exception, branch inference,
overwrite-style rename, silent authority repair, or implicit historical
fallback would make provenance ambiguous. A single absent-file publication
boundary permits deterministic output and exact rollback ownership without a
multi-file transaction.

**Affected files.** Commissioning contract/CLI/tests, manifest and doctor
validation, source config/registries/input/active manifest, package command,
combined schema, adoption and contract documentation, and WP4b plan/logs.

## 2026-08-15 — Generic active verification commissioning boundary (WP4a)

**Decision.** New in-flight verification commissioning uses the strict
`verification-manifest.v2` shape at `.agent/verification-manifest.json`. Its
generic commissioning identity binds an exact base commit, canonical timestamp,
and `bootstrap` or `readiness` profile; that profile must equal
`package.json#milestoneLoop.verification.defaultProfile`. Exact closure remains
literal no-argument `pnpm verify`, and the existing `exact-readiness` wire check
id stays stable compatibility data even though the exact result profile may be
bootstrap or readiness. Tier results remain non-authoritative at schema `1.2.0`;
all reconciliation/adoption paths still require readiness evidence explicitly,
so bootstrap can never satisfy autonomous readiness.

The frozen `verification-manifest.v1` source and Ski Tycoon records are legacy
types accepted only through closed, purpose-named historical loaders. Source
reconciliation alone may adapt the source record to the generic tier input; the
adapter adds the current protected floor and generic reconciliation minimum but
does not rewrite historical bytes; its generic `createdAt` is the canonical Git
commit timestamp of that retained record, not an invented historical event.
There is no implicit v1 fallback. The
published combined JSON Schema advances to `2.0.0` because its manifest branch
is replacement-incompatible, while its tier-result branch continues to require
wire schema `1.2.0`.

**Why.** A D-031/D-032 literal cannot commission a reusable loop, and an exact
command whose profile is duplicated in a manifest can drift from the package
authority. Separate active and historical boundaries make provenance explicit,
while resolving the exact profile from the package default avoids override
semantics without weakening the one-way readiness gate. Alternatives rejected:
accepting v1 for new work, silently translating any supplied legacy path,
rewriting the frozen source record, treating bootstrap as readiness, renaming
the stable exact check id in this slice, and migrating the live source before
the WP4b commissioning workflow exists.

**Affected files.** Manifest contracts/validators/schema, configuration and
profile loaders, tier construction and CLI, historical benchmark and
reconciliation callers, startup/doctor/safety protected-root checks, focused
fixtures/tests, `README.md`, `CONTRACT.md`, and configuration documentation.

## 2026-08-14 — Docker-attested disposable OCI data plane (WP3d)

**Decision.** Trusted candidate execution now uses Docker Engine through one
fixed, versioned executor. Version 1.0.0 rejects Podman at capability policy
evaluation because its interpreted create/inspect semantics have not been
implemented or exercised. There is no implicit Windows-to-WSL or local
fallback. Every command begins with a new origin-free, no-alternates,
no-hardlinks clone of the exact clean candidate commit and creates a uniquely
named candidate container, read-only artifact-exporter container, and two
uniquely named Docker local-driver tmpfs volumes. Containers and volumes are
removed and their absence independently inspected after every outcome; only an
immutable image whose controller-owned input labels match may be reused.

The candidate sees exactly two read-only host binds: the disposable source
clone and the controller's pnpm v11 store. Its mutable workspace, evidence, and
temporary filesystems are bounded container-local storage. The root filesystem
is read-only; the process is `65532:65532`, has no network, capabilities,
new-privilege path, host PID/IPC namespace, port/device/socket, host home,
credential, target, or controller-state mount, and has fixed CPU, memory, PID,
file, and core limits. Before launch, image identity/labels, bounded-volume
options, and Docker's interpreted container policy are parsed independently of
the argv builder. Randomized candidate/exporter names must be proven unused
before create; once a create request is attempted, cleanup and absence
confirmation run even when the client response is interrupted or malformed.
The real hang case is accepted only after a controller-retained descendant PID
marker proves that setup completed before the bounded deadline fired.
The exporter starts before the candidate and keeps the tmpfs
volumes alive after candidate exit while exposing them read-only; a fixed
in-container preflight rejects links, special files, and combined size/count
breaches before any host copy. Publication then uses an exclusively opened
destination inode plus repeated size/hash checks.

Dependency installation is offline with a frozen lockfile, read-only frozen
store, explicit store-integrity verification, and copy materialization. The
lockfile is a mandatory protected trust root. `--trust-lockfile` is required so
pnpm 11 does not attempt network-backed supply-chain-policy revalidation inside
the deliberately networkless container; it does not make the store writable or
relax the frozen lockfile. Controller-owned containment evidence records the
Docker server version, exact image ID/input hash, candidate commit/tree,
capability identity, interpreted policy, lifecycle, bounded-volume cleanup,
and artifact inventories.

**Why.** A daemon-owned container can survive termination of its client, and a
plain bind-mounted writable clone cannot be bounded by bytes or inodes. Explicit
daemon stop/kill/remove plus Docker-managed tmpfs volumes makes termination and
storage limits inspectable. A minimal read-only helper preserves the volumes
long enough for export without making candidate containers reusable. Alternatives
rejected: host writable workspaces/evidence (unbounded host authority), copying
from a stopped tmpfs-backed container (Docker releases its tmpfs mount),
auto-remove (prevents post-exit inspection/export), a writable/shared pnpm store
(cross-command mutation), and claiming Podman or WSL equivalence from mocked
argv alone.

**Known residuals.** Real containment is currently evidenced on Docker Engine
29.1.3 under WSL2 Linux, not by the Windows controller and not on Podman or a
native POSIX CI host. The default template intentionally has no configured
image ID, so doctor remains `NOT_READY` until commissioning supplies one.
Product placeholders, calibration, autonomous readiness, hidden validation,
and human verification remain open.

**Affected files.** `container-executor.ts`, `container-image.ts`,
`container-artifacts.ts`, `verification-clone.ts`, their semantic and real OCI
fixtures/tests, execution-provider wiring, command/report contracts, package
scripts, configuration documentation, `CONTRACT.md`, and `README.md`.

## 2026-08-14 — Fail-closed candidate execution provider control plane (WP3c)

**Decision.** Candidate-authored focused verification and exact aggregate
commands now resolve through one controller-owned execution-provider boundary.
`trusted-container` is the default and every legacy config migration selects
it; until WP3d supplies the pinned OCI executor, it returns a deterministic
NOT_READY/infrastructure result before invoking any candidate launch function.
`unsafe-local-diagnostic` exists only as explicit controller configuration,
uses the WP3a/WP3b bounded supervisor, records host-inherited network and the
absence of image/mount containment, and is always completion-ineligible. There
is no automatic fallback between modes.

Provider evidence uses one strict, versioned identity containing mode,
implementation, runtime, image digest, mount-policy version, resource profile,
network disposition, capability identity/status, and completion eligibility.
The controller overwrites candidate-supplied identity and every
completion-relevant parse, review, target-integration, readiness-history, and
reconciliation boundary validates semantic equality with the authoritative
identity. Direct focused diagnostics are explicitly unattested/ineligible.
Legacy stored evidence migrates to `null`/unattested rather than being blessed;
a legacy pending target-integration operation with no provider attestation is
preserved as blocked with an `execution-provider-ineligible` diagnostic.
Doctor reports implementation, runtime, pinned image, and policy facts
independently, so runtime discovery cannot imply a complete trusted capability.

**Why.** A bounded host process is not containment, and candidate evidence
cannot attest the boundary that executed it. Making policy and identity
controller-owned closes the adoption/control-plane gap now while failing
honestly until the separate WP3d data-plane executor exists. Alternatives
rejected: implicit local fallback (would silently weaken containment), treating
Docker/Podman discovery as readiness (does not prove the executor/image/policy),
accepting structurally similar candidate identity (self-attestation), and
retroactively marking legacy local evidence trusted (fabricated provenance).

**Known residuals.** WP3c does not implement OCI/native containment,
disposable clones, mount construction, resource enforcement, or adversarial
escape coverage. The two POSIX-only process-tree tests remain explicit WP5
skips on Windows. Product placeholders, calibration, autonomous-readiness, and
human-verification gates remain open; no completion/readiness claim is made.

**Affected files.** `execution-provider-identity.ts`, `execution-provider.ts`,
config/schema/state/verifier/tier/integration/reconciliation/doctor paths and
tests, `scripts/verify.mjs`, default/example configs, `CONTRACT.md`, and
`README.md`.

## 2026-08-08 — Shared supervision at verifier and evidence trust roots (WP3b)

**Decision.** Every process launch owned directly by `scripts/verify.mjs` or
`tools/evidence.mjs` now resolves through the existing WP3a
`superviseCommand` boundary. The protected verifier uses finite identity and
stage-command timeouts, the shared per-stream output cap and kill grace, and
adds the complete supervision disposition to each launched-command record
without changing schema `2.1.0`, stage/profile meanings, status weights,
receipt validation, identity-drift rules, immutable-lock validation, or
completion eligibility. Evidence helpers use one asynchronous result adapter;
their callers await it explicitly, timeout or output breach remains
non-passing, and retained stdout/stderr is redacted before any console, log,
manual report, or error write. Package scripts launch the exact pnpm JavaScript
entry under the already selected Node executable so the supervised process is
the real package-manager root and the Node/pnpm pins stay observable. The
supervisor remains directly loadable by plain Node `24.18.0`, and its output
limit and kill-grace defaults have one runtime owner.

Isolated trust-boundary fixtures copy their exact transitive dependencies and
pinned package-manager state. In particular, verifier identity fixtures copy
the shared supervisor plus lockfile, while the production-build PASS-receipt
fixture copies the explicit repository-relative evidence-wrapper dependency
graph, including the supervisor, and creates nested destinations before copy.
This keeps missing dependency edges deterministic instead of allowing a host
checkout to mask them.

**Why.** WP3a bounded orchestrator-owned commands, but these two launch owners
still used bespoke `spawn`/`spawnSync` paths with unbounded capture, direct-child
timeout handling, or no timeout at all. Reusing the same supervisor makes cap,
redaction, tree termination, drain cutoff, exactly-once settle, and honest
`rootExitObserved` behavior consistent across controller, authoritative
verifier, and evidence commands. Executing pnpm through its JavaScript entry
avoids inserting a shell or shim process that would blur ownership and
termination evidence. Alternatives rejected: retaining synchronous probes
(unbounded and unsupervised), wrapping shell/shim launchers (ambiguous process
root), duplicating limits in the verifier/evidence layers (configuration
drift), and weakening isolated fixtures after the new import (would hide a
real packaging dependency).

**Known residuals.** This does not add OCI containment or execution-provider
identity, prove POSIX behavior, convert unrelated repository launch sites,
or change the previously recorded WP3a platform escape residuals. The two
POSIX-only supervisor tests remain explicit WP5 skips. No unsupported-platform,
product-completion, or autonomous-readiness claim is made.

**Affected files.** `scripts/verify.mjs`, `tools/evidence.mjs`,
`tools/run-tool-evidence.mjs`,
`tools/milestone-orchestrator/src/process-supervisor.ts`, `contracts.ts`,
`aggregate-verify-identity.test.ts`, `evidence-supervision.test.ts`, and
`tools/production-build.test.mjs`.

## 2026-08-07 — Supervisor drain cutoff and honest termination facts (WP3a review fix)

**Decision.** Independent review of the WP3a supervisor found three defects,
fixed as follows. (1) A per-stream cap breach that arrives while the runner
is draining after root exit now cuts the drain off immediately: the straggler
sweep runs at the breach (POSIX group SIGKILL; recorded as unavailable on
Windows behind a dead root), streams are destroyed, and the command settles
with a new `drainCutoff: "output-limit"` disposition — a breaching writer
that then closes its pipes can no longer skip the sweep, and the previous
behavior (`outputLimitExceeded` set with no termination action) is a tested
regression. (2) The spawn call is wrapped so a synchronous throw resolves an
ERROR-shaped result with `spawnError` set, restoring the never-rejects
contract end to end. (3) `termination.succeeded` was renamed to
`rootExitObserved` because that is all it ever proved: root exit after kill
initiation. No field claims tree-wide termination success; per-attempt
outcomes stay in `detail`, and tree-level assurance remains test-proven
(grandchild liveness polls), not runtime-claimed. The runner's breach
message distinguishes pre-exit tree termination from a post-exit drain
cutoff. Alternatives rejected: fabricating a termination record for a root
that exited naturally (misrepresents what acted), waiting out the drain
window on a post-exit breach (delays settle for no benefit and loses the
sweep when writers close first), and keeping a boolean named `succeeded`
with documentation-only caveats.

**Affected files.** `tools/milestone-orchestrator/src/process-supervisor.ts`
and tests, `command-runner.ts` and tests, `contracts.ts`.

## 2026-08-07 — Bounded process supervisor for controller commands (WP3a)

**Decision.** All controller-spawned verification commands run through one
shared supervisor (`process-supervisor.ts`) adopted by
`command-runner.ts#runCommand`. Output is retained in memory up to a
configured per-stream cap (`limits.commandOutputLimitBytes`, default 64 MiB),
then redacted and written once; bytes past the cap are counted but never
retained, a breach terminates the process tree and fails the command in the
existing infrastructure lane, and the truncation disposition (retained and
observed byte counts plus a marker line covered by the recorded SHA-256) is
explicit. Timeout and breach own the complete tree: Windows issues a
force-first `taskkill /pid <pid> /T /F` while the tree is intact, then falls
back to `child.kill()`; POSIX spawns the child detached as a process-group
leader and sends group SIGTERM escalating to group SIGKILL after
`limits.commandKillGraceMs` (default 5000 ms). Settle is exactly-once and
hard-bounded (`timeoutMs + 2 x killGraceMs`) through a drain window for
streams held open after exit and an abandonment backstop when no exit is ever
observed; a drain-expired command keeps its exit-code status with
`streamsClosed: false`/`drainTimedOut: true` recorded because receipts, not
stdout logs, gate semantic PASS. The summary carries a full `supervision`
record. Config schema is `1.5.0`; older configs migrate with defaults
injected.

**Why.** Audit CR-02 (P1/high): the runner buffered output without bound,
sent SIGTERM to the direct child only, and settled only on stream `close`, so
a SIGTERM-ignoring child or a pipe-holding descendant hung the controller and
a flood exhausted memory. Probing on Node 24.18.0/win32 (2026-08-07) fixed
two platform facts the design relies on: a non-detached Node grandchild dies
with its parent through libuv's kill-on-close job object, while a detached
grandchild escapes the job object, survives, and holds the inherited pipe
open indefinitely — the exact hang shape. Windows kill ordering is
force-first because `taskkill /T` walks live parent chains (a dead root
enumerates nothing) and WM_CLOSE is meaningless for hidden console children;
the summary's `signal` on Windows timeouts is therefore `null` with the
taskkill exit code, which no consumer misreads (all gate on `signal === null`
plus a specific exit code). Bounded in-memory capture-then-redact was chosen
over the improvement plan's stream-to-file mechanism so no unredacted byte
ever reaches disk; the plan's properties (bounded memory, bounded logs,
recorded disposition) are preserved, and truncation trims to a newline
boundary so a split secret prefix is never retained. The drain and abandon
windows reuse `commandKillGraceMs` rather than adding a third knob because
required config keys are expensive across the strict schema. Alternatives
rejected: Windows Job Objects (native bindings; owned by the container
slice), graceful-then-tree ordering on Windows (orphans grandchildren before
`/T` can see them), automatic local fallback on kill failure (records the
failure instead), and failing drain-expired exit-0 commands (receipts already
gate PASS; stragglers are recorded, and common toolchains leave benign ones).

**Known residuals.** Descendants reparented before the kill and PID reuse can
escape `taskkill /T`; a straggler that outlives the drain window on Windows
cannot be swept through a dead root; a fully detached (setsid) POSIX daemon
escapes group kills. All are recorded dispositions, strictly narrower than
the prior unbounded behavior, and owned by the WP3 container slice. POSIX
supervision paths are written but first execute in WP5 Linux CI; the skipped
tests are flagged `WP5`.

**Affected files.** `tools/milestone-orchestrator/src/process-supervisor.ts`
(new) and its tests, `command-runner.ts`, `contracts.ts`, `schema.ts`,
`config.ts`, `verifier.ts`, `reconciliation.ts`, `orchestrator.ts`,
`test/fixtures.ts`, `config/default.json`, `config/default.template.json`,
`examples/ski-tycoon/default.json`, `config/README.md`, `CONTRACT.md`.

## 2026-08-06 — State-owned approval-bound retention apply (WP2d)

**Decision.** State schema `1.8.0` extends the exclusive pending-operation
union with one global `retention-apply` intent. A strict plan `1.2.0` captures
the exact committed candidate and a SHA-256 fingerprint of tracked, staged,
unstaged, and non-ignored untracked bytes. After the operator approves the
complete plan bytes, apply revalidates controller state, candidate,
configuration, roots, citations, suspensions, and exact target manifests,
then publishes an intent bound to the full plan hash and canonical input
generation before creating apply evidence or deleting a run. Every target
enters durable delete-started state first. The JSONL journal and deterministic
result are synced, exact operation-derived evidence; neither a journal line,
missing path, plan pathname, nor prior result is authority. Recovery completes
only an exact canonical prefix, blocks and preserves conflicts, and adopts a
missing target only from delete-started state. Explicit apply and leased
startup use the same recovery path before other controller mutation, while one
pure reducer records retention completion and removes the intent. Status and
doctor remain read-only. The existing contained recursive-removal helper and
terminal workspace-cleanup semantics are unchanged.

**Why.** The former hash-approved command still transferred authorization to
unbound filesystem text: a forged `deleting` line could make a missing run
look resumable, a torn final append became interior corruption on the next
write, and process loss after deletion or result publication had no canonical
state phase to recover. Partial plan validation and a dirty boolean also failed
to bind exact approved bytes. State-first per-target authorization makes every
irreversible removal attributable, while deterministic derived evidence makes
all declared crash boundaries converge without introducing a second log
authority. Alternatives rejected: journal-owned recovery, hash-prefix apply
directories, adopting any missing approved path, truncating conflicting JSONL,
overwriting result conflicts, weakening freshness checks after intent, adding
automatic deletion to `loop:run`, or changing workspace-cleanup policy.

**Affected files.** Retention plan/apply contracts and tests, state contracts,
runtime/JSON schema and migration, operation reducers and lineage checks,
orchestrator startup/CLI/status/doctor routing, crash/recovery workers and
evidence, `README.md`, and `CONTRACT.md`.

## 2026-08-06 — Intent-first terminal workspace cleanup (WP2c)

**Decision.** State schema `1.7.0` extends the exclusive pending-operation
union with a strict `workspace-cleanup` intent. The controller publishes that
intent before removing `node_modules`, creating failed-run diagnostic entries,
or deleting a workspace. It advances through explicit dependency, archive,
and deletion phases, pins exact diagnostic hashes and completion timestamps,
and recovers under the controller lease before ordinary terminal cleanup. A
missing workspace is adoptable only after durable delete authorization, and a
failed workspace is deletable only after its complete archive exactly matches
the intent. One pure reducer owns every terminal cleanup state consequence.
Ambiguous workspace, Git, path, or archive facts are preserved and durably
blocked; status and doctor only classify them read-only. Completed cleanup
requires the observed HEAD to equal the terminal milestone record. Failed
cleanup retains that recorded fact but separately pins the exact observed
descendant, because candidate drift may itself be the recorded failure.

**Why.** The previous pending flag was written before cleanup but did not name
an exclusive operation or fence unrelated state. Process loss after recursive
deletion therefore left state behind the filesystem, and restart sampled new
timestamps while accepting missing completed workspaces or a lone failed-run
manifest as sufficient proof. Intent-first phases make each destructive effect
attributable and exactly classifiable, while deterministic archive bytes and a
shared completion reducer make restart converge. Alternatives rejected:
reconstructing authorization from the legacy cleanup flag, using archive
existence as authority, accepting a missing workspace before a delete phase,
overwriting conflicting diagnostic files, deleting substituted paths, and
combining cleanup with approval-bound evidence retention.

**Affected files.** State contracts/schema/store and JSON schema,
`operation-intent.ts`, `workspace-cleanup-operation.ts`, orchestrator cleanup
and startup recovery, status and doctor diagnostics, crash/race workers and
recovery tests, `README.md`, and `CONTRACT.md`.

## 2026-08-06 — Intent-first target integration and canonical completion (WP2b)

**Decision.** State schema `1.6.0` extends the single pending-operation union
with a strict `target-integrate` intent. The controller publishes that intent
after exact candidate, approval, verification-result, commit-list, and
protected-file validation but before outcome, fetch, ref, index, or worktree
side effects. The operation pins one deterministic pending/integrated outcome
encoding and advances through explicit artifact/target phases. Recovery runs
under the controller lease before ordinary target-drift handling, revalidates
the standalone candidate on every pass, resumes only from the exact clean
base, and adopts only the exact clean candidate. One pure completion reducer
owns every semantic state consequence. Any other target, candidate, path, Git,
or outcome classification is preserved and durably blocked. Reviewer approval
without the intent no longer permits implicit integration reconciliation.

**Why.** The previous fast-forward happened before canonical completion state,
so process loss could leave the target at the candidate while state still
reported the base and a reviewing milestone. Startup then used a second
handwritten reviewer-as-intent path that omitted vertical-consumer state,
processed count, final outcome, and stop bookkeeping. Intent-first ordering
makes the external side effect attributable before it can happen; deterministic
outcome bytes and exact base/candidate classification make every observable
restart state decidable. A shared reducer prevents normal and recovered paths
from drifting semantically. Alternatives rejected: retaining reviewer approval
as implicit intent, using `git-outcome.json` as authority, resetting or cleaning
an ambiguous target, accepting any descendant target, a second integration
journal, and separate normal/recovery completion mutations.

**Affected files.** State contracts/schema/store and JSON schema,
`operation-intent.ts`, `readiness-completion.ts`, `target-integration.ts`,
orchestrator integration/startup, status and doctor diagnostics, crash/race
workers and recovery tests, `README.md`, and `CONTRACT.md`.

## 2026-08-06 — Intent-first, validate/adopt workspace creation (WP2a)

**Decision.** Isolated workspace creation is represented by one exclusive
state-schema `1.5.0` `workspace-create` operation bound to the exact pre-intent
Git state generation. The controller clones only after that intent is
canonical, uses a unique short `.create-<sha256-prefix>` entry under the
configured workspace root, records adjacent durable phases around filesystem
boundaries, and publishes to the stable run/milestone path with no-clobber
rename semantics. Recovery runs under the controller lease before ordinary
orchestrator mutations. It resumes or adopts only after exact filesystem and
Git validation; ambiguous entries remain in place with a durable blocked
diagnostic. Read-only status and doctor expose the same classification and
next safe action without recovery. Canonical `1.4.0` generations are migrated
in memory and advance to `1.5.0` only on the next CAS save.

**Why.** Direct cloning to the final deterministic path left an unrecorded
directory after a crash between clone and workspace-record persistence, and a
retry could neither prove ownership nor proceed. Intent-first ordering gives
every possible controller-created entry a durable identity, while a temporary
publication boundary separates incomplete clones from adoptable final state.
The short hashed temporary name preserves Windows path headroom for Git ref
lock files without weakening uniqueness. Preserving suspicious content is the
only fail-closed default that does not destroy possible user evidence.
Alternatives rejected: direct final-path clone, deleting or overwriting an
unrecognized path, treating path existence as ownership, reusing the state
mirror as a journal, a second operation-log authority, and automatic
quarantine moves whose source identity cannot be proved race-free.

**Affected files.** State contracts/schema/store, `operation-intent.ts`,
`workspace-create.ts`, orchestrator startup and attempt creation, status and
doctor diagnostics, Git-isolation fixtures, tests, `README.md`, and
`CONTRACT.md`.

## 2026-08-05 — Ref-rooted Git commits as canonical state generations (WP1b)

**Decision.** Canonical controller state lives at the fixed local ref
`refs/milestone-loop/state`. Each target is a strict commit with exact
`state.json` and `metadata.json` blobs, an optional byte-exact
`legacy-state.json`, and one parent naming the prior generation. Creation pins
the controller identity, timestamp, and message; reading validates those facts
plus state schema/hash/revision, exact successor relation, parent, and tree.
Publication uses the exact loaded object ID as the expected old ref. The
configured JSON path is a replaceable human mirror, never a second authority.
Only `initialize()` and `loadForMutation()` arm a `StateStore` for publication;
`load()` is capability-read-only. Doctor diagnostics advanced to schema
`1.2.0` to expose the state ref, generation, source, and mirror disposition.

**Why.** Git is already a required cross-platform dependency and its ref CAS
closes the lost-update window without introducing a second lock protocol.
Commit ancestry keeps the previous generation reachable and inspectable, while
ordinary branch pushes exclude the private namespace. Separating the mirror
allows post-publication repair without rolling back canonical state. Retaining
exact imported bytes preserves reconciliation evidence without running dual
writers. Alternatives rejected: relying on the controller lease alone,
revision-only rename fencing, file locks, treating the mirror as a fallback,
two-format canonical writes, automatic recovery from malformed canonical refs,
and permitting observational loads to authorize later saves.

**Affected files.** `private-ref-store.ts`, `state-generation-store.ts`,
`state-store.ts`, orchestrator/reconciliation/retention call sites, doctor and
status diagnostics, the safety demonstration, tests, `README.md`, and
`CONTRACT.md`.

## 2026-08-05 — Git private ref plus legacy-protocol guard for leases (WP1a)

**Decision.** Controller ownership lives at the fixed local ref
`refs/milestone-loop/controller-lease`; its target is a strict schema `2.0.0`
owner blob. All publication and deletion names an expected old object ID. The
old `controller.lease` pathname remains only as a permanent, recognizable
protocol guard whose foreign host-instance identity makes an older binary fail
closed. Any other legacy-path content blocks ref acquisition. The doctor
diagnostic was advanced to schema `1.1.0` to expose the canonical ref and guard
status.

**Why.** Git is already mandatory, provides tested cross-platform atomic ref
comparison, supports SHA-1 and SHA-256 repositories, keeps the active owner
object reachable, and does not push this namespace during normal branch
pushes. The guard closes the otherwise unavoidable overlap window where an
already-installed old binary could acquire the retired file lease while a new
binary owns only the ref. Alternatives rejected: rename/quarantine retries,
PID-only lock files, an unproved third-party lock package, automatic deletion
of ambiguous legacy files, and running dual lease writers.

**Affected files.** `tools/milestone-orchestrator/src/private-ref-store.ts`,
`controller-lease.ts`, `doctor.ts`, their tests, `README.md`, and `CONTRACT.md`.

## 2026-08-05 — Explicit, clean-clone production-build contract (WP0)

**Decision.** The root `build` script remains the controller-owned evidence
wrapper. Adopters declare a distinct real script and explicit output roots at
`package.json#milestoneLoop.productionBuild`. The wrapper builds the exact clean
commit in a disposable clone after a frozen offline copy-mode install, removes
pre-existing outputs, rejects mutation outside the declared roots and every
linked output, and records a twice-checked output hash inventory before writing
the receipt. Absence of the declaration is `NOT_READY`.

**Why.** Output conventions vary across adopting projects, so guessing `dist/`
or treating exit zero as proof would preserve the original false-positive path.
Building in the source checkout would allow stale ignored artifacts to satisfy
the check. Alternatives rejected: an echo/generated sentinel, timestamp-based
freshness, recursively invoking `build`, trusting a report without rechecking
its files, and silently selecting conventional output directories.

**Affected files.** `tools/production-build.mjs`,
`tools/run-tool-evidence.mjs`, `tools/production-build.test.mjs`, `README.md`,
`CONTRACT.md`, and `tools/milestone-orchestrator/config/README.md`.

## 2026-08-05 — Workspace toolchain re-install before verification (P0.7 / A-1)

**Decision.** `verify()` re-runs `pnpm install --frozen-lockfile --offline
--package-import-method=copy` in the isolated workspace between the Worker
turn and verification (`verification-reinstall` artifact in the attempt
directory).

**Why.** Gitignored `node_modules` content is invisible to every diff,
status, identity, and protected-hash fence, so a Worker with workspace write
access could otherwise leave a tampered toolchain in place for verification
to execute. The frozen offline re-install reconciles the modules directory
with the lockfile-bound store first.

**Known residual.** pnpm skips packages whose recorded install state still
matches, so a byte-level edit inside an installed package that preserves
pnpm's metadata can survive the re-install. Full denial of workspace
`node_modules` writes belongs to process sandboxing (audit R-01 / P1.1).
Alternative considered: `--force` re-copy on every verification — rejected
for now as a large per-attempt cost for a partial gain; revisit with R-01.

**Affected files.** `tools/milestone-orchestrator/src/orchestrator.ts`
(`prepareWorkspace` stage parameter, `verify()` head).
