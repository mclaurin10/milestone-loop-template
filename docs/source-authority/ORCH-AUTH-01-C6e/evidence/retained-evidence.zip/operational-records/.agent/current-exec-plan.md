# Current Execution Plan

Status: C6e source verification passed; evidence sealing/audit pending. Updated: 2026-09-07T05:10Z. Owner: authorized WP6e continuation.

## Objective

Finish and commit the compatible source readers, implementation-audit producer, independent review and recoverable leased publication under approved ORCH-AUTH-01 r2. The immediate public consumer is `pnpm loop:authority:migrate`. Close the current verification and retain independently audited evidence, then identify a clean committed checkpoint for continuation in a fresh task. Actual audit/request/review/activation and candidate obligations remain subsequent required work.

## Goal Constraints

Preserve the frozen authorities, original tests, acceptance meanings, deadlines, readiness history and protected commands/workflows. Approved digest `53d38a2c2038cd9c5ffc240275043709d23dd33a81237e3d12018a38a8378108` is settled; follow [transition safeguards](../docs/proposals/ORCH-AUTH-01-r2/TRANSITION-CONTRACT.md). Approval is not activation. No source controller initialization/adoption, implicit commit/reset, deadline relaxation or WP6f interpretation. Historical WP6e remains BLOCKED at `e590e38c32de2b5baa7423f66bbd8a0230b61839`. Root-unit success does not establish unit-domain success. Linux, native Windows, Server 2022, readiness and human acceptance remain distinct.

## Baseline Evidence

- Primary `master` HEAD: `fc2419d8bdfc3658fe76edf2b543b38051b359f1`; tree: `e8afdd61b47db88f4c6964b77c90ee8db9c1b4b1`. There are 56 unstaged C6e paths (43 source/config and 13 plan/log/documentation), plus the excluded user roadmap; nothing staged. Five original stashes remain.
- Isolated verification commits, in order: `082e4369a8e637243ff45e9e66d368452c74eced` -> `1c386ec95b628a2323f8d5dab351ad72a59abe3a` -> `2fa66568407594523380ec33c063cdf52e4c6d2d`. Latest tree: `a66441b9156667a0a18d44a102f30caad9ee9c3b`. Owned checkout `.tools/wp6e-c6e-unborn-precommit-20260907` is clean on `master`; all 331 executing source/test/config pins match the primary inputs. These are separate from the eventual primary completion commit.
- Legacy authority remains active; C4 inert snapshot `91cbd3eb75ec771cfa1f315fe2641488e361c9e0` is a strict ancestor. No real implementation audit, committed request, SDK review, publication/activation, candidate, mutation proof or source state/private ref exists in primary.
- Preserve `Implementation-ready improvement plan 8-5-26.txt` outside commits, SHA256 `53ea98fb1cb880163a02d3b1d9365963e3fe891025ae3630f00bd4c9232293b1`.

## Steps

1. Complete: implement and regress source evidence/review/publication, committed consumers, unborn-legacy compatibility and strict typed Git-object reads. Preserve every original test body and failure cohort.
2. Complete: the unchanged ten-file native suite passed all 266 cases at clean `2fa6656`, with original deadlines and all 331 pins unchanged. Both earlier failed attempts remain retained separately.
3. **In progress:** static-10 passed; curate all relevant observations and execute the independent retained audit. Commit cohesive verified C6e code/tests/docs and record the clean fresh-task checkpoint. Exact clean post-commit retained audit/consumed build and all five hosted jobs remain mandatory; record any unexecuted ones as the next task's obligations.
4. Later required increments: actual eight-command implementation audit; separate committed request; fixed independent SDK review; leased recoverable publication and explicit activation commit. Then qualify a longer finite host, run the real eleven-check candidate with four independently validated partition receipts, reconcile exactly-once/historical identities and actual provider timeout, and execute committed 5(a)/5(b) rejections. No state initialization/adoption.

## Acceptance Criteria

Readers agree on authenticated committed generations and reject unknown, missing, mixed, pending and rolled-back publication. Fresh independent review and a separate committed request precede the lease and exclusive fsynced intent. Real fault/concurrency boundaries preserve foreign bytes, prior/new states and original/fresh review provenance. Complete affected files and applicable broader commands must pass with command-owned receipts and independently checked artifacts. Retained failed runs remain failures. The eventual exact clean commit and hosted evidence must be identified; no current result establishes candidate/readiness/human acceptance.

## Verification

Use Node 24.18.0 and pnpm 11.15.1: prepend `.tools/node-v24.18.0-win-x64` to PATH and pass `--config.verify-deps-before-run=error`. Keep source verification sequential and freeze the 331 executing pins. No visual change. Never rerun completed work solely to reconstruct context; inspect its receipts, raw reports and input identity.

The corrected native driver has finished; do not rerun it for context. Final retention: `docs/source-authority/ORCH-AUTH-01-C6e/curate.ps1`, then the archive extraction and `pnpm ... exec tsx docs/source-authority/ORCH-AUTH-01-C6e/audit.ts <fresh-input> <fresh-output>` procedure in its [README](../docs/source-authority/ORCH-AUTH-01-C6e/README.md). Curation and full retained audit are still unexecuted. Use fresh `artifacts/c6e-precommit-retained-input-1` and `artifacts/c6e-precommit-retained-audit-1` for the first complete archive audit.

## Risks and Recovery

Native attempt 1 reached five test and three hook deadlines at the unchanged 180000ms limits; contention is only a hypothesis. Attempt 2 is invalid due to leaked receipt IDs and supplies no full-suite result. Preserve both. No concurrent source suite or VM during the corrected retry. Use ordinary source control and owned paths for recovery; do not change shared services/packages/accounts/configuration. The original C3 host is too short for a later 3900000ms partition allowance; retain it unchanged and qualify a separate finite host. Schedule metadata alone cannot prove timeout propagation to the actual provider.

## Progress and Evidence

Evidence root `E` = `artifacts/wp6e-source-publication-20260906`. Historical detail belongs in [autonomy log](../docs/autonomy-log.md) and [decision log](../docs/decision-log.md).

| Observation | Verified result / evidence |
| --- | --- |
| Clean Linux source checks at `2fa6656` | All nine PASS: 1076 controller cases, 1250 root cases / 101 files, consumed build; owned service/cgroup gone. Independent [precommit receipt](../artifacts/wp6e-source-publication-20260906/precommit/result.json): `aed573837d5de96108d17e90949f8aee2c9023069eee6902ecf719f35a3e1b98`. |
| Same-input C3 OCI | Six actual cases PASS; independent [host](../artifacts/wp6e-source-publication-20260906/precommit/vm/host-audit/result.json), [OCI](../artifacts/wp6e-source-publication-20260906/precommit/vm/oci-audit/result.json) and [cleanup](../artifacts/wp6e-source-publication-20260906/precommit/vm/cleanup-audit/result.json) receipts. Separate runtime, no long source suites. |
| Native bounded repair | [130 cases / six files](../artifacts/wp6e-source-publication-20260906/unborn-scope-focused-6/result.json), [typecheck-28](../artifacts/wp6e-source-publication-20260906/typecheck-28/result.json) and [lint-17](../artifacts/wp6e-source-publication-20260906/lint-17/result.json) PASS. |
| Earlier complete regressions | Original 203 cases / frozen-input audit and revised 260 cases / dependency and input audits PASS with their own identities; retained under E. |
| Native attempt 1 | [Full report](../artifacts/wp6e-source-publication-20260906/unborn-publication-focused-1/vitest-report.json): 258 PASS / 8 FAIL / 266, no pending/todo; ERROR, no PASS receipt. Dirty-primary observation. |
| Native attempt 2 | Invalid wrapper: 4 PASS / 6 FAIL / 10 partial cases; no full report/run-end/PASS. [Independent retained inspection](../artifacts/wp6e-source-publication-20260906/invalid-native-retry-audit-1/result.json) PASS, receipt `d9fe970c3ecee6cc1e63a92a68e0d827fed6f8042d523895b5983b4d8506ed79`, checks 37 files, the byte-preserving collection and [targeted stop](../artifacts/wp6e-source-publication-20260906/unborn-publication-focused-2/termination/scope-observation.json). Overbroad diagnostic inventory stays private under retention-draft and excluded from curation. |
| Native attempt 3 | [Full PASS receipt](../artifacts/wp6e-source-publication-20260906/unborn-publication-focused-3/result.json): `fc0e082d5aa56450e46a0fa3b6d0771da280bfc632b87def7eb6817e82933824`; 266 cases / ten files, zero failed/pending/todo/unhandled. Clean `2fa6656`, all 331 before/after pins equal; 14 command files / 583878 bytes collected. |
| Retention tools | [Static-10](../artifacts/wp6e-source-publication-20260906/retention-tools-static-10/result.json) PASS (five commands / twelve pins), receipt `d2f056199253fa0fbc9dfdfae7a57a4db067d11cf7dec775fd8e17ff436f3949`. Curation now archives exact copies of the three operational plan/log files, allowing their live updates while every executable/input pin and original frozen reconstruction stays mandatory. Full behavioral retained audit remains unexecuted. |
| Primary parent hosted | Run `34047573294`: five protected jobs / 43 receipts audited PASS. This is `fc2419d` evidence, not future C6e evidence. |

Active jobs: **none**. Unified exec `79324` completed/collected exit 0 at 05:08:36 UTC; static-10 job `28921` is also closed. Native launch/collection records are in `E/unborn-publication-focused-3/launcher`; complete clone output remains at `.tools/wp6e-c6e-unborn-precommit-20260907/artifacts/c6e-native-retry-2`. No source suite or VM needs restarting.

## Next Action

Run curation, inspect/extract the sealed archive and execute the full retained audit against the fresh paths above. This must validate native raw identities, every receipt/artifact, all frozen/source inputs, Linux/OCI evidence, preserved failures and the new operational snapshots. Record actual outcomes before committing. Then identify the clean checkpoint and first pending action for a fresh task, with every unexecuted post-commit/hosted/activation/candidate gate explicit. Refresh this handoff from actual Git/job/evidence state at each meaningful checkpoint.
