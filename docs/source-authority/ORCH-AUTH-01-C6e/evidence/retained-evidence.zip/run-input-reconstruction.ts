import assert from "node:assert/strict";
import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { evidenceContext, writeReceipt, writeManualEvidenceFailure } from "../../tools/evidence.mjs";
import { inspectFrozenInputs } from "./retention-draft/inspect-frozen-inputs.js";
const context = await evidenceContext("wp6e-c6e", "frozen-input-reconstruction");
try {
  const result = await inspectFrozenInputs({
    repository: context.repositoryRoot,
    retainedRoot: resolve(context.repositoryRoot, "artifacts/wp6e-source-publication-20260906"),
    scratch: resolve(context.repositoryRoot, ".tools/wp6e-c6e-reconstruction-1"),
    subjectDirectory: resolve(context.repositoryRoot, "artifacts/wp6e-source-publication-20260906/precommit-vm-1/input"),
  });
  assert.equal(result.observedFiles, 650);
  assert.equal(result.reconstructedFiles, 649);
  assert.equal(result.explicitTextRepresentations.length, 13);
  assert.equal(result.reconstructedTree, "e45498ae34c9aa23ed17aceeea6f222fb854f518");
  assert.equal(result.isolatedPrecommitInputCommit, "082e4369a8e637243ff45e9e66d368452c74eced");
  await writeFile(resolve(context.artifactDirectory, "executed-helper.ts"), await readFile(resolve(import.meta.dirname, "retention-draft/inspect-frozen-inputs.ts")), { flag: "wx" });
  await writeFile(resolve(context.artifactDirectory, "report.json"), JSON.stringify({ schemaVersion: "c6e-frozen-input-reconstruction.v1", status: "PASS", ...result, completionEligible: false, precommitChecksExecuted: false, actualImplementationAudit: false, actualCandidate: false, sourceStateAdopted: false }, null, 2) + "\n", { flag: "wx" });
  await writeReceipt(context, [{ id: "actual-git-input-reconstruction", summary: "Reconstructed every included frozen input in an isolated Git object store/index, verified thirteen exact raw-to-LF text representations, and imported the real incremental bundle to prove the isolated precommit commit, tree and parent. No test or candidate rerun is claimed." }], [{ path: "report.json", kind: "c6e-frozen-input-reconstruction" }, { path: "executed-helper.ts", kind: "c6e-reconstruction-source" }]);
  console.log(JSON.stringify({ status: "PASS", reconstructedFiles: result.reconstructedFiles, tree: result.reconstructedTree, commit: result.isolatedPrecommitInputCommit, completionEligible: false }));
} catch (error) {
  await writeManualEvidenceFailure(context, { kind: "product", message: error instanceof Error ? error.stack : String(error) });
  throw error;
}
