"""Observe the pinned store around actual installs/checks in one owned Linux root.

No Docker, shared installation, service change or source edit. Failures and raw
observations are retained; this diagnostic is not host or source qualification.
"""
import hashlib
import json
import os
from pathlib import Path
import signal
import sqlite3
import subprocess
import tarfile
import tempfile
import time

repo = Path('/mnt/c/Dev/loop-extraction/milestone-loop-template')
receiver = repo / 'artifacts/wp6e-source-publication-20260906/store-diagnostic-1'
assert os.getuid() == 1000 and not receiver.exists()
receiver.mkdir()
(receiver / 'executed-diagnostic.py').write_bytes(Path(__file__).read_bytes())
root = Path(tempfile.mkdtemp(prefix='c6e-store-diagnostic-', dir='/home/duncan'))
(receiver / 'owned-root.txt').write_text(str(root)+'\n')
assert root.resolve() == root and root.parent == Path('/home/duncan')
source_input = repo / 'artifacts/wp6e-source-publication-20260906/precommit-vm-3/input'
payload = Path('/home/duncan/oc3-c6e-yl2ydymm/input')
node = Path('/home/duncan/oa1-CKn8x9/node-v24.18.0-linux-x64/bin/node')
def digest(path, algorithm='sha256'):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, algorithm).hexdigest()
assert digest(node) == '41a74efb34cbde5c7632cdac0cf8bd1a14d0b8d73dc1e82755014d9a9ce70f5c'
pins = json.loads((payload/'input-manifest.json').read_bytes())['files']
inspections = []
for name, destination in [('pnpm.tgz','pnpm'),('pnpm-cache.tar','cache'),('store.tar','store')]:
    item = next(pin for pin in pins if pin['path']==name)
    path = payload/name
    assert path.is_file() and not path.is_symlink() and path.stat().st_size==item['bytes'] and digest(path)==item['sha256']
    target = root/destination
    target.mkdir()
    with tarfile.open(path) as archive:
        members = archive.getmembers()
        total = 0
        for member in members:
            relative = Path(member.name)
            assert not relative.is_absolute() and '..' not in relative.parts
            assert member.isdir() or member.isfile() or member.issym() or member.islnk()
            assert member.size <= 160_000_000
            total += member.size
        assert total <= 700_000_000
        inspections.append({**item,'members':len(members),'expandedBytes':total,'destination':str(target)})
        archive.extractall(target,filter='data')
(receiver/'input-inspection.json').write_text(json.dumps({'archives':inspections,'nodeSha256':digest(node),'source':json.loads((source_input/'source.json').read_bytes())['source']},indent=2)+'\n')
account = root/'account'
config = account/'.config/pnpm/config.yaml'
config.parent.mkdir(parents=True)
config.write_text('enableGlobalVirtualStore: false\nstoreDir: '+str(root/'store')+'\n')
binary = root/'bin'
binary.mkdir()
(binary/'node').symlink_to(node)
pnpm = binary/'pnpm'
pnpm.write_text('#!/bin/sh\nexec '+str(node)+' '+str(root/'pnpm/package/bin/pnpm.mjs')+' "$@"\n')
pnpm.chmod(0o755)
env = {'PATH':str(binary)+':/usr/bin:/bin','HOME':str(account),'LANG':'C','LC_ALL':'C','CI':'true','pnpm_config_store_dir':str(root/'store'),'pnpm_config_cache_dir':str(root/'cache'),'COREPACK_ENABLE_NETWORK':'0'}
(receiver/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
records = []
def run(name, argv, cwd=None, timeout=300, required=True):
    started = time.time_ns()
    monotonic = time.monotonic_ns()
    timed_out = False
    with (receiver/(name+'.stdout.log')).open('xb') as stdout, (receiver/(name+'.stderr.log')).open('xb') as stderr:
        child = subprocess.Popen(argv,cwd=cwd or root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        try:
            code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGTERM)
            try: code = child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid,signal.SIGKILL)
                code = child.wait(timeout=5)
    record = {'name':name,'argv':[str(value) for value in argv],'cwd':str(cwd or root),'uid':os.getuid(),'startedEpochNanoseconds':str(started),'durationMs':round((time.monotonic_ns()-monotonic)/1e6),'exitCode':code,'timedOut':timed_out}
    records.append(record)
    (receiver/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    (receiver/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    if required: assert code == 0 and not timed_out, name
    return code
run('node-version',[node,'--version'])
run('pnpm-version',[pnpm,'--version'])
assert (receiver/'node-version.stdout.log').read_text().strip()=='v24.18.0'
assert (receiver/'pnpm-version.stdout.log').read_text().strip()=='11.15.1'
run('clone',['/usr/bin/git','clone','--no-hardlinks',str(source_input/'source.bundle'),str(root/'source')])
source = root/'source'
run('checkout',['/usr/bin/git','checkout','-B','master','082e4369a8e637243ff45e9e66d368452c74eced'],source)
run('remove-remote',['/usr/bin/git','remote','remove','origin'],source)
run('store-before',[pnpm,'store','status'],source,required=False)
run('source-install',[pnpm,'install','--frozen-lockfile','--offline','--package-import-method','copy'],source)
run('store-after-source-install',[pnpm,'store','status'],source,required=False)
def inspect_esbuild(name):
    entries=[]
    for package in sorted((source/'node_modules/.pnpm').glob('esbuild@*/node_modules/esbuild')):
        for relative in ['package.json','bin/esbuild','lib/main.js','install.js']:
            path=package/relative
            if path.is_file():
                info=path.stat()
                entries.append({'path':str(path),'bytes':info.st_size,'mode':oct(info.st_mode),'inode':info.st_ino,'links':info.st_nlink,'sha256':digest(path),'sha512':digest(path,'sha512')})
    database=root/'store/v11/index.db'
    connection=sqlite3.connect('file:'+str(database)+'?mode=ro',uri=True)
    schemas=connection.execute("SELECT name,sql FROM sqlite_master WHERE type='table'").fetchall()
    connection.close()
    (receiver/(name+'.json')).write_text(json.dumps({'installed':entries,'databaseSchemas':schemas},indent=2)+'\n')
inspect_esbuild('esbuild-after-source-install')
run('fixture-install',[pnpm,'install','--frozen-lockfile','--offline','--ignore-scripts','--ignore-workspace','--package-import-method','copy'],source/'fixtures/oci-candidate')
run('store-after-fixture-install',[pnpm,'store','status'],source,required=False)
inspect_esbuild('esbuild-after-fixture-install')
for name, command in [('typecheck','typecheck'),('lint','lint'),('format','format:check'),('architecture','lint:source-architecture')]:
    env['LOOP_VERIFY_COMMAND_ARTIFACT_DIR']=str(source/'artifacts/store-diagnostic'/name)
    run(name,[pnpm,'--config.verify-deps-before-run=error',command],source)
    run('store-after-'+name,[pnpm,'store','status'],source,required=False)
inspect_esbuild('esbuild-after-static-checks')
run('clean-after',['/usr/bin/git','status','--porcelain'],source)
assert (receiver/'clean-after.stdout.log').read_text()==''
(receiver/'observation.json').write_text(json.dumps({'schemaVersion':'c6e-store-diagnostic.v1','root':str(root),'commands':records,'completionEligible':False,'sourceQualification':False,'dockerExecuted':False,'sourceFilesChanged':False},indent=2)+'\n')
