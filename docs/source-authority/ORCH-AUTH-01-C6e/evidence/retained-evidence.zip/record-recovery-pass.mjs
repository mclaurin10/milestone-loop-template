import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
const root = process.cwd();
const evidence = resolve(root, "artifacts/wp6e-source-publication-20260906");
const hash = value => createHash("sha256").update(value).digest("hex");
const inspect = async name => {
  const bytes = await readFile(resolve(evidence, name, "result.json"));
  const receipt = JSON.parse(bytes.toString());
  assert.equal(receipt.status, "PASS");
  for (const file of receipt.artifacts) {
    const content = await readFile(resolve(evidence, name, file.path));
    assert.equal(content.length, file.bytes);
    assert.equal(hash(content), file.sha256);
  }
  return hash(bytes);
};
const focusedSha = await inspect("recovery-publication-focused-1");
const auditSha = await inspect("recovery-integration-audit-1");
assert.equal(focusedSha, "c99cd98be09949dfa54fe9dd093b04e1546b0efa67c34975b1a25fe66642c557");
const report = JSON.parse(await readFile(resolve(evidence, "recovery-integration-audit-1/report.json"), "utf8"));
assert.equal(report.tests, 203);
assert.equal(report.inputObservation.files, 650);
const path = resolve(root, ".agent/current-exec-plan.md");
const prior = await readFile(path);
assert.equal(hash(prior), "2037186cdd61718f17cb9f2de45f5348c0957f74c35800bf455bd960d3c86d6f");
await writeFile(resolve(evidence, "plan-consolidation/before-recovery-pass.md"), prior, { flag: "wx" });
const plan = `# Current Execution Plan

Status: C6e broader verification in progress. Updated: ${new Date().toISOString()}. Owner: authorized WP6e continuation.

## Objective

Complete compatible source readers, implementation audit, independent review and recoverable leased publication under approved ORCH-AUTH-01 r2. The migration CLI is the immediate public consumer. Commit the verified implementation, then continue the actual audit/request/review/activation and all remaining candidate/provider/mutation obligations. Do not stop at C6e when the next increment can proceed.

## Goal Constraints

Approved normative digest 53d38a2c2038cd9c5ffc240275043709d23dd33a81237e3d12018a38a8378108 is settled. Follow docs/proposals/ORCH-AUTH-01-r2/TRANSITION-CONTRACT.md. Approval is not activation. Preserve the original authorities, acceptance meanings, commissioning/amendment history, readiness marker/history and protected public argv/workflows. No implicit commit/reset, source controller initialization/adoption, generic pending override or deadline relaxation. Historical WP6e remains BLOCKED at e590e38c32de2b5baa7423f66bbd8a0230b61839. No WP6f interpretation. Root-unit success never establishes unit-domain success. Linux, native Windows, Server 2022, readiness and human acceptance remain distinct.

## Baseline Evidence

Primary HEAD/master/origin-master remains fc2419d8bdfc3658fe76edf2b543b38051b359f1, tree e8afdd61b47db88f4c6964b77c90ee8db9c1b4b1. Exact hosted run 34047573294 passed all five protected jobs; five archives/43 receipts were independently audited at hosted-fc2419d-audit-1, receipt 998b2bd13eb83fc2929720f8fa4a4009a7a218491e982d62d61136dcc547b377. This is parent evidence, not native workflow qualification. Preserve failed bb312f3 and 96abed9 cohorts and all earlier failures.

C4's inert snapshot is strict ancestor 91cbd3eb75ec771cfa1f315fe2641488e361c9e0. Legacy authority remains active. There is no actual source request, active intent, private state/ref, SDK service review or activation in the primary repository. C6e remains uncommitted.

The complete recovery-publication-focused-1 run ended 2026-09-06T22:44:58.621Z, exit 0: 203 PASS, zero failed/pending/todo/unhandled across nine complete files. Its receipt is ${focusedSha}. Independent recovery-integration-audit-1 passed, receipt ${auditSha}: all 650 frozen input files, exact index/patch, raw tests and receipt artifacts agree; all 107 prior focused identities remain. Both actual native invocations retain honest FAIL aggregates, completion false, and the correct full/focused scopes. Synthetic prerequisite/SDK inputs do not establish a real audit, review, activation or candidate execution.

## Steps

1. Complete: integrate strict source evidence/review/publication readers and private permit, held lease, twelve-output publication, durable command-owned export, committed consumers and state fencing. Add stable pre-intent retry, intent-write-gap recovery, fixed-packet export recovery and real native/tier consumer regressions. The complete 203-case run and exact frozen-input audit pass.
2. **In progress:** construct the clean owned precommit input from the recorded frozen bytes in .tools/wp6e-c6e-precommit-20260906. It is currently a clean parent clone. Any commit there is an isolated verification input, not a primary completion commit. Prepare its full and incremental Git bundles. Reuse the unchanged qualified C3 30-minute host policy for nine serial Linux precommit commands: typecheck, lint, format:check, lint:source-architecture, verify:source-dependencies, test:invariants, test:orchestrator, test:unit and consumed build. Keep original command/test deadlines; a host timeout remains a failure. Inspect launchers and exact cached inputs as data before invocation. Require real OCI admission, host/OCI/cleanup audits, all command receipts, exact code/test/config pins and raw identity reconciliation.
3. Complete and execute the retained evidence auditors and curation, preserving all failures, parent clean-postcommit observations, parent hosted results and frozen input reconstruction. Record actual broader results and commit the cohesive C6e implementation and documentation. Reproduce the retained audit and consumed build from the clean commit; obtain all five exact-commit hosted jobs. The subsequent real eight-command implementation audit also supplies fresh complete root coverage for that exact implementation.
4. Execute the real eight-command implementation audit from a clean owned checkout, separately commit the exact request and required evidence, obtain the fixed independent SDK review, publish under the existing lease/recoverable intent, verify consumer agreement and commit the complete activation. Preserve failed request/review clones and correct source through fresh exact requests when necessary. Do not initialize or adopt source state.
5. Qualify a fresh bounded candidate host whose lifecycle preserves the full 3,900,000 ms partition allowance. Run actual clean committed pnpm verify:candidate with documented changed paths; require all eleven scheduled checks, four independently validated partition receipts, raw exactly-once and historical identity reconciliation, no overlapping legacy commands, and the exact timeout reaching the actual execution provider. Execute isolated committed real-candidate 5(a) and 5(b) at the intended ownership and receipt boundaries, with no candidate PASS. Finish an independently audited post-commit acceptance matrix and preserve separate unfinished native/readiness/human gates.

## Acceptance Criteria

Readers agree on a complete authenticated committed source generation and refuse unknown, missing, mixed, pending and rolled-back publication. A separate committed request and actual fresh independent review precede the existing lease and exclusive fsynced active intent. Fault/concurrency tests reach actual boundaries. Recovery accepts only the same request and exact prior/new states, preserves foreign bytes and original/fresh review/lease provenance, and performs no implicit commit/reset/adoption. The complete source floor, four owners and original timeout meanings remain unchanged. Missing full qualification/readiness/human gates stay non-passing.

## Verification

Pin Windows PATH to .tools/node-v24.18.0-win-x64 (Node 24.18.0, pnpm 11.15.1), with --config.verify-deps-before-run=error. Same-checkout verification is sequential. Focused runs use docs/source-authority/ORCH-AUTH-01-C6b/run-focused.ts with complete explicit files and fresh output directories. Freeze executing source/test/config inputs during verification. Independently inspect actual receipt bytes/hashes, raw reports and failed runs. No visual change. Clean consumed production build and the original broad checks remain required.

The prepared retention-draft scripts are unexecuted: apply-precommit-input.mjs, prepare-precommit-source.mjs, prepare-precommit-vm.py, collect-precommit-vm.py, observe-precommit.ts, inspect-frozen-inputs.ts, audit.ts and curate.ps1. Their real execution, error handling and acceptance must be observed before any claim. The VM preparation is ordinary precommit evidence, not the eight-command implementation audit, candidate proof or 65-minute provider qualification.

## Risks and Recovery

All original publisher/test/public verification deadlines are unchanged. Only the newly introduced native consumer harness uses 300000ms supervised captures and 330000ms case bounds, after retaining its actual inadequate 90000ms baseline failure. Preserve that history. The fixed export packet describes the original physical publication; fresh recovery reviews, owners and appended events are independently retained without inventing history.

The archived WP6e criterion at lines 83-88, 304-308 and 562-565 requires actual dispatch propagation of 3,900,000 ms and retained evidence. It does not prescribe an idle expiration experiment. The C3 30-minute host cannot truncate this allowance in the later candidate proof; establish a separate longer finite host policy while retaining C3 unchanged. No shadow or metadata-only dispatch substitutes for actual candidate execution.

Use ordinary source control for recovery, with exact before hashes and preserved failed outputs. No codex.lab or shared package/service/account/clock/config changes. Preserve all existing stashes and the untracked roadmap, SHA256 53ea98fb1cb880163a02d3b1d9365963e3fe891025ae3630f00bd4c9232293b1, outside commits. Committed activation reversal requires another explicitly approved appended revision.

## Progress and Evidence

Evidence root: artifacts/wp6e-source-publication-20260906. Preserve all earlier runs and the three plan-consolidation snapshots. The latest snapshot before-recovery-pass.md has SHA256 ${hash(prior)}. Publication-focused-15 passed 107 (b7f838ec86af2b67f5db50841c9445cd92d511cb7dfbd8df7786294532e57016). Recovery-consumer-baseline-1 failed five of five; baseline-2 failed one of 90 (focused native purpose), both with no PASS receipt. Publication-focused-13's three original deadline failures remain failed. Final typecheck-26, lint-15 and architecture-focused-4 pass with independently checked artifacts. Broader precommit and actual migration/candidate obligations remain open.

Current ownership is 94 controller, five repository-tooling, two adopter-template and one OCI file: 102 catalogue entries, 101 root-selected files and 102 root-plus-OCI files. The complete ownership file passed in the 203-case run. No actual implementation audit/request, SDK service review, migration/activation, candidate or committed 5(a)/5(b) has run. Historical domain recording remains satisfied without promoting its stage to PASS.

## Next Action

Execute the exact frozen-input preparer in the clean owned clone, retain its input-only commit and bundles, inspect/execute the new task-local VM recipe, and collect independent host/OCI/cleanup and nine-command precommit evidence. Keep source/test/config bytes fixed; documentation and ignored preparation may proceed independently. Then seal, commit and continue the full authorized continuation.
`;
await writeFile(path, plan);
const logPath = resolve(root, "docs/autonomy-log.md");
const log = await readFile(logPath, "utf8");
assert(log.startsWith("# Autonomy Log\n"));
const entry = `\n## 2026-09-06 22:46 UTC — Complete C6e recovery/consumer regressions and frozen-input audit\n\nThe nine-file recovery-publication-focused-1 run completed at 22:44:58.621 UTC, exit 0: 203 PASS with zero failed/pending/todo/unhandled. Receipt ${focusedSha}. Independent recovery-integration-audit-1 passed (${auditSha}), rechecking every artifact, all 650 frozen input files, the exact retained index/patch, all raw tests and preservation of the prior 107 focused identities. Both native invocations remain honest non-passing aggregate observations with correct full/focused purposes and completion false. All six new recovery/export/foreign-byte cases and all original publication/committed-consumer cases passed at unchanged original deadlines. Earlier failures remain retained.\n\nThe plan is consolidated, with its exact prior bytes retained in plan-consolidation/before-recovery-pass.md. Prepared but unexecuted retention/VM scripts will construct a clean input commit in the owned parent clone, run the nine original applicable precommit commands under unchanged C3 host policy, and independently audit raw host/OCI/cleanup/command evidence. Primary C6e remains uncommitted and legacy authority remains active. Continue the real audit/request/SDK review/activation, candidate/four partitions/timeout propagation and committed 5(a)/5(b); no source state initialization/adoption or historical WP6e/WP6f claim.\n`;
await writeFile(logPath, "# Autonomy Log\n" + entry + log.slice("# Autonomy Log\n".length));
console.log(JSON.stringify({ focusedSha, auditSha, priorPlanSha256: hash(prior), planUpdated: true, primaryCommitCreated: false }));
