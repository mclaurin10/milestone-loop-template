"""Run the actual repaired dependency command and an owned corruption regression."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

repo=Path('/mnt/c/Dev/loop-extraction/milestone-loop-template')
receiver=repo/'artifacts/wp6e-source-publication-20260906/dependency-repair-linux-1'
assert os.getuid()==1000 and not receiver.exists()
receiver.mkdir()
(receiver/'executed-procedure.py').write_bytes(Path(__file__).read_bytes())
prior=repo/'artifacts/wp6e-source-publication-20260906/store-diagnostic-2'
root=Path((prior/'owned-root.txt').read_text().strip())
assert str(root)=='/home/duncan/c6e-store-diagnostic-0lb9ny6v' and root.resolve()==root
source=root/'source'
env=json.loads((prior/'environment.json').read_bytes())
pnpm=root/'bin/pnpm'
metadata=json.loads((repo/'artifacts/wp6e-source-publication-20260906/precommit-vm-3/input/source.json').read_bytes())
baseline={pin['path']:pin for pin in metadata['pins']}
hash=lambda value:hashlib.sha256(value).hexdigest()
paths=['tools/source-release-inspection.mjs','tools/milestone-orchestrator/src/source-authority-audit-reports.mjs','tools/milestone-orchestrator/test/synthetic-source-audit.ts','tools/milestone-orchestrator/src/source-authority-evidence.test.ts']
changes=[]
for path in paths:
    target=source/path
    assert target.resolve()==target and target.is_file() and target.stat().st_nlink==1
    before=target.read_bytes()
    after=(repo/path).read_bytes()
    assert len(before)==baseline[path]['bytes'] and hash(before)==baseline[path]['sha256']
    assert before!=after
    for name,value in [('before',before),('after',after)]:
        saved=receiver/name/path
        saved.parent.mkdir(parents=True,exist_ok=True)
        saved.write_bytes(value)
    target.write_bytes(after)
    assert target.read_bytes()==after
    changes.append({'path':path,'before':{'bytes':len(before),'sha256':hash(before)},'after':{'bytes':len(after),'sha256':hash(after)}})
(receiver/'source-delta.json').write_text(json.dumps({'baseline':metadata['source'],'changes':changes,'sourceWorkingTreeDirty':True,'actualImplementationAudit':False,'completionEligible':False},indent=2)+'\n')
records=[]
def run(name):
    directory=source/'artifacts'/('dependency-repair-'+name)
    assert not directory.exists()
    env['LOOP_VERIFY_COMMAND_ARTIFACT_DIR']=str(directory)
    argv=[str(pnpm),'--config.verify-deps-before-run=error','verify:source-dependencies']
    started=time.time_ns()
    monotonic=time.monotonic_ns()
    timed_out=False
    with (receiver/(name+'.stdout.log')).open('xb') as stdout,(receiver/(name+'.stderr.log')).open('xb') as stderr:
        process=subprocess.Popen(argv,cwd=source,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        try:code=process.wait(timeout=600)
        except subprocess.TimeoutExpired:
            timed_out=True
            os.killpg(process.pid,signal.SIGTERM)
            try:code=process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL)
                code=process.wait(timeout=5)
    record={'name':name,'argv':argv,'cwd':str(source),'uid':os.getuid(),'startedEpochNanoseconds':str(started),'durationMs':round((time.monotonic_ns()-monotonic)/1e6),'exitCode':code,'timedOut':timed_out}
    records.append(record)
    (receiver/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    shutil.copytree(directory,receiver/name)
    print(json.dumps(record),flush=True)
    assert not timed_out
    return code
assert run('intact')==0
target=source/'node_modules/.pnpm/esbuild@0.28.1/node_modules/esbuild/README.md'
assert target.resolve()==target and target.stat().st_nlink==1
original=target.read_bytes()
mutated=original+b'\nOwned dependency corruption regression.\n'
target.write_bytes(mutated)
try:
    assert run('corrupt')==1
    failure=json.loads((receiver/'corrupt/manifest.json').read_bytes())
    assert failure['status']=='ERROR' and failure['receipt'] is None
    assert 'Installed dependency bytes differ from frozen reference' in failure['failureClassification']['message']
    assert not (receiver/'corrupt/result.json').exists()
finally:
    assert target.read_bytes()==mutated, 'Foreign bytes preserved; refuse restoration'
    target.write_bytes(original)
    assert target.read_bytes()==original
(receiver/'corruption.json').write_text(json.dumps({'path':str(target),'original':{'bytes':len(original),'sha256':hash(original)},'mutated':{'bytes':len(mutated),'sha256':hash(mutated)},'restored':True,'sourceFilesChangedByCorruption':False},indent=2)+'\n')
(receiver/'observation.json').write_text(json.dumps({'commands':records,'delta':changes,'productionCommandExecuted':True,'workingTreeDirty':True,'actualImplementationAudit':False,'sourceQualification':False,'completionEligible':False},indent=2)+'\n')
