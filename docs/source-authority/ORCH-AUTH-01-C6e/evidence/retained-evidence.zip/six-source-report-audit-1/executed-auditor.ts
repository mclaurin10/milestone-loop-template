import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { readFile,writeFile } from 'node:fs/promises';
import { relative,resolve } from 'node:path';
import { evidenceContext,writeReceipt,writeManualEvidenceFailure } from '../../../tools/evidence.mjs';
import { SOURCE_AUDIT_COMMANDS,sourceHistoricalFiles } from '../../../tools/milestone-orchestrator/src/source-authority-evidence.mjs';
import { inspectSourceAuditReports } from '../../../tools/milestone-orchestrator/src/source-authority-audit-reports.mjs';
import { validateCommandReceiptDirectory } from '../../../tools/milestone-orchestrator/src/verifier.ts';
const root=resolve(import.meta.dirname,'../../..');
const evidence=resolve(root,'artifacts/wp6e-source-publication-20260906');
const output=resolve(evidence,'six-source-report-audit-1');
assert(!existsSync(output));
process.env.LOOP_VERIFY_COMMAND_ARTIFACT_DIR=output;
const context=await evidenceContext('orch-auth-01-c6e','six-completed-source-report-meanings');
try{
 const prepared=JSON.parse(await readFile(resolve(evidence,'precommit-linux-3/preparation.json'),'utf8'));
 const clone=resolve(root,'.tools/wp6e-c6e-precommit-20260906');
 const commandsRoot='\\\\wsl.localhost\\Ubuntu'+(prepared.root+'/source/artifacts/c6e-precommit').replaceAll('/','\\');
 const policyPath='tools/source-release-policy.json';
 const policy=JSON.parse(sourceHistoricalFiles(clone,prepared.source.commit,[policyPath]).get(policyPath)!.toString());
 const implementationFiles=sourceHistoricalFiles(clone,prepared.source.commit,[...new Set<string>([policyPath,...policy.payloadFiles,...policy.sourceCheckFiles,'tools/milestone-orchestrator/config/test-ownership.json','tools/milestone-orchestrator/config/invariant-suite.json','pnpm-lock.yaml','pnpm-workspace.yaml'])]);
 type Expected={stageId:string;commandId:string;requiredKinds?:string[]};
 const readReceipt=async(directory:string,expected:Expected)=>{
  const checked=await validateCommandReceiptDirectory({directory,expectedStageId:expected.stageId,expectedCommandId:expected.commandId,requiredKinds:expected.requiredKinds});
  const artifacts=new Map();
  for(const pin of checked.artifacts){const path=relative(directory,pin.path).replaceAll('\\','/');artifacts.set(path,{...pin,path,contents:await readFile(pin.path)});}
  const bytes=await readFile(checked.receiptPath);
  return {receipt:JSON.parse(bytes.toString()),bytes,sha256:checked.receiptSha256,artifacts};
 };
 const required=['typecheck','lint','format','architecture','dependencies','invariants'];
 const reports=new Map();const commands=[];
 for(const id of required){
  const expected=SOURCE_AUDIT_COMMANDS.find((row:{id:string})=>row.id===id)!;assert(expected);
  const directory=resolve(commandsRoot,id);const child=await readReceipt(directory,expected);
  const report=await inspectSourceAuditReports({expected,child,implementation:{commit:prepared.source.commit,tree:prepared.source.tree},runtime:{nodeVersion:'v24.18.0',pnpmVersion:'11.15.1',platform:'linux',architecture:'x64'},implementationFiles,readNestedReceipt:(prefix:string,nested:Expected)=>readReceipt(resolve(directory,prefix),nested)});
  reports.set(id,report);commands.push({id,receiptSha256:child.sha256});
 }
 assert.deepEqual(reports.get('architecture').packageGraph,reports.get('dependencies').packageGraph);
 await writeFile(resolve(output,'executed-auditor.ts'),await readFile(import.meta.filename));
 await writeFile(resolve(output,'report.json'),JSON.stringify({source:prepared.source,commands,productionReportMeanings:true,rootSuite:'PENDING',controllerSuite:'PENDING',build:'PENDING',actualImplementationAudit:false,completionEligible:false},null,2)+'\n');
 await writeReceipt(context,[{id:'six-actual-source-reports',summary:'Production readers independently validated the six completed actual Linux child report meanings against exact clean implementation Git objects. Controller, root unit, build and the real eight-command audit remain separate pending obligations.'}],[{path:'report.json',kind:'six-source-report-audit'},{path:'executed-auditor.ts',kind:'six-source-report-auditor'}]);
 const checked=await validateCommandReceiptDirectory({directory:output,expectedStageId:context.stageId,expectedCommandId:context.commandId,requiredKinds:['six-source-report-audit']});
 console.log(JSON.stringify({commands:commands.length,receiptSha256:checked.receiptSha256,completionEligible:false}));
}catch(error){await writeManualEvidenceFailure(context,{kind:'product',message:error instanceof Error?error.stack:String(error)});throw error;}
