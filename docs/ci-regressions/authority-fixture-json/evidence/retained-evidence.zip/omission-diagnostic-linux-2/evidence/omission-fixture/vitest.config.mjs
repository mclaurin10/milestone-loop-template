export default {
  test: {
    environment: "node",
    globals: true,
    include: ["representative.test.js"],
    passWithNoTests: false,
  },
};
