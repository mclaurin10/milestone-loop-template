describe("omission integration fixture", () => {
  it("representative kept", () => expect(true).toBe(true));
  it("representative omitted by mutation", () => expect(true).toBe(true));
});
